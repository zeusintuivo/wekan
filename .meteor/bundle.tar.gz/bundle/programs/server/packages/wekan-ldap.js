(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var slugify = Package['yasaricli:slugify'].slugify;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var SHA256 = Package.sha.SHA256;
var Accounts = Package['accounts-base'].Accounts;
var SyncedCron = Package['percolate:synced-cron'].SyncedCron;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"wekan-ldap":{"server":{"index.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan-ldap/server/index.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.link("./loginHandler");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ldap.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan-ldap/server/ldap.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  default: () => LDAP
});
let ldapjs;
module.link("ldapjs", {
  default(v) {
    ldapjs = v;
  }

}, 0);
let util;
module.link("util", {
  default(v) {
    util = v;
  }

}, 1);
let Bunyan;
module.link("bunyan", {
  default(v) {
    Bunyan = v;
  }

}, 2);
let log_debug, log_info, log_warn, log_error;
module.link("./logger", {
  log_debug(v) {
    log_debug = v;
  },

  log_info(v) {
    log_info = v;
  },

  log_warn(v) {
    log_warn = v;
  },

  log_error(v) {
    log_error = v;
  }

}, 3);

class LDAP {
  constructor() {
    this.ldapjs = ldapjs;
    this.connected = false;
    this.options = {
      host: this.constructor.settings_get('LDAP_HOST'),
      port: this.constructor.settings_get('LDAP_PORT'),
      Reconnect: this.constructor.settings_get('LDAP_RECONNECT'),
      timeout: this.constructor.settings_get('LDAP_TIMEOUT'),
      connect_timeout: this.constructor.settings_get('LDAP_CONNECT_TIMEOUT'),
      idle_timeout: this.constructor.settings_get('LDAP_IDLE_TIMEOUT'),
      encryption: this.constructor.settings_get('LDAP_ENCRYPTION'),
      ca_cert: this.constructor.settings_get('LDAP_CA_CERT'),
      reject_unauthorized: this.constructor.settings_get('LDAP_REJECT_UNAUTHORIZED') || false,
      Authentication: this.constructor.settings_get('LDAP_AUTHENTIFICATION'),
      Authentication_UserDN: this.constructor.settings_get('LDAP_AUTHENTIFICATION_USERDN'),
      Authentication_Password: this.constructor.settings_get('LDAP_AUTHENTIFICATION_PASSWORD'),
      Authentication_Fallback: this.constructor.settings_get('LDAP_LOGIN_FALLBACK'),
      BaseDN: this.constructor.settings_get('LDAP_BASEDN'),
      Internal_Log_Level: this.constructor.settings_get('INTERNAL_LOG_LEVEL'),
      User_Authentication: this.constructor.settings_get('LDAP_USER_AUTHENTICATION'),
      User_Authentication_Field: this.constructor.settings_get('LDAP_USER_AUTHENTICATION_FIELD'),
      User_Attributes: this.constructor.settings_get('LDAP_USER_ATTRIBUTES'),
      User_Search_Filter: this.constructor.settings_get('LDAP_USER_SEARCH_FILTER'),
      User_Search_Scope: this.constructor.settings_get('LDAP_USER_SEARCH_SCOPE'),
      User_Search_Field: this.constructor.settings_get('LDAP_USER_SEARCH_FIELD'),
      Search_Page_Size: this.constructor.settings_get('LDAP_SEARCH_PAGE_SIZE'),
      Search_Size_Limit: this.constructor.settings_get('LDAP_SEARCH_SIZE_LIMIT'),
      group_filter_enabled: this.constructor.settings_get('LDAP_GROUP_FILTER_ENABLE'),
      group_filter_object_class: this.constructor.settings_get('LDAP_GROUP_FILTER_OBJECTCLASS'),
      group_filter_group_id_attribute: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_ID_ATTRIBUTE'),
      group_filter_group_member_attribute: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_MEMBER_ATTRIBUTE'),
      group_filter_group_member_format: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_MEMBER_FORMAT'),
      group_filter_group_name: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_NAME')
    };
  }

  static settings_get(name) {
    let value = process.env[name];

    if (value !== undefined) {
      if (value === 'true' || value === 'false') {
        value = JSON.parse(value);
      } else if (value !== '' && !isNaN(value)) {
        value = Number(value);
      }

      return value;
    } else {
      log_warn("Lookup for unset variable: ".concat(name));
    }
  }

  connectSync() {
    if (!this._connectSync) {
      this._connectSync = Meteor.wrapAsync(this.connectAsync, this);
    }

    return this._connectSync(...arguments);
  }

  searchAllSync() {
    if (!this._searchAllSync) {
      this._searchAllSync = Meteor.wrapAsync(this.searchAllAsync, this);
    }

    return this._searchAllSync(...arguments);
  }

  connectAsync(callback) {
    log_info('Init setup');
    let replied = false;
    const connectionOptions = {
      url: "".concat(this.options.host, ":").concat(this.options.port),
      timeout: this.options.timeout,
      connectTimeout: this.options.connect_timeout,
      idleTimeout: this.options.idle_timeout,
      reconnect: this.options.Reconnect
    };

    if (this.options.Internal_Log_Level !== 'disabled') {
      connectionOptions.log = new Bunyan({
        name: 'ldapjs',
        component: 'client',
        stream: process.stderr,
        level: this.options.Internal_Log_Level
      });
    }

    const tlsOptions = {
      rejectUnauthorized: this.options.reject_unauthorized
    };

    if (this.options.ca_cert && this.options.ca_cert !== '') {
      // Split CA cert into array of strings
      const chainLines = this.constructor.settings_get('LDAP_CA_CERT').split('\n');
      let cert = [];
      const ca = [];
      chainLines.forEach(line => {
        cert.push(line);

        if (line.match(/-END CERTIFICATE-/)) {
          ca.push(cert.join('\n'));
          cert = [];
        }
      });
      tlsOptions.ca = ca;
    }

    if (this.options.encryption === 'ssl') {
      connectionOptions.url = "ldaps://".concat(connectionOptions.url);
      connectionOptions.tlsOptions = tlsOptions;
    } else {
      connectionOptions.url = "ldap://".concat(connectionOptions.url);
    }

    log_info('Connecting', connectionOptions.url);
    log_debug("connectionOptions".concat(util.inspect(connectionOptions)));
    this.client = ldapjs.createClient(connectionOptions);
    this.bindSync = Meteor.wrapAsync(this.client.bind, this.client);
    this.client.on('error', error => {
      log_error('connection', error);

      if (replied === false) {
        replied = true;
        callback(error, null);
      }
    });
    this.client.on('idle', () => {
      log_info('Idle');
      this.disconnect();
    });
    this.client.on('close', () => {
      log_info('Closed');
    });

    if (this.options.encryption === 'tls') {
      // Set host parameter for tls.connect which is used by ldapjs starttls. This shouldn't be needed in newer nodejs versions (e.g v5.6.0).
      // https://github.com/RocketChat/Rocket.Chat/issues/2035
      // https://github.com/mcavage/node-ldapjs/issues/349
      tlsOptions.host = this.options.host;
      log_info('Starting TLS');
      log_debug('tlsOptions', tlsOptions);
      this.client.starttls(tlsOptions, null, (error, response) => {
        if (error) {
          log_error('TLS connection', error);

          if (replied === false) {
            replied = true;
            callback(error, null);
          }

          return;
        }

        log_info('TLS connected');
        this.connected = true;

        if (replied === false) {
          replied = true;
          callback(null, response);
        }
      });
    } else {
      this.client.on('connect', response => {
        log_info('LDAP connected');
        this.connected = true;

        if (replied === false) {
          replied = true;
          callback(null, response);
        }
      });
    }

    setTimeout(() => {
      if (replied === false) {
        log_error('connection time out', connectionOptions.connectTimeout);
        replied = true;
        callback(new Error('Timeout'));
      }
    }, connectionOptions.connectTimeout);
  }

  getUserFilter(username) {
    const filter = [];

    if (this.options.User_Search_Filter !== '') {
      if (this.options.User_Search_Filter[0] === '(') {
        filter.push("".concat(this.options.User_Search_Filter));
      } else {
        filter.push("(".concat(this.options.User_Search_Filter, ")"));
      }
    }

    const usernameFilter = this.options.User_Search_Field.split(',').map(item => "(".concat(item, "=").concat(username, ")"));

    if (usernameFilter.length === 0) {
      log_error('LDAP_LDAP_User_Search_Field not defined');
    } else if (usernameFilter.length === 1) {
      filter.push("".concat(usernameFilter[0]));
    } else {
      filter.push("(|".concat(usernameFilter.join(''), ")"));
    }

    return "(&".concat(filter.join(''), ")");
  }

  bindUserIfNecessary(username, password) {
    if (this.domainBinded === true) {
      return;
    }

    if (!this.options.User_Authentication) {
      return;
    }

    if (!this.options.BaseDN) throw new Error('BaseDN is not provided');
    const userDn = "".concat(this.options.User_Authentication_Field, "=").concat(username, ",").concat(this.options.BaseDN);
    this.bindSync(userDn, password);
    this.domainBinded = true;
  }

  bindIfNecessary() {
    if (this.domainBinded === true) {
      return;
    }

    if (this.options.Authentication !== true) {
      return;
    }

    log_info('Binding UserDN', this.options.Authentication_UserDN);
    this.bindSync(this.options.Authentication_UserDN, this.options.Authentication_Password);
    this.domainBinded = true;
  }

  searchUsersSync(username, page) {
    this.bindIfNecessary();
    const searchOptions = {
      filter: this.getUserFilter(username),
      scope: this.options.User_Search_Scope || 'sub',
      sizeLimit: this.options.Search_Size_Limit
    };
    if (!!this.options.User_Attributes) searchOptions.attributes = this.options.User_Attributes.split(',');

    if (this.options.Search_Page_Size > 0) {
      searchOptions.paged = {
        pageSize: this.options.Search_Page_Size,
        pagePause: !!page
      };
    }

    log_info('Searching user', username);
    log_debug('searchOptions', searchOptions);
    log_debug('BaseDN', this.options.BaseDN);

    if (page) {
      return this.searchAllPaged(this.options.BaseDN, searchOptions, page);
    }

    return this.searchAllSync(this.options.BaseDN, searchOptions);
  }

  getUserByIdSync(id, attribute) {
    this.bindIfNecessary();
    const Unique_Identifier_Field = this.constructor.settings_get('LDAP_UNIQUE_IDENTIFIER_FIELD').split(',');
    let filter;

    if (attribute) {
      filter = new this.ldapjs.filters.EqualityFilter({
        attribute,
        value: Buffer.from(id, 'hex')
      });
    } else {
      const filters = [];
      Unique_Identifier_Field.forEach(item => {
        filters.push(new this.ldapjs.filters.EqualityFilter({
          attribute: item,
          value: Buffer.from(id, 'hex')
        }));
      });
      filter = new this.ldapjs.filters.OrFilter({
        filters
      });
    }

    const searchOptions = {
      filter,
      scope: 'sub'
    };
    log_info('Searching by id', id);
    log_debug('search filter', searchOptions.filter.toString());
    log_debug('BaseDN', this.options.BaseDN);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return;
    }

    if (result.length > 1) {
      log_error('Search by id', id, 'returned', result.length, 'records');
    }

    return result[0];
  }

  getUserByUsernameSync(username) {
    this.bindIfNecessary();
    const searchOptions = {
      filter: this.getUserFilter(username),
      scope: this.options.User_Search_Scope || 'sub'
    };
    log_info('Searching user', username);
    log_debug('searchOptions', searchOptions);
    log_debug('BaseDN', this.options.BaseDN);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return;
    }

    if (result.length > 1) {
      log_error('Search by username', username, 'returned', result.length, 'records');
    }

    return result[0];
  }

  getUserGroups(username, ldapUser) {
    if (!this.options.group_filter_enabled) {
      return true;
    }

    const filter = ['(&'];

    if (this.options.group_filter_object_class !== '') {
      filter.push("(objectclass=".concat(this.options.group_filter_object_class, ")"));
    }

    if (this.options.group_filter_group_member_attribute !== '') {
      const format_value = ldapUser[this.options.group_filter_group_member_format];

      if (format_value) {
        filter.push("(".concat(this.options.group_filter_group_member_attribute, "=").concat(format_value, ")"));
      }
    }

    filter.push(')');
    const searchOptions = {
      filter: filter.join('').replace(/#{username}/g, username),
      scope: 'sub'
    };
    log_debug('Group list filter LDAP:', searchOptions.filter);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return [];
    }

    const grp_identifier = this.options.group_filter_group_id_attribute || 'cn';
    const groups = [];
    result.map(item => {
      groups.push(item[grp_identifier]);
    });
    log_debug("Groups: ".concat(groups.join(', ')));
    return groups;
  }

  isUserInGroup(username, ldapUser) {
    if (!this.options.group_filter_enabled) {
      return true;
    }

    const grps = this.getUserGroups(username, ldapUser);
    const filter = ['(&'];

    if (this.options.group_filter_object_class !== '') {
      filter.push("(objectclass=".concat(this.options.group_filter_object_class, ")"));
    }

    if (this.options.group_filter_group_member_attribute !== '') {
      const format_value = ldapUser[this.options.group_filter_group_member_format];

      if (format_value) {
        filter.push("(".concat(this.options.group_filter_group_member_attribute, "=").concat(format_value, ")"));
      }
    }

    if (this.options.group_filter_group_id_attribute !== '') {
      filter.push("(".concat(this.options.group_filter_group_id_attribute, "=").concat(this.options.group_filter_group_name, ")"));
    }

    filter.push(')');
    const searchOptions = {
      filter: filter.join('').replace(/#{username}/g, username),
      scope: 'sub'
    };
    log_debug('Group filter LDAP:', searchOptions.filter);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return false;
    }

    return true;
  }

  extractLdapEntryData(entry) {
    const values = {
      _raw: entry.raw
    };
    Object.keys(values._raw).forEach(key => {
      const value = values._raw[key];

      if (!['thumbnailPhoto', 'jpegPhoto'].includes(key)) {
        if (value instanceof Buffer) {
          values[key] = value.toString();
        } else {
          values[key] = value;
        }
      }
    });
    return values;
  }

  searchAllPaged(BaseDN, options, page) {
    this.bindIfNecessary();

    const processPage = (_ref) => {
      let {
        entries,
        title,
        end,
        next
      } = _ref;
      log_info(title); // Force LDAP idle to wait the record processing

      this.client._updateIdle(true);

      page(null, entries, {
        end,
        next: () => {
          // Reset idle timer
          this.client._updateIdle();

          next && next();
        }
      });
    };

    this.client.search(BaseDN, options, (error, res) => {
      if (error) {
        log_error(error);
        page(error);
        return;
      }

      res.on('error', error => {
        log_error(error);
        page(error);
        return;
      });
      let entries = [];
      const internalPageSize = options.paged && options.paged.pageSize > 0 ? options.paged.pageSize * 2 : 500;
      res.on('searchEntry', entry => {
        entries.push(this.extractLdapEntryData(entry));

        if (entries.length >= internalPageSize) {
          processPage({
            entries,
            title: 'Internal Page',
            end: false
          });
          entries = [];
        }
      });
      res.on('page', (result, next) => {
        if (!next) {
          this.client._updateIdle(true);

          processPage({
            entries,
            title: 'Final Page',
            end: true
          });
        } else if (entries.length) {
          log_info('Page');
          processPage({
            entries,
            title: 'Page',
            end: false,
            next
          });
          entries = [];
        }
      });
      res.on('end', () => {
        if (entries.length) {
          processPage({
            entries,
            title: 'Final Page',
            end: true
          });
          entries = [];
        }
      });
    });
  }

  searchAllAsync(BaseDN, options, callback) {
    this.bindIfNecessary();
    this.client.search(BaseDN, options, (error, res) => {
      if (error) {
        log_error(error);
        callback(error);
        return;
      }

      res.on('error', error => {
        log_error(error);
        callback(error);
        return;
      });
      const entries = [];
      res.on('searchEntry', entry => {
        entries.push(this.extractLdapEntryData(entry));
      });
      res.on('end', () => {
        log_info('Search result count', entries.length);
        callback(null, entries);
      });
    });
  }

  authSync(dn, password) {
    log_info('Authenticating', dn);

    try {
      if (password === '') {
        throw new Error('Password is not provided');
      }

      this.bindSync(dn, password);
      log_info('Authenticated', dn);
      return true;
    } catch (error) {
      log_info('Not authenticated', dn);
      log_debug('error', error);
      return false;
    }
  }

  disconnect() {
    this.connected = false;
    this.domainBinded = false;
    log_info('Disconecting');
    this.client.unbind();
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logger.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan-ldap/server/logger.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  log: () => log,
  log_debug: () => log_debug,
  log_info: () => log_info,
  log_warn: () => log_warn,
  log_error: () => log_error
});
const isLogEnabled = process.env.LDAP_LOG_ENABLED === 'true';

function log(level, message, data) {
  if (isLogEnabled) {
    console.log("[".concat(level, "] ").concat(message, " ").concat(data ? JSON.stringify(data, null, 2) : ''));
  }
}

function log_debug() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  log('DEBUG', ...args);
}

function log_info() {
  for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    args[_key2] = arguments[_key2];
  }

  log('INFO', ...args);
}

function log_warn() {
  for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    args[_key3] = arguments[_key3];
  }

  log('WARN', ...args);
}

function log_error() {
  for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
    args[_key4] = arguments[_key4];
  }

  log('ERROR', ...args);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginHandler.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan-ldap/server/loginHandler.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let slug, getLdapUsername, getLdapEmail, getLdapUserUniqueID, syncUserData, addLdapUser;
module.link("./sync", {
  slug(v) {
    slug = v;
  },

  getLdapUsername(v) {
    getLdapUsername = v;
  },

  getLdapEmail(v) {
    getLdapEmail = v;
  },

  getLdapUserUniqueID(v) {
    getLdapUserUniqueID = v;
  },

  syncUserData(v) {
    syncUserData = v;
  },

  addLdapUser(v) {
    addLdapUser = v;
  }

}, 0);
let LDAP;
module.link("./ldap", {
  default(v) {
    LDAP = v;
  }

}, 1);
let log_debug, log_info, log_warn, log_error;
module.link("./logger", {
  log_debug(v) {
    log_debug = v;
  },

  log_info(v) {
    log_info = v;
  },

  log_warn(v) {
    log_warn = v;
  },

  log_error(v) {
    log_error = v;
  }

}, 2);

function fallbackDefaultAccountSystem(bind, username, password) {
  if (typeof username === 'string') {
    if (username.indexOf('@') === -1) {
      username = {
        username
      };
    } else {
      username = {
        email: username
      };
    }
  }

  log_info('Fallback to default account system: ', username);
  const loginRequest = {
    user: username,
    password: {
      digest: SHA256(password),
      algorithm: 'sha-256'
    }
  };
  log_debug('Fallback options: ', loginRequest);
  return Accounts._runLoginHandlers(bind, loginRequest);
}

Accounts.registerLoginHandler('ldap', function (loginRequest) {
  if (!loginRequest.ldap || !loginRequest.ldapOptions) {
    return undefined;
  }

  log_info('Init LDAP login', loginRequest.username);

  if (LDAP.settings_get('LDAP_ENABLE') !== true) {
    return fallbackDefaultAccountSystem(this, loginRequest.username, loginRequest.ldapPass);
  }

  const self = this;
  const ldap = new LDAP();
  let ldapUser;

  try {
    ldap.connectSync();

    if (!!LDAP.settings_get('LDAP_USER_AUTHENTICATION')) {
      ldap.bindUserIfNecessary(loginRequest.username, loginRequest.ldapPass);
      ldapUser = ldap.searchUsersSync(loginRequest.username)[0];
    } else {
      const users = ldap.searchUsersSync(loginRequest.username);

      if (users.length !== 1) {
        log_info('Search returned', users.length, 'record(s) for', loginRequest.username);
        throw new Error('User not Found');
      }

      if (ldap.authSync(users[0].dn, loginRequest.ldapPass) === true) {
        if (ldap.isUserInGroup(loginRequest.username, users[0])) {
          ldapUser = users[0];
        } else {
          throw new Error('User not in a valid group');
        }
      } else {
        log_info('Wrong password for', loginRequest.username);
      }
    }
  } catch (error) {
    log_error(error);
  }

  if (!ldapUser) {
    if (LDAP.settings_get('LDAP_LOGIN_FALLBACK') === true) {
      return fallbackDefaultAccountSystem(self, loginRequest.username, loginRequest.ldapPass);
    }

    throw new Meteor.Error('LDAP-login-error', "LDAP Authentication failed with provided username [".concat(loginRequest.username, "]"));
  } // Look to see if user already exists


  let userQuery;
  const Unique_Identifier_Field = getLdapUserUniqueID(ldapUser);
  let user; // Attempt to find user by unique identifier

  if (Unique_Identifier_Field) {
    userQuery = {
      'services.ldap.id': Unique_Identifier_Field.value
    };
    log_info('Querying user');
    log_debug('userQuery', userQuery);
    user = Meteor.users.findOne(userQuery);
  } // Attempt to find user by username


  let username;
  let email;

  if (LDAP.settings_get('LDAP_USERNAME_FIELD') !== '') {
    username = slug(getLdapUsername(ldapUser));
  } else {
    username = slug(loginRequest.username);
  }

  if (LDAP.settings_get('LDAP_EMAIL_FIELD') !== '') {
    email = getLdapEmail(ldapUser);
  }

  if (!user) {
    if (email && LDAP.settings_get('LDAP_EMAIL_MATCH_REQUIRE') === true) {
      if (LDAP.settings_get('LDAP_EMAIL_MATCH_VERIFIED') === true) {
        userQuery = {
          '_id': username,
          'emails.0.address': email,
          'emails.0.verified': true
        };
      } else {
        userQuery = {
          '_id': username,
          'emails.0.address': email
        };
      }
    } else {
      userQuery = {
        username
      };
    }

    log_debug('userQuery', userQuery);
    user = Meteor.users.findOne(userQuery);
  } // Attempt to find user by e-mail address only


  if (!user && email && LDAP.settings_get('LDAP_EMAIL_MATCH_ENABLE') === true) {
    log_info('No user exists with username', username, '- attempting to find by e-mail address instead');

    if (LDAP.settings_get('LDAP_EMAIL_MATCH_VERIFIED') === true) {
      userQuery = {
        'emails.0.address': email,
        'emails.0.verified': true
      };
    } else {
      userQuery = {
        'emails.0.address': email
      };
    }

    log_debug('userQuery', userQuery);
    user = Meteor.users.findOne(userQuery);
  } // Login user if they exist


  if (user) {
    if (user.authenticationMethod !== 'ldap' && LDAP.settings_get('LDAP_MERGE_EXISTING_USERS') !== true) {
      log_info('User exists without "authenticationMethod : ldap"');
      throw new Meteor.Error('LDAP-login-error', "LDAP Authentication succeded, but there's already a matching Wekan account in MongoDB");
    }

    log_info('Logging user');

    const stampedToken = Accounts._generateStampedLoginToken();

    const update_data = {
      $push: {
        'services.resume.loginTokens': Accounts._hashStampedToken(stampedToken)
      }
    };

    if (LDAP.settings_get('LDAP_SYNC_ADMIN_STATUS') === true) {
      log_debug('Updating admin status');
      const targetGroups = LDAP.settings_get('LDAP_SYNC_ADMIN_GROUPS').split(',');
      const groups = ldap.getUserGroups(username, ldapUser).filter(value => targetGroups.includes(value));
      user.isAdmin = groups.length > 0;
      Meteor.users.update({
        _id: user._id
      }, {
        $set: {
          isAdmin: user.isAdmin
        }
      });
    }

    if (LDAP.settings_get('LDAP_SYNC_GROUP_ROLES') === true) {
      log_debug('Updating Groups/Roles');
      const groups = ldap.getUserGroups(username, ldapUser);

      if (groups.length > 0) {
        Roles.setUserRoles(user._id, groups);
        log_info("Updated roles to:".concat(groups.join(',')));
      }
    }

    Meteor.users.update(user._id, update_data);
    syncUserData(user, ldapUser);

    if (LDAP.settings_get('LDAP_LOGIN_FALLBACK') === true) {
      Accounts.setPassword(user._id, loginRequest.ldapPass, {
        logout: false
      });
    }

    return {
      userId: user._id,
      token: stampedToken.token
    };
  } // Create new user


  log_info('User does not exist, creating', username);

  if (LDAP.settings_get('LDAP_USERNAME_FIELD') === '') {
    username = undefined;
  }

  if (LDAP.settings_get('LDAP_LOGIN_FALLBACK') !== true) {
    loginRequest.ldapPass = undefined;
  }

  const result = addLdapUser(ldapUser, username, loginRequest.ldapPass);

  if (LDAP.settings_get('LDAP_SYNC_ADMIN_STATUS') === true) {
    log_debug('Updating admin status');
    const targetGroups = LDAP.settings_get('LDAP_SYNC_ADMIN_GROUPS').split(',');
    const groups = ldap.getUserGroups(username, ldapUser).filter(value => targetGroups.includes(value));
    result.isAdmin = groups.length > 0;
    Meteor.users.update({
      _id: result.userId
    }, {
      $set: {
        isAdmin: result.isAdmin
      }
    });
  }

  if (LDAP.settings_get('LDAP_SYNC_GROUP_ROLES') === true) {
    const groups = ldap.getUserGroups(username, ldapUser);

    if (groups.length > 0) {
      Roles.setUserRoles(result.userId, groups);
      log_info("Set roles to:".concat(groups.join(',')));
    }
  }

  if (result instanceof Error) {
    throw result;
  }

  return result;
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sync.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan-ldap/server/sync.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  slug: () => slug,
  getPropertyValue: () => getPropertyValue,
  getLdapUsername: () => getLdapUsername,
  getLdapEmail: () => getLdapEmail,
  getLdapFullname: () => getLdapFullname,
  getLdapUserUniqueID: () => getLdapUserUniqueID,
  getDataToSyncUserData: () => getDataToSyncUserData,
  syncUserData: () => syncUserData,
  addLdapUser: () => addLdapUser,
  importNewUsers: () => importNewUsers
});

let _;

module.link("underscore", {
  default(v) {
    _ = v;
  }

}, 0);
let SyncedCron;
module.link("meteor/percolate:synced-cron", {
  default(v) {
    SyncedCron = v;
  }

}, 1);
let LDAP;
module.link("./ldap", {
  default(v) {
    LDAP = v;
  }

}, 2);
let log_debug, log_info, log_warn, log_error;
module.link("./logger", {
  log_debug(v) {
    log_debug = v;
  },

  log_info(v) {
    log_info = v;
  },

  log_warn(v) {
    log_warn = v;
  },

  log_error(v) {
    log_error = v;
  }

}, 3);
Object.defineProperty(Object.prototype, "getLDAPValue", {
  value: function (prop) {
    const self = this;

    for (let key in self) {
      if (key.toLowerCase() == prop.toLowerCase()) {
        return self[key];
      }
    }
  },
  enumerable: false
});

function slug(text) {
  if (LDAP.settings_get('LDAP_UTF8_NAMES_SLUGIFY') !== true) {
    return text;
  }

  text = slugify(text, '.');
  return text.replace(/[^0-9a-z-_.]/g, '');
}

function templateVarHandler(variable, object) {
  const templateRegex = /#{([\w\-]+)}/gi;
  let match = templateRegex.exec(variable);
  let tmpVariable = variable;

  if (match == null) {
    if (!object.hasOwnProperty(variable)) {
      return;
    }

    return object[variable];
  } else {
    while (match != null) {
      const tmplVar = match[0];
      const tmplAttrName = match[1];

      if (!object.hasOwnProperty(tmplAttrName)) {
        return;
      }

      const attrVal = object[tmplAttrName];
      tmpVariable = tmpVariable.replace(tmplVar, attrVal);
      match = templateRegex.exec(variable);
    }

    return tmpVariable;
  }
}

function getPropertyValue(obj, key) {
  try {
    return _.reduce(key.split('.'), (acc, el) => acc[el], obj);
  } catch (err) {
    return undefined;
  }
}

function getLdapUsername(ldapUser) {
  const usernameField = LDAP.settings_get('LDAP_USERNAME_FIELD');

  if (usernameField.indexOf('#{') > -1) {
    return usernameField.replace(/#{(.+?)}/g, function (match, field) {
      return ldapUser.getLDAPValue(field);
    });
  }

  return ldapUser.getLDAPValue(usernameField);
}

function getLdapEmail(ldapUser) {
  const emailField = LDAP.settings_get('LDAP_EMAIL_FIELD');

  if (emailField.indexOf('#{') > -1) {
    return emailField.replace(/#{(.+?)}/g, function (match, field) {
      return ldapUser.getLDAPValue(field);
    });
  }

  return ldapUser.getLDAPValue(emailField);
}

function getLdapFullname(ldapUser) {
  const fullnameField = LDAP.settings_get('LDAP_FULLNAME_FIELD');

  if (fullnameField.indexOf('#{') > -1) {
    return fullnameField.replace(/#{(.+?)}/g, function (match, field) {
      return ldapUser.getLDAPValue(field);
    });
  }

  return ldapUser.getLDAPValue(fullnameField);
}

function getLdapUserUniqueID(ldapUser) {
  let Unique_Identifier_Field = LDAP.settings_get('LDAP_UNIQUE_IDENTIFIER_FIELD');

  if (Unique_Identifier_Field !== '') {
    Unique_Identifier_Field = Unique_Identifier_Field.replace(/\s/g, '').split(',');
  } else {
    Unique_Identifier_Field = [];
  }

  let User_Search_Field = LDAP.settings_get('LDAP_USER_SEARCH_FIELD');

  if (User_Search_Field !== '') {
    User_Search_Field = User_Search_Field.replace(/\s/g, '').split(',');
  } else {
    User_Search_Field = [];
  }

  Unique_Identifier_Field = Unique_Identifier_Field.concat(User_Search_Field);

  if (Unique_Identifier_Field.length > 0) {
    Unique_Identifier_Field = Unique_Identifier_Field.find(field => {
      return !_.isEmpty(ldapUser._raw.getLDAPValue(field));
    });

    if (Unique_Identifier_Field) {
      log_debug("Identifying user with: ".concat(Unique_Identifier_Field));
      Unique_Identifier_Field = {
        attribute: Unique_Identifier_Field,
        value: ldapUser._raw.getLDAPValue(Unique_Identifier_Field).toString('hex')
      };
    }

    return Unique_Identifier_Field;
  }
}

function getDataToSyncUserData(ldapUser, user) {
  const syncUserData = LDAP.settings_get('LDAP_SYNC_USER_DATA');
  const syncUserDataFieldMap = LDAP.settings_get('LDAP_SYNC_USER_DATA_FIELDMAP').trim();
  const userData = {};

  if (syncUserData && syncUserDataFieldMap) {
    const whitelistedUserFields = ['email', 'name', 'customFields'];
    const fieldMap = JSON.parse(syncUserDataFieldMap);
    const emailList = [];

    _.map(fieldMap, function (userField, ldapField) {
      log_debug("Mapping field ".concat(ldapField, " -> ").concat(userField));

      switch (userField) {
        case 'email':
          if (!ldapUser.hasOwnProperty(ldapField)) {
            log_debug("user does not have attribute: ".concat(ldapField));
            return;
          }

          if (_.isObject(ldapUser[ldapField])) {
            _.map(ldapUser[ldapField], function (item) {
              emailList.push({
                address: item,
                verified: true
              });
            });
          } else {
            emailList.push({
              address: ldapUser[ldapField],
              verified: true
            });
          }

          break;

        default:
          const [outerKey, innerKeys] = userField.split(/\.(.+)/);

          if (!_.find(whitelistedUserFields, el => el === outerKey)) {
            log_debug("user attribute not whitelisted: ".concat(userField));
            return;
          }

          if (outerKey === 'customFields') {
            let customFieldsMeta;

            try {
              customFieldsMeta = JSON.parse(LDAP.settings_get('Accounts_CustomFields'));
            } catch (e) {
              log_debug('Invalid JSON for Custom Fields');
              return;
            }

            if (!getPropertyValue(customFieldsMeta, innerKeys)) {
              log_debug("user attribute does not exist: ".concat(userField));
              return;
            }
          }

          const tmpUserField = getPropertyValue(user, userField);
          const tmpLdapField = templateVarHandler(ldapField, ldapUser);

          if (tmpLdapField && tmpUserField !== tmpLdapField) {
            // creates the object structure instead of just assigning 'tmpLdapField' to
            // 'userData[userField]' in order to avoid the "cannot use the part (...)
            // to traverse the element" (MongoDB) error that can happen. Do not handle
            // arrays.
            // TODO: Find a better solution.
            const dKeys = userField.split('.');

            const lastKey = _.last(dKeys);

            _.reduce(dKeys, (obj, currKey) => currKey === lastKey ? obj[currKey] = tmpLdapField : obj[currKey] = obj[currKey] || {}, userData);

            log_debug("user.".concat(userField, " changed to: ").concat(tmpLdapField));
          }

      }
    });

    if (emailList.length > 0) {
      if (JSON.stringify(user.emails) !== JSON.stringify(emailList)) {
        userData.emails = emailList;
      }
    }
  }

  const uniqueId = getLdapUserUniqueID(ldapUser);

  if (uniqueId && (!user.services || !user.services.ldap || user.services.ldap.id !== uniqueId.value || user.services.ldap.idAttribute !== uniqueId.attribute)) {
    userData['services.ldap.id'] = uniqueId.value;
    userData['services.ldap.idAttribute'] = uniqueId.attribute;
  }

  if (user.authenticationMethod !== 'ldap') {
    userData.ldap = true;
  }

  if (_.size(userData)) {
    return userData;
  }
}

function syncUserData(user, ldapUser) {
  log_info('Syncing user data');
  log_debug('user', {
    'email': user.email,
    '_id': user._id
  }); // log_debug('ldapUser', ldapUser.object);

  if (LDAP.settings_get('LDAP_USERNAME_FIELD') !== '') {
    const username = slug(getLdapUsername(ldapUser));

    if (user && user._id && username !== user.username) {
      log_info('Syncing user username', user.username, '->', username);
      Meteor.users.findOne({
        _id: user._id
      }, {
        $set: {
          username
        }
      });
    }
  }

  if (LDAP.settings_get('LDAP_FULLNAME_FIELD') !== '') {
    const fullname = getLdapFullname(ldapUser);
    log_debug('fullname=', fullname);

    if (user && user._id && fullname !== '') {
      log_info('Syncing user fullname:', fullname);
      Meteor.users.update({
        _id: user._id
      }, {
        $set: {
          'profile.fullname': fullname
        }
      });
    }
  }

  if (LDAP.settings_get('LDAP_EMAIL_FIELD') !== '') {
    const email = getLdapEmail(ldapUser);
    log_debug('email=', email);

    if (user && user._id && email !== '') {
      log_info('Syncing user email:', email);
      Meteor.users.update({
        _id: user._id
      }, {
        $set: {
          'emails.0.address': email
        }
      });
    }
  }
}

function addLdapUser(ldapUser, username, password) {
  const uniqueId = getLdapUserUniqueID(ldapUser);
  const userObject = {};

  if (username) {
    userObject.username = username;
  }

  const userData = getDataToSyncUserData(ldapUser, {});

  if (userData && userData.emails && userData.emails[0] && userData.emails[0].address) {
    if (Array.isArray(userData.emails[0].address)) {
      userObject.email = userData.emails[0].address[0];
    } else {
      userObject.email = userData.emails[0].address;
    }
  } else if (ldapUser.mail && ldapUser.mail.indexOf('@') > -1) {
    userObject.email = ldapUser.mail;
  } else if (LDAP.settings_get('LDAP_DEFAULT_DOMAIN') !== '') {
    userObject.email = "".concat(username || uniqueId.value, "@").concat(LDAP.settings_get('LDAP_DEFAULT_DOMAIN'));
  } else {
    const error = new Meteor.Error('LDAP-login-error', 'LDAP Authentication succeded, there is no email to create an account. Have you tried setting your Default Domain in LDAP Settings?');
    log_error(error);
    throw error;
  }

  log_debug('New user data', userObject);

  if (password) {
    userObject.password = password;
  }

  try {
    // This creates the account with password service
    userObject.ldap = true;
    userObject._id = Accounts.createUser(userObject); // Add the services.ldap identifiers

    Meteor.users.update({
      _id: userObject._id
    }, {
      $set: {
        'services.ldap': {
          id: uniqueId.value
        },
        'emails.0.verified': true,
        'authenticationMethod': 'ldap'
      }
    });
  } catch (error) {
    log_error('Error creating user', error);
    return error;
  }

  syncUserData(userObject, ldapUser);
  return {
    userId: userObject._id
  };
}

function importNewUsers(ldap) {
  if (LDAP.settings_get('LDAP_ENABLE') !== true) {
    log_error('Can\'t run LDAP Import, LDAP is disabled');
    return;
  }

  if (!ldap) {
    ldap = new LDAP();
    ldap.connectSync();
  }

  let count = 0;
  ldap.searchUsersSync('*', Meteor.bindEnvironment(function (error, ldapUsers) {
    let {
      next,
      end
    } = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    if (error) {
      throw error;
    }

    ldapUsers.forEach(ldapUser => {
      count++;
      const uniqueId = getLdapUserUniqueID(ldapUser); // Look to see if user already exists

      const userQuery = {
        'services.ldap.id': uniqueId.value
      };
      log_debug('userQuery', userQuery);
      let username;

      if (LDAP.settings_get('LDAP_USERNAME_FIELD') !== '') {
        username = slug(getLdapUsername(ldapUser));
      } // Add user if it was not added before


      let user = Meteor.users.findOne(userQuery);

      if (!user && username && LDAP.settings_get('LDAP_MERGE_EXISTING_USERS') === true) {
        const userQuery = {
          username
        };
        log_debug('userQuery merge', userQuery);
        user = Meteor.users.findOne(userQuery);

        if (user) {
          syncUserData(user, ldapUser);
        }
      }

      if (!user) {
        addLdapUser(ldapUser, username);
      }

      if (count % 100 === 0) {
        log_info('Import running. Users imported until now:', count);
      }
    });

    if (end) {
      log_info('Import finished. Users imported:', count);
    }

    next(count);
  }));
}

function sync() {
  if (LDAP.settings_get('LDAP_ENABLE') !== true) {
    return;
  }

  const ldap = new LDAP();

  try {
    ldap.connectSync();
    let users;

    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_KEEP_EXISTANT_USERS_UPDATED') === true) {
      users = Meteor.users.find({
        'services.ldap': {
          $exists: true
        }
      });
    }

    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_IMPORT_NEW_USERS') === true) {
      importNewUsers(ldap);
    }

    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_KEEP_EXISTANT_USERS_UPDATED') === true) {
      users.forEach(function (user) {
        let ldapUser;

        if (user.services && user.services.ldap && user.services.ldap.id) {
          ldapUser = ldap.getUserByIdSync(user.services.ldap.id, user.services.ldap.idAttribute);
        } else {
          ldapUser = ldap.getUserByUsernameSync(user.username);
        }

        if (ldapUser) {
          syncUserData(user, ldapUser);
        } else {
          log_info('Can\'t sync user', user.username);
        }
      });
    }
  } catch (error) {
    log_error(error);
    return error;
  }

  return true;
}

const jobName = 'LDAP_Sync';

const addCronJob = _.debounce(Meteor.bindEnvironment(function addCronJobDebounced() {
  let sc = SyncedCron.SyncedCron; //Why ?? something must be wrong in the import

  if (LDAP.settings_get('LDAP_BACKGROUND_SYNC') !== true) {
    log_info('Disabling LDAP Background Sync');

    if (sc.nextScheduledAtDate(jobName)) {
      sc.remove(jobName);
    }

    return;
  }

  log_info('Enabling LDAP Background Sync');
  sc.add({
    name: jobName,
    schedule: function (parser) {
      if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_INTERVAL')) {
        return parser.text(LDAP.settings_get('LDAP_BACKGROUND_SYNC_INTERVAL'));
      } else {
        return parser.recur().on(0).minute();
      }
    },
    job: function () {
      sync();
    }
  });
  sc.start();
}), 500);

Meteor.startup(() => {
  Meteor.defer(() => {
    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC')) {
      addCronJob();
    }
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"ldapjs":{"package.json":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/wekan-ldap/node_modules/ldapjs/package.json                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exports = {
  "name": "ldapjs",
  "version": "1.0.2",
  "main": "lib/index.js"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/wekan-ldap/node_modules/ldapjs/lib/index.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.useNode();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"bunyan":{"package.json":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/wekan-ldap/node_modules/bunyan/package.json                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exports = {
  "name": "bunyan",
  "version": "1.8.14",
  "main": "./lib/bunyan.js"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"bunyan.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/wekan-ldap/node_modules/bunyan/lib/bunyan.js                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.useNode();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/wekan-ldap/server/index.js");

/* Exports */
Package._define("wekan-ldap", exports);

})();

//# sourceURL=meteor://💻app/packages/wekan-ldap.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvd2VrYW4tbGRhcC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3dla2FuLWxkYXAvc2VydmVyL2xkYXAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3dla2FuLWxkYXAvc2VydmVyL2xvZ2dlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvd2VrYW4tbGRhcC9zZXJ2ZXIvbG9naW5IYW5kbGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy93ZWthbi1sZGFwL3NlcnZlci9zeW5jLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImxpbmsiLCJleHBvcnQiLCJkZWZhdWx0IiwiTERBUCIsImxkYXBqcyIsInYiLCJ1dGlsIiwiQnVueWFuIiwibG9nX2RlYnVnIiwibG9nX2luZm8iLCJsb2dfd2FybiIsImxvZ19lcnJvciIsImNvbnN0cnVjdG9yIiwiY29ubmVjdGVkIiwib3B0aW9ucyIsImhvc3QiLCJzZXR0aW5nc19nZXQiLCJwb3J0IiwiUmVjb25uZWN0IiwidGltZW91dCIsImNvbm5lY3RfdGltZW91dCIsImlkbGVfdGltZW91dCIsImVuY3J5cHRpb24iLCJjYV9jZXJ0IiwicmVqZWN0X3VuYXV0aG9yaXplZCIsIkF1dGhlbnRpY2F0aW9uIiwiQXV0aGVudGljYXRpb25fVXNlckROIiwiQXV0aGVudGljYXRpb25fUGFzc3dvcmQiLCJBdXRoZW50aWNhdGlvbl9GYWxsYmFjayIsIkJhc2VETiIsIkludGVybmFsX0xvZ19MZXZlbCIsIlVzZXJfQXV0aGVudGljYXRpb24iLCJVc2VyX0F1dGhlbnRpY2F0aW9uX0ZpZWxkIiwiVXNlcl9BdHRyaWJ1dGVzIiwiVXNlcl9TZWFyY2hfRmlsdGVyIiwiVXNlcl9TZWFyY2hfU2NvcGUiLCJVc2VyX1NlYXJjaF9GaWVsZCIsIlNlYXJjaF9QYWdlX1NpemUiLCJTZWFyY2hfU2l6ZV9MaW1pdCIsImdyb3VwX2ZpbHRlcl9lbmFibGVkIiwiZ3JvdXBfZmlsdGVyX29iamVjdF9jbGFzcyIsImdyb3VwX2ZpbHRlcl9ncm91cF9pZF9hdHRyaWJ1dGUiLCJncm91cF9maWx0ZXJfZ3JvdXBfbWVtYmVyX2F0dHJpYnV0ZSIsImdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfZm9ybWF0IiwiZ3JvdXBfZmlsdGVyX2dyb3VwX25hbWUiLCJuYW1lIiwidmFsdWUiLCJwcm9jZXNzIiwiZW52IiwidW5kZWZpbmVkIiwiSlNPTiIsInBhcnNlIiwiaXNOYU4iLCJOdW1iZXIiLCJjb25uZWN0U3luYyIsIl9jb25uZWN0U3luYyIsIk1ldGVvciIsIndyYXBBc3luYyIsImNvbm5lY3RBc3luYyIsInNlYXJjaEFsbFN5bmMiLCJfc2VhcmNoQWxsU3luYyIsInNlYXJjaEFsbEFzeW5jIiwiY2FsbGJhY2siLCJyZXBsaWVkIiwiY29ubmVjdGlvbk9wdGlvbnMiLCJ1cmwiLCJjb25uZWN0VGltZW91dCIsImlkbGVUaW1lb3V0IiwicmVjb25uZWN0IiwibG9nIiwiY29tcG9uZW50Iiwic3RyZWFtIiwic3RkZXJyIiwibGV2ZWwiLCJ0bHNPcHRpb25zIiwicmVqZWN0VW5hdXRob3JpemVkIiwiY2hhaW5MaW5lcyIsInNwbGl0IiwiY2VydCIsImNhIiwiZm9yRWFjaCIsImxpbmUiLCJwdXNoIiwibWF0Y2giLCJqb2luIiwiaW5zcGVjdCIsImNsaWVudCIsImNyZWF0ZUNsaWVudCIsImJpbmRTeW5jIiwiYmluZCIsIm9uIiwiZXJyb3IiLCJkaXNjb25uZWN0Iiwic3RhcnR0bHMiLCJyZXNwb25zZSIsInNldFRpbWVvdXQiLCJFcnJvciIsImdldFVzZXJGaWx0ZXIiLCJ1c2VybmFtZSIsImZpbHRlciIsInVzZXJuYW1lRmlsdGVyIiwibWFwIiwiaXRlbSIsImxlbmd0aCIsImJpbmRVc2VySWZOZWNlc3NhcnkiLCJwYXNzd29yZCIsImRvbWFpbkJpbmRlZCIsInVzZXJEbiIsImJpbmRJZk5lY2Vzc2FyeSIsInNlYXJjaFVzZXJzU3luYyIsInBhZ2UiLCJzZWFyY2hPcHRpb25zIiwic2NvcGUiLCJzaXplTGltaXQiLCJhdHRyaWJ1dGVzIiwicGFnZWQiLCJwYWdlU2l6ZSIsInBhZ2VQYXVzZSIsInNlYXJjaEFsbFBhZ2VkIiwiZ2V0VXNlckJ5SWRTeW5jIiwiaWQiLCJhdHRyaWJ1dGUiLCJVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCIsImZpbHRlcnMiLCJFcXVhbGl0eUZpbHRlciIsIkJ1ZmZlciIsImZyb20iLCJPckZpbHRlciIsInRvU3RyaW5nIiwicmVzdWx0IiwiQXJyYXkiLCJpc0FycmF5IiwiZ2V0VXNlckJ5VXNlcm5hbWVTeW5jIiwiZ2V0VXNlckdyb3VwcyIsImxkYXBVc2VyIiwiZm9ybWF0X3ZhbHVlIiwicmVwbGFjZSIsImdycF9pZGVudGlmaWVyIiwiZ3JvdXBzIiwiaXNVc2VySW5Hcm91cCIsImdycHMiLCJleHRyYWN0TGRhcEVudHJ5RGF0YSIsImVudHJ5IiwidmFsdWVzIiwiX3JhdyIsInJhdyIsIk9iamVjdCIsImtleXMiLCJrZXkiLCJpbmNsdWRlcyIsInByb2Nlc3NQYWdlIiwiZW50cmllcyIsInRpdGxlIiwiZW5kIiwibmV4dCIsIl91cGRhdGVJZGxlIiwic2VhcmNoIiwicmVzIiwiaW50ZXJuYWxQYWdlU2l6ZSIsImF1dGhTeW5jIiwiZG4iLCJ1bmJpbmQiLCJpc0xvZ0VuYWJsZWQiLCJMREFQX0xPR19FTkFCTEVEIiwibWVzc2FnZSIsImRhdGEiLCJjb25zb2xlIiwic3RyaW5naWZ5IiwiYXJncyIsInNsdWciLCJnZXRMZGFwVXNlcm5hbWUiLCJnZXRMZGFwRW1haWwiLCJnZXRMZGFwVXNlclVuaXF1ZUlEIiwic3luY1VzZXJEYXRhIiwiYWRkTGRhcFVzZXIiLCJmYWxsYmFja0RlZmF1bHRBY2NvdW50U3lzdGVtIiwiaW5kZXhPZiIsImVtYWlsIiwibG9naW5SZXF1ZXN0IiwidXNlciIsImRpZ2VzdCIsIlNIQTI1NiIsImFsZ29yaXRobSIsIkFjY291bnRzIiwiX3J1bkxvZ2luSGFuZGxlcnMiLCJyZWdpc3RlckxvZ2luSGFuZGxlciIsImxkYXAiLCJsZGFwT3B0aW9ucyIsImxkYXBQYXNzIiwic2VsZiIsInVzZXJzIiwidXNlclF1ZXJ5IiwiZmluZE9uZSIsImF1dGhlbnRpY2F0aW9uTWV0aG9kIiwic3RhbXBlZFRva2VuIiwiX2dlbmVyYXRlU3RhbXBlZExvZ2luVG9rZW4iLCJ1cGRhdGVfZGF0YSIsIiRwdXNoIiwiX2hhc2hTdGFtcGVkVG9rZW4iLCJ0YXJnZXRHcm91cHMiLCJpc0FkbWluIiwidXBkYXRlIiwiX2lkIiwiJHNldCIsIlJvbGVzIiwic2V0VXNlclJvbGVzIiwic2V0UGFzc3dvcmQiLCJsb2dvdXQiLCJ1c2VySWQiLCJ0b2tlbiIsImdldFByb3BlcnR5VmFsdWUiLCJnZXRMZGFwRnVsbG5hbWUiLCJnZXREYXRhVG9TeW5jVXNlckRhdGEiLCJpbXBvcnROZXdVc2VycyIsIl8iLCJTeW5jZWRDcm9uIiwiZGVmaW5lUHJvcGVydHkiLCJwcm90b3R5cGUiLCJwcm9wIiwidG9Mb3dlckNhc2UiLCJlbnVtZXJhYmxlIiwidGV4dCIsInNsdWdpZnkiLCJ0ZW1wbGF0ZVZhckhhbmRsZXIiLCJ2YXJpYWJsZSIsIm9iamVjdCIsInRlbXBsYXRlUmVnZXgiLCJleGVjIiwidG1wVmFyaWFibGUiLCJoYXNPd25Qcm9wZXJ0eSIsInRtcGxWYXIiLCJ0bXBsQXR0ck5hbWUiLCJhdHRyVmFsIiwib2JqIiwicmVkdWNlIiwiYWNjIiwiZWwiLCJlcnIiLCJ1c2VybmFtZUZpZWxkIiwiZmllbGQiLCJnZXRMREFQVmFsdWUiLCJlbWFpbEZpZWxkIiwiZnVsbG5hbWVGaWVsZCIsImNvbmNhdCIsImZpbmQiLCJpc0VtcHR5Iiwic3luY1VzZXJEYXRhRmllbGRNYXAiLCJ0cmltIiwidXNlckRhdGEiLCJ3aGl0ZWxpc3RlZFVzZXJGaWVsZHMiLCJmaWVsZE1hcCIsImVtYWlsTGlzdCIsInVzZXJGaWVsZCIsImxkYXBGaWVsZCIsImlzT2JqZWN0IiwiYWRkcmVzcyIsInZlcmlmaWVkIiwib3V0ZXJLZXkiLCJpbm5lcktleXMiLCJjdXN0b21GaWVsZHNNZXRhIiwiZSIsInRtcFVzZXJGaWVsZCIsInRtcExkYXBGaWVsZCIsImRLZXlzIiwibGFzdEtleSIsImxhc3QiLCJjdXJyS2V5IiwiZW1haWxzIiwidW5pcXVlSWQiLCJzZXJ2aWNlcyIsImlkQXR0cmlidXRlIiwic2l6ZSIsImZ1bGxuYW1lIiwidXNlck9iamVjdCIsIm1haWwiLCJjcmVhdGVVc2VyIiwiY291bnQiLCJiaW5kRW52aXJvbm1lbnQiLCJsZGFwVXNlcnMiLCJzeW5jIiwiJGV4aXN0cyIsImpvYk5hbWUiLCJhZGRDcm9uSm9iIiwiZGVib3VuY2UiLCJhZGRDcm9uSm9iRGVib3VuY2VkIiwic2MiLCJuZXh0U2NoZWR1bGVkQXREYXRlIiwicmVtb3ZlIiwiYWRkIiwic2NoZWR1bGUiLCJwYXJzZXIiLCJyZWN1ciIsIm1pbnV0ZSIsImpvYiIsInN0YXJ0Iiwic3RhcnR1cCIsImRlZmVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFOzs7Ozs7Ozs7OztBQ0FBRCxNQUFNLENBQUNFLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSUM7QUFBYixDQUFkO0FBQWtDLElBQUlDLE1BQUo7QUFBV0wsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDRSxTQUFPLENBQUNHLENBQUQsRUFBRztBQUFDRCxVQUFNLEdBQUNDLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsSUFBSjtBQUFTUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxNQUFaLEVBQW1CO0FBQUNFLFNBQU8sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFuQixDQUFuQixFQUF3QyxDQUF4QztBQUEyQyxJQUFJRSxNQUFKO0FBQVdSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ0UsU0FBTyxDQUFDRyxDQUFELEVBQUc7QUFBQ0UsVUFBTSxHQUFDRixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlHLFNBQUosRUFBY0MsUUFBZCxFQUF1QkMsUUFBdkIsRUFBZ0NDLFNBQWhDO0FBQTBDWixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNRLFdBQVMsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLGFBQVMsR0FBQ0gsQ0FBVjtBQUFZLEdBQTFCOztBQUEyQkksVUFBUSxDQUFDSixDQUFELEVBQUc7QUFBQ0ksWUFBUSxHQUFDSixDQUFUO0FBQVcsR0FBbEQ7O0FBQW1ESyxVQUFRLENBQUNMLENBQUQsRUFBRztBQUFDSyxZQUFRLEdBQUNMLENBQVQ7QUFBVyxHQUExRTs7QUFBMkVNLFdBQVMsQ0FBQ04sQ0FBRCxFQUFHO0FBQUNNLGFBQVMsR0FBQ04sQ0FBVjtBQUFZOztBQUFwRyxDQUF2QixFQUE2SCxDQUE3SDs7QUFNck8sTUFBTUYsSUFBTixDQUFXO0FBQ3hCUyxhQUFXLEdBQUc7QUFDWixTQUFLUixNQUFMLEdBQWNBLE1BQWQ7QUFFQSxTQUFLUyxTQUFMLEdBQWlCLEtBQWpCO0FBRUEsU0FBS0MsT0FBTCxHQUFlO0FBQ2JDLFVBQUksRUFBaUMsS0FBS0gsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsV0FBOUIsQ0FEeEI7QUFFYkMsVUFBSSxFQUFpQyxLQUFLTCxXQUFMLENBQWlCSSxZQUFqQixDQUE4QixXQUE5QixDQUZ4QjtBQUdiRSxlQUFTLEVBQTRCLEtBQUtOLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLGdCQUE5QixDQUh4QjtBQUliRyxhQUFPLEVBQThCLEtBQUtQLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLGNBQTlCLENBSnhCO0FBS2JJLHFCQUFlLEVBQXNCLEtBQUtSLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHNCQUE5QixDQUx4QjtBQU1iSyxrQkFBWSxFQUF5QixLQUFLVCxXQUFMLENBQWlCSSxZQUFqQixDQUE4QixtQkFBOUIsQ0FOeEI7QUFPYk0sZ0JBQVUsRUFBMkIsS0FBS1YsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsaUJBQTlCLENBUHhCO0FBUWJPLGFBQU8sRUFBOEIsS0FBS1gsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsY0FBOUIsQ0FSeEI7QUFTYlEseUJBQW1CLEVBQWtCLEtBQUtaLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDBCQUE5QixLQUE2RCxLQVRyRjtBQVViUyxvQkFBYyxFQUF1QixLQUFLYixXQUFMLENBQWlCSSxZQUFqQixDQUE4Qix1QkFBOUIsQ0FWeEI7QUFXYlUsMkJBQXFCLEVBQWdCLEtBQUtkLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDhCQUE5QixDQVh4QjtBQVliVyw2QkFBdUIsRUFBYyxLQUFLZixXQUFMLENBQWlCSSxZQUFqQixDQUE4QixnQ0FBOUIsQ0FaeEI7QUFhYlksNkJBQXVCLEVBQWMsS0FBS2hCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHFCQUE5QixDQWJ4QjtBQWNiYSxZQUFNLEVBQStCLEtBQUtqQixXQUFMLENBQWlCSSxZQUFqQixDQUE4QixhQUE5QixDQWR4QjtBQWViYyx3QkFBa0IsRUFBbUIsS0FBS2xCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLG9CQUE5QixDQWZ4QjtBQWdCYmUseUJBQW1CLEVBQWtCLEtBQUtuQixXQUFMLENBQWlCSSxZQUFqQixDQUE4QiwwQkFBOUIsQ0FoQnhCO0FBaUJiZ0IsK0JBQXlCLEVBQVksS0FBS3BCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLGdDQUE5QixDQWpCeEI7QUFrQmJpQixxQkFBZSxFQUFzQixLQUFLckIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsc0JBQTlCLENBbEJ4QjtBQW1CYmtCLHdCQUFrQixFQUFtQixLQUFLdEIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIseUJBQTlCLENBbkJ4QjtBQW9CYm1CLHVCQUFpQixFQUFvQixLQUFLdkIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsd0JBQTlCLENBcEJ4QjtBQXFCYm9CLHVCQUFpQixFQUFvQixLQUFLeEIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsd0JBQTlCLENBckJ4QjtBQXNCYnFCLHNCQUFnQixFQUFxQixLQUFLekIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsdUJBQTlCLENBdEJ4QjtBQXVCYnNCLHVCQUFpQixFQUFvQixLQUFLMUIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsd0JBQTlCLENBdkJ4QjtBQXdCYnVCLDBCQUFvQixFQUFpQixLQUFLM0IsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsMEJBQTlCLENBeEJ4QjtBQXlCYndCLCtCQUF5QixFQUFZLEtBQUs1QixXQUFMLENBQWlCSSxZQUFqQixDQUE4QiwrQkFBOUIsQ0F6QnhCO0FBMEJieUIscUNBQStCLEVBQU0sS0FBSzdCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHNDQUE5QixDQTFCeEI7QUEyQmIwQix5Q0FBbUMsRUFBRSxLQUFLOUIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsMENBQTlCLENBM0J4QjtBQTRCYjJCLHNDQUFnQyxFQUFLLEtBQUsvQixXQUFMLENBQWlCSSxZQUFqQixDQUE4Qix1Q0FBOUIsQ0E1QnhCO0FBNkJiNEIsNkJBQXVCLEVBQWMsS0FBS2hDLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDhCQUE5QjtBQTdCeEIsS0FBZjtBQStCRDs7QUFFRCxTQUFPQSxZQUFQLENBQW9CNkIsSUFBcEIsRUFBbUM7QUFDakMsUUFBSUMsS0FBSyxHQUFHQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUgsSUFBWixDQUFaOztBQUNBLFFBQUlDLEtBQUssS0FBS0csU0FBZCxFQUF5QjtBQUN2QixVQUFJSCxLQUFLLEtBQUssTUFBVixJQUFvQkEsS0FBSyxLQUFLLE9BQWxDLEVBQTJDO0FBQ3pDQSxhQUFLLEdBQUdJLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxLQUFYLENBQVI7QUFDRCxPQUZELE1BRU8sSUFBSUEsS0FBSyxLQUFLLEVBQVYsSUFBZ0IsQ0FBQ00sS0FBSyxDQUFDTixLQUFELENBQTFCLEVBQW1DO0FBQ3hDQSxhQUFLLEdBQUdPLE1BQU0sQ0FBQ1AsS0FBRCxDQUFkO0FBQ0Q7O0FBQ0QsYUFBT0EsS0FBUDtBQUNELEtBUEQsTUFPTztBQUNMcEMsY0FBUSxzQ0FBK0JtQyxJQUEvQixFQUFSO0FBQ0Q7QUFDRjs7QUFFRFMsYUFBVyxHQUFVO0FBQ2xCLFFBQUksQ0FBQyxLQUFLQyxZQUFWLEVBQXdCO0FBQ3ZCLFdBQUtBLFlBQUwsR0FBb0JDLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQixLQUFLQyxZQUF0QixFQUFvQyxJQUFwQyxDQUFwQjtBQUNEOztBQUNELFdBQU8sS0FBS0gsWUFBTCxDQUFrQixZQUFsQixDQUFQO0FBQ0Q7O0FBRURJLGVBQWEsR0FBVTtBQUVyQixRQUFJLENBQUMsS0FBS0MsY0FBVixFQUEwQjtBQUN4QixXQUFLQSxjQUFMLEdBQXNCSixNQUFNLENBQUNDLFNBQVAsQ0FBaUIsS0FBS0ksY0FBdEIsRUFBc0MsSUFBdEMsQ0FBdEI7QUFDRDs7QUFDRCxXQUFPLEtBQUtELGNBQUwsQ0FBb0IsWUFBcEIsQ0FBUDtBQUNEOztBQUVERixjQUFZLENBQUNJLFFBQUQsRUFBVztBQUNyQnJELFlBQVEsQ0FBQyxZQUFELENBQVI7QUFFQSxRQUFJc0QsT0FBTyxHQUFHLEtBQWQ7QUFFQSxVQUFNQyxpQkFBaUIsR0FBRztBQUN4QkMsU0FBRyxZQUFnQixLQUFLbkQsT0FBTCxDQUFhQyxJQUE3QixjQUFxQyxLQUFLRCxPQUFMLENBQWFHLElBQWxELENBRHFCO0FBRXhCRSxhQUFPLEVBQVMsS0FBS0wsT0FBTCxDQUFhSyxPQUZMO0FBR3hCK0Msb0JBQWMsRUFBRSxLQUFLcEQsT0FBTCxDQUFhTSxlQUhMO0FBSXhCK0MsaUJBQVcsRUFBSyxLQUFLckQsT0FBTCxDQUFhTyxZQUpMO0FBS3hCK0MsZUFBUyxFQUFPLEtBQUt0RCxPQUFMLENBQWFJO0FBTEwsS0FBMUI7O0FBUUEsUUFBSSxLQUFLSixPQUFMLENBQWFnQixrQkFBYixLQUFvQyxVQUF4QyxFQUFvRDtBQUNsRGtDLHVCQUFpQixDQUFDSyxHQUFsQixHQUF3QixJQUFJOUQsTUFBSixDQUFXO0FBQ2pDc0MsWUFBSSxFQUFPLFFBRHNCO0FBRWpDeUIsaUJBQVMsRUFBRSxRQUZzQjtBQUdqQ0MsY0FBTSxFQUFLeEIsT0FBTyxDQUFDeUIsTUFIYztBQUlqQ0MsYUFBSyxFQUFNLEtBQUszRCxPQUFMLENBQWFnQjtBQUpTLE9BQVgsQ0FBeEI7QUFNRDs7QUFFRCxVQUFNNEMsVUFBVSxHQUFHO0FBQ2pCQyx3QkFBa0IsRUFBRSxLQUFLN0QsT0FBTCxDQUFhVTtBQURoQixLQUFuQjs7QUFJQSxRQUFJLEtBQUtWLE9BQUwsQ0FBYVMsT0FBYixJQUF3QixLQUFLVCxPQUFMLENBQWFTLE9BQWIsS0FBeUIsRUFBckQsRUFBeUQ7QUFDdkQ7QUFDQSxZQUFNcUQsVUFBVSxHQUFHLEtBQUtoRSxXQUFMLENBQWlCSSxZQUFqQixDQUE4QixjQUE5QixFQUE4QzZELEtBQTlDLENBQW9ELElBQXBELENBQW5CO0FBQ0EsVUFBSUMsSUFBSSxHQUFXLEVBQW5CO0FBQ0EsWUFBTUMsRUFBRSxHQUFXLEVBQW5CO0FBQ0FILGdCQUFVLENBQUNJLE9BQVgsQ0FBb0JDLElBQUQsSUFBVTtBQUMzQkgsWUFBSSxDQUFDSSxJQUFMLENBQVVELElBQVY7O0FBQ0EsWUFBSUEsSUFBSSxDQUFDRSxLQUFMLENBQVcsbUJBQVgsQ0FBSixFQUFxQztBQUNuQ0osWUFBRSxDQUFDRyxJQUFILENBQVFKLElBQUksQ0FBQ00sSUFBTCxDQUFVLElBQVYsQ0FBUjtBQUNBTixjQUFJLEdBQUcsRUFBUDtBQUNEO0FBQ0YsT0FORDtBQU9BSixnQkFBVSxDQUFDSyxFQUFYLEdBQWdCQSxFQUFoQjtBQUNEOztBQUVELFFBQUksS0FBS2pFLE9BQUwsQ0FBYVEsVUFBYixLQUE0QixLQUFoQyxFQUF1QztBQUNyQzBDLHVCQUFpQixDQUFDQyxHQUFsQixxQkFBMENELGlCQUFpQixDQUFDQyxHQUE1RDtBQUNBRCx1QkFBaUIsQ0FBQ1UsVUFBbEIsR0FBK0JBLFVBQS9CO0FBQ0QsS0FIRCxNQUdPO0FBQ0xWLHVCQUFpQixDQUFDQyxHQUFsQixvQkFBa0NELGlCQUFpQixDQUFDQyxHQUFwRDtBQUNEOztBQUVEeEQsWUFBUSxDQUFDLFlBQUQsRUFBZXVELGlCQUFpQixDQUFDQyxHQUFqQyxDQUFSO0FBQ0F6RCxhQUFTLDRCQUFxQkYsSUFBSSxDQUFDK0UsT0FBTCxDQUFhckIsaUJBQWIsQ0FBckIsRUFBVDtBQUVBLFNBQUtzQixNQUFMLEdBQWNsRixNQUFNLENBQUNtRixZQUFQLENBQW9CdkIsaUJBQXBCLENBQWQ7QUFFQSxTQUFLd0IsUUFBTCxHQUFnQmhDLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQixLQUFLNkIsTUFBTCxDQUFZRyxJQUE3QixFQUFtQyxLQUFLSCxNQUF4QyxDQUFoQjtBQUVBLFNBQUtBLE1BQUwsQ0FBWUksRUFBWixDQUFlLE9BQWYsRUFBeUJDLEtBQUQsSUFBVztBQUNqQ2hGLGVBQVMsQ0FBQyxZQUFELEVBQWVnRixLQUFmLENBQVQ7O0FBQ0EsVUFBSTVCLE9BQU8sS0FBSyxLQUFoQixFQUF1QjtBQUNyQkEsZUFBTyxHQUFHLElBQVY7QUFDQUQsZ0JBQVEsQ0FBQzZCLEtBQUQsRUFBUSxJQUFSLENBQVI7QUFDRDtBQUNGLEtBTkQ7QUFRQSxTQUFLTCxNQUFMLENBQVlJLEVBQVosQ0FBZSxNQUFmLEVBQXVCLE1BQU07QUFDM0JqRixjQUFRLENBQUMsTUFBRCxDQUFSO0FBQ0EsV0FBS21GLFVBQUw7QUFDRCxLQUhEO0FBS0EsU0FBS04sTUFBTCxDQUFZSSxFQUFaLENBQWUsT0FBZixFQUF3QixNQUFNO0FBQzVCakYsY0FBUSxDQUFDLFFBQUQsQ0FBUjtBQUNELEtBRkQ7O0FBSUEsUUFBSSxLQUFLSyxPQUFMLENBQWFRLFVBQWIsS0FBNEIsS0FBaEMsRUFBdUM7QUFDckM7QUFDQTtBQUNBO0FBQ0FvRCxnQkFBVSxDQUFDM0QsSUFBWCxHQUFrQixLQUFLRCxPQUFMLENBQWFDLElBQS9CO0FBRUFOLGNBQVEsQ0FBQyxjQUFELENBQVI7QUFDQUQsZUFBUyxDQUFDLFlBQUQsRUFBZWtFLFVBQWYsQ0FBVDtBQUVBLFdBQUtZLE1BQUwsQ0FBWU8sUUFBWixDQUFxQm5CLFVBQXJCLEVBQWlDLElBQWpDLEVBQXVDLENBQUNpQixLQUFELEVBQVFHLFFBQVIsS0FBcUI7QUFDMUQsWUFBSUgsS0FBSixFQUFXO0FBQ1RoRixtQkFBUyxDQUFDLGdCQUFELEVBQW1CZ0YsS0FBbkIsQ0FBVDs7QUFDQSxjQUFJNUIsT0FBTyxLQUFLLEtBQWhCLEVBQXVCO0FBQ3JCQSxtQkFBTyxHQUFHLElBQVY7QUFDQUQsb0JBQVEsQ0FBQzZCLEtBQUQsRUFBUSxJQUFSLENBQVI7QUFDRDs7QUFDRDtBQUNEOztBQUVEbEYsZ0JBQVEsQ0FBQyxlQUFELENBQVI7QUFDQSxhQUFLSSxTQUFMLEdBQWlCLElBQWpCOztBQUNBLFlBQUlrRCxPQUFPLEtBQUssS0FBaEIsRUFBdUI7QUFDckJBLGlCQUFPLEdBQUcsSUFBVjtBQUNBRCxrQkFBUSxDQUFDLElBQUQsRUFBT2dDLFFBQVAsQ0FBUjtBQUNEO0FBQ0YsT0FoQkQ7QUFpQkQsS0ExQkQsTUEwQk87QUFDTCxXQUFLUixNQUFMLENBQVlJLEVBQVosQ0FBZSxTQUFmLEVBQTJCSSxRQUFELElBQWM7QUFDdENyRixnQkFBUSxDQUFDLGdCQUFELENBQVI7QUFDQSxhQUFLSSxTQUFMLEdBQWlCLElBQWpCOztBQUNBLFlBQUlrRCxPQUFPLEtBQUssS0FBaEIsRUFBdUI7QUFDckJBLGlCQUFPLEdBQUcsSUFBVjtBQUNBRCxrQkFBUSxDQUFDLElBQUQsRUFBT2dDLFFBQVAsQ0FBUjtBQUNEO0FBQ0YsT0FQRDtBQVFEOztBQUVEQyxjQUFVLENBQUMsTUFBTTtBQUNmLFVBQUloQyxPQUFPLEtBQUssS0FBaEIsRUFBdUI7QUFDckJwRCxpQkFBUyxDQUFDLHFCQUFELEVBQXdCcUQsaUJBQWlCLENBQUNFLGNBQTFDLENBQVQ7QUFDQUgsZUFBTyxHQUFHLElBQVY7QUFDQUQsZ0JBQVEsQ0FBQyxJQUFJa0MsS0FBSixDQUFVLFNBQVYsQ0FBRCxDQUFSO0FBQ0Q7QUFDRixLQU5TLEVBTVBoQyxpQkFBaUIsQ0FBQ0UsY0FOWCxDQUFWO0FBT0Q7O0FBRUQrQixlQUFhLENBQUNDLFFBQUQsRUFBVztBQUN0QixVQUFNQyxNQUFNLEdBQUcsRUFBZjs7QUFFQSxRQUFJLEtBQUtyRixPQUFMLENBQWFvQixrQkFBYixLQUFvQyxFQUF4QyxFQUE0QztBQUMxQyxVQUFJLEtBQUtwQixPQUFMLENBQWFvQixrQkFBYixDQUFnQyxDQUFoQyxNQUF1QyxHQUEzQyxFQUFnRDtBQUM5Q2lFLGNBQU0sQ0FBQ2pCLElBQVAsV0FBZSxLQUFLcEUsT0FBTCxDQUFhb0Isa0JBQTVCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xpRSxjQUFNLENBQUNqQixJQUFQLFlBQWdCLEtBQUtwRSxPQUFMLENBQWFvQixrQkFBN0I7QUFDRDtBQUNGOztBQUVELFVBQU1rRSxjQUFjLEdBQUcsS0FBS3RGLE9BQUwsQ0FBYXNCLGlCQUFiLENBQStCeUMsS0FBL0IsQ0FBcUMsR0FBckMsRUFBMEN3QixHQUExQyxDQUErQ0MsSUFBRCxlQUFjQSxJQUFkLGNBQXNCSixRQUF0QixNQUE5QyxDQUF2Qjs7QUFFQSxRQUFJRSxjQUFjLENBQUNHLE1BQWYsS0FBMEIsQ0FBOUIsRUFBaUM7QUFDL0I1RixlQUFTLENBQUMseUNBQUQsQ0FBVDtBQUNELEtBRkQsTUFFTyxJQUFJeUYsY0FBYyxDQUFDRyxNQUFmLEtBQTBCLENBQTlCLEVBQWlDO0FBQ3RDSixZQUFNLENBQUNqQixJQUFQLFdBQWVrQixjQUFjLENBQUMsQ0FBRCxDQUE3QjtBQUNELEtBRk0sTUFFQTtBQUNMRCxZQUFNLENBQUNqQixJQUFQLGFBQWlCa0IsY0FBYyxDQUFDaEIsSUFBZixDQUFvQixFQUFwQixDQUFqQjtBQUNEOztBQUVELHVCQUFZZSxNQUFNLENBQUNmLElBQVAsQ0FBWSxFQUFaLENBQVo7QUFDRDs7QUFFRG9CLHFCQUFtQixDQUFDTixRQUFELEVBQVdPLFFBQVgsRUFBcUI7QUFFdEMsUUFBSSxLQUFLQyxZQUFMLEtBQXNCLElBQTFCLEVBQWdDO0FBQzlCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDLEtBQUs1RixPQUFMLENBQWFpQixtQkFBbEIsRUFBdUM7QUFDckM7QUFDRDs7QUFHRCxRQUFJLENBQUMsS0FBS2pCLE9BQUwsQ0FBYWUsTUFBbEIsRUFBMEIsTUFBTSxJQUFJbUUsS0FBSixDQUFVLHdCQUFWLENBQU47QUFFMUIsVUFBTVcsTUFBTSxhQUFNLEtBQUs3RixPQUFMLENBQWFrQix5QkFBbkIsY0FBZ0RrRSxRQUFoRCxjQUE0RCxLQUFLcEYsT0FBTCxDQUFhZSxNQUF6RSxDQUFaO0FBRUEsU0FBSzJELFFBQUwsQ0FBY21CLE1BQWQsRUFBc0JGLFFBQXRCO0FBQ0EsU0FBS0MsWUFBTCxHQUFvQixJQUFwQjtBQUNEOztBQUVERSxpQkFBZSxHQUFHO0FBQ2hCLFFBQUksS0FBS0YsWUFBTCxLQUFzQixJQUExQixFQUFnQztBQUM5QjtBQUNEOztBQUVELFFBQUksS0FBSzVGLE9BQUwsQ0FBYVcsY0FBYixLQUFnQyxJQUFwQyxFQUEwQztBQUN4QztBQUNEOztBQUVEaEIsWUFBUSxDQUFDLGdCQUFELEVBQW1CLEtBQUtLLE9BQUwsQ0FBYVkscUJBQWhDLENBQVI7QUFFQSxTQUFLOEQsUUFBTCxDQUFjLEtBQUsxRSxPQUFMLENBQWFZLHFCQUEzQixFQUFrRCxLQUFLWixPQUFMLENBQWFhLHVCQUEvRDtBQUNBLFNBQUsrRSxZQUFMLEdBQW9CLElBQXBCO0FBQ0Q7O0FBRURHLGlCQUFlLENBQUNYLFFBQUQsRUFBV1ksSUFBWCxFQUFpQjtBQUM5QixTQUFLRixlQUFMO0FBQ0EsVUFBTUcsYUFBYSxHQUFHO0FBQ3BCWixZQUFNLEVBQUssS0FBS0YsYUFBTCxDQUFtQkMsUUFBbkIsQ0FEUztBQUVwQmMsV0FBSyxFQUFNLEtBQUtsRyxPQUFMLENBQWFxQixpQkFBYixJQUFrQyxLQUZ6QjtBQUdwQjhFLGVBQVMsRUFBRSxLQUFLbkcsT0FBTCxDQUFhd0I7QUFISixLQUF0QjtBQU1BLFFBQUksQ0FBQyxDQUFDLEtBQUt4QixPQUFMLENBQWFtQixlQUFuQixFQUFvQzhFLGFBQWEsQ0FBQ0csVUFBZCxHQUEyQixLQUFLcEcsT0FBTCxDQUFhbUIsZUFBYixDQUE2QjRDLEtBQTdCLENBQW1DLEdBQW5DLENBQTNCOztBQUVwQyxRQUFJLEtBQUsvRCxPQUFMLENBQWF1QixnQkFBYixHQUFnQyxDQUFwQyxFQUF1QztBQUNyQzBFLG1CQUFhLENBQUNJLEtBQWQsR0FBc0I7QUFDcEJDLGdCQUFRLEVBQUcsS0FBS3RHLE9BQUwsQ0FBYXVCLGdCQURKO0FBRXBCZ0YsaUJBQVMsRUFBRSxDQUFDLENBQUNQO0FBRk8sT0FBdEI7QUFJRDs7QUFFRHJHLFlBQVEsQ0FBQyxnQkFBRCxFQUFtQnlGLFFBQW5CLENBQVI7QUFDQTFGLGFBQVMsQ0FBQyxlQUFELEVBQWtCdUcsYUFBbEIsQ0FBVDtBQUNBdkcsYUFBUyxDQUFDLFFBQUQsRUFBVyxLQUFLTSxPQUFMLENBQWFlLE1BQXhCLENBQVQ7O0FBRUEsUUFBSWlGLElBQUosRUFBVTtBQUNSLGFBQU8sS0FBS1EsY0FBTCxDQUFvQixLQUFLeEcsT0FBTCxDQUFhZSxNQUFqQyxFQUF5Q2tGLGFBQXpDLEVBQXdERCxJQUF4RCxDQUFQO0FBQ0Q7O0FBRUQsV0FBTyxLQUFLbkQsYUFBTCxDQUFtQixLQUFLN0MsT0FBTCxDQUFhZSxNQUFoQyxFQUF3Q2tGLGFBQXhDLENBQVA7QUFDRDs7QUFFRFEsaUJBQWUsQ0FBQ0MsRUFBRCxFQUFLQyxTQUFMLEVBQWdCO0FBQzdCLFNBQUtiLGVBQUw7QUFFQSxVQUFNYyx1QkFBdUIsR0FBRyxLQUFLOUcsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsOEJBQTlCLEVBQThENkQsS0FBOUQsQ0FBb0UsR0FBcEUsQ0FBaEM7QUFFQSxRQUFJc0IsTUFBSjs7QUFFQSxRQUFJc0IsU0FBSixFQUFlO0FBQ2J0QixZQUFNLEdBQUcsSUFBSSxLQUFLL0YsTUFBTCxDQUFZdUgsT0FBWixDQUFvQkMsY0FBeEIsQ0FBdUM7QUFDOUNILGlCQUQ4QztBQUU5QzNFLGFBQUssRUFBRStFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZTixFQUFaLEVBQWdCLEtBQWhCO0FBRnVDLE9BQXZDLENBQVQ7QUFJRCxLQUxELE1BS087QUFDTCxZQUFNRyxPQUFPLEdBQUcsRUFBaEI7QUFDQUQsNkJBQXVCLENBQUMxQyxPQUF4QixDQUFpQ3NCLElBQUQsSUFBVTtBQUN4Q3FCLGVBQU8sQ0FBQ3pDLElBQVIsQ0FBYSxJQUFJLEtBQUs5RSxNQUFMLENBQVl1SCxPQUFaLENBQW9CQyxjQUF4QixDQUF1QztBQUNsREgsbUJBQVMsRUFBRW5CLElBRHVDO0FBRWxEeEQsZUFBSyxFQUFNK0UsTUFBTSxDQUFDQyxJQUFQLENBQVlOLEVBQVosRUFBZ0IsS0FBaEI7QUFGdUMsU0FBdkMsQ0FBYjtBQUlELE9BTEQ7QUFPQXJCLFlBQU0sR0FBRyxJQUFJLEtBQUsvRixNQUFMLENBQVl1SCxPQUFaLENBQW9CSSxRQUF4QixDQUFpQztBQUFFSjtBQUFGLE9BQWpDLENBQVQ7QUFDRDs7QUFFRCxVQUFNWixhQUFhLEdBQUc7QUFDcEJaLFlBRG9CO0FBRXBCYSxXQUFLLEVBQUU7QUFGYSxLQUF0QjtBQUtBdkcsWUFBUSxDQUFDLGlCQUFELEVBQW9CK0csRUFBcEIsQ0FBUjtBQUNBaEgsYUFBUyxDQUFDLGVBQUQsRUFBa0J1RyxhQUFhLENBQUNaLE1BQWQsQ0FBcUI2QixRQUFyQixFQUFsQixDQUFUO0FBQ0F4SCxhQUFTLENBQUMsUUFBRCxFQUFXLEtBQUtNLE9BQUwsQ0FBYWUsTUFBeEIsQ0FBVDtBQUVBLFVBQU1vRyxNQUFNLEdBQUcsS0FBS3RFLGFBQUwsQ0FBbUIsS0FBSzdDLE9BQUwsQ0FBYWUsTUFBaEMsRUFBd0NrRixhQUF4QyxDQUFmOztBQUVBLFFBQUksQ0FBQ21CLEtBQUssQ0FBQ0MsT0FBTixDQUFjRixNQUFkLENBQUQsSUFBMEJBLE1BQU0sQ0FBQzFCLE1BQVAsS0FBa0IsQ0FBaEQsRUFBbUQ7QUFDakQ7QUFDRDs7QUFFRCxRQUFJMEIsTUFBTSxDQUFDMUIsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUNyQjVGLGVBQVMsQ0FBQyxjQUFELEVBQWlCNkcsRUFBakIsRUFBcUIsVUFBckIsRUFBaUNTLE1BQU0sQ0FBQzFCLE1BQXhDLEVBQWdELFNBQWhELENBQVQ7QUFDRDs7QUFFRCxXQUFPMEIsTUFBTSxDQUFDLENBQUQsQ0FBYjtBQUNEOztBQUVERyx1QkFBcUIsQ0FBQ2xDLFFBQUQsRUFBVztBQUM5QixTQUFLVSxlQUFMO0FBRUEsVUFBTUcsYUFBYSxHQUFHO0FBQ3BCWixZQUFNLEVBQUUsS0FBS0YsYUFBTCxDQUFtQkMsUUFBbkIsQ0FEWTtBQUVwQmMsV0FBSyxFQUFHLEtBQUtsRyxPQUFMLENBQWFxQixpQkFBYixJQUFrQztBQUZ0QixLQUF0QjtBQUtBMUIsWUFBUSxDQUFDLGdCQUFELEVBQW1CeUYsUUFBbkIsQ0FBUjtBQUNBMUYsYUFBUyxDQUFDLGVBQUQsRUFBa0J1RyxhQUFsQixDQUFUO0FBQ0F2RyxhQUFTLENBQUMsUUFBRCxFQUFXLEtBQUtNLE9BQUwsQ0FBYWUsTUFBeEIsQ0FBVDtBQUVBLFVBQU1vRyxNQUFNLEdBQUcsS0FBS3RFLGFBQUwsQ0FBbUIsS0FBSzdDLE9BQUwsQ0FBYWUsTUFBaEMsRUFBd0NrRixhQUF4QyxDQUFmOztBQUVBLFFBQUksQ0FBQ21CLEtBQUssQ0FBQ0MsT0FBTixDQUFjRixNQUFkLENBQUQsSUFBMEJBLE1BQU0sQ0FBQzFCLE1BQVAsS0FBa0IsQ0FBaEQsRUFBbUQ7QUFDakQ7QUFDRDs7QUFFRCxRQUFJMEIsTUFBTSxDQUFDMUIsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUNyQjVGLGVBQVMsQ0FBQyxvQkFBRCxFQUF1QnVGLFFBQXZCLEVBQWlDLFVBQWpDLEVBQTZDK0IsTUFBTSxDQUFDMUIsTUFBcEQsRUFBNEQsU0FBNUQsQ0FBVDtBQUNEOztBQUVELFdBQU8wQixNQUFNLENBQUMsQ0FBRCxDQUFiO0FBQ0Q7O0FBRURJLGVBQWEsQ0FBQ25DLFFBQUQsRUFBV29DLFFBQVgsRUFBcUI7QUFDaEMsUUFBSSxDQUFDLEtBQUt4SCxPQUFMLENBQWF5QixvQkFBbEIsRUFBd0M7QUFDdEMsYUFBTyxJQUFQO0FBQ0Q7O0FBRUQsVUFBTTRELE1BQU0sR0FBRyxDQUFDLElBQUQsQ0FBZjs7QUFFQSxRQUFJLEtBQUtyRixPQUFMLENBQWEwQix5QkFBYixLQUEyQyxFQUEvQyxFQUFtRDtBQUNqRDJELFlBQU0sQ0FBQ2pCLElBQVAsd0JBQTRCLEtBQUtwRSxPQUFMLENBQWEwQix5QkFBekM7QUFDRDs7QUFFRCxRQUFJLEtBQUsxQixPQUFMLENBQWE0QixtQ0FBYixLQUFxRCxFQUF6RCxFQUE2RDtBQUMzRCxZQUFNNkYsWUFBWSxHQUFHRCxRQUFRLENBQUMsS0FBS3hILE9BQUwsQ0FBYTZCLGdDQUFkLENBQTdCOztBQUNBLFVBQUk0RixZQUFKLEVBQWtCO0FBQ2hCcEMsY0FBTSxDQUFDakIsSUFBUCxZQUFnQixLQUFLcEUsT0FBTCxDQUFhNEIsbUNBQTdCLGNBQW9FNkYsWUFBcEU7QUFDRDtBQUNGOztBQUVEcEMsVUFBTSxDQUFDakIsSUFBUCxDQUFZLEdBQVo7QUFFQSxVQUFNNkIsYUFBYSxHQUFHO0FBQ3BCWixZQUFNLEVBQUVBLE1BQU0sQ0FBQ2YsSUFBUCxDQUFZLEVBQVosRUFBZ0JvRCxPQUFoQixDQUF3QixjQUF4QixFQUF3Q3RDLFFBQXhDLENBRFk7QUFFcEJjLFdBQUssRUFBRztBQUZZLEtBQXRCO0FBS0F4RyxhQUFTLENBQUMseUJBQUQsRUFBNEJ1RyxhQUFhLENBQUNaLE1BQTFDLENBQVQ7QUFFQSxVQUFNOEIsTUFBTSxHQUFHLEtBQUt0RSxhQUFMLENBQW1CLEtBQUs3QyxPQUFMLENBQWFlLE1BQWhDLEVBQXdDa0YsYUFBeEMsQ0FBZjs7QUFFQSxRQUFJLENBQUNtQixLQUFLLENBQUNDLE9BQU4sQ0FBY0YsTUFBZCxDQUFELElBQTBCQSxNQUFNLENBQUMxQixNQUFQLEtBQWtCLENBQWhELEVBQW1EO0FBQ2pELGFBQU8sRUFBUDtBQUNEOztBQUVELFVBQU1rQyxjQUFjLEdBQUcsS0FBSzNILE9BQUwsQ0FBYTJCLCtCQUFiLElBQWdELElBQXZFO0FBQ0EsVUFBTWlHLE1BQU0sR0FBVyxFQUF2QjtBQUNBVCxVQUFNLENBQUM1QixHQUFQLENBQVlDLElBQUQsSUFBVTtBQUNuQm9DLFlBQU0sQ0FBQ3hELElBQVAsQ0FBWW9CLElBQUksQ0FBQ21DLGNBQUQsQ0FBaEI7QUFDRCxLQUZEO0FBR0FqSSxhQUFTLG1CQUFZa0ksTUFBTSxDQUFDdEQsSUFBUCxDQUFZLElBQVosQ0FBWixFQUFUO0FBQ0EsV0FBT3NELE1BQVA7QUFFRDs7QUFFREMsZUFBYSxDQUFDekMsUUFBRCxFQUFXb0MsUUFBWCxFQUFxQjtBQUNoQyxRQUFJLENBQUMsS0FBS3hILE9BQUwsQ0FBYXlCLG9CQUFsQixFQUF3QztBQUN0QyxhQUFPLElBQVA7QUFDRDs7QUFFRCxVQUFNcUcsSUFBSSxHQUFHLEtBQUtQLGFBQUwsQ0FBbUJuQyxRQUFuQixFQUE2Qm9DLFFBQTdCLENBQWI7QUFFQSxVQUFNbkMsTUFBTSxHQUFHLENBQUMsSUFBRCxDQUFmOztBQUVBLFFBQUksS0FBS3JGLE9BQUwsQ0FBYTBCLHlCQUFiLEtBQTJDLEVBQS9DLEVBQW1EO0FBQ2pEMkQsWUFBTSxDQUFDakIsSUFBUCx3QkFBNEIsS0FBS3BFLE9BQUwsQ0FBYTBCLHlCQUF6QztBQUNEOztBQUVELFFBQUksS0FBSzFCLE9BQUwsQ0FBYTRCLG1DQUFiLEtBQXFELEVBQXpELEVBQTZEO0FBQzNELFlBQU02RixZQUFZLEdBQUdELFFBQVEsQ0FBQyxLQUFLeEgsT0FBTCxDQUFhNkIsZ0NBQWQsQ0FBN0I7O0FBQ0EsVUFBSTRGLFlBQUosRUFBa0I7QUFDaEJwQyxjQUFNLENBQUNqQixJQUFQLFlBQWdCLEtBQUtwRSxPQUFMLENBQWE0QixtQ0FBN0IsY0FBb0U2RixZQUFwRTtBQUNEO0FBQ0Y7O0FBRUQsUUFBSSxLQUFLekgsT0FBTCxDQUFhMkIsK0JBQWIsS0FBaUQsRUFBckQsRUFBeUQ7QUFDdkQwRCxZQUFNLENBQUNqQixJQUFQLFlBQWdCLEtBQUtwRSxPQUFMLENBQWEyQiwrQkFBN0IsY0FBZ0UsS0FBSzNCLE9BQUwsQ0FBYThCLHVCQUE3RTtBQUNEOztBQUNEdUQsVUFBTSxDQUFDakIsSUFBUCxDQUFZLEdBQVo7QUFFQSxVQUFNNkIsYUFBYSxHQUFHO0FBQ3BCWixZQUFNLEVBQUVBLE1BQU0sQ0FBQ2YsSUFBUCxDQUFZLEVBQVosRUFBZ0JvRCxPQUFoQixDQUF3QixjQUF4QixFQUF3Q3RDLFFBQXhDLENBRFk7QUFFcEJjLFdBQUssRUFBRztBQUZZLEtBQXRCO0FBS0F4RyxhQUFTLENBQUMsb0JBQUQsRUFBdUJ1RyxhQUFhLENBQUNaLE1BQXJDLENBQVQ7QUFFQSxVQUFNOEIsTUFBTSxHQUFHLEtBQUt0RSxhQUFMLENBQW1CLEtBQUs3QyxPQUFMLENBQWFlLE1BQWhDLEVBQXdDa0YsYUFBeEMsQ0FBZjs7QUFFQSxRQUFJLENBQUNtQixLQUFLLENBQUNDLE9BQU4sQ0FBY0YsTUFBZCxDQUFELElBQTBCQSxNQUFNLENBQUMxQixNQUFQLEtBQWtCLENBQWhELEVBQW1EO0FBQ2pELGFBQU8sS0FBUDtBQUNEOztBQUNELFdBQU8sSUFBUDtBQUNEOztBQUVEc0Msc0JBQW9CLENBQUNDLEtBQUQsRUFBUTtBQUMxQixVQUFNQyxNQUFNLEdBQUc7QUFDYkMsVUFBSSxFQUFFRixLQUFLLENBQUNHO0FBREMsS0FBZjtBQUlBQyxVQUFNLENBQUNDLElBQVAsQ0FBWUosTUFBTSxDQUFDQyxJQUFuQixFQUF5QmhFLE9BQXpCLENBQWtDb0UsR0FBRCxJQUFTO0FBQ3hDLFlBQU10RyxLQUFLLEdBQUdpRyxNQUFNLENBQUNDLElBQVAsQ0FBWUksR0FBWixDQUFkOztBQUVBLFVBQUksQ0FBQyxDQUFDLGdCQUFELEVBQW1CLFdBQW5CLEVBQWdDQyxRQUFoQyxDQUF5Q0QsR0FBekMsQ0FBTCxFQUFvRDtBQUNsRCxZQUFJdEcsS0FBSyxZQUFZK0UsTUFBckIsRUFBNkI7QUFDM0JrQixnQkFBTSxDQUFDSyxHQUFELENBQU4sR0FBY3RHLEtBQUssQ0FBQ2tGLFFBQU4sRUFBZDtBQUNELFNBRkQsTUFFTztBQUNMZSxnQkFBTSxDQUFDSyxHQUFELENBQU4sR0FBY3RHLEtBQWQ7QUFDRDtBQUNGO0FBQ0YsS0FWRDtBQVlBLFdBQU9pRyxNQUFQO0FBQ0Q7O0FBRUR6QixnQkFBYyxDQUFDekYsTUFBRCxFQUFTZixPQUFULEVBQWtCZ0csSUFBbEIsRUFBd0I7QUFDcEMsU0FBS0YsZUFBTDs7QUFFQSxVQUFNMEMsV0FBVyxHQUFHLFVBQW1DO0FBQUEsVUFBbEM7QUFBRUMsZUFBRjtBQUFXQyxhQUFYO0FBQWtCQyxXQUFsQjtBQUF1QkM7QUFBdkIsT0FBa0M7QUFDckRqSixjQUFRLENBQUMrSSxLQUFELENBQVIsQ0FEcUQsQ0FFckQ7O0FBQ0EsV0FBS2xFLE1BQUwsQ0FBWXFFLFdBQVosQ0FBd0IsSUFBeEI7O0FBQ0E3QyxVQUFJLENBQUMsSUFBRCxFQUFPeUMsT0FBUCxFQUFnQjtBQUNsQkUsV0FEa0I7QUFDYkMsWUFBSSxFQUFFLE1BQU07QUFDZjtBQUNBLGVBQUtwRSxNQUFMLENBQVlxRSxXQUFaOztBQUNBRCxjQUFJLElBQUlBLElBQUksRUFBWjtBQUNEO0FBTGlCLE9BQWhCLENBQUo7QUFPRCxLQVhEOztBQWFBLFNBQUtwRSxNQUFMLENBQVlzRSxNQUFaLENBQW1CL0gsTUFBbkIsRUFBMkJmLE9BQTNCLEVBQW9DLENBQUM2RSxLQUFELEVBQVFrRSxHQUFSLEtBQWdCO0FBQ2xELFVBQUlsRSxLQUFKLEVBQVc7QUFDVGhGLGlCQUFTLENBQUNnRixLQUFELENBQVQ7QUFDQW1CLFlBQUksQ0FBQ25CLEtBQUQsQ0FBSjtBQUNBO0FBQ0Q7O0FBRURrRSxTQUFHLENBQUNuRSxFQUFKLENBQU8sT0FBUCxFQUFpQkMsS0FBRCxJQUFXO0FBQ3pCaEYsaUJBQVMsQ0FBQ2dGLEtBQUQsQ0FBVDtBQUNBbUIsWUFBSSxDQUFDbkIsS0FBRCxDQUFKO0FBQ0E7QUFDRCxPQUpEO0FBTUEsVUFBSTRELE9BQU8sR0FBRyxFQUFkO0FBRUEsWUFBTU8sZ0JBQWdCLEdBQUdoSixPQUFPLENBQUNxRyxLQUFSLElBQWlCckcsT0FBTyxDQUFDcUcsS0FBUixDQUFjQyxRQUFkLEdBQXlCLENBQTFDLEdBQThDdEcsT0FBTyxDQUFDcUcsS0FBUixDQUFjQyxRQUFkLEdBQXlCLENBQXZFLEdBQTJFLEdBQXBHO0FBRUF5QyxTQUFHLENBQUNuRSxFQUFKLENBQU8sYUFBUCxFQUF1Qm9ELEtBQUQsSUFBVztBQUMvQlMsZUFBTyxDQUFDckUsSUFBUixDQUFhLEtBQUsyRCxvQkFBTCxDQUEwQkMsS0FBMUIsQ0FBYjs7QUFFQSxZQUFJUyxPQUFPLENBQUNoRCxNQUFSLElBQWtCdUQsZ0JBQXRCLEVBQXdDO0FBQ3RDUixxQkFBVyxDQUFDO0FBQ1ZDLG1CQURVO0FBRVZDLGlCQUFLLEVBQUUsZUFGRztBQUdWQyxlQUFHLEVBQUk7QUFIRyxXQUFELENBQVg7QUFLQUYsaUJBQU8sR0FBRyxFQUFWO0FBQ0Q7QUFDRixPQVhEO0FBYUFNLFNBQUcsQ0FBQ25FLEVBQUosQ0FBTyxNQUFQLEVBQWUsQ0FBQ3VDLE1BQUQsRUFBU3lCLElBQVQsS0FBa0I7QUFDL0IsWUFBSSxDQUFDQSxJQUFMLEVBQVc7QUFDVCxlQUFLcEUsTUFBTCxDQUFZcUUsV0FBWixDQUF3QixJQUF4Qjs7QUFDQUwscUJBQVcsQ0FBQztBQUNWQyxtQkFEVTtBQUVWQyxpQkFBSyxFQUFFLFlBRkc7QUFHVkMsZUFBRyxFQUFJO0FBSEcsV0FBRCxDQUFYO0FBS0QsU0FQRCxNQU9PLElBQUlGLE9BQU8sQ0FBQ2hELE1BQVosRUFBb0I7QUFDekI5RixrQkFBUSxDQUFDLE1BQUQsQ0FBUjtBQUNBNkkscUJBQVcsQ0FBQztBQUNWQyxtQkFEVTtBQUVWQyxpQkFBSyxFQUFFLE1BRkc7QUFHVkMsZUFBRyxFQUFJLEtBSEc7QUFJVkM7QUFKVSxXQUFELENBQVg7QUFNQUgsaUJBQU8sR0FBRyxFQUFWO0FBQ0Q7QUFDRixPQWxCRDtBQW9CQU0sU0FBRyxDQUFDbkUsRUFBSixDQUFPLEtBQVAsRUFBYyxNQUFNO0FBQ2xCLFlBQUk2RCxPQUFPLENBQUNoRCxNQUFaLEVBQW9CO0FBQ2xCK0MscUJBQVcsQ0FBQztBQUNWQyxtQkFEVTtBQUVWQyxpQkFBSyxFQUFFLFlBRkc7QUFHVkMsZUFBRyxFQUFJO0FBSEcsV0FBRCxDQUFYO0FBS0FGLGlCQUFPLEdBQUcsRUFBVjtBQUNEO0FBQ0YsT0FURDtBQVVELEtBNUREO0FBNkREOztBQUVEMUYsZ0JBQWMsQ0FBQ2hDLE1BQUQsRUFBU2YsT0FBVCxFQUFrQmdELFFBQWxCLEVBQTRCO0FBQ3hDLFNBQUs4QyxlQUFMO0FBRUEsU0FBS3RCLE1BQUwsQ0FBWXNFLE1BQVosQ0FBbUIvSCxNQUFuQixFQUEyQmYsT0FBM0IsRUFBb0MsQ0FBQzZFLEtBQUQsRUFBUWtFLEdBQVIsS0FBZ0I7QUFDbEQsVUFBSWxFLEtBQUosRUFBVztBQUNUaEYsaUJBQVMsQ0FBQ2dGLEtBQUQsQ0FBVDtBQUNBN0IsZ0JBQVEsQ0FBQzZCLEtBQUQsQ0FBUjtBQUNBO0FBQ0Q7O0FBRURrRSxTQUFHLENBQUNuRSxFQUFKLENBQU8sT0FBUCxFQUFpQkMsS0FBRCxJQUFXO0FBQ3pCaEYsaUJBQVMsQ0FBQ2dGLEtBQUQsQ0FBVDtBQUNBN0IsZ0JBQVEsQ0FBQzZCLEtBQUQsQ0FBUjtBQUNBO0FBQ0QsT0FKRDtBQU1BLFlBQU00RCxPQUFPLEdBQUcsRUFBaEI7QUFFQU0sU0FBRyxDQUFDbkUsRUFBSixDQUFPLGFBQVAsRUFBdUJvRCxLQUFELElBQVc7QUFDL0JTLGVBQU8sQ0FBQ3JFLElBQVIsQ0FBYSxLQUFLMkQsb0JBQUwsQ0FBMEJDLEtBQTFCLENBQWI7QUFDRCxPQUZEO0FBSUFlLFNBQUcsQ0FBQ25FLEVBQUosQ0FBTyxLQUFQLEVBQWMsTUFBTTtBQUNsQmpGLGdCQUFRLENBQUMscUJBQUQsRUFBd0I4SSxPQUFPLENBQUNoRCxNQUFoQyxDQUFSO0FBQ0F6QyxnQkFBUSxDQUFDLElBQUQsRUFBT3lGLE9BQVAsQ0FBUjtBQUNELE9BSEQ7QUFJRCxLQXZCRDtBQXdCRDs7QUFFRFEsVUFBUSxDQUFDQyxFQUFELEVBQUt2RCxRQUFMLEVBQWU7QUFDckJoRyxZQUFRLENBQUMsZ0JBQUQsRUFBbUJ1SixFQUFuQixDQUFSOztBQUVBLFFBQUk7QUFDRixVQUFJdkQsUUFBUSxLQUFLLEVBQWpCLEVBQXFCO0FBQ25CLGNBQU0sSUFBSVQsS0FBSixDQUFVLDBCQUFWLENBQU47QUFDRDs7QUFDRCxXQUFLUixRQUFMLENBQWN3RSxFQUFkLEVBQWtCdkQsUUFBbEI7QUFDQWhHLGNBQVEsQ0FBQyxlQUFELEVBQWtCdUosRUFBbEIsQ0FBUjtBQUNBLGFBQU8sSUFBUDtBQUNELEtBUEQsQ0FPRSxPQUFPckUsS0FBUCxFQUFjO0FBQ2RsRixjQUFRLENBQUMsbUJBQUQsRUFBc0J1SixFQUF0QixDQUFSO0FBQ0F4SixlQUFTLENBQUMsT0FBRCxFQUFVbUYsS0FBVixDQUFUO0FBQ0EsYUFBTyxLQUFQO0FBQ0Q7QUFDRjs7QUFFREMsWUFBVSxHQUFHO0FBQ1gsU0FBSy9FLFNBQUwsR0FBb0IsS0FBcEI7QUFDQSxTQUFLNkYsWUFBTCxHQUFvQixLQUFwQjtBQUNBakcsWUFBUSxDQUFDLGNBQUQsQ0FBUjtBQUNBLFNBQUs2RSxNQUFMLENBQVkyRSxNQUFaO0FBQ0Q7O0FBaGtCdUIsQzs7Ozs7Ozs7Ozs7QUNOMUJsSyxNQUFNLENBQUNFLE1BQVAsQ0FBYztBQUFDb0UsS0FBRyxFQUFDLE1BQUlBLEdBQVQ7QUFBYTdELFdBQVMsRUFBQyxNQUFJQSxTQUEzQjtBQUFxQ0MsVUFBUSxFQUFDLE1BQUlBLFFBQWxEO0FBQTJEQyxVQUFRLEVBQUMsTUFBSUEsUUFBeEU7QUFBaUZDLFdBQVMsRUFBQyxNQUFJQTtBQUEvRixDQUFkO0FBQUEsTUFBTXVKLFlBQVksR0FBSW5ILE9BQU8sQ0FBQ0MsR0FBUixDQUFZbUgsZ0JBQVosS0FBaUMsTUFBdkQ7O0FBR0EsU0FBUzlGLEdBQVQsQ0FBY0ksS0FBZCxFQUFxQjJGLE9BQXJCLEVBQThCQyxJQUE5QixFQUFvQztBQUNoQyxNQUFJSCxZQUFKLEVBQWtCO0FBQ2RJLFdBQU8sQ0FBQ2pHLEdBQVIsWUFBZ0JJLEtBQWhCLGVBQTBCMkYsT0FBMUIsY0FBc0NDLElBQUksR0FBR25ILElBQUksQ0FBQ3FILFNBQUwsQ0FBZUYsSUFBZixFQUFxQixJQUFyQixFQUEyQixDQUEzQixDQUFILEdBQW1DLEVBQTdFO0FBQ0g7QUFDSjs7QUFFRCxTQUFTN0osU0FBVCxHQUE2QjtBQUFBLG9DQUFOZ0ssSUFBTTtBQUFOQSxRQUFNO0FBQUE7O0FBQUVuRyxLQUFHLENBQUMsT0FBRCxFQUFVLEdBQUdtRyxJQUFiLENBQUg7QUFBd0I7O0FBQ3ZELFNBQVMvSixRQUFULEdBQTRCO0FBQUEscUNBQU4rSixJQUFNO0FBQU5BLFFBQU07QUFBQTs7QUFBRW5HLEtBQUcsQ0FBQyxNQUFELEVBQVMsR0FBR21HLElBQVosQ0FBSDtBQUF1Qjs7QUFDckQsU0FBUzlKLFFBQVQsR0FBNEI7QUFBQSxxQ0FBTjhKLElBQU07QUFBTkEsUUFBTTtBQUFBOztBQUFFbkcsS0FBRyxDQUFDLE1BQUQsRUFBUyxHQUFHbUcsSUFBWixDQUFIO0FBQXVCOztBQUNyRCxTQUFTN0osU0FBVCxHQUE2QjtBQUFBLHFDQUFONkosSUFBTTtBQUFOQSxRQUFNO0FBQUE7O0FBQUVuRyxLQUFHLENBQUMsT0FBRCxFQUFVLEdBQUdtRyxJQUFiLENBQUg7QUFBd0IsQzs7Ozs7Ozs7Ozs7QUNadkQsSUFBSUMsSUFBSixFQUFTQyxlQUFULEVBQXlCQyxZQUF6QixFQUFzQ0MsbUJBQXRDLEVBQTBEQyxZQUExRCxFQUF1RUMsV0FBdkU7QUFBbUYvSyxNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUN5SyxNQUFJLENBQUNwSyxDQUFELEVBQUc7QUFBQ29LLFFBQUksR0FBQ3BLLENBQUw7QUFBTyxHQUFoQjs7QUFBaUJxSyxpQkFBZSxDQUFDckssQ0FBRCxFQUFHO0FBQUNxSyxtQkFBZSxHQUFDckssQ0FBaEI7QUFBa0IsR0FBdEQ7O0FBQXVEc0ssY0FBWSxDQUFDdEssQ0FBRCxFQUFHO0FBQUNzSyxnQkFBWSxHQUFDdEssQ0FBYjtBQUFlLEdBQXRGOztBQUF1RnVLLHFCQUFtQixDQUFDdkssQ0FBRCxFQUFHO0FBQUN1Syx1QkFBbUIsR0FBQ3ZLLENBQXBCO0FBQXNCLEdBQXBJOztBQUFxSXdLLGNBQVksQ0FBQ3hLLENBQUQsRUFBRztBQUFDd0ssZ0JBQVksR0FBQ3hLLENBQWI7QUFBZSxHQUFwSzs7QUFBcUt5SyxhQUFXLENBQUN6SyxDQUFELEVBQUc7QUFBQ3lLLGVBQVcsR0FBQ3pLLENBQVo7QUFBYzs7QUFBbE0sQ0FBckIsRUFBeU4sQ0FBek47QUFBNE4sSUFBSUYsSUFBSjtBQUFTSixNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNFLFNBQU8sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNGLFFBQUksR0FBQ0UsQ0FBTDtBQUFPOztBQUFuQixDQUFyQixFQUEwQyxDQUExQztBQUE2QyxJQUFJRyxTQUFKLEVBQWNDLFFBQWQsRUFBdUJDLFFBQXZCLEVBQWdDQyxTQUFoQztBQUEwQ1osTUFBTSxDQUFDQyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDUSxXQUFTLENBQUNILENBQUQsRUFBRztBQUFDRyxhQUFTLEdBQUNILENBQVY7QUFBWSxHQUExQjs7QUFBMkJJLFVBQVEsQ0FBQ0osQ0FBRCxFQUFHO0FBQUNJLFlBQVEsR0FBQ0osQ0FBVDtBQUFXLEdBQWxEOztBQUFtREssVUFBUSxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssWUFBUSxHQUFDTCxDQUFUO0FBQVcsR0FBMUU7O0FBQTJFTSxXQUFTLENBQUNOLENBQUQsRUFBRztBQUFDTSxhQUFTLEdBQUNOLENBQVY7QUFBWTs7QUFBcEcsQ0FBdkIsRUFBNkgsQ0FBN0g7O0FBSS9ZLFNBQVMwSyw0QkFBVCxDQUFzQ3RGLElBQXRDLEVBQTRDUyxRQUE1QyxFQUFzRE8sUUFBdEQsRUFBZ0U7QUFDOUQsTUFBSSxPQUFPUCxRQUFQLEtBQW9CLFFBQXhCLEVBQWtDO0FBQ2hDLFFBQUlBLFFBQVEsQ0FBQzhFLE9BQVQsQ0FBaUIsR0FBakIsTUFBMEIsQ0FBQyxDQUEvQixFQUFrQztBQUNoQzlFLGNBQVEsR0FBRztBQUFDQTtBQUFELE9BQVg7QUFDRCxLQUZELE1BRU87QUFDTEEsY0FBUSxHQUFHO0FBQUMrRSxhQUFLLEVBQUUvRTtBQUFSLE9BQVg7QUFDRDtBQUNGOztBQUVEekYsVUFBUSxDQUFDLHNDQUFELEVBQXlDeUYsUUFBekMsQ0FBUjtBQUVBLFFBQU1nRixZQUFZLEdBQUc7QUFDbkJDLFFBQUksRUFBRWpGLFFBRGE7QUFFbkJPLFlBQVEsRUFBRTtBQUNSMkUsWUFBTSxFQUFFQyxNQUFNLENBQUM1RSxRQUFELENBRE47QUFFUjZFLGVBQVMsRUFBRTtBQUZIO0FBRlMsR0FBckI7QUFPQTlLLFdBQVMsQ0FBQyxvQkFBRCxFQUF1QjBLLFlBQXZCLENBQVQ7QUFFQSxTQUFPSyxRQUFRLENBQUNDLGlCQUFULENBQTJCL0YsSUFBM0IsRUFBaUN5RixZQUFqQyxDQUFQO0FBQ0Q7O0FBRURLLFFBQVEsQ0FBQ0Usb0JBQVQsQ0FBOEIsTUFBOUIsRUFBc0MsVUFBU1AsWUFBVCxFQUF1QjtBQUMzRCxNQUFJLENBQUNBLFlBQVksQ0FBQ1EsSUFBZCxJQUFzQixDQUFDUixZQUFZLENBQUNTLFdBQXhDLEVBQXFEO0FBQ25ELFdBQU8xSSxTQUFQO0FBQ0Q7O0FBRUR4QyxVQUFRLENBQUMsaUJBQUQsRUFBb0J5SyxZQUFZLENBQUNoRixRQUFqQyxDQUFSOztBQUVBLE1BQUkvRixJQUFJLENBQUNhLFlBQUwsQ0FBa0IsYUFBbEIsTUFBcUMsSUFBekMsRUFBK0M7QUFDN0MsV0FBTytKLDRCQUE0QixDQUFDLElBQUQsRUFBT0csWUFBWSxDQUFDaEYsUUFBcEIsRUFBOEJnRixZQUFZLENBQUNVLFFBQTNDLENBQW5DO0FBQ0Q7O0FBRUQsUUFBTUMsSUFBSSxHQUFHLElBQWI7QUFDQSxRQUFNSCxJQUFJLEdBQUcsSUFBSXZMLElBQUosRUFBYjtBQUNBLE1BQUltSSxRQUFKOztBQUVBLE1BQUk7QUFFQW9ELFFBQUksQ0FBQ3BJLFdBQUw7O0FBRUQsUUFBSSxDQUFDLENBQUNuRCxJQUFJLENBQUNhLFlBQUwsQ0FBa0IsMEJBQWxCLENBQU4sRUFBcUQ7QUFDbEQwSyxVQUFJLENBQUNsRixtQkFBTCxDQUF5QjBFLFlBQVksQ0FBQ2hGLFFBQXRDLEVBQWdEZ0YsWUFBWSxDQUFDVSxRQUE3RDtBQUNEdEQsY0FBUSxHQUFHb0QsSUFBSSxDQUFDN0UsZUFBTCxDQUFxQnFFLFlBQVksQ0FBQ2hGLFFBQWxDLEVBQTRDLENBQTVDLENBQVg7QUFDQyxLQUhILE1BR1M7QUFFUCxZQUFNNEYsS0FBSyxHQUFHSixJQUFJLENBQUM3RSxlQUFMLENBQXFCcUUsWUFBWSxDQUFDaEYsUUFBbEMsQ0FBZDs7QUFFQSxVQUFJNEYsS0FBSyxDQUFDdkYsTUFBTixLQUFpQixDQUFyQixFQUF3QjtBQUN0QjlGLGdCQUFRLENBQUMsaUJBQUQsRUFBb0JxTCxLQUFLLENBQUN2RixNQUExQixFQUFrQyxlQUFsQyxFQUFtRDJFLFlBQVksQ0FBQ2hGLFFBQWhFLENBQVI7QUFDQSxjQUFNLElBQUlGLEtBQUosQ0FBVSxnQkFBVixDQUFOO0FBQ0Q7O0FBRUQsVUFBSTBGLElBQUksQ0FBQzNCLFFBQUwsQ0FBYytCLEtBQUssQ0FBQyxDQUFELENBQUwsQ0FBUzlCLEVBQXZCLEVBQTJCa0IsWUFBWSxDQUFDVSxRQUF4QyxNQUFzRCxJQUExRCxFQUFnRTtBQUM5RCxZQUFJRixJQUFJLENBQUMvQyxhQUFMLENBQW1CdUMsWUFBWSxDQUFDaEYsUUFBaEMsRUFBMEM0RixLQUFLLENBQUMsQ0FBRCxDQUEvQyxDQUFKLEVBQXlEO0FBQ3ZEeEQsa0JBQVEsR0FBR3dELEtBQUssQ0FBQyxDQUFELENBQWhCO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsZ0JBQU0sSUFBSTlGLEtBQUosQ0FBVSwyQkFBVixDQUFOO0FBQ0Q7QUFDRixPQU5ELE1BTU87QUFDTHZGLGdCQUFRLENBQUMsb0JBQUQsRUFBdUJ5SyxZQUFZLENBQUNoRixRQUFwQyxDQUFSO0FBQ0Q7QUFDRjtBQUdILEdBNUJELENBNEJFLE9BQU9QLEtBQVAsRUFBYztBQUNiaEYsYUFBUyxDQUFDZ0YsS0FBRCxDQUFUO0FBQ0Y7O0FBRUQsTUFBSSxDQUFDMkMsUUFBTCxFQUFlO0FBQ2IsUUFBSW5JLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixxQkFBbEIsTUFBNkMsSUFBakQsRUFBdUQ7QUFDckQsYUFBTytKLDRCQUE0QixDQUFDYyxJQUFELEVBQU9YLFlBQVksQ0FBQ2hGLFFBQXBCLEVBQThCZ0YsWUFBWSxDQUFDVSxRQUEzQyxDQUFuQztBQUNEOztBQUVELFVBQU0sSUFBSXBJLE1BQU0sQ0FBQ3dDLEtBQVgsQ0FBaUIsa0JBQWpCLCtEQUE0RmtGLFlBQVksQ0FBQ2hGLFFBQXpHLE9BQU47QUFDRCxHQXJEMEQsQ0F1RDNEOzs7QUFFQSxNQUFJNkYsU0FBSjtBQUVBLFFBQU1yRSx1QkFBdUIsR0FBR2tELG1CQUFtQixDQUFDdEMsUUFBRCxDQUFuRDtBQUNBLE1BQUk2QyxJQUFKLENBNUQyRCxDQTZEMUQ7O0FBRUQsTUFBSXpELHVCQUFKLEVBQTZCO0FBQzNCcUUsYUFBUyxHQUFHO0FBQ1YsMEJBQW9CckUsdUJBQXVCLENBQUM1RTtBQURsQyxLQUFaO0FBSUFyQyxZQUFRLENBQUMsZUFBRCxDQUFSO0FBQ0FELGFBQVMsQ0FBQyxXQUFELEVBQWN1TCxTQUFkLENBQVQ7QUFFQVosUUFBSSxHQUFHM0gsTUFBTSxDQUFDc0ksS0FBUCxDQUFhRSxPQUFiLENBQXFCRCxTQUFyQixDQUFQO0FBQ0EsR0F4RXlELENBMEUzRDs7O0FBRUEsTUFBSTdGLFFBQUo7QUFDQSxNQUFJK0UsS0FBSjs7QUFFQyxNQUFJOUssSUFBSSxDQUFDYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxFQUFqRCxFQUFxRDtBQUNwRGtGLFlBQVEsR0FBR3VFLElBQUksQ0FBQ0MsZUFBZSxDQUFDcEMsUUFBRCxDQUFoQixDQUFmO0FBQ0QsR0FGQSxNQUVNO0FBQ0xwQyxZQUFRLEdBQUd1RSxJQUFJLENBQUNTLFlBQVksQ0FBQ2hGLFFBQWQsQ0FBZjtBQUNEOztBQUVELE1BQUcvRixJQUFJLENBQUNhLFlBQUwsQ0FBa0Isa0JBQWxCLE1BQTBDLEVBQTdDLEVBQWlEO0FBQy9DaUssU0FBSyxHQUFHTixZQUFZLENBQUNyQyxRQUFELENBQXBCO0FBQ0Q7O0FBR0QsTUFBSSxDQUFDNkMsSUFBTCxFQUFXO0FBQ1QsUUFBR0YsS0FBSyxJQUFJOUssSUFBSSxDQUFDYSxZQUFMLENBQWtCLDBCQUFsQixNQUFrRCxJQUE5RCxFQUFvRTtBQUNsRSxVQUFHYixJQUFJLENBQUNhLFlBQUwsQ0FBa0IsMkJBQWxCLE1BQW1ELElBQXRELEVBQTREO0FBQzFEK0ssaUJBQVMsR0FBRztBQUNWLGlCQUFRN0YsUUFERTtBQUVWLDhCQUFxQitFLEtBRlg7QUFHViwrQkFBc0I7QUFIWixTQUFaO0FBS0QsT0FORCxNQU1PO0FBQ0xjLGlCQUFTLEdBQUc7QUFDVixpQkFBUTdGLFFBREU7QUFFViw4QkFBcUIrRTtBQUZYLFNBQVo7QUFJRDtBQUNGLEtBYkQsTUFhTztBQUNMYyxlQUFTLEdBQUc7QUFDVjdGO0FBRFUsT0FBWjtBQUdEOztBQUVEMUYsYUFBUyxDQUFDLFdBQUQsRUFBY3VMLFNBQWQsQ0FBVDtBQUVBWixRQUFJLEdBQUczSCxNQUFNLENBQUNzSSxLQUFQLENBQWFFLE9BQWIsQ0FBcUJELFNBQXJCLENBQVA7QUFDRCxHQWpIMEQsQ0FtSDNEOzs7QUFFQSxNQUFJLENBQUNaLElBQUQsSUFBU0YsS0FBVCxJQUFrQjlLLElBQUksQ0FBQ2EsWUFBTCxDQUFrQix5QkFBbEIsTUFBaUQsSUFBdkUsRUFBNkU7QUFFM0VQLFlBQVEsQ0FBQyw4QkFBRCxFQUFpQ3lGLFFBQWpDLEVBQTJDLGdEQUEzQyxDQUFSOztBQUVBLFFBQUcvRixJQUFJLENBQUNhLFlBQUwsQ0FBa0IsMkJBQWxCLE1BQW1ELElBQXRELEVBQTREO0FBQzFEK0ssZUFBUyxHQUFHO0FBQ1YsNEJBQW9CZCxLQURWO0FBRVYsNkJBQXNCO0FBRlosT0FBWjtBQUlELEtBTEQsTUFLTztBQUNMYyxlQUFTLEdBQUc7QUFDViw0QkFBcUJkO0FBRFgsT0FBWjtBQUdEOztBQUVEekssYUFBUyxDQUFDLFdBQUQsRUFBY3VMLFNBQWQsQ0FBVDtBQUVBWixRQUFJLEdBQUczSCxNQUFNLENBQUNzSSxLQUFQLENBQWFFLE9BQWIsQ0FBcUJELFNBQXJCLENBQVA7QUFFRCxHQXhJMEQsQ0EwSTNEOzs7QUFDQSxNQUFJWixJQUFKLEVBQVU7QUFDUixRQUFJQSxJQUFJLENBQUNjLG9CQUFMLEtBQThCLE1BQTlCLElBQXdDOUwsSUFBSSxDQUFDYSxZQUFMLENBQWtCLDJCQUFsQixNQUFtRCxJQUEvRixFQUFxRztBQUNuR1AsY0FBUSxDQUFDLG1EQUFELENBQVI7QUFDQSxZQUFNLElBQUkrQyxNQUFNLENBQUN3QyxLQUFYLENBQWlCLGtCQUFqQiwwRkFBTjtBQUNEOztBQUVEdkYsWUFBUSxDQUFDLGNBQUQsQ0FBUjs7QUFFQSxVQUFNeUwsWUFBWSxHQUFHWCxRQUFRLENBQUNZLDBCQUFULEVBQXJCOztBQUNBLFVBQU1DLFdBQVcsR0FBRztBQUNsQkMsV0FBSyxFQUFFO0FBQ0wsdUNBQStCZCxRQUFRLENBQUNlLGlCQUFULENBQTJCSixZQUEzQjtBQUQxQjtBQURXLEtBQXBCOztBQU1BLFFBQUkvTCxJQUFJLENBQUNhLFlBQUwsQ0FBa0Isd0JBQWxCLE1BQWdELElBQXBELEVBQTBEO0FBQ3hEUixlQUFTLENBQUMsdUJBQUQsQ0FBVDtBQUNBLFlBQU0rTCxZQUFZLEdBQUdwTSxJQUFJLENBQUNhLFlBQUwsQ0FBa0Isd0JBQWxCLEVBQTRDNkQsS0FBNUMsQ0FBa0QsR0FBbEQsQ0FBckI7QUFDQSxZQUFNNkQsTUFBTSxHQUFHZ0QsSUFBSSxDQUFDckQsYUFBTCxDQUFtQm5DLFFBQW5CLEVBQTZCb0MsUUFBN0IsRUFBdUNuQyxNQUF2QyxDQUErQ3JELEtBQUQsSUFBV3lKLFlBQVksQ0FBQ2xELFFBQWIsQ0FBc0J2RyxLQUF0QixDQUF6RCxDQUFmO0FBRUFxSSxVQUFJLENBQUNxQixPQUFMLEdBQWU5RCxNQUFNLENBQUNuQyxNQUFQLEdBQWdCLENBQS9CO0FBQ0EvQyxZQUFNLENBQUNzSSxLQUFQLENBQWFXLE1BQWIsQ0FBb0I7QUFBQ0MsV0FBRyxFQUFFdkIsSUFBSSxDQUFDdUI7QUFBWCxPQUFwQixFQUFxQztBQUFDQyxZQUFJLEVBQUU7QUFBQ0gsaUJBQU8sRUFBRXJCLElBQUksQ0FBQ3FCO0FBQWY7QUFBUCxPQUFyQztBQUNEOztBQUVELFFBQUlyTSxJQUFJLENBQUNhLFlBQUwsQ0FBa0IsdUJBQWxCLE1BQStDLElBQW5ELEVBQTBEO0FBQ3hEUixlQUFTLENBQUMsdUJBQUQsQ0FBVDtBQUNBLFlBQU1rSSxNQUFNLEdBQUdnRCxJQUFJLENBQUNyRCxhQUFMLENBQW1CbkMsUUFBbkIsRUFBNkJvQyxRQUE3QixDQUFmOztBQUVBLFVBQUlJLE1BQU0sQ0FBQ25DLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBd0I7QUFDdEJxRyxhQUFLLENBQUNDLFlBQU4sQ0FBbUIxQixJQUFJLENBQUN1QixHQUF4QixFQUE2QmhFLE1BQTdCO0FBQ0FqSSxnQkFBUSw0QkFBdUJpSSxNQUFNLENBQUN0RCxJQUFQLENBQVksR0FBWixDQUF2QixFQUFSO0FBQ0Q7QUFDRjs7QUFFRDVCLFVBQU0sQ0FBQ3NJLEtBQVAsQ0FBYVcsTUFBYixDQUFvQnRCLElBQUksQ0FBQ3VCLEdBQXpCLEVBQThCTixXQUE5QjtBQUVBdkIsZ0JBQVksQ0FBQ00sSUFBRCxFQUFPN0MsUUFBUCxDQUFaOztBQUVBLFFBQUluSSxJQUFJLENBQUNhLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLElBQWpELEVBQXVEO0FBQ3JEdUssY0FBUSxDQUFDdUIsV0FBVCxDQUFxQjNCLElBQUksQ0FBQ3VCLEdBQTFCLEVBQStCeEIsWUFBWSxDQUFDVSxRQUE1QyxFQUFzRDtBQUFDbUIsY0FBTSxFQUFFO0FBQVQsT0FBdEQ7QUFDRDs7QUFFRCxXQUFPO0FBQ0xDLFlBQU0sRUFBRTdCLElBQUksQ0FBQ3VCLEdBRFI7QUFFTE8sV0FBSyxFQUFFZixZQUFZLENBQUNlO0FBRmYsS0FBUDtBQUlELEdBekwwRCxDQTJMM0Q7OztBQUVBeE0sVUFBUSxDQUFDLCtCQUFELEVBQWtDeUYsUUFBbEMsQ0FBUjs7QUFFQSxNQUFJL0YsSUFBSSxDQUFDYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxFQUFqRCxFQUFxRDtBQUNuRGtGLFlBQVEsR0FBR2pELFNBQVg7QUFDRDs7QUFFRCxNQUFJOUMsSUFBSSxDQUFDYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxJQUFqRCxFQUF1RDtBQUNyRGtLLGdCQUFZLENBQUNVLFFBQWIsR0FBd0IzSSxTQUF4QjtBQUNEOztBQUVELFFBQU1nRixNQUFNLEdBQUc2QyxXQUFXLENBQUN4QyxRQUFELEVBQVdwQyxRQUFYLEVBQXFCZ0YsWUFBWSxDQUFDVSxRQUFsQyxDQUExQjs7QUFFQSxNQUFJekwsSUFBSSxDQUFDYSxZQUFMLENBQWtCLHdCQUFsQixNQUFnRCxJQUFwRCxFQUEwRDtBQUN4RFIsYUFBUyxDQUFDLHVCQUFELENBQVQ7QUFDQSxVQUFNK0wsWUFBWSxHQUFHcE0sSUFBSSxDQUFDYSxZQUFMLENBQWtCLHdCQUFsQixFQUE0QzZELEtBQTVDLENBQWtELEdBQWxELENBQXJCO0FBQ0EsVUFBTTZELE1BQU0sR0FBR2dELElBQUksQ0FBQ3JELGFBQUwsQ0FBbUJuQyxRQUFuQixFQUE2Qm9DLFFBQTdCLEVBQXVDbkMsTUFBdkMsQ0FBK0NyRCxLQUFELElBQVd5SixZQUFZLENBQUNsRCxRQUFiLENBQXNCdkcsS0FBdEIsQ0FBekQsQ0FBZjtBQUVBbUYsVUFBTSxDQUFDdUUsT0FBUCxHQUFpQjlELE1BQU0sQ0FBQ25DLE1BQVAsR0FBZ0IsQ0FBakM7QUFDQS9DLFVBQU0sQ0FBQ3NJLEtBQVAsQ0FBYVcsTUFBYixDQUFvQjtBQUFDQyxTQUFHLEVBQUV6RSxNQUFNLENBQUMrRTtBQUFiLEtBQXBCLEVBQTBDO0FBQUNMLFVBQUksRUFBRTtBQUFDSCxlQUFPLEVBQUV2RSxNQUFNLENBQUN1RTtBQUFqQjtBQUFQLEtBQTFDO0FBQ0Q7O0FBRUQsTUFBSXJNLElBQUksQ0FBQ2EsWUFBTCxDQUFrQix1QkFBbEIsTUFBK0MsSUFBbkQsRUFBMEQ7QUFDeEQsVUFBTTBILE1BQU0sR0FBR2dELElBQUksQ0FBQ3JELGFBQUwsQ0FBbUJuQyxRQUFuQixFQUE2Qm9DLFFBQTdCLENBQWY7O0FBQ0EsUUFBSUksTUFBTSxDQUFDbkMsTUFBUCxHQUFnQixDQUFwQixFQUF3QjtBQUN0QnFHLFdBQUssQ0FBQ0MsWUFBTixDQUFtQjVFLE1BQU0sQ0FBQytFLE1BQTFCLEVBQWtDdEUsTUFBbEM7QUFDQWpJLGNBQVEsd0JBQW1CaUksTUFBTSxDQUFDdEQsSUFBUCxDQUFZLEdBQVosQ0FBbkIsRUFBUjtBQUNEO0FBQ0Y7O0FBR0QsTUFBSTZDLE1BQU0sWUFBWWpDLEtBQXRCLEVBQTZCO0FBQzNCLFVBQU1pQyxNQUFOO0FBQ0Q7O0FBRUQsU0FBT0EsTUFBUDtBQUNELENBaE9ELEU7Ozs7Ozs7Ozs7O0FDM0JBbEksTUFBTSxDQUFDRSxNQUFQLENBQWM7QUFBQ3dLLE1BQUksRUFBQyxNQUFJQSxJQUFWO0FBQWV5QyxrQkFBZ0IsRUFBQyxNQUFJQSxnQkFBcEM7QUFBcUR4QyxpQkFBZSxFQUFDLE1BQUlBLGVBQXpFO0FBQXlGQyxjQUFZLEVBQUMsTUFBSUEsWUFBMUc7QUFBdUh3QyxpQkFBZSxFQUFDLE1BQUlBLGVBQTNJO0FBQTJKdkMscUJBQW1CLEVBQUMsTUFBSUEsbUJBQW5MO0FBQXVNd0MsdUJBQXFCLEVBQUMsTUFBSUEscUJBQWpPO0FBQXVQdkMsY0FBWSxFQUFDLE1BQUlBLFlBQXhRO0FBQXFSQyxhQUFXLEVBQUMsTUFBSUEsV0FBclM7QUFBaVR1QyxnQkFBYyxFQUFDLE1BQUlBO0FBQXBVLENBQWQ7O0FBQW1XLElBQUlDLENBQUo7O0FBQU12TixNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNFLFNBQU8sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNpTixLQUFDLEdBQUNqTixDQUFGO0FBQUk7O0FBQWhCLENBQXpCLEVBQTJDLENBQTNDO0FBQThDLElBQUlrTixVQUFKO0FBQWV4TixNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDRSxTQUFPLENBQUNHLENBQUQsRUFBRztBQUFDa04sY0FBVSxHQUFDbE4sQ0FBWDtBQUFhOztBQUF6QixDQUEzQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJRixJQUFKO0FBQVNKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ0UsU0FBTyxDQUFDRyxDQUFELEVBQUc7QUFBQ0YsUUFBSSxHQUFDRSxDQUFMO0FBQU87O0FBQW5CLENBQXJCLEVBQTBDLENBQTFDO0FBQTZDLElBQUlHLFNBQUosRUFBY0MsUUFBZCxFQUF1QkMsUUFBdkIsRUFBZ0NDLFNBQWhDO0FBQTBDWixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNRLFdBQVMsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLGFBQVMsR0FBQ0gsQ0FBVjtBQUFZLEdBQTFCOztBQUEyQkksVUFBUSxDQUFDSixDQUFELEVBQUc7QUFBQ0ksWUFBUSxHQUFDSixDQUFUO0FBQVcsR0FBbEQ7O0FBQW1ESyxVQUFRLENBQUNMLENBQUQsRUFBRztBQUFDSyxZQUFRLEdBQUNMLENBQVQ7QUFBVyxHQUExRTs7QUFBMkVNLFdBQVMsQ0FBQ04sQ0FBRCxFQUFHO0FBQUNNLGFBQVMsR0FBQ04sQ0FBVjtBQUFZOztBQUFwRyxDQUF2QixFQUE2SCxDQUE3SDtBQUsva0I2SSxNQUFNLENBQUNzRSxjQUFQLENBQXNCdEUsTUFBTSxDQUFDdUUsU0FBN0IsRUFBd0MsY0FBeEMsRUFBd0Q7QUFDdEQzSyxPQUFLLEVBQUUsVUFBVTRLLElBQVYsRUFBZ0I7QUFDbkIsVUFBTTdCLElBQUksR0FBRyxJQUFiOztBQUNBLFNBQUssSUFBSXpDLEdBQVQsSUFBZ0J5QyxJQUFoQixFQUFzQjtBQUNsQixVQUFJekMsR0FBRyxDQUFDdUUsV0FBSixNQUFxQkQsSUFBSSxDQUFDQyxXQUFMLEVBQXpCLEVBQTZDO0FBQ3pDLGVBQU85QixJQUFJLENBQUN6QyxHQUFELENBQVg7QUFDSDtBQUNKO0FBQ0osR0FScUQ7QUFVdER3RSxZQUFVLEVBQUU7QUFWMEMsQ0FBeEQ7O0FBYU8sU0FBU25ELElBQVQsQ0FBY29ELElBQWQsRUFBb0I7QUFDekIsTUFBSTFOLElBQUksQ0FBQ2EsWUFBTCxDQUFrQix5QkFBbEIsTUFBaUQsSUFBckQsRUFBMkQ7QUFDekQsV0FBTzZNLElBQVA7QUFDRDs7QUFDREEsTUFBSSxHQUFHQyxPQUFPLENBQUNELElBQUQsRUFBTyxHQUFQLENBQWQ7QUFDQSxTQUFPQSxJQUFJLENBQUNyRixPQUFMLENBQWEsZUFBYixFQUE4QixFQUE5QixDQUFQO0FBQ0Q7O0FBRUQsU0FBU3VGLGtCQUFULENBQTZCQyxRQUE3QixFQUF1Q0MsTUFBdkMsRUFBK0M7QUFFN0MsUUFBTUMsYUFBYSxHQUFHLGdCQUF0QjtBQUNBLE1BQUkvSSxLQUFLLEdBQUcrSSxhQUFhLENBQUNDLElBQWQsQ0FBbUJILFFBQW5CLENBQVo7QUFDQSxNQUFJSSxXQUFXLEdBQUdKLFFBQWxCOztBQUVBLE1BQUk3SSxLQUFLLElBQUksSUFBYixFQUFtQjtBQUNqQixRQUFJLENBQUM4SSxNQUFNLENBQUNJLGNBQVAsQ0FBc0JMLFFBQXRCLENBQUwsRUFBc0M7QUFDcEM7QUFDRDs7QUFDRCxXQUFPQyxNQUFNLENBQUNELFFBQUQsQ0FBYjtBQUNELEdBTEQsTUFLTztBQUNMLFdBQU83SSxLQUFLLElBQUksSUFBaEIsRUFBc0I7QUFDcEIsWUFBTW1KLE9BQU8sR0FBR25KLEtBQUssQ0FBQyxDQUFELENBQXJCO0FBQ0EsWUFBTW9KLFlBQVksR0FBR3BKLEtBQUssQ0FBQyxDQUFELENBQTFCOztBQUVBLFVBQUksQ0FBQzhJLE1BQU0sQ0FBQ0ksY0FBUCxDQUFzQkUsWUFBdEIsQ0FBTCxFQUEwQztBQUN4QztBQUNEOztBQUVELFlBQU1DLE9BQU8sR0FBR1AsTUFBTSxDQUFDTSxZQUFELENBQXRCO0FBQ0FILGlCQUFXLEdBQUdBLFdBQVcsQ0FBQzVGLE9BQVosQ0FBb0I4RixPQUFwQixFQUE2QkUsT0FBN0IsQ0FBZDtBQUNBckosV0FBSyxHQUFHK0ksYUFBYSxDQUFDQyxJQUFkLENBQW1CSCxRQUFuQixDQUFSO0FBQ0Q7O0FBQ0QsV0FBT0ksV0FBUDtBQUNEO0FBQ0Y7O0FBRU0sU0FBU2xCLGdCQUFULENBQTBCdUIsR0FBMUIsRUFBK0JyRixHQUEvQixFQUFvQztBQUN6QyxNQUFJO0FBQ0YsV0FBT2tFLENBQUMsQ0FBQ29CLE1BQUYsQ0FBU3RGLEdBQUcsQ0FBQ3ZFLEtBQUosQ0FBVSxHQUFWLENBQVQsRUFBeUIsQ0FBQzhKLEdBQUQsRUFBTUMsRUFBTixLQUFhRCxHQUFHLENBQUNDLEVBQUQsQ0FBekMsRUFBK0NILEdBQS9DLENBQVA7QUFDRCxHQUZELENBRUUsT0FBT0ksR0FBUCxFQUFZO0FBQ1osV0FBTzVMLFNBQVA7QUFDRDtBQUNGOztBQUVNLFNBQVN5SCxlQUFULENBQXlCcEMsUUFBekIsRUFBbUM7QUFDeEMsUUFBTXdHLGFBQWEsR0FBRzNPLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixxQkFBbEIsQ0FBdEI7O0FBRUEsTUFBSThOLGFBQWEsQ0FBQzlELE9BQWQsQ0FBc0IsSUFBdEIsSUFBOEIsQ0FBQyxDQUFuQyxFQUFzQztBQUNwQyxXQUFPOEQsYUFBYSxDQUFDdEcsT0FBZCxDQUFzQixXQUF0QixFQUFtQyxVQUFTckQsS0FBVCxFQUFnQjRKLEtBQWhCLEVBQXVCO0FBQy9ELGFBQU96RyxRQUFRLENBQUMwRyxZQUFULENBQXNCRCxLQUF0QixDQUFQO0FBQ0QsS0FGTSxDQUFQO0FBR0Q7O0FBRUQsU0FBT3pHLFFBQVEsQ0FBQzBHLFlBQVQsQ0FBc0JGLGFBQXRCLENBQVA7QUFDRDs7QUFFTSxTQUFTbkUsWUFBVCxDQUFzQnJDLFFBQXRCLEVBQWdDO0FBQ3JDLFFBQU0yRyxVQUFVLEdBQUc5TyxJQUFJLENBQUNhLFlBQUwsQ0FBa0Isa0JBQWxCLENBQW5COztBQUVBLE1BQUlpTyxVQUFVLENBQUNqRSxPQUFYLENBQW1CLElBQW5CLElBQTJCLENBQUMsQ0FBaEMsRUFBbUM7QUFDakMsV0FBT2lFLFVBQVUsQ0FBQ3pHLE9BQVgsQ0FBbUIsV0FBbkIsRUFBZ0MsVUFBU3JELEtBQVQsRUFBZ0I0SixLQUFoQixFQUF1QjtBQUM1RCxhQUFPekcsUUFBUSxDQUFDMEcsWUFBVCxDQUFzQkQsS0FBdEIsQ0FBUDtBQUNELEtBRk0sQ0FBUDtBQUdEOztBQUVELFNBQU96RyxRQUFRLENBQUMwRyxZQUFULENBQXNCQyxVQUF0QixDQUFQO0FBQ0Q7O0FBRU0sU0FBUzlCLGVBQVQsQ0FBeUI3RSxRQUF6QixFQUFtQztBQUN4QyxRQUFNNEcsYUFBYSxHQUFHL08sSUFBSSxDQUFDYSxZQUFMLENBQWtCLHFCQUFsQixDQUF0Qjs7QUFDQSxNQUFJa08sYUFBYSxDQUFDbEUsT0FBZCxDQUFzQixJQUF0QixJQUE4QixDQUFDLENBQW5DLEVBQXNDO0FBQ3BDLFdBQU9rRSxhQUFhLENBQUMxRyxPQUFkLENBQXNCLFdBQXRCLEVBQW1DLFVBQVNyRCxLQUFULEVBQWdCNEosS0FBaEIsRUFBdUI7QUFDL0QsYUFBT3pHLFFBQVEsQ0FBQzBHLFlBQVQsQ0FBc0JELEtBQXRCLENBQVA7QUFDRCxLQUZNLENBQVA7QUFHRDs7QUFDRCxTQUFPekcsUUFBUSxDQUFDMEcsWUFBVCxDQUFzQkUsYUFBdEIsQ0FBUDtBQUNEOztBQUVNLFNBQVN0RSxtQkFBVCxDQUE2QnRDLFFBQTdCLEVBQXVDO0FBQzVDLE1BQUlaLHVCQUF1QixHQUFHdkgsSUFBSSxDQUFDYSxZQUFMLENBQWtCLDhCQUFsQixDQUE5Qjs7QUFFQSxNQUFJMEcsdUJBQXVCLEtBQUssRUFBaEMsRUFBb0M7QUFDbENBLDJCQUF1QixHQUFHQSx1QkFBdUIsQ0FBQ2MsT0FBeEIsQ0FBZ0MsS0FBaEMsRUFBdUMsRUFBdkMsRUFBMkMzRCxLQUEzQyxDQUFpRCxHQUFqRCxDQUExQjtBQUNELEdBRkQsTUFFTztBQUNMNkMsMkJBQXVCLEdBQUcsRUFBMUI7QUFDRDs7QUFFRCxNQUFJdEYsaUJBQWlCLEdBQUdqQyxJQUFJLENBQUNhLFlBQUwsQ0FBa0Isd0JBQWxCLENBQXhCOztBQUVBLE1BQUlvQixpQkFBaUIsS0FBSyxFQUExQixFQUE4QjtBQUM1QkEscUJBQWlCLEdBQUdBLGlCQUFpQixDQUFDb0csT0FBbEIsQ0FBMEIsS0FBMUIsRUFBaUMsRUFBakMsRUFBcUMzRCxLQUFyQyxDQUEyQyxHQUEzQyxDQUFwQjtBQUNELEdBRkQsTUFFTztBQUNMekMscUJBQWlCLEdBQUcsRUFBcEI7QUFDRDs7QUFFRHNGLHlCQUF1QixHQUFHQSx1QkFBdUIsQ0FBQ3lILE1BQXhCLENBQStCL00saUJBQS9CLENBQTFCOztBQUVBLE1BQUlzRix1QkFBdUIsQ0FBQ25CLE1BQXhCLEdBQWlDLENBQXJDLEVBQXdDO0FBQ3RDbUIsMkJBQXVCLEdBQUdBLHVCQUF1QixDQUFDMEgsSUFBeEIsQ0FBOEJMLEtBQUQsSUFBVztBQUNoRSxhQUFPLENBQUN6QixDQUFDLENBQUMrQixPQUFGLENBQVUvRyxRQUFRLENBQUNVLElBQVQsQ0FBY2dHLFlBQWQsQ0FBMkJELEtBQTNCLENBQVYsQ0FBUjtBQUNELEtBRnlCLENBQTFCOztBQUdBLFFBQUlySCx1QkFBSixFQUE2QjtBQUMzQmxILGVBQVMsa0NBQTZCa0gsdUJBQTdCLEVBQVQ7QUFDQUEsNkJBQXVCLEdBQUc7QUFDeEJELGlCQUFTLEVBQUVDLHVCQURhO0FBRXhCNUUsYUFBSyxFQUFFd0YsUUFBUSxDQUFDVSxJQUFULENBQWNnRyxZQUFkLENBQTJCdEgsdUJBQTNCLEVBQW9ETSxRQUFwRCxDQUE2RCxLQUE3RDtBQUZpQixPQUExQjtBQUlEOztBQUNELFdBQU9OLHVCQUFQO0FBQ0Q7QUFDRjs7QUFFTSxTQUFTMEYscUJBQVQsQ0FBK0I5RSxRQUEvQixFQUF5QzZDLElBQXpDLEVBQStDO0FBQ3BELFFBQU1OLFlBQVksR0FBRzFLLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixxQkFBbEIsQ0FBckI7QUFDQSxRQUFNc08sb0JBQW9CLEdBQUduUCxJQUFJLENBQUNhLFlBQUwsQ0FBa0IsOEJBQWxCLEVBQWtEdU8sSUFBbEQsRUFBN0I7QUFFQSxRQUFNQyxRQUFRLEdBQUcsRUFBakI7O0FBRUEsTUFBSTNFLFlBQVksSUFBSXlFLG9CQUFwQixFQUEwQztBQUN4QyxVQUFNRyxxQkFBcUIsR0FBRyxDQUFDLE9BQUQsRUFBVSxNQUFWLEVBQWtCLGNBQWxCLENBQTlCO0FBQ0EsVUFBTUMsUUFBUSxHQUFHeE0sSUFBSSxDQUFDQyxLQUFMLENBQVdtTSxvQkFBWCxDQUFqQjtBQUNBLFVBQU1LLFNBQVMsR0FBRyxFQUFsQjs7QUFDQXJDLEtBQUMsQ0FBQ2pILEdBQUYsQ0FBTXFKLFFBQU4sRUFBZ0IsVUFBU0UsU0FBVCxFQUFvQkMsU0FBcEIsRUFBK0I7QUFDN0NyUCxlQUFTLHlCQUFrQnFQLFNBQWxCLGlCQUFrQ0QsU0FBbEMsRUFBVDs7QUFDQSxjQUFRQSxTQUFSO0FBQ0EsYUFBSyxPQUFMO0FBQ0UsY0FBSSxDQUFDdEgsUUFBUSxDQUFDK0YsY0FBVCxDQUF3QndCLFNBQXhCLENBQUwsRUFBeUM7QUFDdkNyUCxxQkFBUyx5Q0FBbUNxUCxTQUFuQyxFQUFUO0FBQ0E7QUFDRDs7QUFFRCxjQUFJdkMsQ0FBQyxDQUFDd0MsUUFBRixDQUFXeEgsUUFBUSxDQUFDdUgsU0FBRCxDQUFuQixDQUFKLEVBQXFDO0FBQ25DdkMsYUFBQyxDQUFDakgsR0FBRixDQUFNaUMsUUFBUSxDQUFDdUgsU0FBRCxDQUFkLEVBQTJCLFVBQVN2SixJQUFULEVBQWU7QUFDeENxSix1QkFBUyxDQUFDekssSUFBVixDQUFlO0FBQUU2Syx1QkFBTyxFQUFFekosSUFBWDtBQUFpQjBKLHdCQUFRLEVBQUU7QUFBM0IsZUFBZjtBQUNELGFBRkQ7QUFHRCxXQUpELE1BSU87QUFDTEwscUJBQVMsQ0FBQ3pLLElBQVYsQ0FBZTtBQUFFNksscUJBQU8sRUFBRXpILFFBQVEsQ0FBQ3VILFNBQUQsQ0FBbkI7QUFBZ0NHLHNCQUFRLEVBQUU7QUFBMUMsYUFBZjtBQUNEOztBQUNEOztBQUVGO0FBQ0UsZ0JBQU0sQ0FBQ0MsUUFBRCxFQUFXQyxTQUFYLElBQXdCTixTQUFTLENBQUMvSyxLQUFWLENBQWdCLFFBQWhCLENBQTlCOztBQUVBLGNBQUksQ0FBQ3lJLENBQUMsQ0FBQzhCLElBQUYsQ0FBT0sscUJBQVAsRUFBK0JiLEVBQUQsSUFBUUEsRUFBRSxLQUFLcUIsUUFBN0MsQ0FBTCxFQUE2RDtBQUMzRHpQLHFCQUFTLDJDQUFxQ29QLFNBQXJDLEVBQVQ7QUFDQTtBQUNEOztBQUVELGNBQUlLLFFBQVEsS0FBSyxjQUFqQixFQUFpQztBQUMvQixnQkFBSUUsZ0JBQUo7O0FBRUEsZ0JBQUk7QUFDRkEsOEJBQWdCLEdBQUdqTixJQUFJLENBQUNDLEtBQUwsQ0FBV2hELElBQUksQ0FBQ2EsWUFBTCxDQUFrQix1QkFBbEIsQ0FBWCxDQUFuQjtBQUNELGFBRkQsQ0FFRSxPQUFPb1AsQ0FBUCxFQUFVO0FBQ1Y1UCx1QkFBUyxDQUFDLGdDQUFELENBQVQ7QUFDQTtBQUNEOztBQUVELGdCQUFJLENBQUMwTSxnQkFBZ0IsQ0FBQ2lELGdCQUFELEVBQW1CRCxTQUFuQixDQUFyQixFQUFvRDtBQUNsRDFQLHVCQUFTLDBDQUFvQ29QLFNBQXBDLEVBQVQ7QUFDQTtBQUNEO0FBQ0Y7O0FBRUQsZ0JBQU1TLFlBQVksR0FBR25ELGdCQUFnQixDQUFDL0IsSUFBRCxFQUFPeUUsU0FBUCxDQUFyQztBQUNBLGdCQUFNVSxZQUFZLEdBQUd2QyxrQkFBa0IsQ0FBQzhCLFNBQUQsRUFBWXZILFFBQVosQ0FBdkM7O0FBRUEsY0FBSWdJLFlBQVksSUFBSUQsWUFBWSxLQUFLQyxZQUFyQyxFQUFtRDtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQU1DLEtBQUssR0FBR1gsU0FBUyxDQUFDL0ssS0FBVixDQUFnQixHQUFoQixDQUFkOztBQUNBLGtCQUFNMkwsT0FBTyxHQUFHbEQsQ0FBQyxDQUFDbUQsSUFBRixDQUFPRixLQUFQLENBQWhCOztBQUNBakQsYUFBQyxDQUFDb0IsTUFBRixDQUFTNkIsS0FBVCxFQUFnQixDQUFDOUIsR0FBRCxFQUFNaUMsT0FBTixLQUNiQSxPQUFPLEtBQUtGLE9BQWIsR0FDSS9CLEdBQUcsQ0FBQ2lDLE9BQUQsQ0FBSCxHQUFlSixZQURuQixHQUVJN0IsR0FBRyxDQUFDaUMsT0FBRCxDQUFILEdBQWVqQyxHQUFHLENBQUNpQyxPQUFELENBQUgsSUFBZ0IsRUFIckMsRUFJSWxCLFFBSko7O0FBS0FoUCxxQkFBUyxnQkFBVW9QLFNBQVYsMEJBQXFDVSxZQUFyQyxFQUFUO0FBQ0Q7O0FBekRIO0FBMkRELEtBN0REOztBQStEQSxRQUFJWCxTQUFTLENBQUNwSixNQUFWLEdBQW1CLENBQXZCLEVBQTBCO0FBQ3hCLFVBQUlyRCxJQUFJLENBQUNxSCxTQUFMLENBQWVZLElBQUksQ0FBQ3dGLE1BQXBCLE1BQWdDek4sSUFBSSxDQUFDcUgsU0FBTCxDQUFlb0YsU0FBZixDQUFwQyxFQUErRDtBQUM3REgsZ0JBQVEsQ0FBQ21CLE1BQVQsR0FBa0JoQixTQUFsQjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxRQUFNaUIsUUFBUSxHQUFHaEcsbUJBQW1CLENBQUN0QyxRQUFELENBQXBDOztBQUVBLE1BQUlzSSxRQUFRLEtBQUssQ0FBQ3pGLElBQUksQ0FBQzBGLFFBQU4sSUFBa0IsQ0FBQzFGLElBQUksQ0FBQzBGLFFBQUwsQ0FBY25GLElBQWpDLElBQXlDUCxJQUFJLENBQUMwRixRQUFMLENBQWNuRixJQUFkLENBQW1CbEUsRUFBbkIsS0FBMEJvSixRQUFRLENBQUM5TixLQUE1RSxJQUFxRnFJLElBQUksQ0FBQzBGLFFBQUwsQ0FBY25GLElBQWQsQ0FBbUJvRixXQUFuQixLQUFtQ0YsUUFBUSxDQUFDbkosU0FBdEksQ0FBWixFQUE4SjtBQUM1SitILFlBQVEsQ0FBQyxrQkFBRCxDQUFSLEdBQStCb0IsUUFBUSxDQUFDOU4sS0FBeEM7QUFDQTBNLFlBQVEsQ0FBQywyQkFBRCxDQUFSLEdBQXdDb0IsUUFBUSxDQUFDbkosU0FBakQ7QUFDRDs7QUFFRCxNQUFJMEQsSUFBSSxDQUFDYyxvQkFBTCxLQUE4QixNQUFsQyxFQUEwQztBQUN4Q3VELFlBQVEsQ0FBQzlELElBQVQsR0FBZ0IsSUFBaEI7QUFDRDs7QUFFRCxNQUFJNEIsQ0FBQyxDQUFDeUQsSUFBRixDQUFPdkIsUUFBUCxDQUFKLEVBQXNCO0FBQ3BCLFdBQU9BLFFBQVA7QUFDRDtBQUNGOztBQUdNLFNBQVMzRSxZQUFULENBQXNCTSxJQUF0QixFQUE0QjdDLFFBQTVCLEVBQXNDO0FBQzNDN0gsVUFBUSxDQUFDLG1CQUFELENBQVI7QUFDQUQsV0FBUyxDQUFDLE1BQUQsRUFBUztBQUFDLGFBQVMySyxJQUFJLENBQUNGLEtBQWY7QUFBc0IsV0FBT0UsSUFBSSxDQUFDdUI7QUFBbEMsR0FBVCxDQUFULENBRjJDLENBRzNDOztBQUVBLE1BQUl2TSxJQUFJLENBQUNhLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLEVBQWpELEVBQXFEO0FBQ25ELFVBQU1rRixRQUFRLEdBQUd1RSxJQUFJLENBQUNDLGVBQWUsQ0FBQ3BDLFFBQUQsQ0FBaEIsQ0FBckI7O0FBQ0EsUUFBSTZDLElBQUksSUFBSUEsSUFBSSxDQUFDdUIsR0FBYixJQUFvQnhHLFFBQVEsS0FBS2lGLElBQUksQ0FBQ2pGLFFBQTFDLEVBQW9EO0FBQ2xEekYsY0FBUSxDQUFDLHVCQUFELEVBQTBCMEssSUFBSSxDQUFDakYsUUFBL0IsRUFBeUMsSUFBekMsRUFBK0NBLFFBQS9DLENBQVI7QUFDQTFDLFlBQU0sQ0FBQ3NJLEtBQVAsQ0FBYUUsT0FBYixDQUFxQjtBQUFFVSxXQUFHLEVBQUV2QixJQUFJLENBQUN1QjtBQUFaLE9BQXJCLEVBQXdDO0FBQUVDLFlBQUksRUFBRTtBQUFFekc7QUFBRjtBQUFSLE9BQXhDO0FBQ0Q7QUFDRjs7QUFFRCxNQUFJL0YsSUFBSSxDQUFDYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxFQUFqRCxFQUFxRDtBQUNuRCxVQUFNZ1EsUUFBUSxHQUFFN0QsZUFBZSxDQUFDN0UsUUFBRCxDQUEvQjtBQUNBOUgsYUFBUyxDQUFDLFdBQUQsRUFBYXdRLFFBQWIsQ0FBVDs7QUFDQSxRQUFJN0YsSUFBSSxJQUFJQSxJQUFJLENBQUN1QixHQUFiLElBQW9Cc0UsUUFBUSxLQUFLLEVBQXJDLEVBQXlDO0FBQ3ZDdlEsY0FBUSxDQUFDLHdCQUFELEVBQTJCdVEsUUFBM0IsQ0FBUjtBQUNBeE4sWUFBTSxDQUFDc0ksS0FBUCxDQUFhVyxNQUFiLENBQW9CO0FBQUVDLFdBQUcsRUFBR3ZCLElBQUksQ0FBQ3VCO0FBQWIsT0FBcEIsRUFBd0M7QUFBRUMsWUFBSSxFQUFFO0FBQUUsOEJBQXFCcUU7QUFBdkI7QUFBUixPQUF4QztBQUNEO0FBQ0Y7O0FBRUQsTUFBSTdRLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixrQkFBbEIsTUFBMEMsRUFBOUMsRUFBa0Q7QUFDaEQsVUFBTWlLLEtBQUssR0FBR04sWUFBWSxDQUFDckMsUUFBRCxDQUExQjtBQUNBOUgsYUFBUyxDQUFDLFFBQUQsRUFBV3lLLEtBQVgsQ0FBVDs7QUFFQSxRQUFJRSxJQUFJLElBQUlBLElBQUksQ0FBQ3VCLEdBQWIsSUFBb0J6QixLQUFLLEtBQUssRUFBbEMsRUFBc0M7QUFDcEN4SyxjQUFRLENBQUMscUJBQUQsRUFBd0J3SyxLQUF4QixDQUFSO0FBQ0F6SCxZQUFNLENBQUNzSSxLQUFQLENBQWFXLE1BQWIsQ0FBb0I7QUFDbEJDLFdBQUcsRUFBRXZCLElBQUksQ0FBQ3VCO0FBRFEsT0FBcEIsRUFFRztBQUNEQyxZQUFJLEVBQUU7QUFDSiw4QkFBb0IxQjtBQURoQjtBQURMLE9BRkg7QUFPRDtBQUNGO0FBRUY7O0FBRU0sU0FBU0gsV0FBVCxDQUFxQnhDLFFBQXJCLEVBQStCcEMsUUFBL0IsRUFBeUNPLFFBQXpDLEVBQW1EO0FBQ3hELFFBQU1tSyxRQUFRLEdBQUdoRyxtQkFBbUIsQ0FBQ3RDLFFBQUQsQ0FBcEM7QUFFQSxRQUFNMkksVUFBVSxHQUFHLEVBQW5COztBQUdBLE1BQUkvSyxRQUFKLEVBQWM7QUFDWitLLGNBQVUsQ0FBQy9LLFFBQVgsR0FBc0JBLFFBQXRCO0FBQ0Q7O0FBRUQsUUFBTXNKLFFBQVEsR0FBR3BDLHFCQUFxQixDQUFDOUUsUUFBRCxFQUFXLEVBQVgsQ0FBdEM7O0FBRUEsTUFBSWtILFFBQVEsSUFBSUEsUUFBUSxDQUFDbUIsTUFBckIsSUFBK0JuQixRQUFRLENBQUNtQixNQUFULENBQWdCLENBQWhCLENBQS9CLElBQXFEbkIsUUFBUSxDQUFDbUIsTUFBVCxDQUFnQixDQUFoQixFQUFtQlosT0FBNUUsRUFBcUY7QUFDbkYsUUFBSTdILEtBQUssQ0FBQ0MsT0FBTixDQUFjcUgsUUFBUSxDQUFDbUIsTUFBVCxDQUFnQixDQUFoQixFQUFtQlosT0FBakMsQ0FBSixFQUErQztBQUM3Q2tCLGdCQUFVLENBQUNoRyxLQUFYLEdBQW1CdUUsUUFBUSxDQUFDbUIsTUFBVCxDQUFnQixDQUFoQixFQUFtQlosT0FBbkIsQ0FBMkIsQ0FBM0IsQ0FBbkI7QUFDRCxLQUZELE1BRU87QUFDTGtCLGdCQUFVLENBQUNoRyxLQUFYLEdBQW1CdUUsUUFBUSxDQUFDbUIsTUFBVCxDQUFnQixDQUFoQixFQUFtQlosT0FBdEM7QUFDRDtBQUNGLEdBTkQsTUFNTyxJQUFJekgsUUFBUSxDQUFDNEksSUFBVCxJQUFpQjVJLFFBQVEsQ0FBQzRJLElBQVQsQ0FBY2xHLE9BQWQsQ0FBc0IsR0FBdEIsSUFBNkIsQ0FBQyxDQUFuRCxFQUFzRDtBQUMzRGlHLGNBQVUsQ0FBQ2hHLEtBQVgsR0FBbUIzQyxRQUFRLENBQUM0SSxJQUE1QjtBQUNELEdBRk0sTUFFQSxJQUFJL1EsSUFBSSxDQUFDYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxFQUFqRCxFQUFxRDtBQUMxRGlRLGNBQVUsQ0FBQ2hHLEtBQVgsYUFBdUIvRSxRQUFRLElBQUkwSyxRQUFRLENBQUM5TixLQUE1QyxjQUF1RDNDLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixxQkFBbEIsQ0FBdkQ7QUFDRCxHQUZNLE1BRUE7QUFDTCxVQUFNMkUsS0FBSyxHQUFHLElBQUluQyxNQUFNLENBQUN3QyxLQUFYLENBQWlCLGtCQUFqQixFQUFxQyxvSUFBckMsQ0FBZDtBQUNBckYsYUFBUyxDQUFDZ0YsS0FBRCxDQUFUO0FBQ0EsVUFBTUEsS0FBTjtBQUNEOztBQUVEbkYsV0FBUyxDQUFDLGVBQUQsRUFBa0J5USxVQUFsQixDQUFUOztBQUVBLE1BQUl4SyxRQUFKLEVBQWM7QUFDWndLLGNBQVUsQ0FBQ3hLLFFBQVgsR0FBc0JBLFFBQXRCO0FBQ0Q7O0FBRUQsTUFBSTtBQUNGO0FBQ0F3SyxjQUFVLENBQUN2RixJQUFYLEdBQWtCLElBQWxCO0FBQ0F1RixjQUFVLENBQUN2RSxHQUFYLEdBQWlCbkIsUUFBUSxDQUFDNEYsVUFBVCxDQUFvQkYsVUFBcEIsQ0FBakIsQ0FIRSxDQUtGOztBQUNBek4sVUFBTSxDQUFDc0ksS0FBUCxDQUFhVyxNQUFiLENBQW9CO0FBQUVDLFNBQUcsRUFBR3VFLFVBQVUsQ0FBQ3ZFO0FBQW5CLEtBQXBCLEVBQThDO0FBQzVDQyxVQUFJLEVBQUU7QUFDRix5QkFBaUI7QUFBRW5GLFlBQUUsRUFBRW9KLFFBQVEsQ0FBQzlOO0FBQWYsU0FEZjtBQUVGLDZCQUFxQixJQUZuQjtBQUdGLGdDQUF3QjtBQUh0QjtBQURzQyxLQUE5QztBQU1ELEdBWkQsQ0FZRSxPQUFPNkMsS0FBUCxFQUFjO0FBQ2RoRixhQUFTLENBQUMscUJBQUQsRUFBd0JnRixLQUF4QixDQUFUO0FBQ0EsV0FBT0EsS0FBUDtBQUNEOztBQUVEa0YsY0FBWSxDQUFDb0csVUFBRCxFQUFhM0ksUUFBYixDQUFaO0FBRUEsU0FBTztBQUNMMEUsVUFBTSxFQUFFaUUsVUFBVSxDQUFDdkU7QUFEZCxHQUFQO0FBR0Q7O0FBRU0sU0FBU1csY0FBVCxDQUF3QjNCLElBQXhCLEVBQThCO0FBQ25DLE1BQUl2TCxJQUFJLENBQUNhLFlBQUwsQ0FBa0IsYUFBbEIsTUFBcUMsSUFBekMsRUFBK0M7QUFDN0NMLGFBQVMsQ0FBQywwQ0FBRCxDQUFUO0FBQ0E7QUFDRDs7QUFFRCxNQUFJLENBQUMrSyxJQUFMLEVBQVc7QUFDVEEsUUFBSSxHQUFHLElBQUl2TCxJQUFKLEVBQVA7QUFDQXVMLFFBQUksQ0FBQ3BJLFdBQUw7QUFDRDs7QUFFRCxNQUFJOE4sS0FBSyxHQUFHLENBQVo7QUFDQTFGLE1BQUksQ0FBQzdFLGVBQUwsQ0FBcUIsR0FBckIsRUFBMEJyRCxNQUFNLENBQUM2TixlQUFQLENBQXVCLFVBQUMxTCxLQUFELEVBQVEyTCxTQUFSLEVBQXdDO0FBQUEsUUFBckI7QUFBQzVILFVBQUQ7QUFBT0Q7QUFBUCxLQUFxQix1RUFBUCxFQUFPOztBQUN2RixRQUFJOUQsS0FBSixFQUFXO0FBQ1QsWUFBTUEsS0FBTjtBQUNEOztBQUVEMkwsYUFBUyxDQUFDdE0sT0FBVixDQUFtQnNELFFBQUQsSUFBYztBQUM5QjhJLFdBQUs7QUFFTCxZQUFNUixRQUFRLEdBQUdoRyxtQkFBbUIsQ0FBQ3RDLFFBQUQsQ0FBcEMsQ0FIOEIsQ0FJOUI7O0FBQ0EsWUFBTXlELFNBQVMsR0FBRztBQUNoQiw0QkFBb0I2RSxRQUFRLENBQUM5TjtBQURiLE9BQWxCO0FBSUF0QyxlQUFTLENBQUMsV0FBRCxFQUFjdUwsU0FBZCxDQUFUO0FBRUEsVUFBSTdGLFFBQUo7O0FBQ0EsVUFBSS9GLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixxQkFBbEIsTUFBNkMsRUFBakQsRUFBcUQ7QUFDbkRrRixnQkFBUSxHQUFHdUUsSUFBSSxDQUFDQyxlQUFlLENBQUNwQyxRQUFELENBQWhCLENBQWY7QUFDRCxPQWQ2QixDQWdCOUI7OztBQUNBLFVBQUk2QyxJQUFJLEdBQUczSCxNQUFNLENBQUNzSSxLQUFQLENBQWFFLE9BQWIsQ0FBcUJELFNBQXJCLENBQVg7O0FBRUEsVUFBSSxDQUFDWixJQUFELElBQVNqRixRQUFULElBQXFCL0YsSUFBSSxDQUFDYSxZQUFMLENBQWtCLDJCQUFsQixNQUFtRCxJQUE1RSxFQUFrRjtBQUNoRixjQUFNK0ssU0FBUyxHQUFHO0FBQ2hCN0Y7QUFEZ0IsU0FBbEI7QUFJQTFGLGlCQUFTLENBQUMsaUJBQUQsRUFBb0J1TCxTQUFwQixDQUFUO0FBRUFaLFlBQUksR0FBRzNILE1BQU0sQ0FBQ3NJLEtBQVAsQ0FBYUUsT0FBYixDQUFxQkQsU0FBckIsQ0FBUDs7QUFDQSxZQUFJWixJQUFKLEVBQVU7QUFDUk4sc0JBQVksQ0FBQ00sSUFBRCxFQUFPN0MsUUFBUCxDQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFJLENBQUM2QyxJQUFMLEVBQVc7QUFDVEwsbUJBQVcsQ0FBQ3hDLFFBQUQsRUFBV3BDLFFBQVgsQ0FBWDtBQUNEOztBQUVELFVBQUlrTCxLQUFLLEdBQUcsR0FBUixLQUFnQixDQUFwQixFQUF1QjtBQUNyQjNRLGdCQUFRLENBQUMsMkNBQUQsRUFBOEMyUSxLQUE5QyxDQUFSO0FBQ0Q7QUFDRixLQXZDRDs7QUF5Q0EsUUFBSTNILEdBQUosRUFBUztBQUNQaEosY0FBUSxDQUFDLGtDQUFELEVBQXFDMlEsS0FBckMsQ0FBUjtBQUNEOztBQUVEMUgsUUFBSSxDQUFDMEgsS0FBRCxDQUFKO0FBQ0QsR0FuRHlCLENBQTFCO0FBb0REOztBQUVELFNBQVNHLElBQVQsR0FBZ0I7QUFDZCxNQUFJcFIsSUFBSSxDQUFDYSxZQUFMLENBQWtCLGFBQWxCLE1BQXFDLElBQXpDLEVBQStDO0FBQzdDO0FBQ0Q7O0FBRUQsUUFBTTBLLElBQUksR0FBRyxJQUFJdkwsSUFBSixFQUFiOztBQUVBLE1BQUk7QUFDRnVMLFFBQUksQ0FBQ3BJLFdBQUw7QUFFQSxRQUFJd0ksS0FBSjs7QUFDQSxRQUFJM0wsSUFBSSxDQUFDYSxZQUFMLENBQWtCLGtEQUFsQixNQUEwRSxJQUE5RSxFQUFvRjtBQUNsRjhLLFdBQUssR0FBR3RJLE1BQU0sQ0FBQ3NJLEtBQVAsQ0FBYXNELElBQWIsQ0FBa0I7QUFBRSx5QkFBaUI7QUFBRW9DLGlCQUFPLEVBQUU7QUFBWDtBQUFuQixPQUFsQixDQUFSO0FBQ0Q7O0FBRUQsUUFBSXJSLElBQUksQ0FBQ2EsWUFBTCxDQUFrQix1Q0FBbEIsTUFBK0QsSUFBbkUsRUFBeUU7QUFDdkVxTSxvQkFBYyxDQUFDM0IsSUFBRCxDQUFkO0FBQ0Q7O0FBRUQsUUFBSXZMLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixrREFBbEIsTUFBMEUsSUFBOUUsRUFBb0Y7QUFDbEY4SyxXQUFLLENBQUM5RyxPQUFOLENBQWMsVUFBU21HLElBQVQsRUFBZTtBQUMzQixZQUFJN0MsUUFBSjs7QUFFQSxZQUFJNkMsSUFBSSxDQUFDMEYsUUFBTCxJQUFpQjFGLElBQUksQ0FBQzBGLFFBQUwsQ0FBY25GLElBQS9CLElBQXVDUCxJQUFJLENBQUMwRixRQUFMLENBQWNuRixJQUFkLENBQW1CbEUsRUFBOUQsRUFBa0U7QUFDaEVjLGtCQUFRLEdBQUdvRCxJQUFJLENBQUNuRSxlQUFMLENBQXFCNEQsSUFBSSxDQUFDMEYsUUFBTCxDQUFjbkYsSUFBZCxDQUFtQmxFLEVBQXhDLEVBQTRDMkQsSUFBSSxDQUFDMEYsUUFBTCxDQUFjbkYsSUFBZCxDQUFtQm9GLFdBQS9ELENBQVg7QUFDRCxTQUZELE1BRU87QUFDTHhJLGtCQUFRLEdBQUdvRCxJQUFJLENBQUN0RCxxQkFBTCxDQUEyQitDLElBQUksQ0FBQ2pGLFFBQWhDLENBQVg7QUFDRDs7QUFFRCxZQUFJb0MsUUFBSixFQUFjO0FBQ1p1QyxzQkFBWSxDQUFDTSxJQUFELEVBQU83QyxRQUFQLENBQVo7QUFDRCxTQUZELE1BRU87QUFDTDdILGtCQUFRLENBQUMsa0JBQUQsRUFBcUIwSyxJQUFJLENBQUNqRixRQUExQixDQUFSO0FBQ0Q7QUFDRixPQWREO0FBZUQ7QUFDRixHQTdCRCxDQTZCRSxPQUFPUCxLQUFQLEVBQWM7QUFDZGhGLGFBQVMsQ0FBQ2dGLEtBQUQsQ0FBVDtBQUNBLFdBQU9BLEtBQVA7QUFDRDs7QUFDRCxTQUFPLElBQVA7QUFDRDs7QUFFRCxNQUFNOEwsT0FBTyxHQUFHLFdBQWhCOztBQUVBLE1BQU1DLFVBQVUsR0FBR3BFLENBQUMsQ0FBQ3FFLFFBQUYsQ0FBV25PLE1BQU0sQ0FBQzZOLGVBQVAsQ0FBdUIsU0FBU08sbUJBQVQsR0FBK0I7QUFDbEYsTUFBSUMsRUFBRSxHQUFDdEUsVUFBVSxDQUFDQSxVQUFsQixDQURrRixDQUNwRDs7QUFDOUIsTUFBSXBOLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixzQkFBbEIsTUFBOEMsSUFBbEQsRUFBd0Q7QUFDdERQLFlBQVEsQ0FBQyxnQ0FBRCxDQUFSOztBQUNBLFFBQUlvUixFQUFFLENBQUNDLG1CQUFILENBQXVCTCxPQUF2QixDQUFKLEVBQXFDO0FBQ25DSSxRQUFFLENBQUNFLE1BQUgsQ0FBVU4sT0FBVjtBQUNEOztBQUNEO0FBQ0Q7O0FBRURoUixVQUFRLENBQUMsK0JBQUQsQ0FBUjtBQUNBb1IsSUFBRSxDQUFDRyxHQUFILENBQU87QUFDTG5QLFFBQUksRUFBRTRPLE9BREQ7QUFFTFEsWUFBUSxFQUFFLFVBQVNDLE1BQVQsRUFBaUI7QUFDM0IsVUFBSS9SLElBQUksQ0FBQ2EsWUFBTCxDQUFrQiwrQkFBbEIsQ0FBSixFQUF3RDtBQUNyRCxlQUFPa1IsTUFBTSxDQUFDckUsSUFBUCxDQUFZMU4sSUFBSSxDQUFDYSxZQUFMLENBQWtCLCtCQUFsQixDQUFaLENBQVA7QUFDRixPQUZELE1BR0s7QUFDRixlQUFPa1IsTUFBTSxDQUFDQyxLQUFQLEdBQWV6TSxFQUFmLENBQWtCLENBQWxCLEVBQXFCME0sTUFBckIsRUFBUDtBQUNGO0FBQUMsS0FSRztBQVNMQyxPQUFHLEVBQUUsWUFBVztBQUNkZCxVQUFJO0FBQ0w7QUFYSSxHQUFQO0FBYUFNLElBQUUsQ0FBQ1MsS0FBSDtBQUVELENBMUI2QixDQUFYLEVBMEJmLEdBMUJlLENBQW5COztBQTRCQTlPLE1BQU0sQ0FBQytPLE9BQVAsQ0FBZSxNQUFNO0FBQ25CL08sUUFBTSxDQUFDZ1AsS0FBUCxDQUFhLE1BQU07QUFDakIsUUFBR3JTLElBQUksQ0FBQ2EsWUFBTCxDQUFrQixzQkFBbEIsQ0FBSCxFQUE2QztBQUFDMFEsZ0JBQVU7QUFBSTtBQUM3RCxHQUZEO0FBR0QsQ0FKRCxFIiwiZmlsZSI6Ii9wYWNrYWdlcy93ZWthbi1sZGFwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL2xvZ2luSGFuZGxlcic7XG4iLCJpbXBvcnQgbGRhcGpzIGZyb20gJ2xkYXBqcyc7XG5pbXBvcnQgdXRpbCBmcm9tICd1dGlsJztcbmltcG9ydCBCdW55YW4gZnJvbSAnYnVueWFuJztcbmltcG9ydCB7bG9nX2RlYnVnLCBsb2dfaW5mbywgbG9nX3dhcm4sIGxvZ19lcnJvcn0gZnJvbSAnLi9sb2dnZXInO1xuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIExEQVAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmxkYXBqcyA9IGxkYXBqcztcblxuICAgIHRoaXMuY29ubmVjdGVkID0gZmFsc2U7XG5cbiAgICB0aGlzLm9wdGlvbnMgPSB7XG4gICAgICBob3N0ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfSE9TVCcpLFxuICAgICAgcG9ydCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1BPUlQnKSxcbiAgICAgIFJlY29ubmVjdCAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9SRUNPTk5FQ1QnKSxcbiAgICAgIHRpbWVvdXQgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9USU1FT1VUJyksXG4gICAgICBjb25uZWN0X3RpbWVvdXQgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfQ09OTkVDVF9USU1FT1VUJyksXG4gICAgICBpZGxlX3RpbWVvdXQgICAgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfSURMRV9USU1FT1VUJyksXG4gICAgICBlbmNyeXB0aW9uICAgICAgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfRU5DUllQVElPTicpLFxuICAgICAgY2FfY2VydCAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0NBX0NFUlQnKSxcbiAgICAgIHJlamVjdF91bmF1dGhvcml6ZWQgICAgICAgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9SRUpFQ1RfVU5BVVRIT1JJWkVEJykgfHwgZmFsc2UsXG4gICAgICBBdXRoZW50aWNhdGlvbiAgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfQVVUSEVOVElGSUNBVElPTicpLFxuICAgICAgQXV0aGVudGljYXRpb25fVXNlckROICAgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0FVVEhFTlRJRklDQVRJT05fVVNFUkROJyksXG4gICAgICBBdXRoZW50aWNhdGlvbl9QYXNzd29yZCAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfQVVUSEVOVElGSUNBVElPTl9QQVNTV09SRCcpLFxuICAgICAgQXV0aGVudGljYXRpb25fRmFsbGJhY2sgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0xPR0lOX0ZBTExCQUNLJyksXG4gICAgICBCYXNlRE4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfQkFTRUROJyksXG4gICAgICBJbnRlcm5hbF9Mb2dfTGV2ZWwgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0lOVEVSTkFMX0xPR19MRVZFTCcpLFxuICAgICAgVXNlcl9BdXRoZW50aWNhdGlvbiAgICAgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1VTRVJfQVVUSEVOVElDQVRJT04nKSxcbiAgICAgIFVzZXJfQXV0aGVudGljYXRpb25fRmllbGQgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9VU0VSX0FVVEhFTlRJQ0FUSU9OX0ZJRUxEJyksXG4gICAgICBVc2VyX0F0dHJpYnV0ZXMgICAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUl9BVFRSSUJVVEVTJyksXG4gICAgICBVc2VyX1NlYXJjaF9GaWx0ZXIgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUl9TRUFSQ0hfRklMVEVSJyksXG4gICAgICBVc2VyX1NlYXJjaF9TY29wZSAgICAgICAgICAgICAgICAgIDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUl9TRUFSQ0hfU0NPUEUnKSxcbiAgICAgIFVzZXJfU2VhcmNoX0ZpZWxkICAgICAgICAgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9VU0VSX1NFQVJDSF9GSUVMRCcpLFxuICAgICAgU2VhcmNoX1BhZ2VfU2l6ZSAgICAgICAgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1NFQVJDSF9QQUdFX1NJWkUnKSxcbiAgICAgIFNlYXJjaF9TaXplX0xpbWl0ICAgICAgICAgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9TRUFSQ0hfU0laRV9MSU1JVCcpLFxuICAgICAgZ3JvdXBfZmlsdGVyX2VuYWJsZWQgICAgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0dST1VQX0ZJTFRFUl9FTkFCTEUnKSxcbiAgICAgIGdyb3VwX2ZpbHRlcl9vYmplY3RfY2xhc3MgICAgICAgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9HUk9VUF9GSUxURVJfT0JKRUNUQ0xBU1MnKSxcbiAgICAgIGdyb3VwX2ZpbHRlcl9ncm91cF9pZF9hdHRyaWJ1dGUgICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9HUk9VUF9GSUxURVJfR1JPVVBfSURfQVRUUklCVVRFJyksXG4gICAgICBncm91cF9maWx0ZXJfZ3JvdXBfbWVtYmVyX2F0dHJpYnV0ZTogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfR1JPVVBfRklMVEVSX0dST1VQX01FTUJFUl9BVFRSSUJVVEUnKSxcbiAgICAgIGdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfZm9ybWF0ICAgOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9HUk9VUF9GSUxURVJfR1JPVVBfTUVNQkVSX0ZPUk1BVCcpLFxuICAgICAgZ3JvdXBfZmlsdGVyX2dyb3VwX25hbWUgICAgICAgICAgICA6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0dST1VQX0ZJTFRFUl9HUk9VUF9OQU1FJyksXG4gICAgfTtcbiAgfVxuXG4gIHN0YXRpYyBzZXR0aW5nc19nZXQobmFtZSwgLi4uYXJncykge1xuICAgIGxldCB2YWx1ZSA9IHByb2Nlc3MuZW52W25hbWVdO1xuICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodmFsdWUgPT09ICd0cnVlJyB8fCB2YWx1ZSA9PT0gJ2ZhbHNlJykge1xuICAgICAgICB2YWx1ZSA9IEpTT04ucGFyc2UodmFsdWUpO1xuICAgICAgfSBlbHNlIGlmICh2YWx1ZSAhPT0gJycgJiYgIWlzTmFOKHZhbHVlKSkge1xuICAgICAgICB2YWx1ZSA9IE51bWJlcih2YWx1ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxvZ193YXJuKGBMb29rdXAgZm9yIHVuc2V0IHZhcmlhYmxlOiAke25hbWV9YCk7XG4gICAgfVxuICB9XG5cbiAgY29ubmVjdFN5bmMoLi4uYXJncykge1xuICAgICBpZiAoIXRoaXMuX2Nvbm5lY3RTeW5jKSB7XG4gICAgICB0aGlzLl9jb25uZWN0U3luYyA9IE1ldGVvci53cmFwQXN5bmModGhpcy5jb25uZWN0QXN5bmMsIHRoaXMpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fY29ubmVjdFN5bmMoLi4uYXJncyk7XG4gIH1cblxuICBzZWFyY2hBbGxTeW5jKC4uLmFyZ3MpIHtcblxuICAgIGlmICghdGhpcy5fc2VhcmNoQWxsU3luYykge1xuICAgICAgdGhpcy5fc2VhcmNoQWxsU3luYyA9IE1ldGVvci53cmFwQXN5bmModGhpcy5zZWFyY2hBbGxBc3luYywgdGhpcyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9zZWFyY2hBbGxTeW5jKC4uLmFyZ3MpO1xuICB9XG5cbiAgY29ubmVjdEFzeW5jKGNhbGxiYWNrKSB7XG4gICAgbG9nX2luZm8oJ0luaXQgc2V0dXAnKTtcblxuICAgIGxldCByZXBsaWVkID0gZmFsc2U7XG5cbiAgICBjb25zdCBjb25uZWN0aW9uT3B0aW9ucyA9IHtcbiAgICAgIHVybCAgICAgICAgICAgOiBgJHt0aGlzLm9wdGlvbnMuaG9zdH06JHt0aGlzLm9wdGlvbnMucG9ydH1gLFxuICAgICAgdGltZW91dCAgICAgICA6IHRoaXMub3B0aW9ucy50aW1lb3V0LFxuICAgICAgY29ubmVjdFRpbWVvdXQ6IHRoaXMub3B0aW9ucy5jb25uZWN0X3RpbWVvdXQsXG4gICAgICBpZGxlVGltZW91dCAgIDogdGhpcy5vcHRpb25zLmlkbGVfdGltZW91dCxcbiAgICAgIHJlY29ubmVjdCAgICAgOiB0aGlzLm9wdGlvbnMuUmVjb25uZWN0LFxuICAgIH07XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLkludGVybmFsX0xvZ19MZXZlbCAhPT0gJ2Rpc2FibGVkJykge1xuICAgICAgY29ubmVjdGlvbk9wdGlvbnMubG9nID0gbmV3IEJ1bnlhbih7XG4gICAgICAgIG5hbWUgICAgIDogJ2xkYXBqcycsXG4gICAgICAgIGNvbXBvbmVudDogJ2NsaWVudCcsXG4gICAgICAgIHN0cmVhbSAgIDogcHJvY2Vzcy5zdGRlcnIsXG4gICAgICAgIGxldmVsICAgIDogdGhpcy5vcHRpb25zLkludGVybmFsX0xvZ19MZXZlbCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHRsc09wdGlvbnMgPSB7XG4gICAgICByZWplY3RVbmF1dGhvcml6ZWQ6IHRoaXMub3B0aW9ucy5yZWplY3RfdW5hdXRob3JpemVkLFxuICAgIH07XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNhX2NlcnQgJiYgdGhpcy5vcHRpb25zLmNhX2NlcnQgIT09ICcnKSB7XG4gICAgICAvLyBTcGxpdCBDQSBjZXJ0IGludG8gYXJyYXkgb2Ygc3RyaW5nc1xuICAgICAgY29uc3QgY2hhaW5MaW5lcyA9IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0NBX0NFUlQnKS5zcGxpdCgnXFxuJyk7XG4gICAgICBsZXQgY2VydCAgICAgICAgID0gW107XG4gICAgICBjb25zdCBjYSAgICAgICAgID0gW107XG4gICAgICBjaGFpbkxpbmVzLmZvckVhY2goKGxpbmUpID0+IHtcbiAgICAgICAgY2VydC5wdXNoKGxpbmUpO1xuICAgICAgICBpZiAobGluZS5tYXRjaCgvLUVORCBDRVJUSUZJQ0FURS0vKSkge1xuICAgICAgICAgIGNhLnB1c2goY2VydC5qb2luKCdcXG4nKSk7XG4gICAgICAgICAgY2VydCA9IFtdO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHRsc09wdGlvbnMuY2EgPSBjYTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmVuY3J5cHRpb24gPT09ICdzc2wnKSB7XG4gICAgICBjb25uZWN0aW9uT3B0aW9ucy51cmwgICAgICAgID0gYGxkYXBzOi8vJHtjb25uZWN0aW9uT3B0aW9ucy51cmx9YDtcbiAgICAgIGNvbm5lY3Rpb25PcHRpb25zLnRsc09wdGlvbnMgPSB0bHNPcHRpb25zO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25uZWN0aW9uT3B0aW9ucy51cmwgPSBgbGRhcDovLyR7Y29ubmVjdGlvbk9wdGlvbnMudXJsfWA7XG4gICAgfVxuXG4gICAgbG9nX2luZm8oJ0Nvbm5lY3RpbmcnLCBjb25uZWN0aW9uT3B0aW9ucy51cmwpO1xuICAgIGxvZ19kZWJ1ZyhgY29ubmVjdGlvbk9wdGlvbnMke3V0aWwuaW5zcGVjdChjb25uZWN0aW9uT3B0aW9ucyl9YCk7XG5cbiAgICB0aGlzLmNsaWVudCA9IGxkYXBqcy5jcmVhdGVDbGllbnQoY29ubmVjdGlvbk9wdGlvbnMpO1xuXG4gICAgdGhpcy5iaW5kU3luYyA9IE1ldGVvci53cmFwQXN5bmModGhpcy5jbGllbnQuYmluZCwgdGhpcy5jbGllbnQpO1xuXG4gICAgdGhpcy5jbGllbnQub24oJ2Vycm9yJywgKGVycm9yKSA9PiB7XG4gICAgICBsb2dfZXJyb3IoJ2Nvbm5lY3Rpb24nLCBlcnJvcik7XG4gICAgICBpZiAocmVwbGllZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmVwbGllZCA9IHRydWU7XG4gICAgICAgIGNhbGxiYWNrKGVycm9yLCBudWxsKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHRoaXMuY2xpZW50Lm9uKCdpZGxlJywgKCkgPT4ge1xuICAgICAgbG9nX2luZm8oJ0lkbGUnKTtcbiAgICAgIHRoaXMuZGlzY29ubmVjdCgpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5jbGllbnQub24oJ2Nsb3NlJywgKCkgPT4ge1xuICAgICAgbG9nX2luZm8oJ0Nsb3NlZCcpO1xuICAgIH0pO1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5lbmNyeXB0aW9uID09PSAndGxzJykge1xuICAgICAgLy8gU2V0IGhvc3QgcGFyYW1ldGVyIGZvciB0bHMuY29ubmVjdCB3aGljaCBpcyB1c2VkIGJ5IGxkYXBqcyBzdGFydHRscy4gVGhpcyBzaG91bGRuJ3QgYmUgbmVlZGVkIGluIG5ld2VyIG5vZGVqcyB2ZXJzaW9ucyAoZS5nIHY1LjYuMCkuXG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vUm9ja2V0Q2hhdC9Sb2NrZXQuQ2hhdC9pc3N1ZXMvMjAzNVxuICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL21jYXZhZ2Uvbm9kZS1sZGFwanMvaXNzdWVzLzM0OVxuICAgICAgdGxzT3B0aW9ucy5ob3N0ID0gdGhpcy5vcHRpb25zLmhvc3Q7XG5cbiAgICAgIGxvZ19pbmZvKCdTdGFydGluZyBUTFMnKTtcbiAgICAgIGxvZ19kZWJ1ZygndGxzT3B0aW9ucycsIHRsc09wdGlvbnMpO1xuXG4gICAgICB0aGlzLmNsaWVudC5zdGFydHRscyh0bHNPcHRpb25zLCBudWxsLCAoZXJyb3IsIHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIGxvZ19lcnJvcignVExTIGNvbm5lY3Rpb24nLCBlcnJvcik7XG4gICAgICAgICAgaWYgKHJlcGxpZWQgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICByZXBsaWVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGNhbGxiYWNrKGVycm9yLCBudWxsKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgbG9nX2luZm8oJ1RMUyBjb25uZWN0ZWQnKTtcbiAgICAgICAgdGhpcy5jb25uZWN0ZWQgPSB0cnVlO1xuICAgICAgICBpZiAocmVwbGllZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgICByZXBsaWVkID0gdHJ1ZTtcbiAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmNsaWVudC5vbignY29ubmVjdCcsIChyZXNwb25zZSkgPT4ge1xuICAgICAgICBsb2dfaW5mbygnTERBUCBjb25uZWN0ZWQnKTtcbiAgICAgICAgdGhpcy5jb25uZWN0ZWQgPSB0cnVlO1xuICAgICAgICBpZiAocmVwbGllZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgICByZXBsaWVkID0gdHJ1ZTtcbiAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKHJlcGxpZWQgPT09IGZhbHNlKSB7XG4gICAgICAgIGxvZ19lcnJvcignY29ubmVjdGlvbiB0aW1lIG91dCcsIGNvbm5lY3Rpb25PcHRpb25zLmNvbm5lY3RUaW1lb3V0KTtcbiAgICAgICAgcmVwbGllZCA9IHRydWU7XG4gICAgICAgIGNhbGxiYWNrKG5ldyBFcnJvcignVGltZW91dCcpKTtcbiAgICAgIH1cbiAgICB9LCBjb25uZWN0aW9uT3B0aW9ucy5jb25uZWN0VGltZW91dCk7XG4gIH1cblxuICBnZXRVc2VyRmlsdGVyKHVzZXJuYW1lKSB7XG4gICAgY29uc3QgZmlsdGVyID0gW107XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLlVzZXJfU2VhcmNoX0ZpbHRlciAhPT0gJycpIHtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuVXNlcl9TZWFyY2hfRmlsdGVyWzBdID09PSAnKCcpIHtcbiAgICAgICAgZmlsdGVyLnB1c2goYCR7dGhpcy5vcHRpb25zLlVzZXJfU2VhcmNoX0ZpbHRlcn1gKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZpbHRlci5wdXNoKGAoJHt0aGlzLm9wdGlvbnMuVXNlcl9TZWFyY2hfRmlsdGVyfSlgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCB1c2VybmFtZUZpbHRlciA9IHRoaXMub3B0aW9ucy5Vc2VyX1NlYXJjaF9GaWVsZC5zcGxpdCgnLCcpLm1hcCgoaXRlbSkgPT4gYCgke2l0ZW19PSR7dXNlcm5hbWV9KWApO1xuXG4gICAgaWYgKHVzZXJuYW1lRmlsdGVyLmxlbmd0aCA9PT0gMCkge1xuICAgICAgbG9nX2Vycm9yKCdMREFQX0xEQVBfVXNlcl9TZWFyY2hfRmllbGQgbm90IGRlZmluZWQnKTtcbiAgICB9IGVsc2UgaWYgKHVzZXJuYW1lRmlsdGVyLmxlbmd0aCA9PT0gMSkge1xuICAgICAgZmlsdGVyLnB1c2goYCR7dXNlcm5hbWVGaWx0ZXJbMF19YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpbHRlci5wdXNoKGAofCR7dXNlcm5hbWVGaWx0ZXIuam9pbignJyl9KWApO1xuICAgIH1cblxuICAgIHJldHVybiBgKCYke2ZpbHRlci5qb2luKCcnKX0pYDtcbiAgfVxuXG4gIGJpbmRVc2VySWZOZWNlc3NhcnkodXNlcm5hbWUsIHBhc3N3b3JkKSB7XG5cbiAgICBpZiAodGhpcy5kb21haW5CaW5kZWQgPT09IHRydWUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMub3B0aW9ucy5Vc2VyX0F1dGhlbnRpY2F0aW9uKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG5cbiAgICBpZiAoIXRoaXMub3B0aW9ucy5CYXNlRE4pIHRocm93IG5ldyBFcnJvcignQmFzZUROIGlzIG5vdCBwcm92aWRlZCcpO1xuXG4gICAgY29uc3QgdXNlckRuID0gYCR7dGhpcy5vcHRpb25zLlVzZXJfQXV0aGVudGljYXRpb25fRmllbGR9PSR7dXNlcm5hbWV9LCR7dGhpcy5vcHRpb25zLkJhc2VETn1gO1xuXG4gICAgdGhpcy5iaW5kU3luYyh1c2VyRG4sIHBhc3N3b3JkKTtcbiAgICB0aGlzLmRvbWFpbkJpbmRlZCA9IHRydWU7XG4gIH1cblxuICBiaW5kSWZOZWNlc3NhcnkoKSB7XG4gICAgaWYgKHRoaXMuZG9tYWluQmluZGVkID09PSB0cnVlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5BdXRoZW50aWNhdGlvbiAhPT0gdHJ1ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGxvZ19pbmZvKCdCaW5kaW5nIFVzZXJETicsIHRoaXMub3B0aW9ucy5BdXRoZW50aWNhdGlvbl9Vc2VyRE4pO1xuXG4gICAgdGhpcy5iaW5kU3luYyh0aGlzLm9wdGlvbnMuQXV0aGVudGljYXRpb25fVXNlckROLCB0aGlzLm9wdGlvbnMuQXV0aGVudGljYXRpb25fUGFzc3dvcmQpO1xuICAgIHRoaXMuZG9tYWluQmluZGVkID0gdHJ1ZTtcbiAgfVxuXG4gIHNlYXJjaFVzZXJzU3luYyh1c2VybmFtZSwgcGFnZSkge1xuICAgIHRoaXMuYmluZElmTmVjZXNzYXJ5KCk7XG4gICAgY29uc3Qgc2VhcmNoT3B0aW9ucyA9IHtcbiAgICAgIGZpbHRlciAgIDogdGhpcy5nZXRVc2VyRmlsdGVyKHVzZXJuYW1lKSxcbiAgICAgIHNjb3BlICAgIDogdGhpcy5vcHRpb25zLlVzZXJfU2VhcmNoX1Njb3BlIHx8ICdzdWInLFxuICAgICAgc2l6ZUxpbWl0OiB0aGlzLm9wdGlvbnMuU2VhcmNoX1NpemVfTGltaXQsXG4gICAgfTtcblxuICAgIGlmICghIXRoaXMub3B0aW9ucy5Vc2VyX0F0dHJpYnV0ZXMpIHNlYXJjaE9wdGlvbnMuYXR0cmlidXRlcyA9IHRoaXMub3B0aW9ucy5Vc2VyX0F0dHJpYnV0ZXMuc3BsaXQoJywnKTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMuU2VhcmNoX1BhZ2VfU2l6ZSA+IDApIHtcbiAgICAgIHNlYXJjaE9wdGlvbnMucGFnZWQgPSB7XG4gICAgICAgIHBhZ2VTaXplIDogdGhpcy5vcHRpb25zLlNlYXJjaF9QYWdlX1NpemUsXG4gICAgICAgIHBhZ2VQYXVzZTogISFwYWdlLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBsb2dfaW5mbygnU2VhcmNoaW5nIHVzZXInLCB1c2VybmFtZSk7XG4gICAgbG9nX2RlYnVnKCdzZWFyY2hPcHRpb25zJywgc2VhcmNoT3B0aW9ucyk7XG4gICAgbG9nX2RlYnVnKCdCYXNlRE4nLCB0aGlzLm9wdGlvbnMuQmFzZUROKTtcblxuICAgIGlmIChwYWdlKSB7XG4gICAgICByZXR1cm4gdGhpcy5zZWFyY2hBbGxQYWdlZCh0aGlzLm9wdGlvbnMuQmFzZUROLCBzZWFyY2hPcHRpb25zLCBwYWdlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5zZWFyY2hBbGxTeW5jKHRoaXMub3B0aW9ucy5CYXNlRE4sIHNlYXJjaE9wdGlvbnMpO1xuICB9XG5cbiAgZ2V0VXNlckJ5SWRTeW5jKGlkLCBhdHRyaWJ1dGUpIHtcbiAgICB0aGlzLmJpbmRJZk5lY2Vzc2FyeSgpO1xuXG4gICAgY29uc3QgVW5pcXVlX0lkZW50aWZpZXJfRmllbGQgPSB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9VTklRVUVfSURFTlRJRklFUl9GSUVMRCcpLnNwbGl0KCcsJyk7XG5cbiAgICBsZXQgZmlsdGVyO1xuXG4gICAgaWYgKGF0dHJpYnV0ZSkge1xuICAgICAgZmlsdGVyID0gbmV3IHRoaXMubGRhcGpzLmZpbHRlcnMuRXF1YWxpdHlGaWx0ZXIoe1xuICAgICAgICBhdHRyaWJ1dGUsXG4gICAgICAgIHZhbHVlOiBCdWZmZXIuZnJvbShpZCwgJ2hleCcpLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGZpbHRlcnMgPSBbXTtcbiAgICAgIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgZmlsdGVycy5wdXNoKG5ldyB0aGlzLmxkYXBqcy5maWx0ZXJzLkVxdWFsaXR5RmlsdGVyKHtcbiAgICAgICAgICBhdHRyaWJ1dGU6IGl0ZW0sXG4gICAgICAgICAgdmFsdWUgICAgOiBCdWZmZXIuZnJvbShpZCwgJ2hleCcpLFxuICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgZmlsdGVyID0gbmV3IHRoaXMubGRhcGpzLmZpbHRlcnMuT3JGaWx0ZXIoeyBmaWx0ZXJzIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHNlYXJjaE9wdGlvbnMgPSB7XG4gICAgICBmaWx0ZXIsXG4gICAgICBzY29wZTogJ3N1YicsXG4gICAgfTtcblxuICAgIGxvZ19pbmZvKCdTZWFyY2hpbmcgYnkgaWQnLCBpZCk7XG4gICAgbG9nX2RlYnVnKCdzZWFyY2ggZmlsdGVyJywgc2VhcmNoT3B0aW9ucy5maWx0ZXIudG9TdHJpbmcoKSk7XG4gICAgbG9nX2RlYnVnKCdCYXNlRE4nLCB0aGlzLm9wdGlvbnMuQmFzZUROKTtcblxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuc2VhcmNoQWxsU3luYyh0aGlzLm9wdGlvbnMuQmFzZUROLCBzZWFyY2hPcHRpb25zKTtcblxuICAgIGlmICghQXJyYXkuaXNBcnJheShyZXN1bHQpIHx8IHJlc3VsdC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAocmVzdWx0Lmxlbmd0aCA+IDEpIHtcbiAgICAgIGxvZ19lcnJvcignU2VhcmNoIGJ5IGlkJywgaWQsICdyZXR1cm5lZCcsIHJlc3VsdC5sZW5ndGgsICdyZWNvcmRzJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3VsdFswXTtcbiAgfVxuXG4gIGdldFVzZXJCeVVzZXJuYW1lU3luYyh1c2VybmFtZSkge1xuICAgIHRoaXMuYmluZElmTmVjZXNzYXJ5KCk7XG5cbiAgICBjb25zdCBzZWFyY2hPcHRpb25zID0ge1xuICAgICAgZmlsdGVyOiB0aGlzLmdldFVzZXJGaWx0ZXIodXNlcm5hbWUpLFxuICAgICAgc2NvcGUgOiB0aGlzLm9wdGlvbnMuVXNlcl9TZWFyY2hfU2NvcGUgfHwgJ3N1YicsXG4gICAgfTtcblxuICAgIGxvZ19pbmZvKCdTZWFyY2hpbmcgdXNlcicsIHVzZXJuYW1lKTtcbiAgICBsb2dfZGVidWcoJ3NlYXJjaE9wdGlvbnMnLCBzZWFyY2hPcHRpb25zKTtcbiAgICBsb2dfZGVidWcoJ0Jhc2VETicsIHRoaXMub3B0aW9ucy5CYXNlRE4pO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy5zZWFyY2hBbGxTeW5jKHRoaXMub3B0aW9ucy5CYXNlRE4sIHNlYXJjaE9wdGlvbnMpO1xuXG4gICAgaWYgKCFBcnJheS5pc0FycmF5KHJlc3VsdCkgfHwgcmVzdWx0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMSkge1xuICAgICAgbG9nX2Vycm9yKCdTZWFyY2ggYnkgdXNlcm5hbWUnLCB1c2VybmFtZSwgJ3JldHVybmVkJywgcmVzdWx0Lmxlbmd0aCwgJ3JlY29yZHMnKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzdWx0WzBdO1xuICB9XG5cbiAgZ2V0VXNlckdyb3Vwcyh1c2VybmFtZSwgbGRhcFVzZXIpIHtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgY29uc3QgZmlsdGVyID0gWycoJiddO1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfb2JqZWN0X2NsYXNzICE9PSAnJykge1xuICAgICAgZmlsdGVyLnB1c2goYChvYmplY3RjbGFzcz0ke3RoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfb2JqZWN0X2NsYXNzfSlgKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfYXR0cmlidXRlICE9PSAnJykge1xuICAgICAgY29uc3QgZm9ybWF0X3ZhbHVlID0gbGRhcFVzZXJbdGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfZm9ybWF0XTtcbiAgICAgIGlmIChmb3JtYXRfdmFsdWUpIHtcbiAgICAgICAgZmlsdGVyLnB1c2goYCgke3RoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZ3JvdXBfbWVtYmVyX2F0dHJpYnV0ZX09JHtmb3JtYXRfdmFsdWV9KWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGZpbHRlci5wdXNoKCcpJyk7XG5cbiAgICBjb25zdCBzZWFyY2hPcHRpb25zID0ge1xuICAgICAgZmlsdGVyOiBmaWx0ZXIuam9pbignJykucmVwbGFjZSgvI3t1c2VybmFtZX0vZywgdXNlcm5hbWUpLFxuICAgICAgc2NvcGUgOiAnc3ViJyxcbiAgICB9O1xuXG4gICAgbG9nX2RlYnVnKCdHcm91cCBsaXN0IGZpbHRlciBMREFQOicsIHNlYXJjaE9wdGlvbnMuZmlsdGVyKTtcblxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuc2VhcmNoQWxsU3luYyh0aGlzLm9wdGlvbnMuQmFzZUROLCBzZWFyY2hPcHRpb25zKTtcblxuICAgIGlmICghQXJyYXkuaXNBcnJheShyZXN1bHQpIHx8IHJlc3VsdC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBjb25zdCBncnBfaWRlbnRpZmllciA9IHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZ3JvdXBfaWRfYXR0cmlidXRlIHx8ICdjbic7XG4gICAgY29uc3QgZ3JvdXBzICAgICAgICAgPSBbXTtcbiAgICByZXN1bHQubWFwKChpdGVtKSA9PiB7XG4gICAgICBncm91cHMucHVzaChpdGVtW2dycF9pZGVudGlmaWVyXSk7XG4gICAgfSk7XG4gICAgbG9nX2RlYnVnKGBHcm91cHM6ICR7Z3JvdXBzLmpvaW4oJywgJyl9YCk7XG4gICAgcmV0dXJuIGdyb3VwcztcblxuICB9XG5cbiAgaXNVc2VySW5Hcm91cCh1c2VybmFtZSwgbGRhcFVzZXIpIHtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgY29uc3QgZ3JwcyA9IHRoaXMuZ2V0VXNlckdyb3Vwcyh1c2VybmFtZSwgbGRhcFVzZXIpO1xuXG4gICAgY29uc3QgZmlsdGVyID0gWycoJiddO1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfb2JqZWN0X2NsYXNzICE9PSAnJykge1xuICAgICAgZmlsdGVyLnB1c2goYChvYmplY3RjbGFzcz0ke3RoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfb2JqZWN0X2NsYXNzfSlgKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfYXR0cmlidXRlICE9PSAnJykge1xuICAgICAgY29uc3QgZm9ybWF0X3ZhbHVlID0gbGRhcFVzZXJbdGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfZm9ybWF0XTtcbiAgICAgIGlmIChmb3JtYXRfdmFsdWUpIHtcbiAgICAgICAgZmlsdGVyLnB1c2goYCgke3RoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZ3JvdXBfbWVtYmVyX2F0dHJpYnV0ZX09JHtmb3JtYXRfdmFsdWV9KWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX2lkX2F0dHJpYnV0ZSAhPT0gJycpIHtcbiAgICAgIGZpbHRlci5wdXNoKGAoJHt0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX2lkX2F0dHJpYnV0ZX09JHt0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX25hbWV9KWApO1xuICAgIH1cbiAgICBmaWx0ZXIucHVzaCgnKScpO1xuXG4gICAgY29uc3Qgc2VhcmNoT3B0aW9ucyA9IHtcbiAgICAgIGZpbHRlcjogZmlsdGVyLmpvaW4oJycpLnJlcGxhY2UoLyN7dXNlcm5hbWV9L2csIHVzZXJuYW1lKSxcbiAgICAgIHNjb3BlIDogJ3N1YicsXG4gICAgfTtcblxuICAgIGxvZ19kZWJ1ZygnR3JvdXAgZmlsdGVyIExEQVA6Jywgc2VhcmNoT3B0aW9ucy5maWx0ZXIpO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy5zZWFyY2hBbGxTeW5jKHRoaXMub3B0aW9ucy5CYXNlRE4sIHNlYXJjaE9wdGlvbnMpO1xuXG4gICAgaWYgKCFBcnJheS5pc0FycmF5KHJlc3VsdCkgfHwgcmVzdWx0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGV4dHJhY3RMZGFwRW50cnlEYXRhKGVudHJ5KSB7XG4gICAgY29uc3QgdmFsdWVzID0ge1xuICAgICAgX3JhdzogZW50cnkucmF3LFxuICAgIH07XG5cbiAgICBPYmplY3Qua2V5cyh2YWx1ZXMuX3JhdykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBjb25zdCB2YWx1ZSA9IHZhbHVlcy5fcmF3W2tleV07XG5cbiAgICAgIGlmICghWyd0aHVtYm5haWxQaG90bycsICdqcGVnUGhvdG8nXS5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEJ1ZmZlcikge1xuICAgICAgICAgIHZhbHVlc1trZXldID0gdmFsdWUudG9TdHJpbmcoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YWx1ZXNba2V5XSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gdmFsdWVzO1xuICB9XG5cbiAgc2VhcmNoQWxsUGFnZWQoQmFzZUROLCBvcHRpb25zLCBwYWdlKSB7XG4gICAgdGhpcy5iaW5kSWZOZWNlc3NhcnkoKTtcblxuICAgIGNvbnN0IHByb2Nlc3NQYWdlID0gKHsgZW50cmllcywgdGl0bGUsIGVuZCwgbmV4dCB9KSA9PiB7XG4gICAgICBsb2dfaW5mbyh0aXRsZSk7XG4gICAgICAvLyBGb3JjZSBMREFQIGlkbGUgdG8gd2FpdCB0aGUgcmVjb3JkIHByb2Nlc3NpbmdcbiAgICAgIHRoaXMuY2xpZW50Ll91cGRhdGVJZGxlKHRydWUpO1xuICAgICAgcGFnZShudWxsLCBlbnRyaWVzLCB7XG4gICAgICAgIGVuZCwgbmV4dDogKCkgPT4ge1xuICAgICAgICAgIC8vIFJlc2V0IGlkbGUgdGltZXJcbiAgICAgICAgICB0aGlzLmNsaWVudC5fdXBkYXRlSWRsZSgpO1xuICAgICAgICAgIG5leHQgJiYgbmV4dCgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgdGhpcy5jbGllbnQuc2VhcmNoKEJhc2VETiwgb3B0aW9ucywgKGVycm9yLCByZXMpID0+IHtcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICAgICAgICBwYWdlKGVycm9yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICByZXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiB7XG4gICAgICAgIGxvZ19lcnJvcihlcnJvcik7XG4gICAgICAgIHBhZ2UoZXJyb3IpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9KTtcblxuICAgICAgbGV0IGVudHJpZXMgPSBbXTtcblxuICAgICAgY29uc3QgaW50ZXJuYWxQYWdlU2l6ZSA9IG9wdGlvbnMucGFnZWQgJiYgb3B0aW9ucy5wYWdlZC5wYWdlU2l6ZSA+IDAgPyBvcHRpb25zLnBhZ2VkLnBhZ2VTaXplICogMiA6IDUwMDtcblxuICAgICAgcmVzLm9uKCdzZWFyY2hFbnRyeScsIChlbnRyeSkgPT4ge1xuICAgICAgICBlbnRyaWVzLnB1c2godGhpcy5leHRyYWN0TGRhcEVudHJ5RGF0YShlbnRyeSkpO1xuXG4gICAgICAgIGlmIChlbnRyaWVzLmxlbmd0aCA+PSBpbnRlcm5hbFBhZ2VTaXplKSB7XG4gICAgICAgICAgcHJvY2Vzc1BhZ2Uoe1xuICAgICAgICAgICAgZW50cmllcyxcbiAgICAgICAgICAgIHRpdGxlOiAnSW50ZXJuYWwgUGFnZScsXG4gICAgICAgICAgICBlbmQgIDogZmFsc2UsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZW50cmllcyA9IFtdO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgcmVzLm9uKCdwYWdlJywgKHJlc3VsdCwgbmV4dCkgPT4ge1xuICAgICAgICBpZiAoIW5leHQpIHtcbiAgICAgICAgICB0aGlzLmNsaWVudC5fdXBkYXRlSWRsZSh0cnVlKTtcbiAgICAgICAgICBwcm9jZXNzUGFnZSh7XG4gICAgICAgICAgICBlbnRyaWVzLFxuICAgICAgICAgICAgdGl0bGU6ICdGaW5hbCBQYWdlJyxcbiAgICAgICAgICAgIGVuZCAgOiB0cnVlLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGVudHJpZXMubGVuZ3RoKSB7XG4gICAgICAgICAgbG9nX2luZm8oJ1BhZ2UnKTtcbiAgICAgICAgICBwcm9jZXNzUGFnZSh7XG4gICAgICAgICAgICBlbnRyaWVzLFxuICAgICAgICAgICAgdGl0bGU6ICdQYWdlJyxcbiAgICAgICAgICAgIGVuZCAgOiBmYWxzZSxcbiAgICAgICAgICAgIG5leHQsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZW50cmllcyA9IFtdO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgcmVzLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICAgIGlmIChlbnRyaWVzLmxlbmd0aCkge1xuICAgICAgICAgIHByb2Nlc3NQYWdlKHtcbiAgICAgICAgICAgIGVudHJpZXMsXG4gICAgICAgICAgICB0aXRsZTogJ0ZpbmFsIFBhZ2UnLFxuICAgICAgICAgICAgZW5kICA6IHRydWUsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZW50cmllcyA9IFtdO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHNlYXJjaEFsbEFzeW5jKEJhc2VETiwgb3B0aW9ucywgY2FsbGJhY2spIHtcbiAgICB0aGlzLmJpbmRJZk5lY2Vzc2FyeSgpO1xuXG4gICAgdGhpcy5jbGllbnQuc2VhcmNoKEJhc2VETiwgb3B0aW9ucywgKGVycm9yLCByZXMpID0+IHtcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICAgICAgICBjYWxsYmFjayhlcnJvcik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgcmVzLm9uKCdlcnJvcicsIChlcnJvcikgPT4ge1xuICAgICAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICAgICAgICBjYWxsYmFjayhlcnJvcik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBlbnRyaWVzID0gW107XG5cbiAgICAgIHJlcy5vbignc2VhcmNoRW50cnknLCAoZW50cnkpID0+IHtcbiAgICAgICAgZW50cmllcy5wdXNoKHRoaXMuZXh0cmFjdExkYXBFbnRyeURhdGEoZW50cnkpKTtcbiAgICAgIH0pO1xuXG4gICAgICByZXMub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgbG9nX2luZm8oJ1NlYXJjaCByZXN1bHQgY291bnQnLCBlbnRyaWVzLmxlbmd0aCk7XG4gICAgICAgIGNhbGxiYWNrKG51bGwsIGVudHJpZXMpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBhdXRoU3luYyhkbiwgcGFzc3dvcmQpIHtcbiAgICBsb2dfaW5mbygnQXV0aGVudGljYXRpbmcnLCBkbik7XG5cbiAgICB0cnkge1xuICAgICAgaWYgKHBhc3N3b3JkID09PSAnJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Bhc3N3b3JkIGlzIG5vdCBwcm92aWRlZCcpO1xuICAgICAgfVxuICAgICAgdGhpcy5iaW5kU3luYyhkbiwgcGFzc3dvcmQpO1xuICAgICAgbG9nX2luZm8oJ0F1dGhlbnRpY2F0ZWQnLCBkbik7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nX2luZm8oJ05vdCBhdXRoZW50aWNhdGVkJywgZG4pO1xuICAgICAgbG9nX2RlYnVnKCdlcnJvcicsIGVycm9yKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBkaXNjb25uZWN0KCkge1xuICAgIHRoaXMuY29ubmVjdGVkICAgID0gZmFsc2U7XG4gICAgdGhpcy5kb21haW5CaW5kZWQgPSBmYWxzZTtcbiAgICBsb2dfaW5mbygnRGlzY29uZWN0aW5nJyk7XG4gICAgdGhpcy5jbGllbnQudW5iaW5kKCk7XG4gIH1cbn1cbiIsImNvbnN0IGlzTG9nRW5hYmxlZCA9IChwcm9jZXNzLmVudi5MREFQX0xPR19FTkFCTEVEID09PSAndHJ1ZScpO1xuXG5cbmZ1bmN0aW9uIGxvZyAobGV2ZWwsIG1lc3NhZ2UsIGRhdGEpIHsgXG4gICAgaWYgKGlzTG9nRW5hYmxlZCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgWyR7bGV2ZWx9XSAke21lc3NhZ2V9ICR7IGRhdGEgPyBKU09OLnN0cmluZ2lmeShkYXRhLCBudWxsLCAyKSA6ICcnIH1gKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGxvZ19kZWJ1ZyAoLi4uYXJncykgeyBsb2coJ0RFQlVHJywgLi4uYXJncyk7IH1cbmZ1bmN0aW9uIGxvZ19pbmZvICguLi5hcmdzKSB7IGxvZygnSU5GTycsIC4uLmFyZ3MpOyB9XG5mdW5jdGlvbiBsb2dfd2FybiAoLi4uYXJncykgeyBsb2coJ1dBUk4nLCAuLi5hcmdzKTsgfVxuZnVuY3Rpb24gbG9nX2Vycm9yICguLi5hcmdzKSB7IGxvZygnRVJST1InLCAuLi5hcmdzKTsgfVxuXG5leHBvcnQgeyBsb2csIGxvZ19kZWJ1ZywgbG9nX2luZm8sIGxvZ193YXJuLCBsb2dfZXJyb3IgfTtcbiIsImltcG9ydCB7c2x1ZywgZ2V0TGRhcFVzZXJuYW1lLCBnZXRMZGFwRW1haWwsIGdldExkYXBVc2VyVW5pcXVlSUQsIHN5bmNVc2VyRGF0YSwgYWRkTGRhcFVzZXJ9IGZyb20gJy4vc3luYyc7XG5pbXBvcnQgTERBUCBmcm9tICcuL2xkYXAnO1xuaW1wb3J0IHsgbG9nX2RlYnVnLCBsb2dfaW5mbywgbG9nX3dhcm4sIGxvZ19lcnJvciB9IGZyb20gJy4vbG9nZ2VyJztcblxuZnVuY3Rpb24gZmFsbGJhY2tEZWZhdWx0QWNjb3VudFN5c3RlbShiaW5kLCB1c2VybmFtZSwgcGFzc3dvcmQpIHtcbiAgaWYgKHR5cGVvZiB1c2VybmFtZSA9PT0gJ3N0cmluZycpIHtcbiAgICBpZiAodXNlcm5hbWUuaW5kZXhPZignQCcpID09PSAtMSkge1xuICAgICAgdXNlcm5hbWUgPSB7dXNlcm5hbWV9O1xuICAgIH0gZWxzZSB7XG4gICAgICB1c2VybmFtZSA9IHtlbWFpbDogdXNlcm5hbWV9O1xuICAgIH1cbiAgfVxuXG4gIGxvZ19pbmZvKCdGYWxsYmFjayB0byBkZWZhdWx0IGFjY291bnQgc3lzdGVtOiAnLCB1c2VybmFtZSApO1xuXG4gIGNvbnN0IGxvZ2luUmVxdWVzdCA9IHtcbiAgICB1c2VyOiB1c2VybmFtZSxcbiAgICBwYXNzd29yZDoge1xuICAgICAgZGlnZXN0OiBTSEEyNTYocGFzc3dvcmQpLFxuICAgICAgYWxnb3JpdGhtOiAnc2hhLTI1NicsXG4gICAgfSxcbiAgfTtcbiAgbG9nX2RlYnVnKCdGYWxsYmFjayBvcHRpb25zOiAnLCBsb2dpblJlcXVlc3QpO1xuXG4gIHJldHVybiBBY2NvdW50cy5fcnVuTG9naW5IYW5kbGVycyhiaW5kLCBsb2dpblJlcXVlc3QpO1xufVxuXG5BY2NvdW50cy5yZWdpc3RlckxvZ2luSGFuZGxlcignbGRhcCcsIGZ1bmN0aW9uKGxvZ2luUmVxdWVzdCkge1xuICBpZiAoIWxvZ2luUmVxdWVzdC5sZGFwIHx8ICFsb2dpblJlcXVlc3QubGRhcE9wdGlvbnMpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgbG9nX2luZm8oJ0luaXQgTERBUCBsb2dpbicsIGxvZ2luUmVxdWVzdC51c2VybmFtZSk7XG5cbiAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0VOQUJMRScpICE9PSB0cnVlKSB7XG4gICAgcmV0dXJuIGZhbGxiYWNrRGVmYXVsdEFjY291bnRTeXN0ZW0odGhpcywgbG9naW5SZXF1ZXN0LnVzZXJuYW1lLCBsb2dpblJlcXVlc3QubGRhcFBhc3MpO1xuICB9XG5cbiAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gIGNvbnN0IGxkYXAgPSBuZXcgTERBUCgpO1xuICBsZXQgbGRhcFVzZXI7XG5cbiAgdHJ5IHtcblxuICAgICAgbGRhcC5jb25uZWN0U3luYygpO1xuXG4gICAgIGlmICghIUxEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1VTRVJfQVVUSEVOVElDQVRJT04nKSkge1xuICAgICAgICBsZGFwLmJpbmRVc2VySWZOZWNlc3NhcnkobG9naW5SZXF1ZXN0LnVzZXJuYW1lLCBsb2dpblJlcXVlc3QubGRhcFBhc3MpO1xuICAgICAgIGxkYXBVc2VyID0gbGRhcC5zZWFyY2hVc2Vyc1N5bmMobG9naW5SZXF1ZXN0LnVzZXJuYW1lKVswXTtcbiAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgY29uc3QgdXNlcnMgPSBsZGFwLnNlYXJjaFVzZXJzU3luYyhsb2dpblJlcXVlc3QudXNlcm5hbWUpO1xuXG4gICAgICAgaWYgKHVzZXJzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgICAgbG9nX2luZm8oJ1NlYXJjaCByZXR1cm5lZCcsIHVzZXJzLmxlbmd0aCwgJ3JlY29yZChzKSBmb3InLCBsb2dpblJlcXVlc3QudXNlcm5hbWUpO1xuICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVc2VyIG5vdCBGb3VuZCcpO1xuICAgICAgIH1cblxuICAgICAgIGlmIChsZGFwLmF1dGhTeW5jKHVzZXJzWzBdLmRuLCBsb2dpblJlcXVlc3QubGRhcFBhc3MpID09PSB0cnVlKSB7XG4gICAgICAgICBpZiAobGRhcC5pc1VzZXJJbkdyb3VwKGxvZ2luUmVxdWVzdC51c2VybmFtZSwgdXNlcnNbMF0pKSB7XG4gICAgICAgICAgIGxkYXBVc2VyID0gdXNlcnNbMF07XG4gICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VzZXIgbm90IGluIGEgdmFsaWQgZ3JvdXAnKTtcbiAgICAgICAgIH1cbiAgICAgICB9IGVsc2Uge1xuICAgICAgICAgbG9nX2luZm8oJ1dyb25nIHBhc3N3b3JkIGZvcicsIGxvZ2luUmVxdWVzdC51c2VybmFtZSk7XG4gICAgICAgfVxuICAgICB9XG5cblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICB9XG5cbiAgaWYgKCFsZGFwVXNlcikge1xuICAgIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9MT0dJTl9GQUxMQkFDSycpID09PSB0cnVlKSB7XG4gICAgICByZXR1cm4gZmFsbGJhY2tEZWZhdWx0QWNjb3VudFN5c3RlbShzZWxmLCBsb2dpblJlcXVlc3QudXNlcm5hbWUsIGxvZ2luUmVxdWVzdC5sZGFwUGFzcyk7XG4gICAgfVxuXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignTERBUC1sb2dpbi1lcnJvcicsIGBMREFQIEF1dGhlbnRpY2F0aW9uIGZhaWxlZCB3aXRoIHByb3ZpZGVkIHVzZXJuYW1lIFskeyBsb2dpblJlcXVlc3QudXNlcm5hbWUgfV1gKTtcbiAgfVxuXG4gIC8vIExvb2sgdG8gc2VlIGlmIHVzZXIgYWxyZWFkeSBleGlzdHNcblxuICBsZXQgdXNlclF1ZXJ5O1xuXG4gIGNvbnN0IFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0gZ2V0TGRhcFVzZXJVbmlxdWVJRChsZGFwVXNlcik7XG4gIGxldCB1c2VyO1xuICAgLy8gQXR0ZW1wdCB0byBmaW5kIHVzZXIgYnkgdW5pcXVlIGlkZW50aWZpZXJcblxuICBpZiAoVW5pcXVlX0lkZW50aWZpZXJfRmllbGQpIHtcbiAgICB1c2VyUXVlcnkgPSB7XG4gICAgICAnc2VydmljZXMubGRhcC5pZCc6IFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkLnZhbHVlLFxuICAgIH07XG5cbiAgICBsb2dfaW5mbygnUXVlcnlpbmcgdXNlcicpO1xuICAgIGxvZ19kZWJ1ZygndXNlclF1ZXJ5JywgdXNlclF1ZXJ5KTtcblxuICAgIHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh1c2VyUXVlcnkpO1xuICAgfVxuXG4gIC8vIEF0dGVtcHQgdG8gZmluZCB1c2VyIGJ5IHVzZXJuYW1lXG5cbiAgbGV0IHVzZXJuYW1lO1xuICBsZXQgZW1haWw7XG5cbiAgIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9VU0VSTkFNRV9GSUVMRCcpICE9PSAnJykge1xuICAgIHVzZXJuYW1lID0gc2x1ZyhnZXRMZGFwVXNlcm5hbWUobGRhcFVzZXIpKTtcbiAgfSBlbHNlIHtcbiAgICB1c2VybmFtZSA9IHNsdWcobG9naW5SZXF1ZXN0LnVzZXJuYW1lKTtcbiAgfVxuXG4gIGlmKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0VNQUlMX0ZJRUxEJykgIT09ICcnKSB7XG4gICAgZW1haWwgPSBnZXRMZGFwRW1haWwobGRhcFVzZXIpO1xuICB9XG5cblxuICBpZiAoIXVzZXIpIHtcbiAgICBpZihlbWFpbCAmJiBMREFQLnNldHRpbmdzX2dldCgnTERBUF9FTUFJTF9NQVRDSF9SRVFVSVJFJykgPT09IHRydWUpIHtcbiAgICAgIGlmKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0VNQUlMX01BVENIX1ZFUklGSUVEJykgPT09IHRydWUpIHtcbiAgICAgICAgdXNlclF1ZXJ5ID0ge1xuICAgICAgICAgICdfaWQnIDogdXNlcm5hbWUsXG4gICAgICAgICAgJ2VtYWlscy4wLmFkZHJlc3MnIDogZW1haWwsXG4gICAgICAgICAgJ2VtYWlscy4wLnZlcmlmaWVkJyA6IHRydWVcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHVzZXJRdWVyeSA9IHtcbiAgICAgICAgICAnX2lkJyA6IHVzZXJuYW1lLFxuICAgICAgICAgICdlbWFpbHMuMC5hZGRyZXNzJyA6IGVtYWlsXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHVzZXJRdWVyeSA9IHtcbiAgICAgICAgdXNlcm5hbWVcbiAgICAgIH07XG4gICAgfVxuXG4gICAgbG9nX2RlYnVnKCd1c2VyUXVlcnknLCB1c2VyUXVlcnkpO1xuXG4gICAgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHVzZXJRdWVyeSk7XG4gIH1cblxuICAvLyBBdHRlbXB0IHRvIGZpbmQgdXNlciBieSBlLW1haWwgYWRkcmVzcyBvbmx5XG5cbiAgaWYgKCF1c2VyICYmIGVtYWlsICYmIExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0VNQUlMX01BVENIX0VOQUJMRScpID09PSB0cnVlKSB7XG5cbiAgICBsb2dfaW5mbygnTm8gdXNlciBleGlzdHMgd2l0aCB1c2VybmFtZScsIHVzZXJuYW1lLCAnLSBhdHRlbXB0aW5nIHRvIGZpbmQgYnkgZS1tYWlsIGFkZHJlc3MgaW5zdGVhZCcpO1xuXG4gICAgaWYoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU1BSUxfTUFUQ0hfVkVSSUZJRUQnKSA9PT0gdHJ1ZSkge1xuICAgICAgdXNlclF1ZXJ5ID0ge1xuICAgICAgICAnZW1haWxzLjAuYWRkcmVzcyc6IGVtYWlsLFxuICAgICAgICAnZW1haWxzLjAudmVyaWZpZWQnIDogdHJ1ZVxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgdXNlclF1ZXJ5ID0ge1xuICAgICAgICAnZW1haWxzLjAuYWRkcmVzcycgOiBlbWFpbFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBsb2dfZGVidWcoJ3VzZXJRdWVyeScsIHVzZXJRdWVyeSk7XG5cbiAgICB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodXNlclF1ZXJ5KTtcblxuICB9XG5cbiAgLy8gTG9naW4gdXNlciBpZiB0aGV5IGV4aXN0XG4gIGlmICh1c2VyKSB7XG4gICAgaWYgKHVzZXIuYXV0aGVudGljYXRpb25NZXRob2QgIT09ICdsZGFwJyAmJiBMREFQLnNldHRpbmdzX2dldCgnTERBUF9NRVJHRV9FWElTVElOR19VU0VSUycpICE9PSB0cnVlKSB7XG4gICAgICBsb2dfaW5mbygnVXNlciBleGlzdHMgd2l0aG91dCBcImF1dGhlbnRpY2F0aW9uTWV0aG9kIDogbGRhcFwiJyk7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdMREFQLWxvZ2luLWVycm9yJywgYExEQVAgQXV0aGVudGljYXRpb24gc3VjY2VkZWQsIGJ1dCB0aGVyZSdzIGFscmVhZHkgYSBtYXRjaGluZyBXZWthbiBhY2NvdW50IGluIE1vbmdvREJgKTtcbiAgICB9XG5cbiAgICBsb2dfaW5mbygnTG9nZ2luZyB1c2VyJyk7XG5cbiAgICBjb25zdCBzdGFtcGVkVG9rZW4gPSBBY2NvdW50cy5fZ2VuZXJhdGVTdGFtcGVkTG9naW5Ub2tlbigpO1xuICAgIGNvbnN0IHVwZGF0ZV9kYXRhID0ge1xuICAgICAgJHB1c2g6IHtcbiAgICAgICAgJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucyc6IEFjY291bnRzLl9oYXNoU3RhbXBlZFRva2VuKHN0YW1wZWRUb2tlbiksXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfU1lOQ19BRE1JTl9TVEFUVVMnKSA9PT0gdHJ1ZSkge1xuICAgICAgbG9nX2RlYnVnKCdVcGRhdGluZyBhZG1pbiBzdGF0dXMnKTtcbiAgICAgIGNvbnN0IHRhcmdldEdyb3VwcyA9IExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1NZTkNfQURNSU5fR1JPVVBTJykuc3BsaXQoJywnKTtcbiAgICAgIGNvbnN0IGdyb3VwcyA9IGxkYXAuZ2V0VXNlckdyb3Vwcyh1c2VybmFtZSwgbGRhcFVzZXIpLmZpbHRlcigodmFsdWUpID0+IHRhcmdldEdyb3Vwcy5pbmNsdWRlcyh2YWx1ZSkpO1xuXG4gICAgICB1c2VyLmlzQWRtaW4gPSBncm91cHMubGVuZ3RoID4gMDtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LCB7JHNldDoge2lzQWRtaW46IHVzZXIuaXNBZG1pbn19KTtcbiAgICB9XG5cbiAgICBpZiggTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfU1lOQ19HUk9VUF9ST0xFUycpID09PSB0cnVlICkge1xuICAgICAgbG9nX2RlYnVnKCdVcGRhdGluZyBHcm91cHMvUm9sZXMnKTtcbiAgICAgIGNvbnN0IGdyb3VwcyA9IGxkYXAuZ2V0VXNlckdyb3Vwcyh1c2VybmFtZSwgbGRhcFVzZXIpO1xuXG4gICAgICBpZiggZ3JvdXBzLmxlbmd0aCA+IDAgKSB7XG4gICAgICAgIFJvbGVzLnNldFVzZXJSb2xlcyh1c2VyLl9pZCwgZ3JvdXBzICk7XG4gICAgICAgIGxvZ19pbmZvKGBVcGRhdGVkIHJvbGVzIHRvOiR7ICBncm91cHMuam9pbignLCcpfWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIE1ldGVvci51c2Vycy51cGRhdGUodXNlci5faWQsIHVwZGF0ZV9kYXRhICk7XG5cbiAgICBzeW5jVXNlckRhdGEodXNlciwgbGRhcFVzZXIpO1xuXG4gICAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0xPR0lOX0ZBTExCQUNLJykgPT09IHRydWUpIHtcbiAgICAgIEFjY291bnRzLnNldFBhc3N3b3JkKHVzZXIuX2lkLCBsb2dpblJlcXVlc3QubGRhcFBhc3MsIHtsb2dvdXQ6IGZhbHNlfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHVzZXJJZDogdXNlci5faWQsXG4gICAgICB0b2tlbjogc3RhbXBlZFRva2VuLnRva2VuLFxuICAgIH07XG4gIH1cblxuICAvLyBDcmVhdGUgbmV3IHVzZXJcblxuICBsb2dfaW5mbygnVXNlciBkb2VzIG5vdCBleGlzdCwgY3JlYXRpbmcnLCB1c2VybmFtZSk7XG5cbiAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1VTRVJOQU1FX0ZJRUxEJykgPT09ICcnKSB7XG4gICAgdXNlcm5hbWUgPSB1bmRlZmluZWQ7XG4gIH1cblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfTE9HSU5fRkFMTEJBQ0snKSAhPT0gdHJ1ZSkge1xuICAgIGxvZ2luUmVxdWVzdC5sZGFwUGFzcyA9IHVuZGVmaW5lZDtcbiAgfVxuXG4gIGNvbnN0IHJlc3VsdCA9IGFkZExkYXBVc2VyKGxkYXBVc2VyLCB1c2VybmFtZSwgbG9naW5SZXF1ZXN0LmxkYXBQYXNzKTtcblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfU1lOQ19BRE1JTl9TVEFUVVMnKSA9PT0gdHJ1ZSkge1xuICAgIGxvZ19kZWJ1ZygnVXBkYXRpbmcgYWRtaW4gc3RhdHVzJyk7XG4gICAgY29uc3QgdGFyZ2V0R3JvdXBzID0gTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfU1lOQ19BRE1JTl9HUk9VUFMnKS5zcGxpdCgnLCcpO1xuICAgIGNvbnN0IGdyb3VwcyA9IGxkYXAuZ2V0VXNlckdyb3Vwcyh1c2VybmFtZSwgbGRhcFVzZXIpLmZpbHRlcigodmFsdWUpID0+IHRhcmdldEdyb3Vwcy5pbmNsdWRlcyh2YWx1ZSkpO1xuXG4gICAgcmVzdWx0LmlzQWRtaW4gPSBncm91cHMubGVuZ3RoID4gMDtcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHJlc3VsdC51c2VySWR9LCB7JHNldDoge2lzQWRtaW46IHJlc3VsdC5pc0FkbWlufX0pO1xuICB9XG5cbiAgaWYoIExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1NZTkNfR1JPVVBfUk9MRVMnKSA9PT0gdHJ1ZSApIHtcbiAgICBjb25zdCBncm91cHMgPSBsZGFwLmdldFVzZXJHcm91cHModXNlcm5hbWUsIGxkYXBVc2VyKTtcbiAgICBpZiggZ3JvdXBzLmxlbmd0aCA+IDAgKSB7XG4gICAgICBSb2xlcy5zZXRVc2VyUm9sZXMocmVzdWx0LnVzZXJJZCwgZ3JvdXBzICk7XG4gICAgICBsb2dfaW5mbyhgU2V0IHJvbGVzIHRvOiR7ICBncm91cHMuam9pbignLCcpfWApO1xuICAgIH1cbiAgfVxuXG5cbiAgaWYgKHJlc3VsdCBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgdGhyb3cgcmVzdWx0O1xuICB9XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn0pO1xuIiwiaW1wb3J0IF8gZnJvbSAndW5kZXJzY29yZSc7XG5pbXBvcnQgU3luY2VkQ3JvbiBmcm9tICdtZXRlb3IvcGVyY29sYXRlOnN5bmNlZC1jcm9uJztcbmltcG9ydCBMREFQIGZyb20gJy4vbGRhcCc7XG5pbXBvcnQgeyBsb2dfZGVidWcsIGxvZ19pbmZvLCBsb2dfd2FybiwgbG9nX2Vycm9yIH0gZnJvbSAnLi9sb2dnZXInO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoT2JqZWN0LnByb3RvdHlwZSwgXCJnZXRMREFQVmFsdWVcIiwge1xuICB2YWx1ZTogZnVuY3Rpb24gKHByb3ApIHtcbiAgICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgICAgZm9yIChsZXQga2V5IGluIHNlbGYpIHtcbiAgICAgICAgICBpZiAoa2V5LnRvTG93ZXJDYXNlKCkgPT0gcHJvcC50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBzZWxmW2tleV07XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9LFxuXG4gIGVudW1lcmFibGU6IGZhbHNlXG59KTtcblxuZXhwb3J0IGZ1bmN0aW9uIHNsdWcodGV4dCkge1xuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfVVRGOF9OQU1FU19TTFVHSUZZJykgIT09IHRydWUpIHtcbiAgICByZXR1cm4gdGV4dDtcbiAgfVxuICB0ZXh0ID0gc2x1Z2lmeSh0ZXh0LCAnLicpO1xuICByZXR1cm4gdGV4dC5yZXBsYWNlKC9bXjAtOWEtei1fLl0vZywgJycpO1xufVxuXG5mdW5jdGlvbiB0ZW1wbGF0ZVZhckhhbmRsZXIgKHZhcmlhYmxlLCBvYmplY3QpIHtcblxuICBjb25zdCB0ZW1wbGF0ZVJlZ2V4ID0gLyN7KFtcXHdcXC1dKyl9L2dpO1xuICBsZXQgbWF0Y2ggPSB0ZW1wbGF0ZVJlZ2V4LmV4ZWModmFyaWFibGUpO1xuICBsZXQgdG1wVmFyaWFibGUgPSB2YXJpYWJsZTtcblxuICBpZiAobWF0Y2ggPT0gbnVsbCkge1xuICAgIGlmICghb2JqZWN0Lmhhc093blByb3BlcnR5KHZhcmlhYmxlKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0W3ZhcmlhYmxlXTtcbiAgfSBlbHNlIHtcbiAgICB3aGlsZSAobWF0Y2ggIT0gbnVsbCkge1xuICAgICAgY29uc3QgdG1wbFZhciA9IG1hdGNoWzBdO1xuICAgICAgY29uc3QgdG1wbEF0dHJOYW1lID0gbWF0Y2hbMV07XG5cbiAgICAgIGlmICghb2JqZWN0Lmhhc093blByb3BlcnR5KHRtcGxBdHRyTmFtZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBhdHRyVmFsID0gb2JqZWN0W3RtcGxBdHRyTmFtZV07XG4gICAgICB0bXBWYXJpYWJsZSA9IHRtcFZhcmlhYmxlLnJlcGxhY2UodG1wbFZhciwgYXR0clZhbCk7XG4gICAgICBtYXRjaCA9IHRlbXBsYXRlUmVnZXguZXhlYyh2YXJpYWJsZSk7XG4gICAgfVxuICAgIHJldHVybiB0bXBWYXJpYWJsZTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0UHJvcGVydHlWYWx1ZShvYmosIGtleSkge1xuICB0cnkge1xuICAgIHJldHVybiBfLnJlZHVjZShrZXkuc3BsaXQoJy4nKSwgKGFjYywgZWwpID0+IGFjY1tlbF0sIG9iaik7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExkYXBVc2VybmFtZShsZGFwVXNlcikge1xuICBjb25zdCB1c2VybmFtZUZpZWxkID0gTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUk5BTUVfRklFTEQnKTtcblxuICBpZiAodXNlcm5hbWVGaWVsZC5pbmRleE9mKCcjeycpID4gLTEpIHtcbiAgICByZXR1cm4gdXNlcm5hbWVGaWVsZC5yZXBsYWNlKC8jeyguKz8pfS9nLCBmdW5jdGlvbihtYXRjaCwgZmllbGQpIHtcbiAgICAgIHJldHVybiBsZGFwVXNlci5nZXRMREFQVmFsdWUoZmllbGQpO1xuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIGxkYXBVc2VyLmdldExEQVBWYWx1ZSh1c2VybmFtZUZpZWxkKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExkYXBFbWFpbChsZGFwVXNlcikge1xuICBjb25zdCBlbWFpbEZpZWxkID0gTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU1BSUxfRklFTEQnKTtcblxuICBpZiAoZW1haWxGaWVsZC5pbmRleE9mKCcjeycpID4gLTEpIHtcbiAgICByZXR1cm4gZW1haWxGaWVsZC5yZXBsYWNlKC8jeyguKz8pfS9nLCBmdW5jdGlvbihtYXRjaCwgZmllbGQpIHtcbiAgICAgIHJldHVybiBsZGFwVXNlci5nZXRMREFQVmFsdWUoZmllbGQpO1xuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIGxkYXBVc2VyLmdldExEQVBWYWx1ZShlbWFpbEZpZWxkKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExkYXBGdWxsbmFtZShsZGFwVXNlcikge1xuICBjb25zdCBmdWxsbmFtZUZpZWxkID0gTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRlVMTE5BTUVfRklFTEQnKTtcbiAgaWYgKGZ1bGxuYW1lRmllbGQuaW5kZXhPZignI3snKSA+IC0xKSB7XG4gICAgcmV0dXJuIGZ1bGxuYW1lRmllbGQucmVwbGFjZSgvI3soLis/KX0vZywgZnVuY3Rpb24obWF0Y2gsIGZpZWxkKSB7XG4gICAgICByZXR1cm4gbGRhcFVzZXIuZ2V0TERBUFZhbHVlKGZpZWxkKTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gbGRhcFVzZXIuZ2V0TERBUFZhbHVlKGZ1bGxuYW1lRmllbGQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGRhcFVzZXJVbmlxdWVJRChsZGFwVXNlcikge1xuICBsZXQgVW5pcXVlX0lkZW50aWZpZXJfRmllbGQgPSBMREFQLnNldHRpbmdzX2dldCgnTERBUF9VTklRVUVfSURFTlRJRklFUl9GSUVMRCcpO1xuXG4gIGlmIChVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCAhPT0gJycpIHtcbiAgICBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCA9IFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkLnJlcGxhY2UoL1xccy9nLCAnJykuc3BsaXQoJywnKTtcbiAgfSBlbHNlIHtcbiAgICBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCA9IFtdO1xuICB9XG5cbiAgbGV0IFVzZXJfU2VhcmNoX0ZpZWxkID0gTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUl9TRUFSQ0hfRklFTEQnKTtcblxuICBpZiAoVXNlcl9TZWFyY2hfRmllbGQgIT09ICcnKSB7XG4gICAgVXNlcl9TZWFyY2hfRmllbGQgPSBVc2VyX1NlYXJjaF9GaWVsZC5yZXBsYWNlKC9cXHMvZywgJycpLnNwbGl0KCcsJyk7XG4gIH0gZWxzZSB7XG4gICAgVXNlcl9TZWFyY2hfRmllbGQgPSBbXTtcbiAgfVxuXG4gIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0gVW5pcXVlX0lkZW50aWZpZXJfRmllbGQuY29uY2F0KFVzZXJfU2VhcmNoX0ZpZWxkKTtcblxuICBpZiAoVW5pcXVlX0lkZW50aWZpZXJfRmllbGQubGVuZ3RoID4gMCkge1xuICAgIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0gVW5pcXVlX0lkZW50aWZpZXJfRmllbGQuZmluZCgoZmllbGQpID0+IHtcbiAgICAgIHJldHVybiAhXy5pc0VtcHR5KGxkYXBVc2VyLl9yYXcuZ2V0TERBUFZhbHVlKGZpZWxkKSk7XG4gICAgfSk7XG4gICAgaWYgKFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkKSB7XG5cdFx0ICAgIGxvZ19kZWJ1ZyhgSWRlbnRpZnlpbmcgdXNlciB3aXRoOiAkeyAgVW5pcXVlX0lkZW50aWZpZXJfRmllbGR9YCk7XG4gICAgICBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCA9IHtcbiAgICAgICAgYXR0cmlidXRlOiBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCxcbiAgICAgICAgdmFsdWU6IGxkYXBVc2VyLl9yYXcuZ2V0TERBUFZhbHVlKFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkKS50b1N0cmluZygnaGV4JyksXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gVW5pcXVlX0lkZW50aWZpZXJfRmllbGQ7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldERhdGFUb1N5bmNVc2VyRGF0YShsZGFwVXNlciwgdXNlcikge1xuICBjb25zdCBzeW5jVXNlckRhdGEgPSBMREFQLnNldHRpbmdzX2dldCgnTERBUF9TWU5DX1VTRVJfREFUQScpO1xuICBjb25zdCBzeW5jVXNlckRhdGFGaWVsZE1hcCA9IExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1NZTkNfVVNFUl9EQVRBX0ZJRUxETUFQJykudHJpbSgpO1xuXG4gIGNvbnN0IHVzZXJEYXRhID0ge307XG5cbiAgaWYgKHN5bmNVc2VyRGF0YSAmJiBzeW5jVXNlckRhdGFGaWVsZE1hcCkge1xuICAgIGNvbnN0IHdoaXRlbGlzdGVkVXNlckZpZWxkcyA9IFsnZW1haWwnLCAnbmFtZScsICdjdXN0b21GaWVsZHMnXTtcbiAgICBjb25zdCBmaWVsZE1hcCA9IEpTT04ucGFyc2Uoc3luY1VzZXJEYXRhRmllbGRNYXApO1xuICAgIGNvbnN0IGVtYWlsTGlzdCA9IFtdO1xuICAgIF8ubWFwKGZpZWxkTWFwLCBmdW5jdGlvbih1c2VyRmllbGQsIGxkYXBGaWVsZCkge1xuXHRcdCAgICBsb2dfZGVidWcoYE1hcHBpbmcgZmllbGQgJHtsZGFwRmllbGR9IC0+ICR7dXNlckZpZWxkfWApO1xuICAgICAgc3dpdGNoICh1c2VyRmllbGQpIHtcbiAgICAgIGNhc2UgJ2VtYWlsJzpcbiAgICAgICAgaWYgKCFsZGFwVXNlci5oYXNPd25Qcm9wZXJ0eShsZGFwRmllbGQpKSB7XG4gICAgICAgICAgbG9nX2RlYnVnKGB1c2VyIGRvZXMgbm90IGhhdmUgYXR0cmlidXRlOiAkeyBsZGFwRmllbGQgfWApO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChfLmlzT2JqZWN0KGxkYXBVc2VyW2xkYXBGaWVsZF0pKSB7XG4gICAgICAgICAgXy5tYXAobGRhcFVzZXJbbGRhcEZpZWxkXSwgZnVuY3Rpb24oaXRlbSkge1xuICAgICAgICAgICAgZW1haWxMaXN0LnB1c2goeyBhZGRyZXNzOiBpdGVtLCB2ZXJpZmllZDogdHJ1ZSB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBlbWFpbExpc3QucHVzaCh7IGFkZHJlc3M6IGxkYXBVc2VyW2xkYXBGaWVsZF0sIHZlcmlmaWVkOiB0cnVlIH0pO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBjb25zdCBbb3V0ZXJLZXksIGlubmVyS2V5c10gPSB1c2VyRmllbGQuc3BsaXQoL1xcLiguKykvKTtcblxuICAgICAgICBpZiAoIV8uZmluZCh3aGl0ZWxpc3RlZFVzZXJGaWVsZHMsIChlbCkgPT4gZWwgPT09IG91dGVyS2V5KSkge1xuICAgICAgICAgIGxvZ19kZWJ1ZyhgdXNlciBhdHRyaWJ1dGUgbm90IHdoaXRlbGlzdGVkOiAkeyB1c2VyRmllbGQgfWApO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChvdXRlcktleSA9PT0gJ2N1c3RvbUZpZWxkcycpIHtcbiAgICAgICAgICBsZXQgY3VzdG9tRmllbGRzTWV0YTtcblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjdXN0b21GaWVsZHNNZXRhID0gSlNPTi5wYXJzZShMREFQLnNldHRpbmdzX2dldCgnQWNjb3VudHNfQ3VzdG9tRmllbGRzJykpO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGxvZ19kZWJ1ZygnSW52YWxpZCBKU09OIGZvciBDdXN0b20gRmllbGRzJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKCFnZXRQcm9wZXJ0eVZhbHVlKGN1c3RvbUZpZWxkc01ldGEsIGlubmVyS2V5cykpIHtcbiAgICAgICAgICAgIGxvZ19kZWJ1ZyhgdXNlciBhdHRyaWJ1dGUgZG9lcyBub3QgZXhpc3Q6ICR7IHVzZXJGaWVsZCB9YCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdG1wVXNlckZpZWxkID0gZ2V0UHJvcGVydHlWYWx1ZSh1c2VyLCB1c2VyRmllbGQpO1xuICAgICAgICBjb25zdCB0bXBMZGFwRmllbGQgPSB0ZW1wbGF0ZVZhckhhbmRsZXIobGRhcEZpZWxkLCBsZGFwVXNlcik7XG5cbiAgICAgICAgaWYgKHRtcExkYXBGaWVsZCAmJiB0bXBVc2VyRmllbGQgIT09IHRtcExkYXBGaWVsZCkge1xuICAgICAgICAgIC8vIGNyZWF0ZXMgdGhlIG9iamVjdCBzdHJ1Y3R1cmUgaW5zdGVhZCBvZiBqdXN0IGFzc2lnbmluZyAndG1wTGRhcEZpZWxkJyB0b1xuICAgICAgICAgIC8vICd1c2VyRGF0YVt1c2VyRmllbGRdJyBpbiBvcmRlciB0byBhdm9pZCB0aGUgXCJjYW5ub3QgdXNlIHRoZSBwYXJ0ICguLi4pXG4gICAgICAgICAgLy8gdG8gdHJhdmVyc2UgdGhlIGVsZW1lbnRcIiAoTW9uZ29EQikgZXJyb3IgdGhhdCBjYW4gaGFwcGVuLiBEbyBub3QgaGFuZGxlXG4gICAgICAgICAgLy8gYXJyYXlzLlxuICAgICAgICAgIC8vIFRPRE86IEZpbmQgYSBiZXR0ZXIgc29sdXRpb24uXG4gICAgICAgICAgY29uc3QgZEtleXMgPSB1c2VyRmllbGQuc3BsaXQoJy4nKTtcbiAgICAgICAgICBjb25zdCBsYXN0S2V5ID0gXy5sYXN0KGRLZXlzKTtcbiAgICAgICAgICBfLnJlZHVjZShkS2V5cywgKG9iaiwgY3VycktleSkgPT5cbiAgICAgICAgICAgIChjdXJyS2V5ID09PSBsYXN0S2V5KVxuICAgICAgICAgICAgICA/IG9ialtjdXJyS2V5XSA9IHRtcExkYXBGaWVsZFxuICAgICAgICAgICAgICA6IG9ialtjdXJyS2V5XSA9IG9ialtjdXJyS2V5XSB8fCB7fVxuICAgICAgICAgICAgLCB1c2VyRGF0YSk7XG4gICAgICAgICAgbG9nX2RlYnVnKGB1c2VyLiR7IHVzZXJGaWVsZCB9IGNoYW5nZWQgdG86ICR7IHRtcExkYXBGaWVsZCB9YCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGlmIChlbWFpbExpc3QubGVuZ3RoID4gMCkge1xuICAgICAgaWYgKEpTT04uc3RyaW5naWZ5KHVzZXIuZW1haWxzKSAhPT0gSlNPTi5zdHJpbmdpZnkoZW1haWxMaXN0KSkge1xuICAgICAgICB1c2VyRGF0YS5lbWFpbHMgPSBlbWFpbExpc3Q7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3QgdW5pcXVlSWQgPSBnZXRMZGFwVXNlclVuaXF1ZUlEKGxkYXBVc2VyKTtcblxuICBpZiAodW5pcXVlSWQgJiYgKCF1c2VyLnNlcnZpY2VzIHx8ICF1c2VyLnNlcnZpY2VzLmxkYXAgfHwgdXNlci5zZXJ2aWNlcy5sZGFwLmlkICE9PSB1bmlxdWVJZC52YWx1ZSB8fCB1c2VyLnNlcnZpY2VzLmxkYXAuaWRBdHRyaWJ1dGUgIT09IHVuaXF1ZUlkLmF0dHJpYnV0ZSkpIHtcbiAgICB1c2VyRGF0YVsnc2VydmljZXMubGRhcC5pZCddID0gdW5pcXVlSWQudmFsdWU7XG4gICAgdXNlckRhdGFbJ3NlcnZpY2VzLmxkYXAuaWRBdHRyaWJ1dGUnXSA9IHVuaXF1ZUlkLmF0dHJpYnV0ZTtcbiAgfVxuXG4gIGlmICh1c2VyLmF1dGhlbnRpY2F0aW9uTWV0aG9kICE9PSAnbGRhcCcpIHtcbiAgICB1c2VyRGF0YS5sZGFwID0gdHJ1ZTtcbiAgfVxuXG4gIGlmIChfLnNpemUodXNlckRhdGEpKSB7XG4gICAgcmV0dXJuIHVzZXJEYXRhO1xuICB9XG59XG5cblxuZXhwb3J0IGZ1bmN0aW9uIHN5bmNVc2VyRGF0YSh1c2VyLCBsZGFwVXNlcikge1xuICBsb2dfaW5mbygnU3luY2luZyB1c2VyIGRhdGEnKTtcbiAgbG9nX2RlYnVnKCd1c2VyJywgeydlbWFpbCc6IHVzZXIuZW1haWwsICdfaWQnOiB1c2VyLl9pZH0pO1xuICAvLyBsb2dfZGVidWcoJ2xkYXBVc2VyJywgbGRhcFVzZXIub2JqZWN0KTtcblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUk5BTUVfRklFTEQnKSAhPT0gJycpIHtcbiAgICBjb25zdCB1c2VybmFtZSA9IHNsdWcoZ2V0TGRhcFVzZXJuYW1lKGxkYXBVc2VyKSk7XG4gICAgaWYgKHVzZXIgJiYgdXNlci5faWQgJiYgdXNlcm5hbWUgIT09IHVzZXIudXNlcm5hbWUpIHtcbiAgICAgIGxvZ19pbmZvKCdTeW5jaW5nIHVzZXIgdXNlcm5hbWUnLCB1c2VyLnVzZXJuYW1lLCAnLT4nLCB1c2VybmFtZSk7XG4gICAgICBNZXRlb3IudXNlcnMuZmluZE9uZSh7IF9pZDogdXNlci5faWQgfSwgeyAkc2V0OiB7IHVzZXJuYW1lIH19KTtcbiAgICB9XG4gIH1cblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRlVMTE5BTUVfRklFTEQnKSAhPT0gJycpIHtcbiAgICBjb25zdCBmdWxsbmFtZT0gZ2V0TGRhcEZ1bGxuYW1lKGxkYXBVc2VyKTtcbiAgICBsb2dfZGVidWcoJ2Z1bGxuYW1lPScsZnVsbG5hbWUpO1xuICAgIGlmICh1c2VyICYmIHVzZXIuX2lkICYmIGZ1bGxuYW1lICE9PSAnJykge1xuICAgICAgbG9nX2luZm8oJ1N5bmNpbmcgdXNlciBmdWxsbmFtZTonLCBmdWxsbmFtZSk7XG4gICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiAgdXNlci5faWQgfSwgeyAkc2V0OiB7ICdwcm9maWxlLmZ1bGxuYW1lJyA6IGZ1bGxuYW1lLCB9fSk7XG4gICAgfVxuICB9XG5cbiAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0VNQUlMX0ZJRUxEJykgIT09ICcnKSB7XG4gICAgY29uc3QgZW1haWwgPSBnZXRMZGFwRW1haWwobGRhcFVzZXIpO1xuICAgIGxvZ19kZWJ1ZygnZW1haWw9JywgZW1haWwpO1xuXG4gICAgaWYgKHVzZXIgJiYgdXNlci5faWQgJiYgZW1haWwgIT09ICcnKSB7XG4gICAgICBsb2dfaW5mbygnU3luY2luZyB1c2VyIGVtYWlsOicsIGVtYWlsKTtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoe1xuICAgICAgICBfaWQ6IHVzZXIuX2lkXG4gICAgICB9LCB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAnZW1haWxzLjAuYWRkcmVzcyc6IGVtYWlsLFxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkTGRhcFVzZXIobGRhcFVzZXIsIHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICBjb25zdCB1bmlxdWVJZCA9IGdldExkYXBVc2VyVW5pcXVlSUQobGRhcFVzZXIpO1xuXG4gIGNvbnN0IHVzZXJPYmplY3QgPSB7XG4gIH07XG5cbiAgaWYgKHVzZXJuYW1lKSB7XG4gICAgdXNlck9iamVjdC51c2VybmFtZSA9IHVzZXJuYW1lO1xuICB9XG5cbiAgY29uc3QgdXNlckRhdGEgPSBnZXREYXRhVG9TeW5jVXNlckRhdGEobGRhcFVzZXIsIHt9KTtcblxuICBpZiAodXNlckRhdGEgJiYgdXNlckRhdGEuZW1haWxzICYmIHVzZXJEYXRhLmVtYWlsc1swXSAmJiB1c2VyRGF0YS5lbWFpbHNbMF0uYWRkcmVzcykge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHVzZXJEYXRhLmVtYWlsc1swXS5hZGRyZXNzKSkge1xuICAgICAgdXNlck9iamVjdC5lbWFpbCA9IHVzZXJEYXRhLmVtYWlsc1swXS5hZGRyZXNzWzBdO1xuICAgIH0gZWxzZSB7XG4gICAgICB1c2VyT2JqZWN0LmVtYWlsID0gdXNlckRhdGEuZW1haWxzWzBdLmFkZHJlc3M7XG4gICAgfVxuICB9IGVsc2UgaWYgKGxkYXBVc2VyLm1haWwgJiYgbGRhcFVzZXIubWFpbC5pbmRleE9mKCdAJykgPiAtMSkge1xuICAgIHVzZXJPYmplY3QuZW1haWwgPSBsZGFwVXNlci5tYWlsO1xuICB9IGVsc2UgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0RFRkFVTFRfRE9NQUlOJykgIT09ICcnKSB7XG4gICAgdXNlck9iamVjdC5lbWFpbCA9IGAkeyB1c2VybmFtZSB8fCB1bmlxdWVJZC52YWx1ZSB9QCR7IExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0RFRkFVTFRfRE9NQUlOJykgfWA7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgZXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKCdMREFQLWxvZ2luLWVycm9yJywgJ0xEQVAgQXV0aGVudGljYXRpb24gc3VjY2VkZWQsIHRoZXJlIGlzIG5vIGVtYWlsIHRvIGNyZWF0ZSBhbiBhY2NvdW50LiBIYXZlIHlvdSB0cmllZCBzZXR0aW5nIHlvdXIgRGVmYXVsdCBEb21haW4gaW4gTERBUCBTZXR0aW5ncz8nKTtcbiAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICAgIHRocm93IGVycm9yO1xuICB9XG5cbiAgbG9nX2RlYnVnKCdOZXcgdXNlciBkYXRhJywgdXNlck9iamVjdCk7XG5cbiAgaWYgKHBhc3N3b3JkKSB7XG4gICAgdXNlck9iamVjdC5wYXNzd29yZCA9IHBhc3N3b3JkO1xuICB9XG5cbiAgdHJ5IHtcbiAgICAvLyBUaGlzIGNyZWF0ZXMgdGhlIGFjY291bnQgd2l0aCBwYXNzd29yZCBzZXJ2aWNlXG4gICAgdXNlck9iamVjdC5sZGFwID0gdHJ1ZTtcbiAgICB1c2VyT2JqZWN0Ll9pZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIodXNlck9iamVjdCk7XG5cbiAgICAvLyBBZGQgdGhlIHNlcnZpY2VzLmxkYXAgaWRlbnRpZmllcnNcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiAgdXNlck9iamVjdC5faWQgfSwge1xuXHRcdCAgICAkc2V0OiB7XG5cdFx0ICAgICAgICAnc2VydmljZXMubGRhcCc6IHsgaWQ6IHVuaXF1ZUlkLnZhbHVlIH0sXG5cdFx0ICAgICAgICAnZW1haWxzLjAudmVyaWZpZWQnOiB0cnVlLFxuXHRcdCAgICAgICAgJ2F1dGhlbnRpY2F0aW9uTWV0aG9kJzogJ2xkYXAnLFxuXHRcdCAgICB9fSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgbG9nX2Vycm9yKCdFcnJvciBjcmVhdGluZyB1c2VyJywgZXJyb3IpO1xuICAgIHJldHVybiBlcnJvcjtcbiAgfVxuXG4gIHN5bmNVc2VyRGF0YSh1c2VyT2JqZWN0LCBsZGFwVXNlcik7XG5cbiAgcmV0dXJuIHtcbiAgICB1c2VySWQ6IHVzZXJPYmplY3QuX2lkLFxuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0TmV3VXNlcnMobGRhcCkge1xuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU5BQkxFJykgIT09IHRydWUpIHtcbiAgICBsb2dfZXJyb3IoJ0NhblxcJ3QgcnVuIExEQVAgSW1wb3J0LCBMREFQIGlzIGRpc2FibGVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKCFsZGFwKSB7XG4gICAgbGRhcCA9IG5ldyBMREFQKCk7XG4gICAgbGRhcC5jb25uZWN0U3luYygpO1xuICB9XG5cbiAgbGV0IGNvdW50ID0gMDtcbiAgbGRhcC5zZWFyY2hVc2Vyc1N5bmMoJyonLCBNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnJvciwgbGRhcFVzZXJzLCB7bmV4dCwgZW5kfSA9IHt9KSA9PiB7XG4gICAgaWYgKGVycm9yKSB7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG5cbiAgICBsZGFwVXNlcnMuZm9yRWFjaCgobGRhcFVzZXIpID0+IHtcbiAgICAgIGNvdW50Kys7XG5cbiAgICAgIGNvbnN0IHVuaXF1ZUlkID0gZ2V0TGRhcFVzZXJVbmlxdWVJRChsZGFwVXNlcik7XG4gICAgICAvLyBMb29rIHRvIHNlZSBpZiB1c2VyIGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCB1c2VyUXVlcnkgPSB7XG4gICAgICAgICdzZXJ2aWNlcy5sZGFwLmlkJzogdW5pcXVlSWQudmFsdWUsXG4gICAgICB9O1xuXG4gICAgICBsb2dfZGVidWcoJ3VzZXJRdWVyeScsIHVzZXJRdWVyeSk7XG5cbiAgICAgIGxldCB1c2VybmFtZTtcbiAgICAgIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9VU0VSTkFNRV9GSUVMRCcpICE9PSAnJykge1xuICAgICAgICB1c2VybmFtZSA9IHNsdWcoZ2V0TGRhcFVzZXJuYW1lKGxkYXBVc2VyKSk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFkZCB1c2VyIGlmIGl0IHdhcyBub3QgYWRkZWQgYmVmb3JlXG4gICAgICBsZXQgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHVzZXJRdWVyeSk7XG5cbiAgICAgIGlmICghdXNlciAmJiB1c2VybmFtZSAmJiBMREFQLnNldHRpbmdzX2dldCgnTERBUF9NRVJHRV9FWElTVElOR19VU0VSUycpID09PSB0cnVlKSB7XG4gICAgICAgIGNvbnN0IHVzZXJRdWVyeSA9IHtcbiAgICAgICAgICB1c2VybmFtZSxcbiAgICAgICAgfTtcblxuICAgICAgICBsb2dfZGVidWcoJ3VzZXJRdWVyeSBtZXJnZScsIHVzZXJRdWVyeSk7XG5cbiAgICAgICAgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHVzZXJRdWVyeSk7XG4gICAgICAgIGlmICh1c2VyKSB7XG4gICAgICAgICAgc3luY1VzZXJEYXRhKHVzZXIsIGxkYXBVc2VyKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgYWRkTGRhcFVzZXIobGRhcFVzZXIsIHVzZXJuYW1lKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNvdW50ICUgMTAwID09PSAwKSB7XG4gICAgICAgIGxvZ19pbmZvKCdJbXBvcnQgcnVubmluZy4gVXNlcnMgaW1wb3J0ZWQgdW50aWwgbm93OicsIGNvdW50KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGlmIChlbmQpIHtcbiAgICAgIGxvZ19pbmZvKCdJbXBvcnQgZmluaXNoZWQuIFVzZXJzIGltcG9ydGVkOicsIGNvdW50KTtcbiAgICB9XG5cbiAgICBuZXh0KGNvdW50KTtcbiAgfSkpO1xufVxuXG5mdW5jdGlvbiBzeW5jKCkge1xuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU5BQkxFJykgIT09IHRydWUpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBsZGFwID0gbmV3IExEQVAoKTtcblxuICB0cnkge1xuICAgIGxkYXAuY29ubmVjdFN5bmMoKTtcblxuICAgIGxldCB1c2VycztcbiAgICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DX0tFRVBfRVhJU1RBTlRfVVNFUlNfVVBEQVRFRCcpID09PSB0cnVlKSB7XG4gICAgICB1c2VycyA9IE1ldGVvci51c2Vycy5maW5kKHsgJ3NlcnZpY2VzLmxkYXAnOiB7ICRleGlzdHM6IHRydWUgfX0pO1xuICAgIH1cblxuICAgIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9CQUNLR1JPVU5EX1NZTkNfSU1QT1JUX05FV19VU0VSUycpID09PSB0cnVlKSB7XG4gICAgICBpbXBvcnROZXdVc2VycyhsZGFwKTtcbiAgICB9XG5cbiAgICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DX0tFRVBfRVhJU1RBTlRfVVNFUlNfVVBEQVRFRCcpID09PSB0cnVlKSB7XG4gICAgICB1c2Vycy5mb3JFYWNoKGZ1bmN0aW9uKHVzZXIpIHtcbiAgICAgICAgbGV0IGxkYXBVc2VyO1xuXG4gICAgICAgIGlmICh1c2VyLnNlcnZpY2VzICYmIHVzZXIuc2VydmljZXMubGRhcCAmJiB1c2VyLnNlcnZpY2VzLmxkYXAuaWQpIHtcbiAgICAgICAgICBsZGFwVXNlciA9IGxkYXAuZ2V0VXNlckJ5SWRTeW5jKHVzZXIuc2VydmljZXMubGRhcC5pZCwgdXNlci5zZXJ2aWNlcy5sZGFwLmlkQXR0cmlidXRlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsZGFwVXNlciA9IGxkYXAuZ2V0VXNlckJ5VXNlcm5hbWVTeW5jKHVzZXIudXNlcm5hbWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGxkYXBVc2VyKSB7XG4gICAgICAgICAgc3luY1VzZXJEYXRhKHVzZXIsIGxkYXBVc2VyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsb2dfaW5mbygnQ2FuXFwndCBzeW5jIHVzZXInLCB1c2VyLnVzZXJuYW1lKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGxvZ19lcnJvcihlcnJvcik7XG4gICAgcmV0dXJuIGVycm9yO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG5jb25zdCBqb2JOYW1lID0gJ0xEQVBfU3luYyc7XG5cbmNvbnN0IGFkZENyb25Kb2IgPSBfLmRlYm91bmNlKE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24gYWRkQ3JvbkpvYkRlYm91bmNlZCgpIHtcbiAgbGV0IHNjPVN5bmNlZENyb24uU3luY2VkQ3JvbjsgLy9XaHkgPz8gc29tZXRoaW5nIG11c3QgYmUgd3JvbmcgaW4gdGhlIGltcG9ydFxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DJykgIT09IHRydWUpIHtcbiAgICBsb2dfaW5mbygnRGlzYWJsaW5nIExEQVAgQmFja2dyb3VuZCBTeW5jJyk7XG4gICAgaWYgKHNjLm5leHRTY2hlZHVsZWRBdERhdGUoam9iTmFtZSkpIHtcbiAgICAgIHNjLnJlbW92ZShqb2JOYW1lKTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgbG9nX2luZm8oJ0VuYWJsaW5nIExEQVAgQmFja2dyb3VuZCBTeW5jJyk7XG4gIHNjLmFkZCh7XG4gICAgbmFtZTogam9iTmFtZSxcbiAgICBzY2hlZHVsZTogZnVuY3Rpb24ocGFyc2VyKSB7XG4gICAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0JBQ0tHUk9VTkRfU1lOQ19JTlRFUlZBTCcpKSB7XG4gICAgICAgcmV0dXJuIHBhcnNlci50ZXh0KExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0JBQ0tHUk9VTkRfU1lOQ19JTlRFUlZBTCcpKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgcmV0dXJuIHBhcnNlci5yZWN1cigpLm9uKDApLm1pbnV0ZSgpO1xuICAgIH19LFxuICAgIGpvYjogZnVuY3Rpb24oKSB7XG4gICAgICBzeW5jKCk7XG4gICAgfSxcbiAgfSk7XG4gIHNjLnN0YXJ0KCk7XG5cbn0pLCA1MDApO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIE1ldGVvci5kZWZlcigoKSA9PiB7XG4gICAgaWYoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DJykpe2FkZENyb25Kb2IoKTt9XG4gIH0pO1xufSk7XG4iXX0=
