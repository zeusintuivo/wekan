(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Util;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/meteorspark_util/packages/meteorspark_util.js                  //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {

////////////////////////////////////////////////////////////////////////
//                                                                    //
// packages/meteorspark:util/lib/util-server.js                       //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
// https://github.com/isaacs/inherits/blob/master/inherits_browser.js // 1
Util = Npm.require("util")                                            // 2
                                                                      // 3
////////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("meteorspark:util", {
  Util: Util
});

})();
