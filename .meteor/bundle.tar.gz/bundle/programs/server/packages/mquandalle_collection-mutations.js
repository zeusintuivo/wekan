(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"mquandalle:collection-mutations":{"mutations.js":function module(){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/mquandalle_collection-mutations/mutations.js                                         //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
Mongo.Collection.prototype.mutations = function (mutations) {
  const collection = this;
  collection.helpers(_.chain(mutations).map((action, name) => {
    return [name, function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      const mutation = action.apply(this, args);

      if (mutation) {
        collection.update(this._id, mutation);
      }
    }];
  }).object().value());
};
///////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/mquandalle:collection-mutations/mutations.js");

/* Exports */
Package._define("mquandalle:collection-mutations");

})();

//# sourceURL=meteor://💻app/packages/mquandalle_collection-mutations.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbXF1YW5kYWxsZTpjb2xsZWN0aW9uLW11dGF0aW9ucy9tdXRhdGlvbnMuanMiXSwibmFtZXMiOlsiTW9uZ28iLCJDb2xsZWN0aW9uIiwicHJvdG90eXBlIiwibXV0YXRpb25zIiwiY29sbGVjdGlvbiIsImhlbHBlcnMiLCJfIiwiY2hhaW4iLCJtYXAiLCJhY3Rpb24iLCJuYW1lIiwiYXJncyIsIm11dGF0aW9uIiwiYXBwbHkiLCJ1cGRhdGUiLCJfaWQiLCJvYmplY3QiLCJ2YWx1ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEtBQUssQ0FBQ0MsVUFBTixDQUFpQkMsU0FBakIsQ0FBMkJDLFNBQTNCLEdBQXVDLFVBQVNBLFNBQVQsRUFBb0I7QUFDekQsUUFBTUMsVUFBVSxHQUFHLElBQW5CO0FBRUFBLFlBQVUsQ0FBQ0MsT0FBWCxDQUFtQkMsQ0FBQyxDQUFDQyxLQUFGLENBQVFKLFNBQVIsRUFBbUJLLEdBQW5CLENBQXVCLENBQUNDLE1BQUQsRUFBU0MsSUFBVCxLQUFrQjtBQUMxRCxXQUFPLENBQUNBLElBQUQsRUFBTyxZQUFrQjtBQUFBLHdDQUFOQyxJQUFNO0FBQU5BLFlBQU07QUFBQTs7QUFDOUIsWUFBTUMsUUFBUSxHQUFHSCxNQUFNLENBQUNJLEtBQVAsQ0FBYSxJQUFiLEVBQW1CRixJQUFuQixDQUFqQjs7QUFDQSxVQUFJQyxRQUFKLEVBQWM7QUFDWlIsa0JBQVUsQ0FBQ1UsTUFBWCxDQUFrQixLQUFLQyxHQUF2QixFQUE0QkgsUUFBNUI7QUFDRDtBQUNGLEtBTE0sQ0FBUDtBQU1ELEdBUGtCLEVBT2hCSSxNQVBnQixHQU9QQyxLQVBPLEVBQW5CO0FBUUQsQ0FYRCxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9tcXVhbmRhbGxlX2NvbGxlY3Rpb24tbXV0YXRpb25zLmpzIiwic291cmNlc0NvbnRlbnQiOlsiTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGUubXV0YXRpb25zID0gZnVuY3Rpb24obXV0YXRpb25zKSB7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSB0aGlzO1xuXG4gIGNvbGxlY3Rpb24uaGVscGVycyhfLmNoYWluKG11dGF0aW9ucykubWFwKChhY3Rpb24sIG5hbWUpID0+IHtcbiAgICByZXR1cm4gW25hbWUsIGZ1bmN0aW9uKC4uLmFyZ3MpIHtcbiAgICAgIGNvbnN0IG11dGF0aW9uID0gYWN0aW9uLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgaWYgKG11dGF0aW9uKSB7XG4gICAgICAgIGNvbGxlY3Rpb24udXBkYXRlKHRoaXMuX2lkLCBtdXRhdGlvbik7XG4gICAgICB9XG4gICAgfV07XG4gIH0pLm9iamVjdCgpLnZhbHVlKCkpO1xufTtcbiJdfQ==
