(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Swipebox;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/horka_swipebox/packages/horka_swipebox.js                //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("horka:swipebox", {
  Swipebox: Swipebox
});

})();
