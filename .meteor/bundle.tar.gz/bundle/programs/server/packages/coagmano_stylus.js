(function () {



/* Exports */
Package._define("coagmano:stylus");

})();
