(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var DDPRateLimiter = Package['ddp-rate-limiter'].DDPRateLimiter;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var Hook = Package['callback-hook'].Hook;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Accounts, options, stampedLoginToken, handler, name, query, oldestValidDate, user;

var require = meteorInstall({"node_modules":{"meteor":{"accounts-base":{"server_main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/accounts-base/server_main.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  module1.export({
    AccountsServer: () => AccountsServer
  });
  let AccountsServer;
  module1.link("./accounts_server.js", {
    AccountsServer(v) {
      AccountsServer = v;
    }

  }, 0);

  /**
   * @namespace Accounts
   * @summary The namespace for all server-side accounts-related methods.
   */
  Accounts = new AccountsServer(Meteor.server); // Users table. Don't use the normal autopublish, since we want to hide
  // some fields. Code to autopublish this is in accounts_server.js.
  // XXX Allow users to configure this collection name.

  /**
   * @summary A [Mongo.Collection](#collections) containing user documents.
   * @locus Anywhere
   * @type {Mongo.Collection}
   * @importFromPackage meteor
  */

  Meteor.users = Accounts.users;
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"accounts_common.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/accounts-base/accounts_common.js                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  AccountsCommon: () => AccountsCommon,
  EXPIRE_TOKENS_INTERVAL_MS: () => EXPIRE_TOKENS_INTERVAL_MS,
  CONNECTION_CLOSE_DELAY_MS: () => CONNECTION_CLOSE_DELAY_MS
});

class AccountsCommon {
  constructor(options) {
    // Currently this is read directly by packages like accounts-password
    // and accounts-ui-unstyled.
    this._options = {}; // Note that setting this.connection = null causes this.users to be a
    // LocalCollection, which is not what we want.

    this.connection = undefined;

    this._initConnection(options || {}); // There is an allow call in accounts_server.js that restricts writes to
    // this collection.


    this.users = new Mongo.Collection("users", {
      _preventAutopublish: true,
      connection: this.connection
    }); // Callback exceptions are printed with Meteor._debug and ignored.

    this._onLoginHook = new Hook({
      bindEnvironment: false,
      debugPrintExceptions: "onLogin callback"
    });
    this._onLoginFailureHook = new Hook({
      bindEnvironment: false,
      debugPrintExceptions: "onLoginFailure callback"
    });
    this._onLogoutHook = new Hook({
      bindEnvironment: false,
      debugPrintExceptions: "onLogout callback"
    }); // Expose for testing.

    this.DEFAULT_LOGIN_EXPIRATION_DAYS = DEFAULT_LOGIN_EXPIRATION_DAYS;
    this.LOGIN_UNEXPIRING_TOKEN_DAYS = LOGIN_UNEXPIRING_TOKEN_DAYS; // Thrown when the user cancels the login process (eg, closes an oauth
    // popup, declines retina scan, etc)

    const lceName = 'Accounts.LoginCancelledError';
    this.LoginCancelledError = Meteor.makeErrorType(lceName, function (description) {
      this.message = description;
    });
    this.LoginCancelledError.prototype.name = lceName; // This is used to transmit specific subclass errors over the wire. We
    // should come up with a more generic way to do this (eg, with some sort of
    // symbolic error code rather than a number).

    this.LoginCancelledError.numericError = 0x8acdc2f; // loginServiceConfiguration and ConfigError are maintained for backwards compatibility

    Meteor.startup(() => {
      const {
        ServiceConfiguration
      } = Package['service-configuration'];
      this.loginServiceConfiguration = ServiceConfiguration.configurations;
      this.ConfigError = ServiceConfiguration.ConfigError;
    });
  }
  /**
   * @summary Get the current user id, or `null` if no user is logged in. A reactive data source.
   * @locus Anywhere
   */


  userId() {
    throw new Error("userId method not implemented");
  } // merge the defaultFieldSelector with an existing options object


  _addDefaultFieldSelector() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    // this will be the most common case for most people, so make it quick
    if (!this._options.defaultFieldSelector) return options; // if no field selector then just use defaultFieldSelector

    if (!options.fields) return _objectSpread(_objectSpread({}, options), {}, {
      fields: this._options.defaultFieldSelector
    }); // if empty field selector then the full user object is explicitly requested, so obey

    const keys = Object.keys(options.fields);
    if (!keys.length) return options; // if the requested fields are +ve then ignore defaultFieldSelector
    // assume they are all either +ve or -ve because Mongo doesn't like mixed

    if (!!options.fields[keys[0]]) return options; // The requested fields are -ve.
    // If the defaultFieldSelector is +ve then use requested fields, otherwise merge them

    const keys2 = Object.keys(this._options.defaultFieldSelector);
    return this._options.defaultFieldSelector[keys2[0]] ? options : _objectSpread(_objectSpread({}, options), {}, {
      fields: _objectSpread(_objectSpread({}, options.fields), this._options.defaultFieldSelector)
    });
  }
  /**
   * @summary Get the current user record, or `null` if no user is logged in. A reactive data source.
   * @locus Anywhere
   * @param {Object} [options]
   * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
   */


  user(options) {
    const userId = this.userId();
    return userId ? this.users.findOne(userId, this._addDefaultFieldSelector(options)) : null;
  } // Set up config for the accounts system. Call this on both the client
  // and the server.
  //
  // Note that this method gets overridden on AccountsServer.prototype, but
  // the overriding method calls the overridden method.
  //
  // XXX we should add some enforcement that this is called on both the
  // client and the server. Otherwise, a user can
  // 'forbidClientAccountCreation' only on the client and while it looks
  // like their app is secure, the server will still accept createUser
  // calls. https://github.com/meteor/meteor/issues/828
  //
  // @param options {Object} an object with fields:
  // - sendVerificationEmail {Boolean}
  //     Send email address verification emails to new users created from
  //     client signups.
  // - forbidClientAccountCreation {Boolean}
  //     Do not allow clients to create accounts directly.
  // - restrictCreationByEmailDomain {Function or String}
  //     Require created users to have an email matching the function or
  //     having the string as domain.
  // - loginExpirationInDays {Number}
  //     Number of days since login until a user is logged out (login token
  //     expires).
  // - passwordResetTokenExpirationInDays {Number}
  //     Number of days since password reset token creation until the
  //     token cannt be used any longer (password reset token expires).
  // - ambiguousErrorMessages {Boolean}
  //     Return ambiguous error messages from login failures to prevent
  //     user enumeration.
  // - bcryptRounds {Number}
  //     Allows override of number of bcrypt rounds (aka work factor) used
  //     to store passwords.

  /**
   * @summary Set global accounts options.
   * @locus Anywhere
   * @param {Object} options
   * @param {Boolean} options.sendVerificationEmail New users with an email address will receive an address verification email.
   * @param {Boolean} options.forbidClientAccountCreation Calls to [`createUser`](#accounts_createuser) from the client will be rejected. In addition, if you are using [accounts-ui](#accountsui), the "Create account" link will not be available.
   * @param {String | Function} options.restrictCreationByEmailDomain If set to a string, only allows new users if the domain part of their email address matches the string. If set to a function, only allows new users if the function returns true.  The function is passed the full email address of the proposed new user.  Works with password-based sign-in and external services that expose email addresses (Google, Facebook, GitHub). All existing users still can log in after enabling this option. Example: `Accounts.config({ restrictCreationByEmailDomain: 'school.edu' })`.
   * @param {Number} options.loginExpirationInDays The number of days from when a user logs in until their token expires and they are logged out. Defaults to 90. Set to `null` to disable login expiration.
   * @param {String} options.oauthSecretKey When using the `oauth-encryption` package, the 16 byte key using to encrypt sensitive account credentials in the database, encoded in base64.  This option may only be specifed on the server.  See packages/oauth-encryption/README.md for details.
   * @param {Number} options.passwordResetTokenExpirationInDays The number of days from when a link to reset password is sent until token expires and user can't reset password with the link anymore. Defaults to 3.
   * @param {Number} options.passwordEnrollTokenExpirationInDays The number of days from when a link to set inital password is sent until token expires and user can't set password with the link anymore. Defaults to 30.
   * @param {Boolean} options.ambiguousErrorMessages Return ambiguous error messages from login failures to prevent user enumeration. Defaults to false.
   * @param {MongoFieldSpecifier} options.defaultFieldSelector To exclude by default large custom fields from `Meteor.user()` and `Meteor.findUserBy...()` functions when called without a field selector, and all `onLogin`, `onLoginFailure` and `onLogout` callbacks.  Example: `Accounts.config({ defaultFieldSelector: { myBigArray: 0 }})`.
   */


  config(options) {
    // We don't want users to accidentally only call Accounts.config on the
    // client, where some of the options will have partial effects (eg removing
    // the "create account" button from accounts-ui if forbidClientAccountCreation
    // is set, or redirecting Google login to a specific-domain page) without
    // having their full effects.
    if (Meteor.isServer) {
      __meteor_runtime_config__.accountsConfigCalled = true;
    } else if (!__meteor_runtime_config__.accountsConfigCalled) {
      // XXX would be nice to "crash" the client and replace the UI with an error
      // message, but there's no trivial way to do this.
      Meteor._debug("Accounts.config was called on the client but not on the " + "server; some configuration options may not take effect.");
    } // We need to validate the oauthSecretKey option at the time
    // Accounts.config is called. We also deliberately don't store the
    // oauthSecretKey in Accounts._options.


    if (Object.prototype.hasOwnProperty.call(options, 'oauthSecretKey')) {
      if (Meteor.isClient) {
        throw new Error("The oauthSecretKey option may only be specified on the server");
      }

      if (!Package["oauth-encryption"]) {
        throw new Error("The oauth-encryption package must be loaded to set oauthSecretKey");
      }

      Package["oauth-encryption"].OAuthEncryption.loadKey(options.oauthSecretKey);
      options = _objectSpread({}, options);
      delete options.oauthSecretKey;
    } // validate option keys


    const VALID_KEYS = ["sendVerificationEmail", "forbidClientAccountCreation", "passwordEnrollTokenExpirationInDays", "restrictCreationByEmailDomain", "loginExpirationInDays", "passwordResetTokenExpirationInDays", "ambiguousErrorMessages", "bcryptRounds", "defaultFieldSelector"];
    Object.keys(options).forEach(key => {
      if (!VALID_KEYS.includes(key)) {
        throw new Error("Accounts.config: Invalid key: ".concat(key));
      }
    }); // set values in Accounts._options

    VALID_KEYS.forEach(key => {
      if (key in options) {
        if (key in this._options) {
          throw new Error("Can't set `".concat(key, "` more than once"));
        }

        this._options[key] = options[key];
      }
    });
  }
  /**
   * @summary Register a callback to be called after a login attempt succeeds.
   * @locus Anywhere
   * @param {Function} func The callback to be called when login is successful.
   *                        The callback receives a single object that
   *                        holds login details. This object contains the login
   *                        result type (password, resume, etc.) on both the
   *                        client and server. `onLogin` callbacks registered
   *                        on the server also receive extra data, such
   *                        as user details, connection information, etc.
   */


  onLogin(func) {
    let ret = this._onLoginHook.register(func); // call the just registered callback if already logged in


    this._startupCallback(ret.callback);

    return ret;
  }
  /**
   * @summary Register a callback to be called after a login attempt fails.
   * @locus Anywhere
   * @param {Function} func The callback to be called after the login has failed.
   */


  onLoginFailure(func) {
    return this._onLoginFailureHook.register(func);
  }
  /**
   * @summary Register a callback to be called after a logout attempt succeeds.
   * @locus Anywhere
   * @param {Function} func The callback to be called when logout is successful.
   */


  onLogout(func) {
    return this._onLogoutHook.register(func);
  }

  _initConnection(options) {
    if (!Meteor.isClient) {
      return;
    } // The connection used by the Accounts system. This is the connection
    // that will get logged in by Meteor.login(), and this is the
    // connection whose login state will be reflected by Meteor.userId().
    //
    // It would be much preferable for this to be in accounts_client.js,
    // but it has to be here because it's needed to create the
    // Meteor.users collection.


    if (options.connection) {
      this.connection = options.connection;
    } else if (options.ddpUrl) {
      this.connection = DDP.connect(options.ddpUrl);
    } else if (typeof __meteor_runtime_config__ !== "undefined" && __meteor_runtime_config__.ACCOUNTS_CONNECTION_URL) {
      // Temporary, internal hook to allow the server to point the client
      // to a different authentication server. This is for a very
      // particular use case that comes up when implementing a oauth
      // server. Unsupported and may go away at any point in time.
      //
      // We will eventually provide a general way to use account-base
      // against any DDP connection, not just one special one.
      this.connection = DDP.connect(__meteor_runtime_config__.ACCOUNTS_CONNECTION_URL);
    } else {
      this.connection = Meteor.connection;
    }
  }

  _getTokenLifetimeMs() {
    // When loginExpirationInDays is set to null, we'll use a really high
    // number of days (LOGIN_UNEXPIRABLE_TOKEN_DAYS) to simulate an
    // unexpiring token.
    const loginExpirationInDays = this._options.loginExpirationInDays === null ? LOGIN_UNEXPIRING_TOKEN_DAYS : this._options.loginExpirationInDays;
    return (loginExpirationInDays || DEFAULT_LOGIN_EXPIRATION_DAYS) * 24 * 60 * 60 * 1000;
  }

  _getPasswordResetTokenLifetimeMs() {
    return (this._options.passwordResetTokenExpirationInDays || DEFAULT_PASSWORD_RESET_TOKEN_EXPIRATION_DAYS) * 24 * 60 * 60 * 1000;
  }

  _getPasswordEnrollTokenLifetimeMs() {
    return (this._options.passwordEnrollTokenExpirationInDays || DEFAULT_PASSWORD_ENROLL_TOKEN_EXPIRATION_DAYS) * 24 * 60 * 60 * 1000;
  }

  _tokenExpiration(when) {
    // We pass when through the Date constructor for backwards compatibility;
    // `when` used to be a number.
    return new Date(new Date(when).getTime() + this._getTokenLifetimeMs());
  }

  _tokenExpiresSoon(when) {
    let minLifetimeMs = .1 * this._getTokenLifetimeMs();

    const minLifetimeCapMs = MIN_TOKEN_LIFETIME_CAP_SECS * 1000;

    if (minLifetimeMs > minLifetimeCapMs) {
      minLifetimeMs = minLifetimeCapMs;
    }

    return new Date() > new Date(when) - minLifetimeMs;
  } // No-op on the server, overridden on the client.


  _startupCallback(callback) {}

}

// Note that Accounts is defined separately in accounts_client.js and
// accounts_server.js.

/**
 * @summary Get the current user id, or `null` if no user is logged in. A reactive data source.
 * @locus Anywhere but publish functions
 * @importFromPackage meteor
 */
Meteor.userId = () => Accounts.userId();
/**
 * @summary Get the current user record, or `null` if no user is logged in. A reactive data source.
 * @locus Anywhere but publish functions
 * @importFromPackage meteor
 * @param {Object} [options]
 * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
 */


Meteor.user = options => Accounts.user(options); // how long (in days) until a login token expires


const DEFAULT_LOGIN_EXPIRATION_DAYS = 90; // how long (in days) until reset password token expires

const DEFAULT_PASSWORD_RESET_TOKEN_EXPIRATION_DAYS = 3; // how long (in days) until enrol password token expires

const DEFAULT_PASSWORD_ENROLL_TOKEN_EXPIRATION_DAYS = 30; // Clients don't try to auto-login with a token that is going to expire within
// .1 * DEFAULT_LOGIN_EXPIRATION_DAYS, capped at MIN_TOKEN_LIFETIME_CAP_SECS.
// Tries to avoid abrupt disconnects from expiring tokens.

const MIN_TOKEN_LIFETIME_CAP_SECS = 3600; // one hour
// how often (in milliseconds) we check for expired tokens

const EXPIRE_TOKENS_INTERVAL_MS = 600 * 1000;
const CONNECTION_CLOSE_DELAY_MS = 10 * 1000;
// A large number of expiration days (approximately 100 years worth) that is
// used when creating unexpiring tokens.
const LOGIN_UNEXPIRING_TOKEN_DAYS = 365 * 100;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"accounts_server.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/accounts-base/accounts_server.js                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let _objectWithoutProperties;

module.link("@babel/runtime/helpers/objectWithoutProperties", {
  default(v) {
    _objectWithoutProperties = v;
  }

}, 0);

let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 1);
module.export({
  AccountsServer: () => AccountsServer
});
let crypto;
module.link("crypto", {
  default(v) {
    crypto = v;
  }

}, 0);
let AccountsCommon, EXPIRE_TOKENS_INTERVAL_MS, CONNECTION_CLOSE_DELAY_MS;
module.link("./accounts_common.js", {
  AccountsCommon(v) {
    AccountsCommon = v;
  },

  EXPIRE_TOKENS_INTERVAL_MS(v) {
    EXPIRE_TOKENS_INTERVAL_MS = v;
  },

  CONNECTION_CLOSE_DELAY_MS(v) {
    CONNECTION_CLOSE_DELAY_MS = v;
  }

}, 1);
const hasOwn = Object.prototype.hasOwnProperty;
/**
 * @summary Constructor for the `Accounts` namespace on the server.
 * @locus Server
 * @class AccountsServer
 * @extends AccountsCommon
 * @instancename accountsServer
 * @param {Object} server A server object such as `Meteor.server`.
 */

class AccountsServer extends AccountsCommon {
  // Note that this constructor is less likely to be instantiated multiple
  // times than the `AccountsClient` constructor, because a single server
  // can provide only one set of methods.
  constructor(server) {
    super();
    this._server = server || Meteor.server; // Set up the server's methods, as if by calling Meteor.methods.

    this._initServerMethods();

    this._initAccountDataHooks(); // If autopublish is on, publish these user fields. Login service
    // packages (eg accounts-google) add to these by calling
    // addAutopublishFields.  Notably, this isn't implemented with multiple
    // publishes since DDP only merges only across top-level fields, not
    // subfields (such as 'services.facebook.accessToken')


    this._autopublishFields = {
      loggedInUser: ['profile', 'username', 'emails'],
      otherUsers: ['profile', 'username']
    }; // use object to keep the reference when used in functions
    // where _defaultPublishFields is destructured into lexical scope
    // for publish callbacks that need `this`

    this._defaultPublishFields = {
      projection: {
        profile: 1,
        username: 1,
        emails: 1
      }
    };

    this._initServerPublications(); // connectionId -> {connection, loginToken}


    this._accountData = {}; // connection id -> observe handle for the login token that this connection is
    // currently associated with, or a number. The number indicates that we are in
    // the process of setting up the observe (using a number instead of a single
    // sentinel allows multiple attempts to set up the observe to identify which
    // one was theirs).

    this._userObservesForConnections = {};
    this._nextUserObserveNumber = 1; // for the number described above.
    // list of all registered handlers.

    this._loginHandlers = [];
    setupUsersCollection(this.users);
    setupDefaultLoginHandlers(this);
    setExpireTokensInterval(this);
    this._validateLoginHook = new Hook({
      bindEnvironment: false
    });
    this._validateNewUserHooks = [defaultValidateNewUserHook.bind(this)];

    this._deleteSavedTokensForAllUsersOnStartup();

    this._skipCaseInsensitiveChecksForTest = {}; // XXX These should probably not actually be public?

    this.urls = {
      resetPassword: token => Meteor.absoluteUrl("#/reset-password/".concat(token)),
      verifyEmail: token => Meteor.absoluteUrl("#/verify-email/".concat(token)),
      enrollAccount: token => Meteor.absoluteUrl("#/enroll-account/".concat(token))
    };
    this.addDefaultRateLimit();
  } ///
  /// CURRENT USER
  ///
  // @override of "abstract" non-implementation in accounts_common.js


  userId() {
    // This function only works if called inside a method or a pubication.
    // Using any of the infomation from Meteor.user() in a method or
    // publish function will always use the value from when the function first
    // runs. This is likely not what the user expects. The way to make this work
    // in a method or publish function is to do Meteor.find(this.userId).observe
    // and recompute when the user record changes.
    const currentInvocation = DDP._CurrentMethodInvocation.get() || DDP._CurrentPublicationInvocation.get();

    if (!currentInvocation) throw new Error("Meteor.userId can only be invoked in method calls or publications.");
    return currentInvocation.userId;
  } ///
  /// LOGIN HOOKS
  ///

  /**
   * @summary Validate login attempts.
   * @locus Server
   * @param {Function} func Called whenever a login is attempted (either successful or unsuccessful).  A login can be aborted by returning a falsy value or throwing an exception.
   */


  validateLoginAttempt(func) {
    // Exceptions inside the hook callback are passed up to us.
    return this._validateLoginHook.register(func);
  }
  /**
   * @summary Set restrictions on new user creation.
   * @locus Server
   * @param {Function} func Called whenever a new user is created. Takes the new user object, and returns true to allow the creation or false to abort.
   */


  validateNewUser(func) {
    this._validateNewUserHooks.push(func);
  }
  /**
   * @summary Validate login from external service
   * @locus Server
   * @param {Function} func Called whenever login/user creation from external service is attempted. Login or user creation based on this login can be aborted by passing a falsy value or throwing an exception.
   */


  beforeExternalLogin(func) {
    if (this._beforeExternalLoginHook) {
      throw new Error("Can only call beforeExternalLogin once");
    }

    this._beforeExternalLoginHook = func;
  } ///
  /// CREATE USER HOOKS
  ///

  /**
   * @summary Customize new user creation.
   * @locus Server
   * @param {Function} func Called whenever a new user is created. Return the new user object, or throw an `Error` to abort the creation.
   */


  onCreateUser(func) {
    if (this._onCreateUserHook) {
      throw new Error("Can only call onCreateUser once");
    }

    this._onCreateUserHook = func;
  }
  /**
   * @summary Customize oauth user profile updates
   * @locus Server
   * @param {Function} func Called whenever a user is logged in via oauth. Return the profile object to be merged, or throw an `Error` to abort the creation.
   */


  onExternalLogin(func) {
    if (this._onExternalLoginHook) {
      throw new Error("Can only call onExternalLogin once");
    }

    this._onExternalLoginHook = func;
  }

  _validateLogin(connection, attempt) {
    this._validateLoginHook.each(callback => {
      let ret;

      try {
        ret = callback(cloneAttemptWithConnection(connection, attempt));
      } catch (e) {
        attempt.allowed = false; // XXX this means the last thrown error overrides previous error
        // messages. Maybe this is surprising to users and we should make
        // overriding errors more explicit. (see
        // https://github.com/meteor/meteor/issues/1960)

        attempt.error = e;
        return true;
      }

      if (!ret) {
        attempt.allowed = false; // don't override a specific error provided by a previous
        // validator or the initial attempt (eg "incorrect password").

        if (!attempt.error) attempt.error = new Meteor.Error(403, "Login forbidden");
      }

      return true;
    });
  }

  _successfulLogin(connection, attempt) {
    this._onLoginHook.each(callback => {
      callback(cloneAttemptWithConnection(connection, attempt));
      return true;
    });
  }

  _failedLogin(connection, attempt) {
    this._onLoginFailureHook.each(callback => {
      callback(cloneAttemptWithConnection(connection, attempt));
      return true;
    });
  }

  _successfulLogout(connection, userId) {
    // don't fetch the user object unless there are some callbacks registered
    let user;

    this._onLogoutHook.each(callback => {
      if (!user && userId) user = this.users.findOne(userId, {
        fields: this._options.defaultFieldSelector
      });
      callback({
        user,
        connection
      });
      return true;
    });
  }

  ///
  /// LOGIN METHODS
  ///
  // Login methods return to the client an object containing these
  // fields when the user was logged in successfully:
  //
  //   id: userId
  //   token: *
  //   tokenExpires: *
  //
  // tokenExpires is optional and intends to provide a hint to the
  // client as to when the token will expire. If not provided, the
  // client will call Accounts._tokenExpiration, passing it the date
  // that it received the token.
  //
  // The login method will throw an error back to the client if the user
  // failed to log in.
  //
  //
  // Login handlers and service specific login methods such as
  // `createUser` internally return a `result` object containing these
  // fields:
  //
  //   type:
  //     optional string; the service name, overrides the handler
  //     default if present.
  //
  //   error:
  //     exception; if the user is not allowed to login, the reason why.
  //
  //   userId:
  //     string; the user id of the user attempting to login (if
  //     known), required for an allowed login.
  //
  //   options:
  //     optional object merged into the result returned by the login
  //     method; used by HAMK from SRP.
  //
  //   stampedLoginToken:
  //     optional object with `token` and `when` indicating the login
  //     token is already present in the database, returned by the
  //     "resume" login handler.
  //
  // For convenience, login methods can also throw an exception, which
  // is converted into an {error} result.  However, if the id of the
  // user attempting the login is known, a {userId, error} result should
  // be returned instead since the user id is not captured when an
  // exception is thrown.
  //
  // This internal `result` object is automatically converted into the
  // public {id, token, tokenExpires} object returned to the client.
  // Try a login method, converting thrown exceptions into an {error}
  // result.  The `type` argument is a default, inserted into the result
  // object if not explicitly returned.
  //
  // Log in a user on a connection.
  //
  // We use the method invocation to set the user id on the connection,
  // not the connection object directly. setUserId is tied to methods to
  // enforce clear ordering of method application (using wait methods on
  // the client, and a no setUserId after unblock restriction on the
  // server)
  //
  // The `stampedLoginToken` parameter is optional.  When present, it
  // indicates that the login token has already been inserted into the
  // database and doesn't need to be inserted again.  (It's used by the
  // "resume" login handler).
  _loginUser(methodInvocation, userId, stampedLoginToken) {
    if (!stampedLoginToken) {
      stampedLoginToken = this._generateStampedLoginToken();

      this._insertLoginToken(userId, stampedLoginToken);
    } // This order (and the avoidance of yields) is important to make
    // sure that when publish functions are rerun, they see a
    // consistent view of the world: the userId is set and matches
    // the login token on the connection (not that there is
    // currently a public API for reading the login token on a
    // connection).


    Meteor._noYieldsAllowed(() => this._setLoginToken(userId, methodInvocation.connection, this._hashLoginToken(stampedLoginToken.token)));

    methodInvocation.setUserId(userId);
    return {
      id: userId,
      token: stampedLoginToken.token,
      tokenExpires: this._tokenExpiration(stampedLoginToken.when)
    };
  }

  // After a login method has completed, call the login hooks.  Note
  // that `attemptLogin` is called for *all* login attempts, even ones
  // which aren't successful (such as an invalid password, etc).
  //
  // If the login is allowed and isn't aborted by a validate login hook
  // callback, log in the user.
  //
  _attemptLogin(methodInvocation, methodName, methodArgs, result) {
    if (!result) throw new Error("result is required"); // XXX A programming error in a login handler can lead to this occuring, and
    // then we don't call onLogin or onLoginFailure callbacks. Should
    // tryLoginMethod catch this case and turn it into an error?

    if (!result.userId && !result.error) throw new Error("A login method must specify a userId or an error");
    let user;
    if (result.userId) user = this.users.findOne(result.userId, {
      fields: this._options.defaultFieldSelector
    });
    const attempt = {
      type: result.type || "unknown",
      allowed: !!(result.userId && !result.error),
      methodName: methodName,
      methodArguments: Array.from(methodArgs)
    };

    if (result.error) {
      attempt.error = result.error;
    }

    if (user) {
      attempt.user = user;
    } // _validateLogin may mutate `attempt` by adding an error and changing allowed
    // to false, but that's the only change it can make (and the user's callbacks
    // only get a clone of `attempt`).


    this._validateLogin(methodInvocation.connection, attempt);

    if (attempt.allowed) {
      const ret = _objectSpread(_objectSpread({}, this._loginUser(methodInvocation, result.userId, result.stampedLoginToken)), result.options);

      ret.type = attempt.type;

      this._successfulLogin(methodInvocation.connection, attempt);

      return ret;
    } else {
      this._failedLogin(methodInvocation.connection, attempt);

      throw attempt.error;
    }
  }

  // All service specific login methods should go through this function.
  // Ensure that thrown exceptions are caught and that login hook
  // callbacks are still called.
  //
  _loginMethod(methodInvocation, methodName, methodArgs, type, fn) {
    return this._attemptLogin(methodInvocation, methodName, methodArgs, tryLoginMethod(type, fn));
  }

  // Report a login attempt failed outside the context of a normal login
  // method. This is for use in the case where there is a multi-step login
  // procedure (eg SRP based password login). If a method early in the
  // chain fails, it should call this function to report a failure. There
  // is no corresponding method for a successful login; methods that can
  // succeed at logging a user in should always be actual login methods
  // (using either Accounts._loginMethod or Accounts.registerLoginHandler).
  _reportLoginFailure(methodInvocation, methodName, methodArgs, result) {
    const attempt = {
      type: result.type || "unknown",
      allowed: false,
      error: result.error,
      methodName: methodName,
      methodArguments: Array.from(methodArgs)
    };

    if (result.userId) {
      attempt.user = this.users.findOne(result.userId, {
        fields: this._options.defaultFieldSelector
      });
    }

    this._validateLogin(methodInvocation.connection, attempt);

    this._failedLogin(methodInvocation.connection, attempt); // _validateLogin may mutate attempt to set a new error message. Return
    // the modified version.


    return attempt;
  }

  ///
  /// LOGIN HANDLERS
  ///
  // The main entry point for auth packages to hook in to login.
  //
  // A login handler is a login method which can return `undefined` to
  // indicate that the login request is not handled by this handler.
  //
  // @param name {String} Optional.  The service name, used by default
  // if a specific service name isn't returned in the result.
  //
  // @param handler {Function} A function that receives an options object
  // (as passed as an argument to the `login` method) and returns one of:
  // - `undefined`, meaning don't handle;
  // - a login method result object
  registerLoginHandler(name, handler) {
    if (!handler) {
      handler = name;
      name = null;
    }

    this._loginHandlers.push({
      name: name,
      handler: handler
    });
  }

  // Checks a user's credentials against all the registered login
  // handlers, and returns a login token if the credentials are valid. It
  // is like the login method, except that it doesn't set the logged-in
  // user on the connection. Throws a Meteor.Error if logging in fails,
  // including the case where none of the login handlers handled the login
  // request. Otherwise, returns {id: userId, token: *, tokenExpires: *}.
  //
  // For example, if you want to login with a plaintext password, `options` could be
  //   { user: { username: <username> }, password: <password> }, or
  //   { user: { email: <email> }, password: <password> }.
  // Try all of the registered login handlers until one of them doesn't
  // return `undefined`, meaning it handled this call to `login`. Return
  // that return value.
  _runLoginHandlers(methodInvocation, options) {
    for (let handler of this._loginHandlers) {
      const result = tryLoginMethod(handler.name, () => handler.handler.call(methodInvocation, options));

      if (result) {
        return result;
      }

      if (result !== undefined) {
        throw new Meteor.Error(400, "A login handler should return a result or undefined");
      }
    }

    return {
      type: null,
      error: new Meteor.Error(400, "Unrecognized options for login request")
    };
  }

  // Deletes the given loginToken from the database.
  //
  // For new-style hashed token, this will cause all connections
  // associated with the token to be closed.
  //
  // Any connections associated with old-style unhashed tokens will be
  // in the process of becoming associated with hashed tokens and then
  // they'll get closed.
  destroyToken(userId, loginToken) {
    this.users.update(userId, {
      $pull: {
        "services.resume.loginTokens": {
          $or: [{
            hashedToken: loginToken
          }, {
            token: loginToken
          }]
        }
      }
    });
  }

  _initServerMethods() {
    // The methods created in this function need to be created here so that
    // this variable is available in their scope.
    const accounts = this; // This object will be populated with methods and then passed to
    // accounts._server.methods further below.

    const methods = {}; // @returns {Object|null}
    //   If successful, returns {token: reconnectToken, id: userId}
    //   If unsuccessful (for example, if the user closed the oauth login popup),
    //     throws an error describing the reason

    methods.login = function (options) {
      // Login handlers should really also check whatever field they look at in
      // options, but we don't enforce it.
      check(options, Object);

      const result = accounts._runLoginHandlers(this, options);

      return accounts._attemptLogin(this, "login", arguments, result);
    };

    methods.logout = function () {
      const token = accounts._getLoginToken(this.connection.id);

      accounts._setLoginToken(this.userId, this.connection, null);

      if (token && this.userId) {
        accounts.destroyToken(this.userId, token);
      }

      accounts._successfulLogout(this.connection, this.userId);

      this.setUserId(null);
    }; // Delete all the current user's tokens and close all open connections logged
    // in as this user. Returns a fresh new login token that this client can
    // use. Tests set Accounts._noConnectionCloseDelayForTest to delete tokens
    // immediately instead of using a delay.
    //
    // XXX COMPAT WITH 0.7.2
    // This single `logoutOtherClients` method has been replaced with two
    // methods, one that you call to get a new token, and another that you
    // call to remove all tokens except your own. The new design allows
    // clients to know when other clients have actually been logged
    // out. (The `logoutOtherClients` method guarantees the caller that
    // the other clients will be logged out at some point, but makes no
    // guarantees about when.) This method is left in for backwards
    // compatibility, especially since application code might be calling
    // this method directly.
    //
    // @returns {Object} Object with token and tokenExpires keys.


    methods.logoutOtherClients = function () {
      const user = accounts.users.findOne(this.userId, {
        fields: {
          "services.resume.loginTokens": true
        }
      });

      if (user) {
        // Save the current tokens in the database to be deleted in
        // CONNECTION_CLOSE_DELAY_MS ms. This gives other connections in the
        // caller's browser time to find the fresh token in localStorage. We save
        // the tokens in the database in case we crash before actually deleting
        // them.
        const tokens = user.services.resume.loginTokens;

        const newToken = accounts._generateStampedLoginToken();

        accounts.users.update(this.userId, {
          $set: {
            "services.resume.loginTokensToDelete": tokens,
            "services.resume.haveLoginTokensToDelete": true
          },
          $push: {
            "services.resume.loginTokens": accounts._hashStampedToken(newToken)
          }
        });
        Meteor.setTimeout(() => {
          // The observe on Meteor.users will take care of closing the connections
          // associated with `tokens`.
          accounts._deleteSavedTokensForUser(this.userId, tokens);
        }, accounts._noConnectionCloseDelayForTest ? 0 : CONNECTION_CLOSE_DELAY_MS); // We do not set the login token on this connection, but instead the
        // observe closes the connection and the client will reconnect with the
        // new token.

        return {
          token: newToken.token,
          tokenExpires: accounts._tokenExpiration(newToken.when)
        };
      } else {
        throw new Meteor.Error("You are not logged in.");
      }
    }; // Generates a new login token with the same expiration as the
    // connection's current token and saves it to the database. Associates
    // the connection with this new token and returns it. Throws an error
    // if called on a connection that isn't logged in.
    //
    // @returns Object
    //   If successful, returns { token: <new token>, id: <user id>,
    //   tokenExpires: <expiration date> }.


    methods.getNewToken = function () {
      const user = accounts.users.findOne(this.userId, {
        fields: {
          "services.resume.loginTokens": 1
        }
      });

      if (!this.userId || !user) {
        throw new Meteor.Error("You are not logged in.");
      } // Be careful not to generate a new token that has a later
      // expiration than the curren token. Otherwise, a bad guy with a
      // stolen token could use this method to stop his stolen token from
      // ever expiring.


      const currentHashedToken = accounts._getLoginToken(this.connection.id);

      const currentStampedToken = user.services.resume.loginTokens.find(stampedToken => stampedToken.hashedToken === currentHashedToken);

      if (!currentStampedToken) {
        // safety belt: this should never happen
        throw new Meteor.Error("Invalid login token");
      }

      const newStampedToken = accounts._generateStampedLoginToken();

      newStampedToken.when = currentStampedToken.when;

      accounts._insertLoginToken(this.userId, newStampedToken);

      return accounts._loginUser(this, this.userId, newStampedToken);
    }; // Removes all tokens except the token associated with the current
    // connection. Throws an error if the connection is not logged
    // in. Returns nothing on success.


    methods.removeOtherTokens = function () {
      if (!this.userId) {
        throw new Meteor.Error("You are not logged in.");
      }

      const currentToken = accounts._getLoginToken(this.connection.id);

      accounts.users.update(this.userId, {
        $pull: {
          "services.resume.loginTokens": {
            hashedToken: {
              $ne: currentToken
            }
          }
        }
      });
    }; // Allow a one-time configuration for a login service. Modifications
    // to this collection are also allowed in insecure mode.


    methods.configureLoginService = options => {
      check(options, Match.ObjectIncluding({
        service: String
      })); // Don't let random users configure a service we haven't added yet (so
      // that when we do later add it, it's set up with their configuration
      // instead of ours).
      // XXX if service configuration is oauth-specific then this code should
      //     be in accounts-oauth; if it's not then the registry should be
      //     in this package

      if (!(accounts.oauth && accounts.oauth.serviceNames().includes(options.service))) {
        throw new Meteor.Error(403, "Service unknown");
      }

      const {
        ServiceConfiguration
      } = Package['service-configuration'];
      if (ServiceConfiguration.configurations.findOne({
        service: options.service
      })) throw new Meteor.Error(403, "Service ".concat(options.service, " already configured"));
      if (hasOwn.call(options, 'secret') && usingOAuthEncryption()) options.secret = OAuthEncryption.seal(options.secret);
      ServiceConfiguration.configurations.insert(options);
    };

    accounts._server.methods(methods);
  }

  _initAccountDataHooks() {
    this._server.onConnection(connection => {
      this._accountData[connection.id] = {
        connection: connection
      };
      connection.onClose(() => {
        this._removeTokenFromConnection(connection.id);

        delete this._accountData[connection.id];
      });
    });
  }

  _initServerPublications() {
    // Bring into lexical scope for publish callbacks that need `this`
    const {
      users,
      _autopublishFields,
      _defaultPublishFields
    } = this; // Publish all login service configuration fields other than secret.

    this._server.publish("meteor.loginServiceConfiguration", () => {
      const {
        ServiceConfiguration
      } = Package['service-configuration'];
      return ServiceConfiguration.configurations.find({}, {
        fields: {
          secret: 0
        }
      });
    }, {
      is_auto: true
    }); // not techincally autopublish, but stops the warning.
    // Use Meteor.startup to give other packages a chance to call
    // setDefaultPublishFields.


    Meteor.startup(() => {
      // Publish the current user's record to the client.
      this._server.publish(null, function () {
        if (this.userId) {
          return users.find({
            _id: this.userId
          }, {
            fields: _defaultPublishFields.projection
          });
        } else {
          return null;
        }
      },
      /*suppress autopublish warning*/
      {
        is_auto: true
      });
    }); // Use Meteor.startup to give other packages a chance to call
    // addAutopublishFields.

    Package.autopublish && Meteor.startup(() => {
      // ['profile', 'username'] -> {profile: 1, username: 1}
      const toFieldSelector = fields => fields.reduce((prev, field) => _objectSpread(_objectSpread({}, prev), {}, {
        [field]: 1
      }), {});

      this._server.publish(null, function () {
        if (this.userId) {
          return users.find({
            _id: this.userId
          }, {
            fields: toFieldSelector(_autopublishFields.loggedInUser)
          });
        } else {
          return null;
        }
      },
      /*suppress autopublish warning*/
      {
        is_auto: true
      }); // XXX this publish is neither dedup-able nor is it optimized by our special
      // treatment of queries on a specific _id. Therefore this will have O(n^2)
      // run-time performance every time a user document is changed (eg someone
      // logging in). If this is a problem, we can instead write a manual publish
      // function which filters out fields based on 'this.userId'.


      this._server.publish(null, function () {
        const selector = this.userId ? {
          _id: {
            $ne: this.userId
          }
        } : {};
        return users.find(selector, {
          fields: toFieldSelector(_autopublishFields.otherUsers)
        });
      },
      /*suppress autopublish warning*/
      {
        is_auto: true
      });
    });
  }

  // Add to the list of fields or subfields to be automatically
  // published if autopublish is on. Must be called from top-level
  // code (ie, before Meteor.startup hooks run).
  //
  // @param opts {Object} with:
  //   - forLoggedInUser {Array} Array of fields published to the logged-in user
  //   - forOtherUsers {Array} Array of fields published to users that aren't logged in
  addAutopublishFields(opts) {
    this._autopublishFields.loggedInUser.push.apply(this._autopublishFields.loggedInUser, opts.forLoggedInUser);

    this._autopublishFields.otherUsers.push.apply(this._autopublishFields.otherUsers, opts.forOtherUsers);
  }

  // Replaces the fields to be automatically
  // published when the user logs in
  //
  // @param {MongoFieldSpecifier} fields Dictionary of fields to return or exclude.
  setDefaultPublishFields(fields) {
    this._defaultPublishFields.projection = fields;
  }

  ///
  /// ACCOUNT DATA
  ///
  // HACK: This is used by 'meteor-accounts' to get the loginToken for a
  // connection. Maybe there should be a public way to do that.
  _getAccountData(connectionId, field) {
    const data = this._accountData[connectionId];
    return data && data[field];
  }

  _setAccountData(connectionId, field, value) {
    const data = this._accountData[connectionId]; // safety belt. shouldn't happen. accountData is set in onConnection,
    // we don't have a connectionId until it is set.

    if (!data) return;
    if (value === undefined) delete data[field];else data[field] = value;
  }

  ///
  /// RECONNECT TOKENS
  ///
  /// support reconnecting using a meteor login token
  _hashLoginToken(loginToken) {
    const hash = crypto.createHash('sha256');
    hash.update(loginToken);
    return hash.digest('base64');
  }

  // {token, when} => {hashedToken, when}
  _hashStampedToken(stampedToken) {
    const {
      token
    } = stampedToken,
          hashedStampedToken = _objectWithoutProperties(stampedToken, ["token"]);

    return _objectSpread(_objectSpread({}, hashedStampedToken), {}, {
      hashedToken: this._hashLoginToken(token)
    });
  }

  // Using $addToSet avoids getting an index error if another client
  // logging in simultaneously has already inserted the new hashed
  // token.
  _insertHashedLoginToken(userId, hashedToken, query) {
    query = query ? _objectSpread({}, query) : {};
    query._id = userId;
    this.users.update(query, {
      $addToSet: {
        "services.resume.loginTokens": hashedToken
      }
    });
  }

  // Exported for tests.
  _insertLoginToken(userId, stampedToken, query) {
    this._insertHashedLoginToken(userId, this._hashStampedToken(stampedToken), query);
  }

  _clearAllLoginTokens(userId) {
    this.users.update(userId, {
      $set: {
        'services.resume.loginTokens': []
      }
    });
  }

  // test hook
  _getUserObserve(connectionId) {
    return this._userObservesForConnections[connectionId];
  }

  // Clean up this connection's association with the token: that is, stop
  // the observe that we started when we associated the connection with
  // this token.
  _removeTokenFromConnection(connectionId) {
    if (hasOwn.call(this._userObservesForConnections, connectionId)) {
      const observe = this._userObservesForConnections[connectionId];

      if (typeof observe === 'number') {
        // We're in the process of setting up an observe for this connection. We
        // can't clean up that observe yet, but if we delete the placeholder for
        // this connection, then the observe will get cleaned up as soon as it has
        // been set up.
        delete this._userObservesForConnections[connectionId];
      } else {
        delete this._userObservesForConnections[connectionId];
        observe.stop();
      }
    }
  }

  _getLoginToken(connectionId) {
    return this._getAccountData(connectionId, 'loginToken');
  }

  // newToken is a hashed token.
  _setLoginToken(userId, connection, newToken) {
    this._removeTokenFromConnection(connection.id);

    this._setAccountData(connection.id, 'loginToken', newToken);

    if (newToken) {
      // Set up an observe for this token. If the token goes away, we need
      // to close the connection.  We defer the observe because there's
      // no need for it to be on the critical path for login; we just need
      // to ensure that the connection will get closed at some point if
      // the token gets deleted.
      //
      // Initially, we set the observe for this connection to a number; this
      // signifies to other code (which might run while we yield) that we are in
      // the process of setting up an observe for this connection. Once the
      // observe is ready to go, we replace the number with the real observe
      // handle (unless the placeholder has been deleted or replaced by a
      // different placehold number, signifying that the connection was closed
      // already -- in this case we just clean up the observe that we started).
      const myObserveNumber = ++this._nextUserObserveNumber;
      this._userObservesForConnections[connection.id] = myObserveNumber;
      Meteor.defer(() => {
        // If something else happened on this connection in the meantime (it got
        // closed, or another call to _setLoginToken happened), just do
        // nothing. We don't need to start an observe for an old connection or old
        // token.
        if (this._userObservesForConnections[connection.id] !== myObserveNumber) {
          return;
        }

        let foundMatchingUser; // Because we upgrade unhashed login tokens to hashed tokens at
        // login time, sessions will only be logged in with a hashed
        // token. Thus we only need to observe hashed tokens here.

        const observe = this.users.find({
          _id: userId,
          'services.resume.loginTokens.hashedToken': newToken
        }, {
          fields: {
            _id: 1
          }
        }).observeChanges({
          added: () => {
            foundMatchingUser = true;
          },
          removed: connection.close // The onClose callback for the connection takes care of
          // cleaning up the observe handle and any other state we have
          // lying around.

        }, {
          nonMutatingCallbacks: true
        }); // If the user ran another login or logout command we were waiting for the
        // defer or added to fire (ie, another call to _setLoginToken occurred),
        // then we let the later one win (start an observe, etc) and just stop our
        // observe now.
        //
        // Similarly, if the connection was already closed, then the onClose
        // callback would have called _removeTokenFromConnection and there won't
        // be an entry in _userObservesForConnections. We can stop the observe.

        if (this._userObservesForConnections[connection.id] !== myObserveNumber) {
          observe.stop();
          return;
        }

        this._userObservesForConnections[connection.id] = observe;

        if (!foundMatchingUser) {
          // We've set up an observe on the user associated with `newToken`,
          // so if the new token is removed from the database, we'll close
          // the connection. But the token might have already been deleted
          // before we set up the observe, which wouldn't have closed the
          // connection because the observe wasn't running yet.
          connection.close();
        }
      });
    }
  }

  // (Also used by Meteor Accounts server and tests).
  //
  _generateStampedLoginToken() {
    return {
      token: Random.secret(),
      when: new Date()
    };
  }

  ///
  /// TOKEN EXPIRATION
  ///
  // Deletes expired password reset tokens from the database.
  //
  // Exported for tests. Also, the arguments are only used by
  // tests. oldestValidDate is simulate expiring tokens without waiting
  // for them to actually expire. userId is used by tests to only expire
  // tokens for the test user.
  _expirePasswordResetTokens(oldestValidDate, userId) {
    const tokenLifetimeMs = this._getPasswordResetTokenLifetimeMs(); // when calling from a test with extra arguments, you must specify both!


    if (oldestValidDate && !userId || !oldestValidDate && userId) {
      throw new Error("Bad test. Must specify both oldestValidDate and userId.");
    }

    oldestValidDate = oldestValidDate || new Date(new Date() - tokenLifetimeMs);
    const tokenFilter = {
      $or: [{
        "services.password.reset.reason": "reset"
      }, {
        "services.password.reset.reason": {
          $exists: false
        }
      }]
    };
    expirePasswordToken(this, oldestValidDate, tokenFilter, userId);
  } // Deletes expired password enroll tokens from the database.
  //
  // Exported for tests. Also, the arguments are only used by
  // tests. oldestValidDate is simulate expiring tokens without waiting
  // for them to actually expire. userId is used by tests to only expire
  // tokens for the test user.


  _expirePasswordEnrollTokens(oldestValidDate, userId) {
    const tokenLifetimeMs = this._getPasswordEnrollTokenLifetimeMs(); // when calling from a test with extra arguments, you must specify both!


    if (oldestValidDate && !userId || !oldestValidDate && userId) {
      throw new Error("Bad test. Must specify both oldestValidDate and userId.");
    }

    oldestValidDate = oldestValidDate || new Date(new Date() - tokenLifetimeMs);
    const tokenFilter = {
      "services.password.reset.reason": "enroll"
    };
    expirePasswordToken(this, oldestValidDate, tokenFilter, userId);
  } // Deletes expired tokens from the database and closes all open connections
  // associated with these tokens.
  //
  // Exported for tests. Also, the arguments are only used by
  // tests. oldestValidDate is simulate expiring tokens without waiting
  // for them to actually expire. userId is used by tests to only expire
  // tokens for the test user.


  _expireTokens(oldestValidDate, userId) {
    const tokenLifetimeMs = this._getTokenLifetimeMs(); // when calling from a test with extra arguments, you must specify both!


    if (oldestValidDate && !userId || !oldestValidDate && userId) {
      throw new Error("Bad test. Must specify both oldestValidDate and userId.");
    }

    oldestValidDate = oldestValidDate || new Date(new Date() - tokenLifetimeMs);
    const userFilter = userId ? {
      _id: userId
    } : {}; // Backwards compatible with older versions of meteor that stored login token
    // timestamps as numbers.

    this.users.update(_objectSpread(_objectSpread({}, userFilter), {}, {
      $or: [{
        "services.resume.loginTokens.when": {
          $lt: oldestValidDate
        }
      }, {
        "services.resume.loginTokens.when": {
          $lt: +oldestValidDate
        }
      }]
    }), {
      $pull: {
        "services.resume.loginTokens": {
          $or: [{
            when: {
              $lt: oldestValidDate
            }
          }, {
            when: {
              $lt: +oldestValidDate
            }
          }]
        }
      }
    }, {
      multi: true
    }); // The observe on Meteor.users will take care of closing connections for
    // expired tokens.
  }

  // @override from accounts_common.js
  config(options) {
    // Call the overridden implementation of the method.
    const superResult = AccountsCommon.prototype.config.apply(this, arguments); // If the user set loginExpirationInDays to null, then we need to clear the
    // timer that periodically expires tokens.

    if (hasOwn.call(this._options, 'loginExpirationInDays') && this._options.loginExpirationInDays === null && this.expireTokenInterval) {
      Meteor.clearInterval(this.expireTokenInterval);
      this.expireTokenInterval = null;
    }

    return superResult;
  }

  // Called by accounts-password
  insertUserDoc(options, user) {
    // - clone user document, to protect from modification
    // - add createdAt timestamp
    // - prepare an _id, so that you can modify other collections (eg
    // create a first task for every new user)
    //
    // XXX If the onCreateUser or validateNewUser hooks fail, we might
    // end up having modified some other collection
    // inappropriately. The solution is probably to have onCreateUser
    // accept two callbacks - one that gets called before inserting
    // the user document (in which you can modify its contents), and
    // one that gets called after (in which you should change other
    // collections)
    user = _objectSpread({
      createdAt: new Date(),
      _id: Random.id()
    }, user);

    if (user.services) {
      Object.keys(user.services).forEach(service => pinEncryptedFieldsToUser(user.services[service], user._id));
    }

    let fullUser;

    if (this._onCreateUserHook) {
      fullUser = this._onCreateUserHook(options, user); // This is *not* part of the API. We need this because we can't isolate
      // the global server environment between tests, meaning we can't test
      // both having a create user hook set and not having one set.

      if (fullUser === 'TEST DEFAULT HOOK') fullUser = defaultCreateUserHook(options, user);
    } else {
      fullUser = defaultCreateUserHook(options, user);
    }

    this._validateNewUserHooks.forEach(hook => {
      if (!hook(fullUser)) throw new Meteor.Error(403, "User validation failed");
    });

    let userId;

    try {
      userId = this.users.insert(fullUser);
    } catch (e) {
      // XXX string parsing sucks, maybe
      // https://jira.mongodb.org/browse/SERVER-3069 will get fixed one day
      if (!e.errmsg) throw e;
      if (e.errmsg.includes('emails.address')) throw new Meteor.Error(403, "Email already exists.");
      if (e.errmsg.includes('username')) throw new Meteor.Error(403, "Username already exists.");
      throw e;
    }

    return userId;
  }

  // Helper function: returns false if email does not match company domain from
  // the configuration.
  _testEmailDomain(email) {
    const domain = this._options.restrictCreationByEmailDomain;
    return !domain || typeof domain === 'function' && domain(email) || typeof domain === 'string' && new RegExp("@".concat(Meteor._escapeRegExp(domain), "$"), 'i').test(email);
  }

  ///
  /// CLEAN UP FOR `logoutOtherClients`
  ///
  _deleteSavedTokensForUser(userId, tokensToDelete) {
    if (tokensToDelete) {
      this.users.update(userId, {
        $unset: {
          "services.resume.haveLoginTokensToDelete": 1,
          "services.resume.loginTokensToDelete": 1
        },
        $pullAll: {
          "services.resume.loginTokens": tokensToDelete
        }
      });
    }
  }

  _deleteSavedTokensForAllUsersOnStartup() {
    // If we find users who have saved tokens to delete on startup, delete
    // them now. It's possible that the server could have crashed and come
    // back up before new tokens are found in localStorage, but this
    // shouldn't happen very often. We shouldn't put a delay here because
    // that would give a lot of power to an attacker with a stolen login
    // token and the ability to crash the server.
    Meteor.startup(() => {
      this.users.find({
        "services.resume.haveLoginTokensToDelete": true
      }, {
        fields: {
          "services.resume.loginTokensToDelete": 1
        }
      }).forEach(user => {
        this._deleteSavedTokensForUser(user._id, user.services.resume.loginTokensToDelete);
      });
    });
  }

  ///
  /// MANAGING USER OBJECTS
  ///
  // Updates or creates a user after we authenticate with a 3rd party.
  //
  // @param serviceName {String} Service name (eg, twitter).
  // @param serviceData {Object} Data to store in the user's record
  //        under services[serviceName]. Must include an "id" field
  //        which is a unique identifier for the user in the service.
  // @param options {Object, optional} Other options to pass to insertUserDoc
  //        (eg, profile)
  // @returns {Object} Object with token and id keys, like the result
  //        of the "login" method.
  //
  updateOrCreateUserFromExternalService(serviceName, serviceData, options) {
    options = _objectSpread({}, options);

    if (serviceName === "password" || serviceName === "resume") {
      throw new Error("Can't use updateOrCreateUserFromExternalService with internal service " + serviceName);
    }

    if (!hasOwn.call(serviceData, 'id')) {
      throw new Error("Service data for service ".concat(serviceName, " must include id"));
    } // Look for a user with the appropriate service user id.


    const selector = {};
    const serviceIdKey = "services.".concat(serviceName, ".id"); // XXX Temporary special case for Twitter. (Issue #629)
    //   The serviceData.id will be a string representation of an integer.
    //   We want it to match either a stored string or int representation.
    //   This is to cater to earlier versions of Meteor storing twitter
    //   user IDs in number form, and recent versions storing them as strings.
    //   This can be removed once migration technology is in place, and twitter
    //   users stored with integer IDs have been migrated to string IDs.

    if (serviceName === "twitter" && !isNaN(serviceData.id)) {
      selector["$or"] = [{}, {}];
      selector["$or"][0][serviceIdKey] = serviceData.id;
      selector["$or"][1][serviceIdKey] = parseInt(serviceData.id, 10);
    } else {
      selector[serviceIdKey] = serviceData.id;
    }

    let user = this.users.findOne(selector, {
      fields: this._options.defaultFieldSelector
    }); // Before continuing, run user hook to see if we should continue

    if (this._beforeExternalLoginHook && !this._beforeExternalLoginHook(serviceName, serviceData, user)) {
      throw new Meteor.Error(403, "Login forbidden");
    } // When creating a new user we pass through all options. When updating an
    // existing user, by default we only process/pass through the serviceData
    // (eg, so that we keep an unexpired access token and don't cache old email
    // addresses in serviceData.email). The onExternalLogin hook can be used when
    // creating or updating a user, to modify or pass through more options as
    // needed.


    let opts = user ? {} : options;

    if (this._onExternalLoginHook) {
      opts = this._onExternalLoginHook(options, user);
    }

    if (user) {
      pinEncryptedFieldsToUser(serviceData, user._id);
      let setAttrs = {};
      Object.keys(serviceData).forEach(key => setAttrs["services.".concat(serviceName, ".").concat(key)] = serviceData[key]); // XXX Maybe we should re-use the selector above and notice if the update
      //     touches nothing?

      setAttrs = _objectSpread(_objectSpread({}, setAttrs), opts);
      this.users.update(user._id, {
        $set: setAttrs
      });
      return {
        type: serviceName,
        userId: user._id
      };
    } else {
      // Create a new user with the service data.
      user = {
        services: {}
      };
      user.services[serviceName] = serviceData;
      return {
        type: serviceName,
        userId: this.insertUserDoc(opts, user)
      };
    }
  }

  // Removes default rate limiting rule
  removeDefaultRateLimit() {
    const resp = DDPRateLimiter.removeRule(this.defaultRateLimiterRuleId);
    this.defaultRateLimiterRuleId = null;
    return resp;
  }

  // Add a default rule of limiting logins, creating new users and password reset
  // to 5 times every 10 seconds per connection.
  addDefaultRateLimit() {
    if (!this.defaultRateLimiterRuleId) {
      this.defaultRateLimiterRuleId = DDPRateLimiter.addRule({
        userId: null,
        clientAddress: null,
        type: 'method',
        name: name => ['login', 'createUser', 'resetPassword', 'forgotPassword'].includes(name),
        connectionId: connectionId => true
      }, 5, 10000);
    }
  }

}

// Give each login hook callback a fresh cloned copy of the attempt
// object, but don't clone the connection.
//
const cloneAttemptWithConnection = (connection, attempt) => {
  const clonedAttempt = EJSON.clone(attempt);
  clonedAttempt.connection = connection;
  return clonedAttempt;
};

const tryLoginMethod = (type, fn) => {
  let result;

  try {
    result = fn();
  } catch (e) {
    result = {
      error: e
    };
  }

  if (result && !result.type && type) result.type = type;
  return result;
};

const setupDefaultLoginHandlers = accounts => {
  accounts.registerLoginHandler("resume", function (options) {
    return defaultResumeLoginHandler.call(this, accounts, options);
  });
}; // Login handler for resume tokens.


const defaultResumeLoginHandler = (accounts, options) => {
  if (!options.resume) return undefined;
  check(options.resume, String);

  const hashedToken = accounts._hashLoginToken(options.resume); // First look for just the new-style hashed login token, to avoid
  // sending the unhashed token to the database in a query if we don't
  // need to.


  let user = accounts.users.findOne({
    "services.resume.loginTokens.hashedToken": hashedToken
  }, {
    fields: {
      "services.resume.loginTokens.$": 1
    }
  });

  if (!user) {
    // If we didn't find the hashed login token, try also looking for
    // the old-style unhashed token.  But we need to look for either
    // the old-style token OR the new-style token, because another
    // client connection logging in simultaneously might have already
    // converted the token.
    user = accounts.users.findOne({
      $or: [{
        "services.resume.loginTokens.hashedToken": hashedToken
      }, {
        "services.resume.loginTokens.token": options.resume
      }]
    }, // Note: Cannot use ...loginTokens.$ positional operator with $or query.
    {
      fields: {
        "services.resume.loginTokens": 1
      }
    });
  }

  if (!user) return {
    error: new Meteor.Error(403, "You've been logged out by the server. Please log in again.")
  }; // Find the token, which will either be an object with fields
  // {hashedToken, when} for a hashed token or {token, when} for an
  // unhashed token.

  let oldUnhashedStyleToken;
  let token = user.services.resume.loginTokens.find(token => token.hashedToken === hashedToken);

  if (token) {
    oldUnhashedStyleToken = false;
  } else {
    token = user.services.resume.loginTokens.find(token => token.token === options.resume);
    oldUnhashedStyleToken = true;
  }

  const tokenExpires = accounts._tokenExpiration(token.when);

  if (new Date() >= tokenExpires) return {
    userId: user._id,
    error: new Meteor.Error(403, "Your session has expired. Please log in again.")
  }; // Update to a hashed token when an unhashed token is encountered.

  if (oldUnhashedStyleToken) {
    // Only add the new hashed token if the old unhashed token still
    // exists (this avoids resurrecting the token if it was deleted
    // after we read it).  Using $addToSet avoids getting an index
    // error if another client logging in simultaneously has already
    // inserted the new hashed token.
    accounts.users.update({
      _id: user._id,
      "services.resume.loginTokens.token": options.resume
    }, {
      $addToSet: {
        "services.resume.loginTokens": {
          "hashedToken": hashedToken,
          "when": token.when
        }
      }
    }); // Remove the old token *after* adding the new, since otherwise
    // another client trying to login between our removing the old and
    // adding the new wouldn't find a token to login with.

    accounts.users.update(user._id, {
      $pull: {
        "services.resume.loginTokens": {
          "token": options.resume
        }
      }
    });
  }

  return {
    userId: user._id,
    stampedLoginToken: {
      token: options.resume,
      when: token.when
    }
  };
};

const expirePasswordToken = (accounts, oldestValidDate, tokenFilter, userId) => {
  const userFilter = userId ? {
    _id: userId
  } : {};
  const resetRangeOr = {
    $or: [{
      "services.password.reset.when": {
        $lt: oldestValidDate
      }
    }, {
      "services.password.reset.when": {
        $lt: +oldestValidDate
      }
    }]
  };
  const expireFilter = {
    $and: [tokenFilter, resetRangeOr]
  };
  accounts.users.update(_objectSpread(_objectSpread({}, userFilter), expireFilter), {
    $unset: {
      "services.password.reset": ""
    }
  }, {
    multi: true
  });
};

const setExpireTokensInterval = accounts => {
  accounts.expireTokenInterval = Meteor.setInterval(() => {
    accounts._expireTokens();

    accounts._expirePasswordResetTokens();

    accounts._expirePasswordEnrollTokens();
  }, EXPIRE_TOKENS_INTERVAL_MS);
}; ///
/// OAuth Encryption Support
///


const OAuthEncryption = Package["oauth-encryption"] && Package["oauth-encryption"].OAuthEncryption;

const usingOAuthEncryption = () => {
  return OAuthEncryption && OAuthEncryption.keyIsLoaded();
}; // OAuth service data is temporarily stored in the pending credentials
// collection during the oauth authentication process.  Sensitive data
// such as access tokens are encrypted without the user id because
// we don't know the user id yet.  We re-encrypt these fields with the
// user id included when storing the service data permanently in
// the users collection.
//


const pinEncryptedFieldsToUser = (serviceData, userId) => {
  Object.keys(serviceData).forEach(key => {
    let value = serviceData[key];
    if (OAuthEncryption && OAuthEncryption.isSealed(value)) value = OAuthEncryption.seal(OAuthEncryption.open(value), userId);
    serviceData[key] = value;
  });
}; // Encrypt unencrypted login service secrets when oauth-encryption is
// added.
//
// XXX For the oauthSecretKey to be available here at startup, the
// developer must call Accounts.config({oauthSecretKey: ...}) at load
// time, instead of in a Meteor.startup block, because the startup
// block in the app code will run after this accounts-base startup
// block.  Perhaps we need a post-startup callback?


Meteor.startup(() => {
  if (!usingOAuthEncryption()) {
    return;
  }

  const {
    ServiceConfiguration
  } = Package['service-configuration'];
  ServiceConfiguration.configurations.find({
    $and: [{
      secret: {
        $exists: true
      }
    }, {
      "secret.algorithm": {
        $exists: false
      }
    }]
  }).forEach(config => {
    ServiceConfiguration.configurations.update(config._id, {
      $set: {
        secret: OAuthEncryption.seal(config.secret)
      }
    });
  });
}); // XXX see comment on Accounts.createUser in passwords_server about adding a
// second "server options" argument.

const defaultCreateUserHook = (options, user) => {
  if (options.profile) user.profile = options.profile;
  return user;
}; // Validate new user's email or Google/Facebook/GitHub account's email


function defaultValidateNewUserHook(user) {
  const domain = this._options.restrictCreationByEmailDomain;

  if (!domain) {
    return true;
  }

  let emailIsGood = false;

  if (user.emails && user.emails.length > 0) {
    emailIsGood = user.emails.reduce((prev, email) => prev || this._testEmailDomain(email.address), false);
  } else if (user.services && Object.values(user.services).length > 0) {
    // Find any email of any service and check it
    emailIsGood = Object.values(user.services).reduce((prev, service) => service.email && this._testEmailDomain(service.email), false);
  }

  if (emailIsGood) {
    return true;
  }

  if (typeof domain === 'string') {
    throw new Meteor.Error(403, "@".concat(domain, " email required"));
  } else {
    throw new Meteor.Error(403, "Email doesn't match the criteria.");
  }
}

const setupUsersCollection = users => {
  ///
  /// RESTRICTING WRITES TO USER OBJECTS
  ///
  users.allow({
    // clients can modify the profile field of their own document, and
    // nothing else.
    update: (userId, user, fields, modifier) => {
      // make sure it is our record
      if (user._id !== userId) {
        return false;
      } // user can only modify the 'profile' field. sets to multiple
      // sub-keys (eg profile.foo and profile.bar) are merged into entry
      // in the fields list.


      if (fields.length !== 1 || fields[0] !== 'profile') {
        return false;
      }

      return true;
    },
    fetch: ['_id'] // we only look at _id.

  }); /// DEFAULT INDEXES ON USERS

  users._ensureIndex('username', {
    unique: true,
    sparse: true
  });

  users._ensureIndex('emails.address', {
    unique: true,
    sparse: true
  });

  users._ensureIndex('services.resume.loginTokens.hashedToken', {
    unique: true,
    sparse: true
  });

  users._ensureIndex('services.resume.loginTokens.token', {
    unique: true,
    sparse: true
  }); // For taking care of logoutOtherClients calls that crashed before the
  // tokens were deleted.


  users._ensureIndex('services.resume.haveLoginTokensToDelete', {
    sparse: true
  }); // For expiring login tokens


  users._ensureIndex("services.resume.loginTokens.when", {
    sparse: true
  }); // For expiring password tokens


  users._ensureIndex('services.password.reset.when', {
    sparse: true
  });
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/accounts-base/server_main.js");

/* Exports */
Package._define("accounts-base", exports, {
  Accounts: Accounts
});

})();

//# sourceURL=meteor://💻app/packages/accounts-base.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWNjb3VudHMtYmFzZS9zZXJ2ZXJfbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWNjb3VudHMtYmFzZS9hY2NvdW50c19jb21tb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2FjY291bnRzLWJhc2UvYWNjb3VudHNfc2VydmVyLmpzIl0sIm5hbWVzIjpbIm1vZHVsZTEiLCJleHBvcnQiLCJBY2NvdW50c1NlcnZlciIsImxpbmsiLCJ2IiwiQWNjb3VudHMiLCJNZXRlb3IiLCJzZXJ2ZXIiLCJ1c2VycyIsIl9vYmplY3RTcHJlYWQiLCJtb2R1bGUiLCJkZWZhdWx0IiwiQWNjb3VudHNDb21tb24iLCJFWFBJUkVfVE9LRU5TX0lOVEVSVkFMX01TIiwiQ09OTkVDVElPTl9DTE9TRV9ERUxBWV9NUyIsImNvbnN0cnVjdG9yIiwib3B0aW9ucyIsIl9vcHRpb25zIiwiY29ubmVjdGlvbiIsInVuZGVmaW5lZCIsIl9pbml0Q29ubmVjdGlvbiIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIl9wcmV2ZW50QXV0b3B1Ymxpc2giLCJfb25Mb2dpbkhvb2siLCJIb29rIiwiYmluZEVudmlyb25tZW50IiwiZGVidWdQcmludEV4Y2VwdGlvbnMiLCJfb25Mb2dpbkZhaWx1cmVIb29rIiwiX29uTG9nb3V0SG9vayIsIkRFRkFVTFRfTE9HSU5fRVhQSVJBVElPTl9EQVlTIiwiTE9HSU5fVU5FWFBJUklOR19UT0tFTl9EQVlTIiwibGNlTmFtZSIsIkxvZ2luQ2FuY2VsbGVkRXJyb3IiLCJtYWtlRXJyb3JUeXBlIiwiZGVzY3JpcHRpb24iLCJtZXNzYWdlIiwicHJvdG90eXBlIiwibmFtZSIsIm51bWVyaWNFcnJvciIsInN0YXJ0dXAiLCJTZXJ2aWNlQ29uZmlndXJhdGlvbiIsIlBhY2thZ2UiLCJsb2dpblNlcnZpY2VDb25maWd1cmF0aW9uIiwiY29uZmlndXJhdGlvbnMiLCJDb25maWdFcnJvciIsInVzZXJJZCIsIkVycm9yIiwiX2FkZERlZmF1bHRGaWVsZFNlbGVjdG9yIiwiZGVmYXVsdEZpZWxkU2VsZWN0b3IiLCJmaWVsZHMiLCJrZXlzIiwiT2JqZWN0IiwibGVuZ3RoIiwia2V5czIiLCJ1c2VyIiwiZmluZE9uZSIsImNvbmZpZyIsImlzU2VydmVyIiwiX19tZXRlb3JfcnVudGltZV9jb25maWdfXyIsImFjY291bnRzQ29uZmlnQ2FsbGVkIiwiX2RlYnVnIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaXNDbGllbnQiLCJPQXV0aEVuY3J5cHRpb24iLCJsb2FkS2V5Iiwib2F1dGhTZWNyZXRLZXkiLCJWQUxJRF9LRVlTIiwiZm9yRWFjaCIsImtleSIsImluY2x1ZGVzIiwib25Mb2dpbiIsImZ1bmMiLCJyZXQiLCJyZWdpc3RlciIsIl9zdGFydHVwQ2FsbGJhY2siLCJjYWxsYmFjayIsIm9uTG9naW5GYWlsdXJlIiwib25Mb2dvdXQiLCJkZHBVcmwiLCJERFAiLCJjb25uZWN0IiwiQUNDT1VOVFNfQ09OTkVDVElPTl9VUkwiLCJfZ2V0VG9rZW5MaWZldGltZU1zIiwibG9naW5FeHBpcmF0aW9uSW5EYXlzIiwiX2dldFBhc3N3b3JkUmVzZXRUb2tlbkxpZmV0aW1lTXMiLCJwYXNzd29yZFJlc2V0VG9rZW5FeHBpcmF0aW9uSW5EYXlzIiwiREVGQVVMVF9QQVNTV09SRF9SRVNFVF9UT0tFTl9FWFBJUkFUSU9OX0RBWVMiLCJfZ2V0UGFzc3dvcmRFbnJvbGxUb2tlbkxpZmV0aW1lTXMiLCJwYXNzd29yZEVucm9sbFRva2VuRXhwaXJhdGlvbkluRGF5cyIsIkRFRkFVTFRfUEFTU1dPUkRfRU5ST0xMX1RPS0VOX0VYUElSQVRJT05fREFZUyIsIl90b2tlbkV4cGlyYXRpb24iLCJ3aGVuIiwiRGF0ZSIsImdldFRpbWUiLCJfdG9rZW5FeHBpcmVzU29vbiIsIm1pbkxpZmV0aW1lTXMiLCJtaW5MaWZldGltZUNhcE1zIiwiTUlOX1RPS0VOX0xJRkVUSU1FX0NBUF9TRUNTIiwiX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzIiwiY3J5cHRvIiwiaGFzT3duIiwiX3NlcnZlciIsIl9pbml0U2VydmVyTWV0aG9kcyIsIl9pbml0QWNjb3VudERhdGFIb29rcyIsIl9hdXRvcHVibGlzaEZpZWxkcyIsImxvZ2dlZEluVXNlciIsIm90aGVyVXNlcnMiLCJfZGVmYXVsdFB1Ymxpc2hGaWVsZHMiLCJwcm9qZWN0aW9uIiwicHJvZmlsZSIsInVzZXJuYW1lIiwiZW1haWxzIiwiX2luaXRTZXJ2ZXJQdWJsaWNhdGlvbnMiLCJfYWNjb3VudERhdGEiLCJfdXNlck9ic2VydmVzRm9yQ29ubmVjdGlvbnMiLCJfbmV4dFVzZXJPYnNlcnZlTnVtYmVyIiwiX2xvZ2luSGFuZGxlcnMiLCJzZXR1cFVzZXJzQ29sbGVjdGlvbiIsInNldHVwRGVmYXVsdExvZ2luSGFuZGxlcnMiLCJzZXRFeHBpcmVUb2tlbnNJbnRlcnZhbCIsIl92YWxpZGF0ZUxvZ2luSG9vayIsIl92YWxpZGF0ZU5ld1VzZXJIb29rcyIsImRlZmF1bHRWYWxpZGF0ZU5ld1VzZXJIb29rIiwiYmluZCIsIl9kZWxldGVTYXZlZFRva2Vuc0ZvckFsbFVzZXJzT25TdGFydHVwIiwiX3NraXBDYXNlSW5zZW5zaXRpdmVDaGVja3NGb3JUZXN0IiwidXJscyIsInJlc2V0UGFzc3dvcmQiLCJ0b2tlbiIsImFic29sdXRlVXJsIiwidmVyaWZ5RW1haWwiLCJlbnJvbGxBY2NvdW50IiwiYWRkRGVmYXVsdFJhdGVMaW1pdCIsImN1cnJlbnRJbnZvY2F0aW9uIiwiX0N1cnJlbnRNZXRob2RJbnZvY2F0aW9uIiwiZ2V0IiwiX0N1cnJlbnRQdWJsaWNhdGlvbkludm9jYXRpb24iLCJ2YWxpZGF0ZUxvZ2luQXR0ZW1wdCIsInZhbGlkYXRlTmV3VXNlciIsInB1c2giLCJiZWZvcmVFeHRlcm5hbExvZ2luIiwiX2JlZm9yZUV4dGVybmFsTG9naW5Ib29rIiwib25DcmVhdGVVc2VyIiwiX29uQ3JlYXRlVXNlckhvb2siLCJvbkV4dGVybmFsTG9naW4iLCJfb25FeHRlcm5hbExvZ2luSG9vayIsIl92YWxpZGF0ZUxvZ2luIiwiYXR0ZW1wdCIsImVhY2giLCJjbG9uZUF0dGVtcHRXaXRoQ29ubmVjdGlvbiIsImUiLCJhbGxvd2VkIiwiZXJyb3IiLCJfc3VjY2Vzc2Z1bExvZ2luIiwiX2ZhaWxlZExvZ2luIiwiX3N1Y2Nlc3NmdWxMb2dvdXQiLCJfbG9naW5Vc2VyIiwibWV0aG9kSW52b2NhdGlvbiIsInN0YW1wZWRMb2dpblRva2VuIiwiX2dlbmVyYXRlU3RhbXBlZExvZ2luVG9rZW4iLCJfaW5zZXJ0TG9naW5Ub2tlbiIsIl9ub1lpZWxkc0FsbG93ZWQiLCJfc2V0TG9naW5Ub2tlbiIsIl9oYXNoTG9naW5Ub2tlbiIsInNldFVzZXJJZCIsImlkIiwidG9rZW5FeHBpcmVzIiwiX2F0dGVtcHRMb2dpbiIsIm1ldGhvZE5hbWUiLCJtZXRob2RBcmdzIiwicmVzdWx0IiwidHlwZSIsIm1ldGhvZEFyZ3VtZW50cyIsIkFycmF5IiwiZnJvbSIsIl9sb2dpbk1ldGhvZCIsImZuIiwidHJ5TG9naW5NZXRob2QiLCJfcmVwb3J0TG9naW5GYWlsdXJlIiwicmVnaXN0ZXJMb2dpbkhhbmRsZXIiLCJoYW5kbGVyIiwiX3J1bkxvZ2luSGFuZGxlcnMiLCJkZXN0cm95VG9rZW4iLCJsb2dpblRva2VuIiwidXBkYXRlIiwiJHB1bGwiLCIkb3IiLCJoYXNoZWRUb2tlbiIsImFjY291bnRzIiwibWV0aG9kcyIsImxvZ2luIiwiY2hlY2siLCJhcmd1bWVudHMiLCJsb2dvdXQiLCJfZ2V0TG9naW5Ub2tlbiIsImxvZ291dE90aGVyQ2xpZW50cyIsInRva2VucyIsInNlcnZpY2VzIiwicmVzdW1lIiwibG9naW5Ub2tlbnMiLCJuZXdUb2tlbiIsIiRzZXQiLCIkcHVzaCIsIl9oYXNoU3RhbXBlZFRva2VuIiwic2V0VGltZW91dCIsIl9kZWxldGVTYXZlZFRva2Vuc0ZvclVzZXIiLCJfbm9Db25uZWN0aW9uQ2xvc2VEZWxheUZvclRlc3QiLCJnZXROZXdUb2tlbiIsImN1cnJlbnRIYXNoZWRUb2tlbiIsImN1cnJlbnRTdGFtcGVkVG9rZW4iLCJmaW5kIiwic3RhbXBlZFRva2VuIiwibmV3U3RhbXBlZFRva2VuIiwicmVtb3ZlT3RoZXJUb2tlbnMiLCJjdXJyZW50VG9rZW4iLCIkbmUiLCJjb25maWd1cmVMb2dpblNlcnZpY2UiLCJNYXRjaCIsIk9iamVjdEluY2x1ZGluZyIsInNlcnZpY2UiLCJTdHJpbmciLCJvYXV0aCIsInNlcnZpY2VOYW1lcyIsInVzaW5nT0F1dGhFbmNyeXB0aW9uIiwic2VjcmV0Iiwic2VhbCIsImluc2VydCIsIm9uQ29ubmVjdGlvbiIsIm9uQ2xvc2UiLCJfcmVtb3ZlVG9rZW5Gcm9tQ29ubmVjdGlvbiIsInB1Ymxpc2giLCJpc19hdXRvIiwiX2lkIiwiYXV0b3B1Ymxpc2giLCJ0b0ZpZWxkU2VsZWN0b3IiLCJyZWR1Y2UiLCJwcmV2IiwiZmllbGQiLCJzZWxlY3RvciIsImFkZEF1dG9wdWJsaXNoRmllbGRzIiwib3B0cyIsImFwcGx5IiwiZm9yTG9nZ2VkSW5Vc2VyIiwiZm9yT3RoZXJVc2VycyIsInNldERlZmF1bHRQdWJsaXNoRmllbGRzIiwiX2dldEFjY291bnREYXRhIiwiY29ubmVjdGlvbklkIiwiZGF0YSIsIl9zZXRBY2NvdW50RGF0YSIsInZhbHVlIiwiaGFzaCIsImNyZWF0ZUhhc2giLCJkaWdlc3QiLCJoYXNoZWRTdGFtcGVkVG9rZW4iLCJfaW5zZXJ0SGFzaGVkTG9naW5Ub2tlbiIsInF1ZXJ5IiwiJGFkZFRvU2V0IiwiX2NsZWFyQWxsTG9naW5Ub2tlbnMiLCJfZ2V0VXNlck9ic2VydmUiLCJvYnNlcnZlIiwic3RvcCIsIm15T2JzZXJ2ZU51bWJlciIsImRlZmVyIiwiZm91bmRNYXRjaGluZ1VzZXIiLCJvYnNlcnZlQ2hhbmdlcyIsImFkZGVkIiwicmVtb3ZlZCIsImNsb3NlIiwibm9uTXV0YXRpbmdDYWxsYmFja3MiLCJSYW5kb20iLCJfZXhwaXJlUGFzc3dvcmRSZXNldFRva2VucyIsIm9sZGVzdFZhbGlkRGF0ZSIsInRva2VuTGlmZXRpbWVNcyIsInRva2VuRmlsdGVyIiwiJGV4aXN0cyIsImV4cGlyZVBhc3N3b3JkVG9rZW4iLCJfZXhwaXJlUGFzc3dvcmRFbnJvbGxUb2tlbnMiLCJfZXhwaXJlVG9rZW5zIiwidXNlckZpbHRlciIsIiRsdCIsIm11bHRpIiwic3VwZXJSZXN1bHQiLCJleHBpcmVUb2tlbkludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsImluc2VydFVzZXJEb2MiLCJjcmVhdGVkQXQiLCJwaW5FbmNyeXB0ZWRGaWVsZHNUb1VzZXIiLCJmdWxsVXNlciIsImRlZmF1bHRDcmVhdGVVc2VySG9vayIsImhvb2siLCJlcnJtc2ciLCJfdGVzdEVtYWlsRG9tYWluIiwiZW1haWwiLCJkb21haW4iLCJyZXN0cmljdENyZWF0aW9uQnlFbWFpbERvbWFpbiIsIlJlZ0V4cCIsIl9lc2NhcGVSZWdFeHAiLCJ0ZXN0IiwidG9rZW5zVG9EZWxldGUiLCIkdW5zZXQiLCIkcHVsbEFsbCIsImxvZ2luVG9rZW5zVG9EZWxldGUiLCJ1cGRhdGVPckNyZWF0ZVVzZXJGcm9tRXh0ZXJuYWxTZXJ2aWNlIiwic2VydmljZU5hbWUiLCJzZXJ2aWNlRGF0YSIsInNlcnZpY2VJZEtleSIsImlzTmFOIiwicGFyc2VJbnQiLCJzZXRBdHRycyIsInJlbW92ZURlZmF1bHRSYXRlTGltaXQiLCJyZXNwIiwiRERQUmF0ZUxpbWl0ZXIiLCJyZW1vdmVSdWxlIiwiZGVmYXVsdFJhdGVMaW1pdGVyUnVsZUlkIiwiYWRkUnVsZSIsImNsaWVudEFkZHJlc3MiLCJjbG9uZWRBdHRlbXB0IiwiRUpTT04iLCJjbG9uZSIsImRlZmF1bHRSZXN1bWVMb2dpbkhhbmRsZXIiLCJvbGRVbmhhc2hlZFN0eWxlVG9rZW4iLCJyZXNldFJhbmdlT3IiLCJleHBpcmVGaWx0ZXIiLCIkYW5kIiwic2V0SW50ZXJ2YWwiLCJrZXlJc0xvYWRlZCIsImlzU2VhbGVkIiwib3BlbiIsImVtYWlsSXNHb29kIiwiYWRkcmVzcyIsInZhbHVlcyIsImFsbG93IiwibW9kaWZpZXIiLCJmZXRjaCIsIl9lbnN1cmVJbmRleCIsInVuaXF1ZSIsInNwYXJzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsU0FBTyxDQUFDQyxNQUFSLENBQWU7QUFBQ0Msa0JBQWMsRUFBQyxNQUFJQTtBQUFwQixHQUFmO0FBQW9ELE1BQUlBLGNBQUo7QUFBbUJGLFNBQU8sQ0FBQ0csSUFBUixDQUFhLHNCQUFiLEVBQW9DO0FBQUNELGtCQUFjLENBQUNFLENBQUQsRUFBRztBQUFDRixvQkFBYyxHQUFDRSxDQUFmO0FBQWlCOztBQUFwQyxHQUFwQyxFQUEwRSxDQUExRTs7QUFFdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQUMsVUFBUSxHQUFHLElBQUlILGNBQUosQ0FBbUJJLE1BQU0sQ0FBQ0MsTUFBMUIsQ0FBWCxDLENBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQUQsUUFBTSxDQUFDRSxLQUFQLEdBQWVILFFBQVEsQ0FBQ0csS0FBeEI7Ozs7Ozs7Ozs7OztBQ2xCQSxJQUFJQyxhQUFKOztBQUFrQkMsTUFBTSxDQUFDUCxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQ1EsU0FBTyxDQUFDUCxDQUFELEVBQUc7QUFBQ0ssaUJBQWEsR0FBQ0wsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEJNLE1BQU0sQ0FBQ1QsTUFBUCxDQUFjO0FBQUNXLGdCQUFjLEVBQUMsTUFBSUEsY0FBcEI7QUFBbUNDLDJCQUF5QixFQUFDLE1BQUlBLHlCQUFqRTtBQUEyRkMsMkJBQXlCLEVBQUMsTUFBSUE7QUFBekgsQ0FBZDs7QUFTTyxNQUFNRixjQUFOLENBQXFCO0FBQzFCRyxhQUFXLENBQUNDLE9BQUQsRUFBVTtBQUNuQjtBQUNBO0FBQ0EsU0FBS0MsUUFBTCxHQUFnQixFQUFoQixDQUhtQixDQUtuQjtBQUNBOztBQUNBLFNBQUtDLFVBQUwsR0FBa0JDLFNBQWxCOztBQUNBLFNBQUtDLGVBQUwsQ0FBcUJKLE9BQU8sSUFBSSxFQUFoQyxFQVJtQixDQVVuQjtBQUNBOzs7QUFDQSxTQUFLUixLQUFMLEdBQWEsSUFBSWEsS0FBSyxDQUFDQyxVQUFWLENBQXFCLE9BQXJCLEVBQThCO0FBQ3pDQyx5QkFBbUIsRUFBRSxJQURvQjtBQUV6Q0wsZ0JBQVUsRUFBRSxLQUFLQTtBQUZ3QixLQUE5QixDQUFiLENBWm1CLENBaUJuQjs7QUFDQSxTQUFLTSxZQUFMLEdBQW9CLElBQUlDLElBQUosQ0FBUztBQUMzQkMscUJBQWUsRUFBRSxLQURVO0FBRTNCQywwQkFBb0IsRUFBRTtBQUZLLEtBQVQsQ0FBcEI7QUFLQSxTQUFLQyxtQkFBTCxHQUEyQixJQUFJSCxJQUFKLENBQVM7QUFDbENDLHFCQUFlLEVBQUUsS0FEaUI7QUFFbENDLDBCQUFvQixFQUFFO0FBRlksS0FBVCxDQUEzQjtBQUtBLFNBQUtFLGFBQUwsR0FBcUIsSUFBSUosSUFBSixDQUFTO0FBQzVCQyxxQkFBZSxFQUFFLEtBRFc7QUFFNUJDLDBCQUFvQixFQUFFO0FBRk0sS0FBVCxDQUFyQixDQTVCbUIsQ0FpQ25COztBQUNBLFNBQUtHLDZCQUFMLEdBQXFDQSw2QkFBckM7QUFDQSxTQUFLQywyQkFBTCxHQUFtQ0EsMkJBQW5DLENBbkNtQixDQXFDbkI7QUFDQTs7QUFDQSxVQUFNQyxPQUFPLEdBQUcsOEJBQWhCO0FBQ0EsU0FBS0MsbUJBQUwsR0FBMkIzQixNQUFNLENBQUM0QixhQUFQLENBQ3pCRixPQUR5QixFQUV6QixVQUFVRyxXQUFWLEVBQXVCO0FBQ3JCLFdBQUtDLE9BQUwsR0FBZUQsV0FBZjtBQUNELEtBSndCLENBQTNCO0FBTUEsU0FBS0YsbUJBQUwsQ0FBeUJJLFNBQXpCLENBQW1DQyxJQUFuQyxHQUEwQ04sT0FBMUMsQ0E5Q21CLENBZ0RuQjtBQUNBO0FBQ0E7O0FBQ0EsU0FBS0MsbUJBQUwsQ0FBeUJNLFlBQXpCLEdBQXdDLFNBQXhDLENBbkRtQixDQXFEbkI7O0FBQ0FqQyxVQUFNLENBQUNrQyxPQUFQLENBQWUsTUFBTTtBQUNuQixZQUFNO0FBQUVDO0FBQUYsVUFBMkJDLE9BQU8sQ0FBQyx1QkFBRCxDQUF4QztBQUNBLFdBQUtDLHlCQUFMLEdBQWlDRixvQkFBb0IsQ0FBQ0csY0FBdEQ7QUFDQSxXQUFLQyxXQUFMLEdBQW1CSixvQkFBb0IsQ0FBQ0ksV0FBeEM7QUFDRCxLQUpEO0FBS0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VDLFFBQU0sR0FBRztBQUNQLFVBQU0sSUFBSUMsS0FBSixDQUFVLCtCQUFWLENBQU47QUFDRCxHQXBFeUIsQ0FzRTFCOzs7QUFDQUMsMEJBQXdCLEdBQWU7QUFBQSxRQUFkaEMsT0FBYyx1RUFBSixFQUFJO0FBQ3JDO0FBQ0EsUUFBSSxDQUFDLEtBQUtDLFFBQUwsQ0FBY2dDLG9CQUFuQixFQUF5QyxPQUFPakMsT0FBUCxDQUZKLENBSXJDOztBQUNBLFFBQUksQ0FBQ0EsT0FBTyxDQUFDa0MsTUFBYixFQUFxQix1Q0FDaEJsQyxPQURnQjtBQUVuQmtDLFlBQU0sRUFBRSxLQUFLakMsUUFBTCxDQUFjZ0M7QUFGSCxPQUxnQixDQVVyQzs7QUFDQSxVQUFNRSxJQUFJLEdBQUdDLE1BQU0sQ0FBQ0QsSUFBUCxDQUFZbkMsT0FBTyxDQUFDa0MsTUFBcEIsQ0FBYjtBQUNBLFFBQUksQ0FBQ0MsSUFBSSxDQUFDRSxNQUFWLEVBQWtCLE9BQU9yQyxPQUFQLENBWm1CLENBY3JDO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDLENBQUNBLE9BQU8sQ0FBQ2tDLE1BQVIsQ0FBZUMsSUFBSSxDQUFDLENBQUQsQ0FBbkIsQ0FBTixFQUErQixPQUFPbkMsT0FBUCxDQWhCTSxDQWtCckM7QUFDQTs7QUFDQSxVQUFNc0MsS0FBSyxHQUFHRixNQUFNLENBQUNELElBQVAsQ0FBWSxLQUFLbEMsUUFBTCxDQUFjZ0Msb0JBQTFCLENBQWQ7QUFDQSxXQUFPLEtBQUtoQyxRQUFMLENBQWNnQyxvQkFBZCxDQUFtQ0ssS0FBSyxDQUFDLENBQUQsQ0FBeEMsSUFBK0N0QyxPQUEvQyxtQ0FDRkEsT0FERTtBQUVMa0MsWUFBTSxrQ0FDRGxDLE9BQU8sQ0FBQ2tDLE1BRFAsR0FFRCxLQUFLakMsUUFBTCxDQUFjZ0Msb0JBRmI7QUFGRCxNQUFQO0FBT0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFTSxNQUFJLENBQUN2QyxPQUFELEVBQVU7QUFDWixVQUFNOEIsTUFBTSxHQUFHLEtBQUtBLE1BQUwsRUFBZjtBQUNBLFdBQU9BLE1BQU0sR0FBRyxLQUFLdEMsS0FBTCxDQUFXZ0QsT0FBWCxDQUFtQlYsTUFBbkIsRUFBMkIsS0FBS0Usd0JBQUwsQ0FBOEJoQyxPQUE5QixDQUEzQixDQUFILEdBQXdFLElBQXJGO0FBQ0QsR0E5R3lCLENBZ0gxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V5QyxRQUFNLENBQUN6QyxPQUFELEVBQVU7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBSVYsTUFBTSxDQUFDb0QsUUFBWCxFQUFxQjtBQUNuQkMsK0JBQXlCLENBQUNDLG9CQUExQixHQUFpRCxJQUFqRDtBQUNELEtBRkQsTUFFTyxJQUFJLENBQUNELHlCQUF5QixDQUFDQyxvQkFBL0IsRUFBcUQ7QUFDMUQ7QUFDQTtBQUNBdEQsWUFBTSxDQUFDdUQsTUFBUCxDQUFjLDZEQUNBLHlEQURkO0FBRUQsS0FiYSxDQWVkO0FBQ0E7QUFDQTs7O0FBQ0EsUUFBSVQsTUFBTSxDQUFDZixTQUFQLENBQWlCeUIsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDL0MsT0FBckMsRUFBOEMsZ0JBQTlDLENBQUosRUFBcUU7QUFDbkUsVUFBSVYsTUFBTSxDQUFDMEQsUUFBWCxFQUFxQjtBQUNuQixjQUFNLElBQUlqQixLQUFKLENBQVUsK0RBQVYsQ0FBTjtBQUNEOztBQUNELFVBQUksQ0FBRUwsT0FBTyxDQUFDLGtCQUFELENBQWIsRUFBbUM7QUFDakMsY0FBTSxJQUFJSyxLQUFKLENBQVUsbUVBQVYsQ0FBTjtBQUNEOztBQUNETCxhQUFPLENBQUMsa0JBQUQsQ0FBUCxDQUE0QnVCLGVBQTVCLENBQTRDQyxPQUE1QyxDQUFvRGxELE9BQU8sQ0FBQ21ELGNBQTVEO0FBQ0FuRCxhQUFPLHFCQUFRQSxPQUFSLENBQVA7QUFDQSxhQUFPQSxPQUFPLENBQUNtRCxjQUFmO0FBQ0QsS0E1QmEsQ0E4QmQ7OztBQUNBLFVBQU1DLFVBQVUsR0FBRyxDQUFDLHVCQUFELEVBQTBCLDZCQUExQixFQUF5RCxxQ0FBekQsRUFDRCwrQkFEQyxFQUNnQyx1QkFEaEMsRUFDeUQsb0NBRHpELEVBRUQsd0JBRkMsRUFFeUIsY0FGekIsRUFFeUMsc0JBRnpDLENBQW5CO0FBSUFoQixVQUFNLENBQUNELElBQVAsQ0FBWW5DLE9BQVosRUFBcUJxRCxPQUFyQixDQUE2QkMsR0FBRyxJQUFJO0FBQ2xDLFVBQUksQ0FBQ0YsVUFBVSxDQUFDRyxRQUFYLENBQW9CRCxHQUFwQixDQUFMLEVBQStCO0FBQzdCLGNBQU0sSUFBSXZCLEtBQUoseUNBQTJDdUIsR0FBM0MsRUFBTjtBQUNEO0FBQ0YsS0FKRCxFQW5DYyxDQXlDZDs7QUFDQUYsY0FBVSxDQUFDQyxPQUFYLENBQW1CQyxHQUFHLElBQUk7QUFDeEIsVUFBSUEsR0FBRyxJQUFJdEQsT0FBWCxFQUFvQjtBQUNsQixZQUFJc0QsR0FBRyxJQUFJLEtBQUtyRCxRQUFoQixFQUEwQjtBQUN4QixnQkFBTSxJQUFJOEIsS0FBSixzQkFBeUJ1QixHQUF6QixzQkFBTjtBQUNEOztBQUNELGFBQUtyRCxRQUFMLENBQWNxRCxHQUFkLElBQXFCdEQsT0FBTyxDQUFDc0QsR0FBRCxDQUE1QjtBQUNEO0FBQ0YsS0FQRDtBQVFEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VFLFNBQU8sQ0FBQ0MsSUFBRCxFQUFPO0FBQ1osUUFBSUMsR0FBRyxHQUFHLEtBQUtsRCxZQUFMLENBQWtCbUQsUUFBbEIsQ0FBMkJGLElBQTNCLENBQVYsQ0FEWSxDQUVaOzs7QUFDQSxTQUFLRyxnQkFBTCxDQUFzQkYsR0FBRyxDQUFDRyxRQUExQjs7QUFDQSxXQUFPSCxHQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUksZ0JBQWMsQ0FBQ0wsSUFBRCxFQUFPO0FBQ25CLFdBQU8sS0FBSzdDLG1CQUFMLENBQXlCK0MsUUFBekIsQ0FBa0NGLElBQWxDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7OztBQUNFTSxVQUFRLENBQUNOLElBQUQsRUFBTztBQUNiLFdBQU8sS0FBSzVDLGFBQUwsQ0FBbUI4QyxRQUFuQixDQUE0QkYsSUFBNUIsQ0FBUDtBQUNEOztBQUVEckQsaUJBQWUsQ0FBQ0osT0FBRCxFQUFVO0FBQ3ZCLFFBQUksQ0FBRVYsTUFBTSxDQUFDMEQsUUFBYixFQUF1QjtBQUNyQjtBQUNELEtBSHNCLENBS3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxRQUFJaEQsT0FBTyxDQUFDRSxVQUFaLEVBQXdCO0FBQ3RCLFdBQUtBLFVBQUwsR0FBa0JGLE9BQU8sQ0FBQ0UsVUFBMUI7QUFDRCxLQUZELE1BRU8sSUFBSUYsT0FBTyxDQUFDZ0UsTUFBWixFQUFvQjtBQUN6QixXQUFLOUQsVUFBTCxHQUFrQitELEdBQUcsQ0FBQ0MsT0FBSixDQUFZbEUsT0FBTyxDQUFDZ0UsTUFBcEIsQ0FBbEI7QUFDRCxLQUZNLE1BRUEsSUFBSSxPQUFPckIseUJBQVAsS0FBcUMsV0FBckMsSUFDQUEseUJBQXlCLENBQUN3Qix1QkFEOUIsRUFDdUQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFLakUsVUFBTCxHQUNFK0QsR0FBRyxDQUFDQyxPQUFKLENBQVl2Qix5QkFBeUIsQ0FBQ3dCLHVCQUF0QyxDQURGO0FBRUQsS0FYTSxNQVdBO0FBQ0wsV0FBS2pFLFVBQUwsR0FBa0JaLE1BQU0sQ0FBQ1ksVUFBekI7QUFDRDtBQUNGOztBQUVEa0UscUJBQW1CLEdBQUc7QUFDcEI7QUFDQTtBQUNBO0FBQ0EsVUFBTUMscUJBQXFCLEdBQ3hCLEtBQUtwRSxRQUFMLENBQWNvRSxxQkFBZCxLQUF3QyxJQUF6QyxHQUNJdEQsMkJBREosR0FFSSxLQUFLZCxRQUFMLENBQWNvRSxxQkFIcEI7QUFJQSxXQUFPLENBQUNBLHFCQUFxQixJQUN0QnZELDZCQURBLElBQ2lDLEVBRGpDLEdBQ3NDLEVBRHRDLEdBQzJDLEVBRDNDLEdBQ2dELElBRHZEO0FBRUQ7O0FBRUR3RCxrQ0FBZ0MsR0FBRztBQUNqQyxXQUFPLENBQUMsS0FBS3JFLFFBQUwsQ0FBY3NFLGtDQUFkLElBQ0FDLDRDQURELElBQ2lELEVBRGpELEdBQ3NELEVBRHRELEdBQzJELEVBRDNELEdBQ2dFLElBRHZFO0FBRUQ7O0FBRURDLG1DQUFpQyxHQUFHO0FBQ2xDLFdBQU8sQ0FBQyxLQUFLeEUsUUFBTCxDQUFjeUUsbUNBQWQsSUFDSkMsNkNBREcsSUFDOEMsRUFEOUMsR0FDbUQsRUFEbkQsR0FDd0QsRUFEeEQsR0FDNkQsSUFEcEU7QUFFRDs7QUFFREMsa0JBQWdCLENBQUNDLElBQUQsRUFBTztBQUNyQjtBQUNBO0FBQ0EsV0FBTyxJQUFJQyxJQUFKLENBQVUsSUFBSUEsSUFBSixDQUFTRCxJQUFULENBQUQsQ0FBaUJFLE9BQWpCLEtBQTZCLEtBQUtYLG1CQUFMLEVBQXRDLENBQVA7QUFDRDs7QUFFRFksbUJBQWlCLENBQUNILElBQUQsRUFBTztBQUN0QixRQUFJSSxhQUFhLEdBQUcsS0FBSyxLQUFLYixtQkFBTCxFQUF6Qjs7QUFDQSxVQUFNYyxnQkFBZ0IsR0FBR0MsMkJBQTJCLEdBQUcsSUFBdkQ7O0FBQ0EsUUFBSUYsYUFBYSxHQUFHQyxnQkFBcEIsRUFBc0M7QUFDcENELG1CQUFhLEdBQUdDLGdCQUFoQjtBQUNEOztBQUNELFdBQU8sSUFBSUosSUFBSixLQUFjLElBQUlBLElBQUosQ0FBU0QsSUFBVCxJQUFpQkksYUFBdEM7QUFDRCxHQTNUeUIsQ0E2VDFCOzs7QUFDQXJCLGtCQUFnQixDQUFDQyxRQUFELEVBQVcsQ0FBRTs7QUE5VEg7O0FBaVU1QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQXZFLE1BQU0sQ0FBQ3dDLE1BQVAsR0FBZ0IsTUFBTXpDLFFBQVEsQ0FBQ3lDLE1BQVQsRUFBdEI7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0F4QyxNQUFNLENBQUNpRCxJQUFQLEdBQWV2QyxPQUFELElBQWFYLFFBQVEsQ0FBQ2tELElBQVQsQ0FBY3ZDLE9BQWQsQ0FBM0IsQyxDQUVBOzs7QUFDQSxNQUFNYyw2QkFBNkIsR0FBRyxFQUF0QyxDLENBQ0E7O0FBQ0EsTUFBTTBELDRDQUE0QyxHQUFHLENBQXJELEMsQ0FDQTs7QUFDQSxNQUFNRyw2Q0FBNkMsR0FBRyxFQUF0RCxDLENBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQU1RLDJCQUEyQixHQUFHLElBQXBDLEMsQ0FBMEM7QUFDMUM7O0FBQ08sTUFBTXRGLHlCQUF5QixHQUFHLE1BQU0sSUFBeEM7QUFHQSxNQUFNQyx5QkFBeUIsR0FBRyxLQUFLLElBQXZDO0FBQ1A7QUFDQTtBQUNBLE1BQU1pQiwyQkFBMkIsR0FBRyxNQUFNLEdBQTFDLEM7Ozs7Ozs7Ozs7O0FDOVdBLElBQUlxRSx3QkFBSjs7QUFBNkIxRixNQUFNLENBQUNQLElBQVAsQ0FBWSxnREFBWixFQUE2RDtBQUFDUSxTQUFPLENBQUNQLENBQUQsRUFBRztBQUFDZ0csNEJBQXdCLEdBQUNoRyxDQUF6QjtBQUEyQjs7QUFBdkMsQ0FBN0QsRUFBc0csQ0FBdEc7O0FBQXlHLElBQUlLLGFBQUo7O0FBQWtCQyxNQUFNLENBQUNQLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDUSxTQUFPLENBQUNQLENBQUQsRUFBRztBQUFDSyxpQkFBYSxHQUFDTCxDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUF4Sk0sTUFBTSxDQUFDVCxNQUFQLENBQWM7QUFBQ0MsZ0JBQWMsRUFBQyxNQUFJQTtBQUFwQixDQUFkO0FBQW1ELElBQUltRyxNQUFKO0FBQVczRixNQUFNLENBQUNQLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNRLFNBQU8sQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNpRyxVQUFNLEdBQUNqRyxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlRLGNBQUosRUFBbUJDLHlCQUFuQixFQUE2Q0MseUJBQTdDO0FBQXVFSixNQUFNLENBQUNQLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDUyxnQkFBYyxDQUFDUixDQUFELEVBQUc7QUFBQ1Esa0JBQWMsR0FBQ1IsQ0FBZjtBQUFpQixHQUFwQzs7QUFBcUNTLDJCQUF5QixDQUFDVCxDQUFELEVBQUc7QUFBQ1MsNkJBQXlCLEdBQUNULENBQTFCO0FBQTRCLEdBQTlGOztBQUErRlUsMkJBQXlCLENBQUNWLENBQUQsRUFBRztBQUFDVSw2QkFBeUIsR0FBQ1YsQ0FBMUI7QUFBNEI7O0FBQXhKLENBQW5DLEVBQTZMLENBQTdMO0FBT3BMLE1BQU1rRyxNQUFNLEdBQUdsRCxNQUFNLENBQUNmLFNBQVAsQ0FBaUJ5QixjQUFoQztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ08sTUFBTTVELGNBQU4sU0FBNkJVLGNBQTdCLENBQTRDO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBRyxhQUFXLENBQUNSLE1BQUQsRUFBUztBQUNsQjtBQUVBLFNBQUtnRyxPQUFMLEdBQWVoRyxNQUFNLElBQUlELE1BQU0sQ0FBQ0MsTUFBaEMsQ0FIa0IsQ0FJbEI7O0FBQ0EsU0FBS2lHLGtCQUFMOztBQUVBLFNBQUtDLHFCQUFMLEdBUGtCLENBU2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFNBQUtDLGtCQUFMLEdBQTBCO0FBQ3hCQyxrQkFBWSxFQUFFLENBQUMsU0FBRCxFQUFZLFVBQVosRUFBd0IsUUFBeEIsQ0FEVTtBQUV4QkMsZ0JBQVUsRUFBRSxDQUFDLFNBQUQsRUFBWSxVQUFaO0FBRlksS0FBMUIsQ0Fka0IsQ0FtQmxCO0FBQ0E7QUFDQTs7QUFDQSxTQUFLQyxxQkFBTCxHQUE2QjtBQUMzQkMsZ0JBQVUsRUFBRTtBQUNWQyxlQUFPLEVBQUUsQ0FEQztBQUVWQyxnQkFBUSxFQUFFLENBRkE7QUFHVkMsY0FBTSxFQUFFO0FBSEU7QUFEZSxLQUE3Qjs7QUFRQSxTQUFLQyx1QkFBTCxHQTlCa0IsQ0FnQ2xCOzs7QUFDQSxTQUFLQyxZQUFMLEdBQW9CLEVBQXBCLENBakNrQixDQW1DbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxTQUFLQywyQkFBTCxHQUFtQyxFQUFuQztBQUNBLFNBQUtDLHNCQUFMLEdBQThCLENBQTlCLENBekNrQixDQXlDZ0I7QUFFbEM7O0FBQ0EsU0FBS0MsY0FBTCxHQUFzQixFQUF0QjtBQUVBQyx3QkFBb0IsQ0FBQyxLQUFLL0csS0FBTixDQUFwQjtBQUNBZ0gsNkJBQXlCLENBQUMsSUFBRCxDQUF6QjtBQUNBQywyQkFBdUIsQ0FBQyxJQUFELENBQXZCO0FBRUEsU0FBS0Msa0JBQUwsR0FBMEIsSUFBSWpHLElBQUosQ0FBUztBQUFFQyxxQkFBZSxFQUFFO0FBQW5CLEtBQVQsQ0FBMUI7QUFDQSxTQUFLaUcscUJBQUwsR0FBNkIsQ0FDM0JDLDBCQUEwQixDQUFDQyxJQUEzQixDQUFnQyxJQUFoQyxDQUQyQixDQUE3Qjs7QUFJQSxTQUFLQyxzQ0FBTDs7QUFFQSxTQUFLQyxpQ0FBTCxHQUF5QyxFQUF6QyxDQXpEa0IsQ0EyRGxCOztBQUNBLFNBQUtDLElBQUwsR0FBWTtBQUNWQyxtQkFBYSxFQUFFQyxLQUFLLElBQUk1SCxNQUFNLENBQUM2SCxXQUFQLDRCQUF1Q0QsS0FBdkMsRUFEZDtBQUVWRSxpQkFBVyxFQUFFRixLQUFLLElBQUk1SCxNQUFNLENBQUM2SCxXQUFQLDBCQUFxQ0QsS0FBckMsRUFGWjtBQUdWRyxtQkFBYSxFQUFFSCxLQUFLLElBQUk1SCxNQUFNLENBQUM2SCxXQUFQLDRCQUF1Q0QsS0FBdkM7QUFIZCxLQUFaO0FBTUEsU0FBS0ksbUJBQUw7QUFDRCxHQXZFZ0QsQ0F5RWpEO0FBQ0E7QUFDQTtBQUVBOzs7QUFDQXhGLFFBQU0sR0FBRztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQU15RixpQkFBaUIsR0FBR3RELEdBQUcsQ0FBQ3VELHdCQUFKLENBQTZCQyxHQUE3QixNQUFzQ3hELEdBQUcsQ0FBQ3lELDZCQUFKLENBQWtDRCxHQUFsQyxFQUFoRTs7QUFDQSxRQUFJLENBQUNGLGlCQUFMLEVBQ0UsTUFBTSxJQUFJeEYsS0FBSixDQUFVLG9FQUFWLENBQU47QUFDRixXQUFPd0YsaUJBQWlCLENBQUN6RixNQUF6QjtBQUNELEdBekZnRCxDQTJGakQ7QUFDQTtBQUNBOztBQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7OztBQUNFNkYsc0JBQW9CLENBQUNsRSxJQUFELEVBQU87QUFDekI7QUFDQSxXQUFPLEtBQUtpRCxrQkFBTCxDQUF3Qi9DLFFBQXhCLENBQWlDRixJQUFqQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRW1FLGlCQUFlLENBQUNuRSxJQUFELEVBQU87QUFDcEIsU0FBS2tELHFCQUFMLENBQTJCa0IsSUFBM0IsQ0FBZ0NwRSxJQUFoQztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VxRSxxQkFBbUIsQ0FBQ3JFLElBQUQsRUFBTztBQUN4QixRQUFJLEtBQUtzRSx3QkFBVCxFQUFtQztBQUNqQyxZQUFNLElBQUloRyxLQUFKLENBQVUsd0NBQVYsQ0FBTjtBQUNEOztBQUVELFNBQUtnRyx3QkFBTCxHQUFnQ3RFLElBQWhDO0FBQ0QsR0E3SGdELENBK0hqRDtBQUNBO0FBQ0E7O0FBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V1RSxjQUFZLENBQUN2RSxJQUFELEVBQU87QUFDakIsUUFBSSxLQUFLd0UsaUJBQVQsRUFBNEI7QUFDMUIsWUFBTSxJQUFJbEcsS0FBSixDQUFVLGlDQUFWLENBQU47QUFDRDs7QUFFRCxTQUFLa0csaUJBQUwsR0FBeUJ4RSxJQUF6QjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V5RSxpQkFBZSxDQUFDekUsSUFBRCxFQUFPO0FBQ3BCLFFBQUksS0FBSzBFLG9CQUFULEVBQStCO0FBQzdCLFlBQU0sSUFBSXBHLEtBQUosQ0FBVSxvQ0FBVixDQUFOO0FBQ0Q7O0FBRUQsU0FBS29HLG9CQUFMLEdBQTRCMUUsSUFBNUI7QUFDRDs7QUFFRDJFLGdCQUFjLENBQUNsSSxVQUFELEVBQWFtSSxPQUFiLEVBQXNCO0FBQ2xDLFNBQUszQixrQkFBTCxDQUF3QjRCLElBQXhCLENBQTZCekUsUUFBUSxJQUFJO0FBQ3ZDLFVBQUlILEdBQUo7O0FBQ0EsVUFBSTtBQUNGQSxXQUFHLEdBQUdHLFFBQVEsQ0FBQzBFLDBCQUEwQixDQUFDckksVUFBRCxFQUFhbUksT0FBYixDQUEzQixDQUFkO0FBQ0QsT0FGRCxDQUdBLE9BQU9HLENBQVAsRUFBVTtBQUNSSCxlQUFPLENBQUNJLE9BQVIsR0FBa0IsS0FBbEIsQ0FEUSxDQUVSO0FBQ0E7QUFDQTtBQUNBOztBQUNBSixlQUFPLENBQUNLLEtBQVIsR0FBZ0JGLENBQWhCO0FBQ0EsZUFBTyxJQUFQO0FBQ0Q7O0FBQ0QsVUFBSSxDQUFFOUUsR0FBTixFQUFXO0FBQ1QyRSxlQUFPLENBQUNJLE9BQVIsR0FBa0IsS0FBbEIsQ0FEUyxDQUVUO0FBQ0E7O0FBQ0EsWUFBSSxDQUFDSixPQUFPLENBQUNLLEtBQWIsRUFDRUwsT0FBTyxDQUFDSyxLQUFSLEdBQWdCLElBQUlwSixNQUFNLENBQUN5QyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGlCQUF0QixDQUFoQjtBQUNIOztBQUNELGFBQU8sSUFBUDtBQUNELEtBdEJEO0FBdUJEOztBQUVENEcsa0JBQWdCLENBQUN6SSxVQUFELEVBQWFtSSxPQUFiLEVBQXNCO0FBQ3BDLFNBQUs3SCxZQUFMLENBQWtCOEgsSUFBbEIsQ0FBdUJ6RSxRQUFRLElBQUk7QUFDakNBLGNBQVEsQ0FBQzBFLDBCQUEwQixDQUFDckksVUFBRCxFQUFhbUksT0FBYixDQUEzQixDQUFSO0FBQ0EsYUFBTyxJQUFQO0FBQ0QsS0FIRDtBQUlEOztBQUVETyxjQUFZLENBQUMxSSxVQUFELEVBQWFtSSxPQUFiLEVBQXNCO0FBQ2hDLFNBQUt6SCxtQkFBTCxDQUF5QjBILElBQXpCLENBQThCekUsUUFBUSxJQUFJO0FBQ3hDQSxjQUFRLENBQUMwRSwwQkFBMEIsQ0FBQ3JJLFVBQUQsRUFBYW1JLE9BQWIsQ0FBM0IsQ0FBUjtBQUNBLGFBQU8sSUFBUDtBQUNELEtBSEQ7QUFJRDs7QUFFRFEsbUJBQWlCLENBQUMzSSxVQUFELEVBQWE0QixNQUFiLEVBQXFCO0FBQ3BDO0FBQ0EsUUFBSVMsSUFBSjs7QUFDQSxTQUFLMUIsYUFBTCxDQUFtQnlILElBQW5CLENBQXdCekUsUUFBUSxJQUFJO0FBQ2xDLFVBQUksQ0FBQ3RCLElBQUQsSUFBU1QsTUFBYixFQUFxQlMsSUFBSSxHQUFHLEtBQUsvQyxLQUFMLENBQVdnRCxPQUFYLENBQW1CVixNQUFuQixFQUEyQjtBQUFDSSxjQUFNLEVBQUUsS0FBS2pDLFFBQUwsQ0FBY2dDO0FBQXZCLE9BQTNCLENBQVA7QUFDckI0QixjQUFRLENBQUM7QUFBRXRCLFlBQUY7QUFBUXJDO0FBQVIsT0FBRCxDQUFSO0FBQ0EsYUFBTyxJQUFQO0FBQ0QsS0FKRDtBQUtEOztBQUVEO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E0SSxZQUFVLENBQUNDLGdCQUFELEVBQW1CakgsTUFBbkIsRUFBMkJrSCxpQkFBM0IsRUFBOEM7QUFDdEQsUUFBSSxDQUFFQSxpQkFBTixFQUF5QjtBQUN2QkEsdUJBQWlCLEdBQUcsS0FBS0MsMEJBQUwsRUFBcEI7O0FBQ0EsV0FBS0MsaUJBQUwsQ0FBdUJwSCxNQUF2QixFQUErQmtILGlCQUEvQjtBQUNELEtBSnFELENBTXREO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ExSixVQUFNLENBQUM2SixnQkFBUCxDQUF3QixNQUN0QixLQUFLQyxjQUFMLENBQ0V0SCxNQURGLEVBRUVpSCxnQkFBZ0IsQ0FBQzdJLFVBRm5CLEVBR0UsS0FBS21KLGVBQUwsQ0FBcUJMLGlCQUFpQixDQUFDOUIsS0FBdkMsQ0FIRixDQURGOztBQVFBNkIsb0JBQWdCLENBQUNPLFNBQWpCLENBQTJCeEgsTUFBM0I7QUFFQSxXQUFPO0FBQ0x5SCxRQUFFLEVBQUV6SCxNQURDO0FBRUxvRixXQUFLLEVBQUU4QixpQkFBaUIsQ0FBQzlCLEtBRnBCO0FBR0xzQyxrQkFBWSxFQUFFLEtBQUs1RSxnQkFBTCxDQUFzQm9FLGlCQUFpQixDQUFDbkUsSUFBeEM7QUFIVCxLQUFQO0FBS0Q7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTRFLGVBQWEsQ0FDWFYsZ0JBRFcsRUFFWFcsVUFGVyxFQUdYQyxVQUhXLEVBSVhDLE1BSlcsRUFLWDtBQUNBLFFBQUksQ0FBQ0EsTUFBTCxFQUNFLE1BQU0sSUFBSTdILEtBQUosQ0FBVSxvQkFBVixDQUFOLENBRkYsQ0FJQTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDNkgsTUFBTSxDQUFDOUgsTUFBUixJQUFrQixDQUFDOEgsTUFBTSxDQUFDbEIsS0FBOUIsRUFDRSxNQUFNLElBQUkzRyxLQUFKLENBQVUsa0RBQVYsQ0FBTjtBQUVGLFFBQUlRLElBQUo7QUFDQSxRQUFJcUgsTUFBTSxDQUFDOUgsTUFBWCxFQUNFUyxJQUFJLEdBQUcsS0FBSy9DLEtBQUwsQ0FBV2dELE9BQVgsQ0FBbUJvSCxNQUFNLENBQUM5SCxNQUExQixFQUFrQztBQUFDSSxZQUFNLEVBQUUsS0FBS2pDLFFBQUwsQ0FBY2dDO0FBQXZCLEtBQWxDLENBQVA7QUFFRixVQUFNb0csT0FBTyxHQUFHO0FBQ2R3QixVQUFJLEVBQUVELE1BQU0sQ0FBQ0MsSUFBUCxJQUFlLFNBRFA7QUFFZHBCLGFBQU8sRUFBRSxDQUFDLEVBQUdtQixNQUFNLENBQUM5SCxNQUFQLElBQWlCLENBQUM4SCxNQUFNLENBQUNsQixLQUE1QixDQUZJO0FBR2RnQixnQkFBVSxFQUFFQSxVQUhFO0FBSWRJLHFCQUFlLEVBQUVDLEtBQUssQ0FBQ0MsSUFBTixDQUFXTCxVQUFYO0FBSkgsS0FBaEI7O0FBTUEsUUFBSUMsTUFBTSxDQUFDbEIsS0FBWCxFQUFrQjtBQUNoQkwsYUFBTyxDQUFDSyxLQUFSLEdBQWdCa0IsTUFBTSxDQUFDbEIsS0FBdkI7QUFDRDs7QUFDRCxRQUFJbkcsSUFBSixFQUFVO0FBQ1I4RixhQUFPLENBQUM5RixJQUFSLEdBQWVBLElBQWY7QUFDRCxLQXpCRCxDQTJCQTtBQUNBO0FBQ0E7OztBQUNBLFNBQUs2RixjQUFMLENBQW9CVyxnQkFBZ0IsQ0FBQzdJLFVBQXJDLEVBQWlEbUksT0FBakQ7O0FBRUEsUUFBSUEsT0FBTyxDQUFDSSxPQUFaLEVBQXFCO0FBQ25CLFlBQU0vRSxHQUFHLG1DQUNKLEtBQUtvRixVQUFMLENBQ0RDLGdCQURDLEVBRURhLE1BQU0sQ0FBQzlILE1BRk4sRUFHRDhILE1BQU0sQ0FBQ1osaUJBSE4sQ0FESSxHQU1KWSxNQUFNLENBQUM1SixPQU5ILENBQVQ7O0FBUUEwRCxTQUFHLENBQUNtRyxJQUFKLEdBQVd4QixPQUFPLENBQUN3QixJQUFuQjs7QUFDQSxXQUFLbEIsZ0JBQUwsQ0FBc0JJLGdCQUFnQixDQUFDN0ksVUFBdkMsRUFBbURtSSxPQUFuRDs7QUFDQSxhQUFPM0UsR0FBUDtBQUNELEtBWkQsTUFhSztBQUNILFdBQUtrRixZQUFMLENBQWtCRyxnQkFBZ0IsQ0FBQzdJLFVBQW5DLEVBQStDbUksT0FBL0M7O0FBQ0EsWUFBTUEsT0FBTyxDQUFDSyxLQUFkO0FBQ0Q7QUFDRjs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBdUIsY0FBWSxDQUNWbEIsZ0JBRFUsRUFFVlcsVUFGVSxFQUdWQyxVQUhVLEVBSVZFLElBSlUsRUFLVkssRUFMVSxFQU1WO0FBQ0EsV0FBTyxLQUFLVCxhQUFMLENBQ0xWLGdCQURLLEVBRUxXLFVBRkssRUFHTEMsVUFISyxFQUlMUSxjQUFjLENBQUNOLElBQUQsRUFBT0ssRUFBUCxDQUpULENBQVA7QUFNRDs7QUFHRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBRSxxQkFBbUIsQ0FDakJyQixnQkFEaUIsRUFFakJXLFVBRmlCLEVBR2pCQyxVQUhpQixFQUlqQkMsTUFKaUIsRUFLakI7QUFDQSxVQUFNdkIsT0FBTyxHQUFHO0FBQ2R3QixVQUFJLEVBQUVELE1BQU0sQ0FBQ0MsSUFBUCxJQUFlLFNBRFA7QUFFZHBCLGFBQU8sRUFBRSxLQUZLO0FBR2RDLFdBQUssRUFBRWtCLE1BQU0sQ0FBQ2xCLEtBSEE7QUFJZGdCLGdCQUFVLEVBQUVBLFVBSkU7QUFLZEkscUJBQWUsRUFBRUMsS0FBSyxDQUFDQyxJQUFOLENBQVdMLFVBQVg7QUFMSCxLQUFoQjs7QUFRQSxRQUFJQyxNQUFNLENBQUM5SCxNQUFYLEVBQW1CO0FBQ2pCdUcsYUFBTyxDQUFDOUYsSUFBUixHQUFlLEtBQUsvQyxLQUFMLENBQVdnRCxPQUFYLENBQW1Cb0gsTUFBTSxDQUFDOUgsTUFBMUIsRUFBa0M7QUFBQ0ksY0FBTSxFQUFFLEtBQUtqQyxRQUFMLENBQWNnQztBQUF2QixPQUFsQyxDQUFmO0FBQ0Q7O0FBRUQsU0FBS21HLGNBQUwsQ0FBb0JXLGdCQUFnQixDQUFDN0ksVUFBckMsRUFBaURtSSxPQUFqRDs7QUFDQSxTQUFLTyxZQUFMLENBQWtCRyxnQkFBZ0IsQ0FBQzdJLFVBQW5DLEVBQStDbUksT0FBL0MsRUFkQSxDQWdCQTtBQUNBOzs7QUFDQSxXQUFPQSxPQUFQO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFnQyxzQkFBb0IsQ0FBQy9JLElBQUQsRUFBT2dKLE9BQVAsRUFBZ0I7QUFDbEMsUUFBSSxDQUFFQSxPQUFOLEVBQWU7QUFDYkEsYUFBTyxHQUFHaEosSUFBVjtBQUNBQSxVQUFJLEdBQUcsSUFBUDtBQUNEOztBQUVELFNBQUtnRixjQUFMLENBQW9CdUIsSUFBcEIsQ0FBeUI7QUFDdkJ2RyxVQUFJLEVBQUVBLElBRGlCO0FBRXZCZ0osYUFBTyxFQUFFQTtBQUZjLEtBQXpCO0FBSUQ7O0FBR0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQUMsbUJBQWlCLENBQUN4QixnQkFBRCxFQUFtQi9JLE9BQW5CLEVBQTRCO0FBQzNDLFNBQUssSUFBSXNLLE9BQVQsSUFBb0IsS0FBS2hFLGNBQXpCLEVBQXlDO0FBQ3ZDLFlBQU1zRCxNQUFNLEdBQUdPLGNBQWMsQ0FDM0JHLE9BQU8sQ0FBQ2hKLElBRG1CLEVBRTNCLE1BQU1nSixPQUFPLENBQUNBLE9BQVIsQ0FBZ0J2SCxJQUFoQixDQUFxQmdHLGdCQUFyQixFQUF1Qy9JLE9BQXZDLENBRnFCLENBQTdCOztBQUtBLFVBQUk0SixNQUFKLEVBQVk7QUFDVixlQUFPQSxNQUFQO0FBQ0Q7O0FBRUQsVUFBSUEsTUFBTSxLQUFLekosU0FBZixFQUEwQjtBQUN4QixjQUFNLElBQUliLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IscURBQXRCLENBQU47QUFDRDtBQUNGOztBQUVELFdBQU87QUFDTDhILFVBQUksRUFBRSxJQUREO0FBRUxuQixXQUFLLEVBQUUsSUFBSXBKLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0Isd0NBQXRCO0FBRkYsS0FBUDtBQUlEOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQXlJLGNBQVksQ0FBQzFJLE1BQUQsRUFBUzJJLFVBQVQsRUFBcUI7QUFDL0IsU0FBS2pMLEtBQUwsQ0FBV2tMLE1BQVgsQ0FBa0I1SSxNQUFsQixFQUEwQjtBQUN4QjZJLFdBQUssRUFBRTtBQUNMLHVDQUErQjtBQUM3QkMsYUFBRyxFQUFFLENBQ0g7QUFBRUMsdUJBQVcsRUFBRUo7QUFBZixXQURHLEVBRUg7QUFBRXZELGlCQUFLLEVBQUV1RDtBQUFULFdBRkc7QUFEd0I7QUFEMUI7QUFEaUIsS0FBMUI7QUFVRDs7QUFFRGpGLG9CQUFrQixHQUFHO0FBQ25CO0FBQ0E7QUFDQSxVQUFNc0YsUUFBUSxHQUFHLElBQWpCLENBSG1CLENBTW5CO0FBQ0E7O0FBQ0EsVUFBTUMsT0FBTyxHQUFHLEVBQWhCLENBUm1CLENBVW5CO0FBQ0E7QUFDQTtBQUNBOztBQUNBQSxXQUFPLENBQUNDLEtBQVIsR0FBZ0IsVUFBVWhMLE9BQVYsRUFBbUI7QUFDakM7QUFDQTtBQUNBaUwsV0FBSyxDQUFDakwsT0FBRCxFQUFVb0MsTUFBVixDQUFMOztBQUVBLFlBQU13SCxNQUFNLEdBQUdrQixRQUFRLENBQUNQLGlCQUFULENBQTJCLElBQTNCLEVBQWlDdkssT0FBakMsQ0FBZjs7QUFFQSxhQUFPOEssUUFBUSxDQUFDckIsYUFBVCxDQUF1QixJQUF2QixFQUE2QixPQUE3QixFQUFzQ3lCLFNBQXRDLEVBQWlEdEIsTUFBakQsQ0FBUDtBQUNELEtBUkQ7O0FBVUFtQixXQUFPLENBQUNJLE1BQVIsR0FBaUIsWUFBWTtBQUMzQixZQUFNakUsS0FBSyxHQUFHNEQsUUFBUSxDQUFDTSxjQUFULENBQXdCLEtBQUtsTCxVQUFMLENBQWdCcUosRUFBeEMsQ0FBZDs7QUFDQXVCLGNBQVEsQ0FBQzFCLGNBQVQsQ0FBd0IsS0FBS3RILE1BQTdCLEVBQXFDLEtBQUs1QixVQUExQyxFQUFzRCxJQUF0RDs7QUFDQSxVQUFJZ0gsS0FBSyxJQUFJLEtBQUtwRixNQUFsQixFQUEwQjtBQUN4QmdKLGdCQUFRLENBQUNOLFlBQVQsQ0FBc0IsS0FBSzFJLE1BQTNCLEVBQW1Db0YsS0FBbkM7QUFDRDs7QUFDRDRELGNBQVEsQ0FBQ2pDLGlCQUFULENBQTJCLEtBQUszSSxVQUFoQyxFQUE0QyxLQUFLNEIsTUFBakQ7O0FBQ0EsV0FBS3dILFNBQUwsQ0FBZSxJQUFmO0FBQ0QsS0FSRCxDQXhCbUIsQ0FrQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBeUIsV0FBTyxDQUFDTSxrQkFBUixHQUE2QixZQUFZO0FBQ3ZDLFlBQU05SSxJQUFJLEdBQUd1SSxRQUFRLENBQUN0TCxLQUFULENBQWVnRCxPQUFmLENBQXVCLEtBQUtWLE1BQTVCLEVBQW9DO0FBQy9DSSxjQUFNLEVBQUU7QUFDTix5Q0FBK0I7QUFEekI7QUFEdUMsT0FBcEMsQ0FBYjs7QUFLQSxVQUFJSyxJQUFKLEVBQVU7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBTStJLE1BQU0sR0FBRy9JLElBQUksQ0FBQ2dKLFFBQUwsQ0FBY0MsTUFBZCxDQUFxQkMsV0FBcEM7O0FBQ0EsY0FBTUMsUUFBUSxHQUFHWixRQUFRLENBQUM3QiwwQkFBVCxFQUFqQjs7QUFDQTZCLGdCQUFRLENBQUN0TCxLQUFULENBQWVrTCxNQUFmLENBQXNCLEtBQUs1SSxNQUEzQixFQUFtQztBQUNqQzZKLGNBQUksRUFBRTtBQUNKLG1EQUF1Q0wsTUFEbkM7QUFFSix1REFBMkM7QUFGdkMsV0FEMkI7QUFLakNNLGVBQUssRUFBRTtBQUFFLDJDQUErQmQsUUFBUSxDQUFDZSxpQkFBVCxDQUEyQkgsUUFBM0I7QUFBakM7QUFMMEIsU0FBbkM7QUFPQXBNLGNBQU0sQ0FBQ3dNLFVBQVAsQ0FBa0IsTUFBTTtBQUN0QjtBQUNBO0FBQ0FoQixrQkFBUSxDQUFDaUIseUJBQVQsQ0FBbUMsS0FBS2pLLE1BQXhDLEVBQWdEd0osTUFBaEQ7QUFDRCxTQUpELEVBSUdSLFFBQVEsQ0FBQ2tCLDhCQUFULEdBQTBDLENBQTFDLEdBQ0RsTSx5QkFMRixFQWZRLENBcUJSO0FBQ0E7QUFDQTs7QUFDQSxlQUFPO0FBQ0xvSCxlQUFLLEVBQUV3RSxRQUFRLENBQUN4RSxLQURYO0FBRUxzQyxzQkFBWSxFQUFFc0IsUUFBUSxDQUFDbEcsZ0JBQVQsQ0FBMEI4RyxRQUFRLENBQUM3RyxJQUFuQztBQUZULFNBQVA7QUFJRCxPQTVCRCxNQTRCTztBQUNMLGNBQU0sSUFBSXZGLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsd0JBQWpCLENBQU47QUFDRDtBQUNGLEtBckNELENBbkRtQixDQTBGbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FnSixXQUFPLENBQUNrQixXQUFSLEdBQXNCLFlBQVk7QUFDaEMsWUFBTTFKLElBQUksR0FBR3VJLFFBQVEsQ0FBQ3RMLEtBQVQsQ0FBZWdELE9BQWYsQ0FBdUIsS0FBS1YsTUFBNUIsRUFBb0M7QUFDL0NJLGNBQU0sRUFBRTtBQUFFLHlDQUErQjtBQUFqQztBQUR1QyxPQUFwQyxDQUFiOztBQUdBLFVBQUksQ0FBRSxLQUFLSixNQUFQLElBQWlCLENBQUVTLElBQXZCLEVBQTZCO0FBQzNCLGNBQU0sSUFBSWpELE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsd0JBQWpCLENBQU47QUFDRCxPQU4rQixDQU9oQztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsWUFBTW1LLGtCQUFrQixHQUFHcEIsUUFBUSxDQUFDTSxjQUFULENBQXdCLEtBQUtsTCxVQUFMLENBQWdCcUosRUFBeEMsQ0FBM0I7O0FBQ0EsWUFBTTRDLG1CQUFtQixHQUFHNUosSUFBSSxDQUFDZ0osUUFBTCxDQUFjQyxNQUFkLENBQXFCQyxXQUFyQixDQUFpQ1csSUFBakMsQ0FDMUJDLFlBQVksSUFBSUEsWUFBWSxDQUFDeEIsV0FBYixLQUE2QnFCLGtCQURuQixDQUE1Qjs7QUFHQSxVQUFJLENBQUVDLG1CQUFOLEVBQTJCO0FBQUU7QUFDM0IsY0FBTSxJQUFJN00sTUFBTSxDQUFDeUMsS0FBWCxDQUFpQixxQkFBakIsQ0FBTjtBQUNEOztBQUNELFlBQU11SyxlQUFlLEdBQUd4QixRQUFRLENBQUM3QiwwQkFBVCxFQUF4Qjs7QUFDQXFELHFCQUFlLENBQUN6SCxJQUFoQixHQUF1QnNILG1CQUFtQixDQUFDdEgsSUFBM0M7O0FBQ0FpRyxjQUFRLENBQUM1QixpQkFBVCxDQUEyQixLQUFLcEgsTUFBaEMsRUFBd0N3SyxlQUF4Qzs7QUFDQSxhQUFPeEIsUUFBUSxDQUFDaEMsVUFBVCxDQUFvQixJQUFwQixFQUEwQixLQUFLaEgsTUFBL0IsRUFBdUN3SyxlQUF2QyxDQUFQO0FBQ0QsS0F0QkQsQ0FsR21CLENBMEhuQjtBQUNBO0FBQ0E7OztBQUNBdkIsV0FBTyxDQUFDd0IsaUJBQVIsR0FBNEIsWUFBWTtBQUN0QyxVQUFJLENBQUUsS0FBS3pLLE1BQVgsRUFBbUI7QUFDakIsY0FBTSxJQUFJeEMsTUFBTSxDQUFDeUMsS0FBWCxDQUFpQix3QkFBakIsQ0FBTjtBQUNEOztBQUNELFlBQU15SyxZQUFZLEdBQUcxQixRQUFRLENBQUNNLGNBQVQsQ0FBd0IsS0FBS2xMLFVBQUwsQ0FBZ0JxSixFQUF4QyxDQUFyQjs7QUFDQXVCLGNBQVEsQ0FBQ3RMLEtBQVQsQ0FBZWtMLE1BQWYsQ0FBc0IsS0FBSzVJLE1BQTNCLEVBQW1DO0FBQ2pDNkksYUFBSyxFQUFFO0FBQ0wseUNBQStCO0FBQUVFLHVCQUFXLEVBQUU7QUFBRTRCLGlCQUFHLEVBQUVEO0FBQVA7QUFBZjtBQUQxQjtBQUQwQixPQUFuQztBQUtELEtBVkQsQ0E3SG1CLENBeUluQjtBQUNBOzs7QUFDQXpCLFdBQU8sQ0FBQzJCLHFCQUFSLEdBQWlDMU0sT0FBRCxJQUFhO0FBQzNDaUwsV0FBSyxDQUFDakwsT0FBRCxFQUFVMk0sS0FBSyxDQUFDQyxlQUFOLENBQXNCO0FBQUNDLGVBQU8sRUFBRUM7QUFBVixPQUF0QixDQUFWLENBQUwsQ0FEMkMsQ0FFM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQUksRUFBRWhDLFFBQVEsQ0FBQ2lDLEtBQVQsSUFDRGpDLFFBQVEsQ0FBQ2lDLEtBQVQsQ0FBZUMsWUFBZixHQUE4QnpKLFFBQTlCLENBQXVDdkQsT0FBTyxDQUFDNk0sT0FBL0MsQ0FERCxDQUFKLEVBQytEO0FBQzdELGNBQU0sSUFBSXZOLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsaUJBQXRCLENBQU47QUFDRDs7QUFFRCxZQUFNO0FBQUVOO0FBQUYsVUFBMkJDLE9BQU8sQ0FBQyx1QkFBRCxDQUF4QztBQUNBLFVBQUlELG9CQUFvQixDQUFDRyxjQUFyQixDQUFvQ1ksT0FBcEMsQ0FBNEM7QUFBQ3FLLGVBQU8sRUFBRTdNLE9BQU8sQ0FBQzZNO0FBQWxCLE9BQTVDLENBQUosRUFDRSxNQUFNLElBQUl2TixNQUFNLENBQUN5QyxLQUFYLENBQWlCLEdBQWpCLG9CQUFpQy9CLE9BQU8sQ0FBQzZNLE9BQXpDLHlCQUFOO0FBRUYsVUFBSXZILE1BQU0sQ0FBQ3ZDLElBQVAsQ0FBWS9DLE9BQVosRUFBcUIsUUFBckIsS0FBa0NpTixvQkFBb0IsRUFBMUQsRUFDRWpOLE9BQU8sQ0FBQ2tOLE1BQVIsR0FBaUJqSyxlQUFlLENBQUNrSyxJQUFoQixDQUFxQm5OLE9BQU8sQ0FBQ2tOLE1BQTdCLENBQWpCO0FBRUZ6TCwwQkFBb0IsQ0FBQ0csY0FBckIsQ0FBb0N3TCxNQUFwQyxDQUEyQ3BOLE9BQTNDO0FBQ0QsS0FyQkQ7O0FBdUJBOEssWUFBUSxDQUFDdkYsT0FBVCxDQUFpQndGLE9BQWpCLENBQXlCQSxPQUF6QjtBQUNEOztBQUVEdEYsdUJBQXFCLEdBQUc7QUFDdEIsU0FBS0YsT0FBTCxDQUFhOEgsWUFBYixDQUEwQm5OLFVBQVUsSUFBSTtBQUN0QyxXQUFLaUcsWUFBTCxDQUFrQmpHLFVBQVUsQ0FBQ3FKLEVBQTdCLElBQW1DO0FBQ2pDckosa0JBQVUsRUFBRUE7QUFEcUIsT0FBbkM7QUFJQUEsZ0JBQVUsQ0FBQ29OLE9BQVgsQ0FBbUIsTUFBTTtBQUN2QixhQUFLQywwQkFBTCxDQUFnQ3JOLFVBQVUsQ0FBQ3FKLEVBQTNDOztBQUNBLGVBQU8sS0FBS3BELFlBQUwsQ0FBa0JqRyxVQUFVLENBQUNxSixFQUE3QixDQUFQO0FBQ0QsT0FIRDtBQUlELEtBVEQ7QUFVRDs7QUFFRHJELHlCQUF1QixHQUFHO0FBQ3hCO0FBQ0EsVUFBTTtBQUFFMUcsV0FBRjtBQUFTa0csd0JBQVQ7QUFBNkJHO0FBQTdCLFFBQXVELElBQTdELENBRndCLENBSXhCOztBQUNBLFNBQUtOLE9BQUwsQ0FBYWlJLE9BQWIsQ0FBcUIsa0NBQXJCLEVBQXlELE1BQU07QUFDN0QsWUFBTTtBQUFFL0w7QUFBRixVQUEyQkMsT0FBTyxDQUFDLHVCQUFELENBQXhDO0FBQ0EsYUFBT0Qsb0JBQW9CLENBQUNHLGNBQXJCLENBQW9Dd0ssSUFBcEMsQ0FBeUMsRUFBekMsRUFBNkM7QUFBQ2xLLGNBQU0sRUFBRTtBQUFDZ0wsZ0JBQU0sRUFBRTtBQUFUO0FBQVQsT0FBN0MsQ0FBUDtBQUNELEtBSEQsRUFHRztBQUFDTyxhQUFPLEVBQUU7QUFBVixLQUhILEVBTHdCLENBUUg7QUFFckI7QUFDQTs7O0FBQ0FuTyxVQUFNLENBQUNrQyxPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBLFdBQUsrRCxPQUFMLENBQWFpSSxPQUFiLENBQXFCLElBQXJCLEVBQTJCLFlBQVk7QUFDckMsWUFBSSxLQUFLMUwsTUFBVCxFQUFpQjtBQUNmLGlCQUFPdEMsS0FBSyxDQUFDNE0sSUFBTixDQUFXO0FBQ2hCc0IsZUFBRyxFQUFFLEtBQUs1TDtBQURNLFdBQVgsRUFFSjtBQUNESSxrQkFBTSxFQUFFMkQscUJBQXFCLENBQUNDO0FBRDdCLFdBRkksQ0FBUDtBQUtELFNBTkQsTUFNTztBQUNMLGlCQUFPLElBQVA7QUFDRDtBQUNGLE9BVkQ7QUFVRztBQUFnQztBQUFDMkgsZUFBTyxFQUFFO0FBQVYsT0FWbkM7QUFXRCxLQWJELEVBWndCLENBMkJ4QjtBQUNBOztBQUNBL0wsV0FBTyxDQUFDaU0sV0FBUixJQUF1QnJPLE1BQU0sQ0FBQ2tDLE9BQVAsQ0FBZSxNQUFNO0FBQzFDO0FBQ0EsWUFBTW9NLGVBQWUsR0FBRzFMLE1BQU0sSUFBSUEsTUFBTSxDQUFDMkwsTUFBUCxDQUFjLENBQUNDLElBQUQsRUFBT0MsS0FBUCxxQ0FDdkNELElBRHVDO0FBQ2pDLFNBQUNDLEtBQUQsR0FBUztBQUR3QixRQUFkLEVBRWhDLEVBRmdDLENBQWxDOztBQUlBLFdBQUt4SSxPQUFMLENBQWFpSSxPQUFiLENBQXFCLElBQXJCLEVBQTJCLFlBQVk7QUFDckMsWUFBSSxLQUFLMUwsTUFBVCxFQUFpQjtBQUNmLGlCQUFPdEMsS0FBSyxDQUFDNE0sSUFBTixDQUFXO0FBQUVzQixlQUFHLEVBQUUsS0FBSzVMO0FBQVosV0FBWCxFQUFpQztBQUN0Q0ksa0JBQU0sRUFBRTBMLGVBQWUsQ0FBQ2xJLGtCQUFrQixDQUFDQyxZQUFwQjtBQURlLFdBQWpDLENBQVA7QUFHRCxTQUpELE1BSU87QUFDTCxpQkFBTyxJQUFQO0FBQ0Q7QUFDRixPQVJEO0FBUUc7QUFBZ0M7QUFBQzhILGVBQU8sRUFBRTtBQUFWLE9BUm5DLEVBTjBDLENBZ0IxQztBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxXQUFLbEksT0FBTCxDQUFhaUksT0FBYixDQUFxQixJQUFyQixFQUEyQixZQUFZO0FBQ3JDLGNBQU1RLFFBQVEsR0FBRyxLQUFLbE0sTUFBTCxHQUFjO0FBQUU0TCxhQUFHLEVBQUU7QUFBRWpCLGVBQUcsRUFBRSxLQUFLM0s7QUFBWjtBQUFQLFNBQWQsR0FBOEMsRUFBL0Q7QUFDQSxlQUFPdEMsS0FBSyxDQUFDNE0sSUFBTixDQUFXNEIsUUFBWCxFQUFxQjtBQUMxQjlMLGdCQUFNLEVBQUUwTCxlQUFlLENBQUNsSSxrQkFBa0IsQ0FBQ0UsVUFBcEI7QUFERyxTQUFyQixDQUFQO0FBR0QsT0FMRDtBQUtHO0FBQWdDO0FBQUM2SCxlQUFPLEVBQUU7QUFBVixPQUxuQztBQU1ELEtBM0JzQixDQUF2QjtBQTRCRDs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBUSxzQkFBb0IsQ0FBQ0MsSUFBRCxFQUFPO0FBQ3pCLFNBQUt4SSxrQkFBTCxDQUF3QkMsWUFBeEIsQ0FBcUNrQyxJQUFyQyxDQUEwQ3NHLEtBQTFDLENBQ0UsS0FBS3pJLGtCQUFMLENBQXdCQyxZQUQxQixFQUN3Q3VJLElBQUksQ0FBQ0UsZUFEN0M7O0FBRUEsU0FBSzFJLGtCQUFMLENBQXdCRSxVQUF4QixDQUFtQ2lDLElBQW5DLENBQXdDc0csS0FBeEMsQ0FDRSxLQUFLekksa0JBQUwsQ0FBd0JFLFVBRDFCLEVBQ3NDc0ksSUFBSSxDQUFDRyxhQUQzQztBQUVEOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLHlCQUF1QixDQUFDcE0sTUFBRCxFQUFTO0FBQzlCLFNBQUsyRCxxQkFBTCxDQUEyQkMsVUFBM0IsR0FBd0M1RCxNQUF4QztBQUNEOztBQUVEO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQXFNLGlCQUFlLENBQUNDLFlBQUQsRUFBZVQsS0FBZixFQUFzQjtBQUNuQyxVQUFNVSxJQUFJLEdBQUcsS0FBS3RJLFlBQUwsQ0FBa0JxSSxZQUFsQixDQUFiO0FBQ0EsV0FBT0MsSUFBSSxJQUFJQSxJQUFJLENBQUNWLEtBQUQsQ0FBbkI7QUFDRDs7QUFFRFcsaUJBQWUsQ0FBQ0YsWUFBRCxFQUFlVCxLQUFmLEVBQXNCWSxLQUF0QixFQUE2QjtBQUMxQyxVQUFNRixJQUFJLEdBQUcsS0FBS3RJLFlBQUwsQ0FBa0JxSSxZQUFsQixDQUFiLENBRDBDLENBRzFDO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDQyxJQUFMLEVBQ0U7QUFFRixRQUFJRSxLQUFLLEtBQUt4TyxTQUFkLEVBQ0UsT0FBT3NPLElBQUksQ0FBQ1YsS0FBRCxDQUFYLENBREYsS0FHRVUsSUFBSSxDQUFDVixLQUFELENBQUosR0FBY1ksS0FBZDtBQUNIOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBRUF0RixpQkFBZSxDQUFDb0IsVUFBRCxFQUFhO0FBQzFCLFVBQU1tRSxJQUFJLEdBQUd2SixNQUFNLENBQUN3SixVQUFQLENBQWtCLFFBQWxCLENBQWI7QUFDQUQsUUFBSSxDQUFDbEUsTUFBTCxDQUFZRCxVQUFaO0FBQ0EsV0FBT21FLElBQUksQ0FBQ0UsTUFBTCxDQUFZLFFBQVosQ0FBUDtBQUNEOztBQUVEO0FBQ0FqRCxtQkFBaUIsQ0FBQ1EsWUFBRCxFQUFlO0FBQzlCLFVBQU07QUFBRW5GO0FBQUYsUUFBbUNtRixZQUF6QztBQUFBLFVBQWtCMEMsa0JBQWxCLDRCQUF5QzFDLFlBQXpDOztBQUNBLDJDQUNLMEMsa0JBREw7QUFFRWxFLGlCQUFXLEVBQUUsS0FBS3hCLGVBQUwsQ0FBcUJuQyxLQUFyQjtBQUZmO0FBSUQ7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E4SCx5QkFBdUIsQ0FBQ2xOLE1BQUQsRUFBUytJLFdBQVQsRUFBc0JvRSxLQUF0QixFQUE2QjtBQUNsREEsU0FBSyxHQUFHQSxLQUFLLHFCQUFRQSxLQUFSLElBQWtCLEVBQS9CO0FBQ0FBLFNBQUssQ0FBQ3ZCLEdBQU4sR0FBWTVMLE1BQVo7QUFDQSxTQUFLdEMsS0FBTCxDQUFXa0wsTUFBWCxDQUFrQnVFLEtBQWxCLEVBQXlCO0FBQ3ZCQyxlQUFTLEVBQUU7QUFDVCx1Q0FBK0JyRTtBQUR0QjtBQURZLEtBQXpCO0FBS0Q7O0FBRUQ7QUFDQTNCLG1CQUFpQixDQUFDcEgsTUFBRCxFQUFTdUssWUFBVCxFQUF1QjRDLEtBQXZCLEVBQThCO0FBQzdDLFNBQUtELHVCQUFMLENBQ0VsTixNQURGLEVBRUUsS0FBSytKLGlCQUFMLENBQXVCUSxZQUF2QixDQUZGLEVBR0U0QyxLQUhGO0FBS0Q7O0FBRURFLHNCQUFvQixDQUFDck4sTUFBRCxFQUFTO0FBQzNCLFNBQUt0QyxLQUFMLENBQVdrTCxNQUFYLENBQWtCNUksTUFBbEIsRUFBMEI7QUFDeEI2SixVQUFJLEVBQUU7QUFDSix1Q0FBK0I7QUFEM0I7QUFEa0IsS0FBMUI7QUFLRDs7QUFFRDtBQUNBeUQsaUJBQWUsQ0FBQ1osWUFBRCxFQUFlO0FBQzVCLFdBQU8sS0FBS3BJLDJCQUFMLENBQWlDb0ksWUFBakMsQ0FBUDtBQUNEOztBQUVEO0FBQ0E7QUFDQTtBQUNBakIsNEJBQTBCLENBQUNpQixZQUFELEVBQWU7QUFDdkMsUUFBSWxKLE1BQU0sQ0FBQ3ZDLElBQVAsQ0FBWSxLQUFLcUQsMkJBQWpCLEVBQThDb0ksWUFBOUMsQ0FBSixFQUFpRTtBQUMvRCxZQUFNYSxPQUFPLEdBQUcsS0FBS2pKLDJCQUFMLENBQWlDb0ksWUFBakMsQ0FBaEI7O0FBQ0EsVUFBSSxPQUFPYSxPQUFQLEtBQW1CLFFBQXZCLEVBQWlDO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBTyxLQUFLakosMkJBQUwsQ0FBaUNvSSxZQUFqQyxDQUFQO0FBQ0QsT0FORCxNQU1PO0FBQ0wsZUFBTyxLQUFLcEksMkJBQUwsQ0FBaUNvSSxZQUFqQyxDQUFQO0FBQ0FhLGVBQU8sQ0FBQ0MsSUFBUjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRGxFLGdCQUFjLENBQUNvRCxZQUFELEVBQWU7QUFDM0IsV0FBTyxLQUFLRCxlQUFMLENBQXFCQyxZQUFyQixFQUFtQyxZQUFuQyxDQUFQO0FBQ0Q7O0FBRUQ7QUFDQXBGLGdCQUFjLENBQUN0SCxNQUFELEVBQVM1QixVQUFULEVBQXFCd0wsUUFBckIsRUFBK0I7QUFDM0MsU0FBSzZCLDBCQUFMLENBQWdDck4sVUFBVSxDQUFDcUosRUFBM0M7O0FBQ0EsU0FBS21GLGVBQUwsQ0FBcUJ4TyxVQUFVLENBQUNxSixFQUFoQyxFQUFvQyxZQUFwQyxFQUFrRG1DLFFBQWxEOztBQUVBLFFBQUlBLFFBQUosRUFBYztBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBTTZELGVBQWUsR0FBRyxFQUFFLEtBQUtsSixzQkFBL0I7QUFDQSxXQUFLRCwyQkFBTCxDQUFpQ2xHLFVBQVUsQ0FBQ3FKLEVBQTVDLElBQWtEZ0csZUFBbEQ7QUFDQWpRLFlBQU0sQ0FBQ2tRLEtBQVAsQ0FBYSxNQUFNO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBSSxLQUFLcEosMkJBQUwsQ0FBaUNsRyxVQUFVLENBQUNxSixFQUE1QyxNQUFvRGdHLGVBQXhELEVBQXlFO0FBQ3ZFO0FBQ0Q7O0FBRUQsWUFBSUUsaUJBQUosQ0FUaUIsQ0FVakI7QUFDQTtBQUNBOztBQUNBLGNBQU1KLE9BQU8sR0FBRyxLQUFLN1AsS0FBTCxDQUFXNE0sSUFBWCxDQUFnQjtBQUM5QnNCLGFBQUcsRUFBRTVMLE1BRHlCO0FBRTlCLHFEQUEyQzRKO0FBRmIsU0FBaEIsRUFHYjtBQUFFeEosZ0JBQU0sRUFBRTtBQUFFd0wsZUFBRyxFQUFFO0FBQVA7QUFBVixTQUhhLEVBR1dnQyxjQUhYLENBRzBCO0FBQ3hDQyxlQUFLLEVBQUUsTUFBTTtBQUNYRiw2QkFBaUIsR0FBRyxJQUFwQjtBQUNELFdBSHVDO0FBSXhDRyxpQkFBTyxFQUFFMVAsVUFBVSxDQUFDMlAsS0FKb0IsQ0FLeEM7QUFDQTtBQUNBOztBQVB3QyxTQUgxQixFQVdiO0FBQUVDLDhCQUFvQixFQUFFO0FBQXhCLFNBWGEsQ0FBaEIsQ0FiaUIsQ0EwQmpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsWUFBSSxLQUFLMUosMkJBQUwsQ0FBaUNsRyxVQUFVLENBQUNxSixFQUE1QyxNQUFvRGdHLGVBQXhELEVBQXlFO0FBQ3ZFRixpQkFBTyxDQUFDQyxJQUFSO0FBQ0E7QUFDRDs7QUFFRCxhQUFLbEosMkJBQUwsQ0FBaUNsRyxVQUFVLENBQUNxSixFQUE1QyxJQUFrRDhGLE9BQWxEOztBQUVBLFlBQUksQ0FBRUksaUJBQU4sRUFBeUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBdlAsb0JBQVUsQ0FBQzJQLEtBQVg7QUFDRDtBQUNGLE9BakREO0FBa0REO0FBQ0Y7O0FBRUQ7QUFDQTtBQUNBNUcsNEJBQTBCLEdBQUc7QUFDM0IsV0FBTztBQUNML0IsV0FBSyxFQUFFNkksTUFBTSxDQUFDN0MsTUFBUCxFQURGO0FBRUxySSxVQUFJLEVBQUUsSUFBSUMsSUFBSjtBQUZELEtBQVA7QUFJRDs7QUFFRDtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQWtMLDRCQUEwQixDQUFDQyxlQUFELEVBQWtCbk8sTUFBbEIsRUFBMEI7QUFDbEQsVUFBTW9PLGVBQWUsR0FBRyxLQUFLNUwsZ0NBQUwsRUFBeEIsQ0FEa0QsQ0FHbEQ7OztBQUNBLFFBQUsyTCxlQUFlLElBQUksQ0FBQ25PLE1BQXJCLElBQWlDLENBQUNtTyxlQUFELElBQW9Cbk8sTUFBekQsRUFBa0U7QUFDaEUsWUFBTSxJQUFJQyxLQUFKLENBQVUseURBQVYsQ0FBTjtBQUNEOztBQUVEa08sbUJBQWUsR0FBR0EsZUFBZSxJQUM5QixJQUFJbkwsSUFBSixDQUFTLElBQUlBLElBQUosS0FBYW9MLGVBQXRCLENBREg7QUFHQSxVQUFNQyxXQUFXLEdBQUc7QUFDbEJ2RixTQUFHLEVBQUUsQ0FDSDtBQUFFLDBDQUFrQztBQUFwQyxPQURHLEVBRUg7QUFBRSwwQ0FBa0M7QUFBQ3dGLGlCQUFPLEVBQUU7QUFBVjtBQUFwQyxPQUZHO0FBRGEsS0FBcEI7QUFPQUMsdUJBQW1CLENBQUMsSUFBRCxFQUFPSixlQUFQLEVBQXdCRSxXQUF4QixFQUFxQ3JPLE1BQXJDLENBQW5CO0FBQ0QsR0F0OUJnRCxDQXc5QmpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0F3Tyw2QkFBMkIsQ0FBQ0wsZUFBRCxFQUFrQm5PLE1BQWxCLEVBQTBCO0FBQ25ELFVBQU1vTyxlQUFlLEdBQUcsS0FBS3pMLGlDQUFMLEVBQXhCLENBRG1ELENBR25EOzs7QUFDQSxRQUFLd0wsZUFBZSxJQUFJLENBQUNuTyxNQUFyQixJQUFpQyxDQUFDbU8sZUFBRCxJQUFvQm5PLE1BQXpELEVBQWtFO0FBQ2hFLFlBQU0sSUFBSUMsS0FBSixDQUFVLHlEQUFWLENBQU47QUFDRDs7QUFFRGtPLG1CQUFlLEdBQUdBLGVBQWUsSUFDOUIsSUFBSW5MLElBQUosQ0FBUyxJQUFJQSxJQUFKLEtBQWFvTCxlQUF0QixDQURIO0FBR0EsVUFBTUMsV0FBVyxHQUFHO0FBQ2xCLHdDQUFrQztBQURoQixLQUFwQjtBQUlBRSx1QkFBbUIsQ0FBQyxJQUFELEVBQU9KLGVBQVAsRUFBd0JFLFdBQXhCLEVBQXFDck8sTUFBckMsQ0FBbkI7QUFDRCxHQTkrQmdELENBZy9CakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBeU8sZUFBYSxDQUFDTixlQUFELEVBQWtCbk8sTUFBbEIsRUFBMEI7QUFDckMsVUFBTW9PLGVBQWUsR0FBRyxLQUFLOUwsbUJBQUwsRUFBeEIsQ0FEcUMsQ0FHckM7OztBQUNBLFFBQUs2TCxlQUFlLElBQUksQ0FBQ25PLE1BQXJCLElBQWlDLENBQUNtTyxlQUFELElBQW9Cbk8sTUFBekQsRUFBa0U7QUFDaEUsWUFBTSxJQUFJQyxLQUFKLENBQVUseURBQVYsQ0FBTjtBQUNEOztBQUVEa08sbUJBQWUsR0FBR0EsZUFBZSxJQUM5QixJQUFJbkwsSUFBSixDQUFTLElBQUlBLElBQUosS0FBYW9MLGVBQXRCLENBREg7QUFFQSxVQUFNTSxVQUFVLEdBQUcxTyxNQUFNLEdBQUc7QUFBQzRMLFNBQUcsRUFBRTVMO0FBQU4sS0FBSCxHQUFtQixFQUE1QyxDQVZxQyxDQWFyQztBQUNBOztBQUNBLFNBQUt0QyxLQUFMLENBQVdrTCxNQUFYLGlDQUF1QjhGLFVBQXZCO0FBQ0U1RixTQUFHLEVBQUUsQ0FDSDtBQUFFLDRDQUFvQztBQUFFNkYsYUFBRyxFQUFFUjtBQUFQO0FBQXRDLE9BREcsRUFFSDtBQUFFLDRDQUFvQztBQUFFUSxhQUFHLEVBQUUsQ0FBQ1I7QUFBUjtBQUF0QyxPQUZHO0FBRFAsUUFLRztBQUNEdEYsV0FBSyxFQUFFO0FBQ0wsdUNBQStCO0FBQzdCQyxhQUFHLEVBQUUsQ0FDSDtBQUFFL0YsZ0JBQUksRUFBRTtBQUFFNEwsaUJBQUcsRUFBRVI7QUFBUDtBQUFSLFdBREcsRUFFSDtBQUFFcEwsZ0JBQUksRUFBRTtBQUFFNEwsaUJBQUcsRUFBRSxDQUFDUjtBQUFSO0FBQVIsV0FGRztBQUR3QjtBQUQxQjtBQUROLEtBTEgsRUFjRztBQUFFUyxXQUFLLEVBQUU7QUFBVCxLQWRILEVBZnFDLENBOEJyQztBQUNBO0FBQ0Q7O0FBRUQ7QUFDQWpPLFFBQU0sQ0FBQ3pDLE9BQUQsRUFBVTtBQUNkO0FBQ0EsVUFBTTJRLFdBQVcsR0FBRy9RLGNBQWMsQ0FBQ3lCLFNBQWYsQ0FBeUJvQixNQUF6QixDQUFnQzBMLEtBQWhDLENBQXNDLElBQXRDLEVBQTRDakQsU0FBNUMsQ0FBcEIsQ0FGYyxDQUlkO0FBQ0E7O0FBQ0EsUUFBSTVGLE1BQU0sQ0FBQ3ZDLElBQVAsQ0FBWSxLQUFLOUMsUUFBakIsRUFBMkIsdUJBQTNCLEtBQ0YsS0FBS0EsUUFBTCxDQUFjb0UscUJBQWQsS0FBd0MsSUFEdEMsSUFFRixLQUFLdU0sbUJBRlAsRUFFNEI7QUFDMUJ0UixZQUFNLENBQUN1UixhQUFQLENBQXFCLEtBQUtELG1CQUExQjtBQUNBLFdBQUtBLG1CQUFMLEdBQTJCLElBQTNCO0FBQ0Q7O0FBRUQsV0FBT0QsV0FBUDtBQUNEOztBQUVEO0FBQ0FHLGVBQWEsQ0FBQzlRLE9BQUQsRUFBVXVDLElBQVYsRUFBZ0I7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FBLFFBQUk7QUFDRndPLGVBQVMsRUFBRSxJQUFJak0sSUFBSixFQURUO0FBRUY0SSxTQUFHLEVBQUVxQyxNQUFNLENBQUN4RyxFQUFQO0FBRkgsT0FHQ2hILElBSEQsQ0FBSjs7QUFNQSxRQUFJQSxJQUFJLENBQUNnSixRQUFULEVBQW1CO0FBQ2pCbkosWUFBTSxDQUFDRCxJQUFQLENBQVlJLElBQUksQ0FBQ2dKLFFBQWpCLEVBQTJCbEksT0FBM0IsQ0FBbUN3SixPQUFPLElBQ3hDbUUsd0JBQXdCLENBQUN6TyxJQUFJLENBQUNnSixRQUFMLENBQWNzQixPQUFkLENBQUQsRUFBeUJ0SyxJQUFJLENBQUNtTCxHQUE5QixDQUQxQjtBQUdEOztBQUVELFFBQUl1RCxRQUFKOztBQUNBLFFBQUksS0FBS2hKLGlCQUFULEVBQTRCO0FBQzFCZ0osY0FBUSxHQUFHLEtBQUtoSixpQkFBTCxDQUF1QmpJLE9BQXZCLEVBQWdDdUMsSUFBaEMsQ0FBWCxDQUQwQixDQUcxQjtBQUNBO0FBQ0E7O0FBQ0EsVUFBSTBPLFFBQVEsS0FBSyxtQkFBakIsRUFDRUEsUUFBUSxHQUFHQyxxQkFBcUIsQ0FBQ2xSLE9BQUQsRUFBVXVDLElBQVYsQ0FBaEM7QUFDSCxLQVJELE1BUU87QUFDTDBPLGNBQVEsR0FBR0MscUJBQXFCLENBQUNsUixPQUFELEVBQVV1QyxJQUFWLENBQWhDO0FBQ0Q7O0FBRUQsU0FBS29FLHFCQUFMLENBQTJCdEQsT0FBM0IsQ0FBbUM4TixJQUFJLElBQUk7QUFDekMsVUFBSSxDQUFFQSxJQUFJLENBQUNGLFFBQUQsQ0FBVixFQUNFLE1BQU0sSUFBSTNSLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0Isd0JBQXRCLENBQU47QUFDSCxLQUhEOztBQUtBLFFBQUlELE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxZQUFNLEdBQUcsS0FBS3RDLEtBQUwsQ0FBVzROLE1BQVgsQ0FBa0I2RCxRQUFsQixDQUFUO0FBQ0QsS0FGRCxDQUVFLE9BQU96SSxDQUFQLEVBQVU7QUFDVjtBQUNBO0FBQ0EsVUFBSSxDQUFDQSxDQUFDLENBQUM0SSxNQUFQLEVBQWUsTUFBTTVJLENBQU47QUFDZixVQUFJQSxDQUFDLENBQUM0SSxNQUFGLENBQVM3TixRQUFULENBQWtCLGdCQUFsQixDQUFKLEVBQ0UsTUFBTSxJQUFJakUsTUFBTSxDQUFDeUMsS0FBWCxDQUFpQixHQUFqQixFQUFzQix1QkFBdEIsQ0FBTjtBQUNGLFVBQUl5RyxDQUFDLENBQUM0SSxNQUFGLENBQVM3TixRQUFULENBQWtCLFVBQWxCLENBQUosRUFDRSxNQUFNLElBQUlqRSxNQUFNLENBQUN5QyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDBCQUF0QixDQUFOO0FBQ0YsWUFBTXlHLENBQU47QUFDRDs7QUFDRCxXQUFPMUcsTUFBUDtBQUNEOztBQUVEO0FBQ0E7QUFDQXVQLGtCQUFnQixDQUFDQyxLQUFELEVBQVE7QUFDdEIsVUFBTUMsTUFBTSxHQUFHLEtBQUt0UixRQUFMLENBQWN1Uiw2QkFBN0I7QUFFQSxXQUFPLENBQUNELE1BQUQsSUFDSixPQUFPQSxNQUFQLEtBQWtCLFVBQWxCLElBQWdDQSxNQUFNLENBQUNELEtBQUQsQ0FEbEMsSUFFSixPQUFPQyxNQUFQLEtBQWtCLFFBQWxCLElBQ0UsSUFBSUUsTUFBSixZQUFlblMsTUFBTSxDQUFDb1MsYUFBUCxDQUFxQkgsTUFBckIsQ0FBZixRQUFnRCxHQUFoRCxDQUFELENBQXVESSxJQUF2RCxDQUE0REwsS0FBNUQsQ0FISjtBQUlEOztBQUVEO0FBQ0E7QUFDQTtBQUVBdkYsMkJBQXlCLENBQUNqSyxNQUFELEVBQVM4UCxjQUFULEVBQXlCO0FBQ2hELFFBQUlBLGNBQUosRUFBb0I7QUFDbEIsV0FBS3BTLEtBQUwsQ0FBV2tMLE1BQVgsQ0FBa0I1SSxNQUFsQixFQUEwQjtBQUN4QitQLGNBQU0sRUFBRTtBQUNOLHFEQUEyQyxDQURyQztBQUVOLGlEQUF1QztBQUZqQyxTQURnQjtBQUt4QkMsZ0JBQVEsRUFBRTtBQUNSLHlDQUErQkY7QUFEdkI7QUFMYyxPQUExQjtBQVNEO0FBQ0Y7O0FBRUQ5Syx3Q0FBc0MsR0FBRztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQXhILFVBQU0sQ0FBQ2tDLE9BQVAsQ0FBZSxNQUFNO0FBQ25CLFdBQUtoQyxLQUFMLENBQVc0TSxJQUFYLENBQWdCO0FBQ2QsbURBQTJDO0FBRDdCLE9BQWhCLEVBRUc7QUFBQ2xLLGNBQU0sRUFBRTtBQUNWLGlEQUF1QztBQUQ3QjtBQUFULE9BRkgsRUFJSW1CLE9BSkosQ0FJWWQsSUFBSSxJQUFJO0FBQ2xCLGFBQUt3Six5QkFBTCxDQUNFeEosSUFBSSxDQUFDbUwsR0FEUCxFQUVFbkwsSUFBSSxDQUFDZ0osUUFBTCxDQUFjQyxNQUFkLENBQXFCdUcsbUJBRnZCO0FBSUQsT0FURDtBQVVELEtBWEQ7QUFZRDs7QUFFRDtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLHVDQUFxQyxDQUNuQ0MsV0FEbUMsRUFFbkNDLFdBRm1DLEVBR25DbFMsT0FIbUMsRUFJbkM7QUFDQUEsV0FBTyxxQkFBUUEsT0FBUixDQUFQOztBQUVBLFFBQUlpUyxXQUFXLEtBQUssVUFBaEIsSUFBOEJBLFdBQVcsS0FBSyxRQUFsRCxFQUE0RDtBQUMxRCxZQUFNLElBQUlsUSxLQUFKLENBQ0osMkVBQ0VrUSxXQUZFLENBQU47QUFHRDs7QUFDRCxRQUFJLENBQUMzTSxNQUFNLENBQUN2QyxJQUFQLENBQVltUCxXQUFaLEVBQXlCLElBQXpCLENBQUwsRUFBcUM7QUFDbkMsWUFBTSxJQUFJblEsS0FBSixvQ0FDd0JrUSxXQUR4QixzQkFBTjtBQUVELEtBWEQsQ0FhQTs7O0FBQ0EsVUFBTWpFLFFBQVEsR0FBRyxFQUFqQjtBQUNBLFVBQU1tRSxZQUFZLHNCQUFlRixXQUFmLFFBQWxCLENBZkEsQ0FpQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSUEsV0FBVyxLQUFLLFNBQWhCLElBQTZCLENBQUNHLEtBQUssQ0FBQ0YsV0FBVyxDQUFDM0ksRUFBYixDQUF2QyxFQUF5RDtBQUN2RHlFLGNBQVEsQ0FBQyxLQUFELENBQVIsR0FBa0IsQ0FBQyxFQUFELEVBQUksRUFBSixDQUFsQjtBQUNBQSxjQUFRLENBQUMsS0FBRCxDQUFSLENBQWdCLENBQWhCLEVBQW1CbUUsWUFBbkIsSUFBbUNELFdBQVcsQ0FBQzNJLEVBQS9DO0FBQ0F5RSxjQUFRLENBQUMsS0FBRCxDQUFSLENBQWdCLENBQWhCLEVBQW1CbUUsWUFBbkIsSUFBbUNFLFFBQVEsQ0FBQ0gsV0FBVyxDQUFDM0ksRUFBYixFQUFpQixFQUFqQixDQUEzQztBQUNELEtBSkQsTUFJTztBQUNMeUUsY0FBUSxDQUFDbUUsWUFBRCxDQUFSLEdBQXlCRCxXQUFXLENBQUMzSSxFQUFyQztBQUNEOztBQUVELFFBQUloSCxJQUFJLEdBQUcsS0FBSy9DLEtBQUwsQ0FBV2dELE9BQVgsQ0FBbUJ3TCxRQUFuQixFQUE2QjtBQUFDOUwsWUFBTSxFQUFFLEtBQUtqQyxRQUFMLENBQWNnQztBQUF2QixLQUE3QixDQUFYLENBaENBLENBa0NBOztBQUNBLFFBQUksS0FBSzhGLHdCQUFMLElBQWlDLENBQUMsS0FBS0Esd0JBQUwsQ0FBOEJrSyxXQUE5QixFQUEyQ0MsV0FBM0MsRUFBd0QzUCxJQUF4RCxDQUF0QyxFQUFxRztBQUNuRyxZQUFNLElBQUlqRCxNQUFNLENBQUN5QyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGlCQUF0QixDQUFOO0FBQ0QsS0FyQ0QsQ0F1Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxRQUFJbU0sSUFBSSxHQUFHM0wsSUFBSSxHQUFHLEVBQUgsR0FBUXZDLE9BQXZCOztBQUNBLFFBQUksS0FBS21JLG9CQUFULEVBQStCO0FBQzdCK0YsVUFBSSxHQUFHLEtBQUsvRixvQkFBTCxDQUEwQm5JLE9BQTFCLEVBQW1DdUMsSUFBbkMsQ0FBUDtBQUNEOztBQUVELFFBQUlBLElBQUosRUFBVTtBQUNSeU8sOEJBQXdCLENBQUNrQixXQUFELEVBQWMzUCxJQUFJLENBQUNtTCxHQUFuQixDQUF4QjtBQUVBLFVBQUk0RSxRQUFRLEdBQUcsRUFBZjtBQUNBbFEsWUFBTSxDQUFDRCxJQUFQLENBQVkrUCxXQUFaLEVBQXlCN08sT0FBekIsQ0FBaUNDLEdBQUcsSUFDbENnUCxRQUFRLG9CQUFhTCxXQUFiLGNBQTRCM08sR0FBNUIsRUFBUixHQUE2QzRPLFdBQVcsQ0FBQzVPLEdBQUQsQ0FEMUQsRUFKUSxDQVFSO0FBQ0E7O0FBQ0FnUCxjQUFRLG1DQUFRQSxRQUFSLEdBQXFCcEUsSUFBckIsQ0FBUjtBQUNBLFdBQUsxTyxLQUFMLENBQVdrTCxNQUFYLENBQWtCbkksSUFBSSxDQUFDbUwsR0FBdkIsRUFBNEI7QUFDMUIvQixZQUFJLEVBQUUyRztBQURvQixPQUE1QjtBQUlBLGFBQU87QUFDTHpJLFlBQUksRUFBRW9JLFdBREQ7QUFFTG5RLGNBQU0sRUFBRVMsSUFBSSxDQUFDbUw7QUFGUixPQUFQO0FBSUQsS0FuQkQsTUFtQk87QUFDTDtBQUNBbkwsVUFBSSxHQUFHO0FBQUNnSixnQkFBUSxFQUFFO0FBQVgsT0FBUDtBQUNBaEosVUFBSSxDQUFDZ0osUUFBTCxDQUFjMEcsV0FBZCxJQUE2QkMsV0FBN0I7QUFDQSxhQUFPO0FBQ0xySSxZQUFJLEVBQUVvSSxXQUREO0FBRUxuUSxjQUFNLEVBQUUsS0FBS2dQLGFBQUwsQ0FBbUI1QyxJQUFuQixFQUF5QjNMLElBQXpCO0FBRkgsT0FBUDtBQUlEO0FBQ0Y7O0FBRUQ7QUFDQWdRLHdCQUFzQixHQUFHO0FBQ3ZCLFVBQU1DLElBQUksR0FBR0MsY0FBYyxDQUFDQyxVQUFmLENBQTBCLEtBQUtDLHdCQUEvQixDQUFiO0FBQ0EsU0FBS0Esd0JBQUwsR0FBZ0MsSUFBaEM7QUFDQSxXQUFPSCxJQUFQO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBbEwscUJBQW1CLEdBQUc7QUFDcEIsUUFBSSxDQUFDLEtBQUtxTCx3QkFBVixFQUFvQztBQUNsQyxXQUFLQSx3QkFBTCxHQUFnQ0YsY0FBYyxDQUFDRyxPQUFmLENBQXVCO0FBQ3JEOVEsY0FBTSxFQUFFLElBRDZDO0FBRXJEK1EscUJBQWEsRUFBRSxJQUZzQztBQUdyRGhKLFlBQUksRUFBRSxRQUgrQztBQUlyRHZJLFlBQUksRUFBRUEsSUFBSSxJQUFJLENBQUMsT0FBRCxFQUFVLFlBQVYsRUFBd0IsZUFBeEIsRUFBeUMsZ0JBQXpDLEVBQ1hpQyxRQURXLENBQ0ZqQyxJQURFLENBSnVDO0FBTXJEa04sb0JBQVksRUFBR0EsWUFBRCxJQUFrQjtBQU5xQixPQUF2QixFQU83QixDQVA2QixFQU8xQixLQVAwQixDQUFoQztBQVFEO0FBQ0Y7O0FBL3dDZ0Q7O0FBbXhDbkQ7QUFDQTtBQUNBO0FBQ0EsTUFBTWpHLDBCQUEwQixHQUFHLENBQUNySSxVQUFELEVBQWFtSSxPQUFiLEtBQXlCO0FBQzFELFFBQU15SyxhQUFhLEdBQUdDLEtBQUssQ0FBQ0MsS0FBTixDQUFZM0ssT0FBWixDQUF0QjtBQUNBeUssZUFBYSxDQUFDNVMsVUFBZCxHQUEyQkEsVUFBM0I7QUFDQSxTQUFPNFMsYUFBUDtBQUNELENBSkQ7O0FBTUEsTUFBTTNJLGNBQWMsR0FBRyxDQUFDTixJQUFELEVBQU9LLEVBQVAsS0FBYztBQUNuQyxNQUFJTixNQUFKOztBQUNBLE1BQUk7QUFDRkEsVUFBTSxHQUFHTSxFQUFFLEVBQVg7QUFDRCxHQUZELENBR0EsT0FBTzFCLENBQVAsRUFBVTtBQUNSb0IsVUFBTSxHQUFHO0FBQUNsQixXQUFLLEVBQUVGO0FBQVIsS0FBVDtBQUNEOztBQUVELE1BQUlvQixNQUFNLElBQUksQ0FBQ0EsTUFBTSxDQUFDQyxJQUFsQixJQUEwQkEsSUFBOUIsRUFDRUQsTUFBTSxDQUFDQyxJQUFQLEdBQWNBLElBQWQ7QUFFRixTQUFPRCxNQUFQO0FBQ0QsQ0FiRDs7QUFlQSxNQUFNcEQseUJBQXlCLEdBQUdzRSxRQUFRLElBQUk7QUFDNUNBLFVBQVEsQ0FBQ1Qsb0JBQVQsQ0FBOEIsUUFBOUIsRUFBd0MsVUFBVXJLLE9BQVYsRUFBbUI7QUFDekQsV0FBT2lULHlCQUF5QixDQUFDbFEsSUFBMUIsQ0FBK0IsSUFBL0IsRUFBcUMrSCxRQUFyQyxFQUErQzlLLE9BQS9DLENBQVA7QUFDRCxHQUZEO0FBR0QsQ0FKRCxDLENBTUE7OztBQUNBLE1BQU1pVCx5QkFBeUIsR0FBRyxDQUFDbkksUUFBRCxFQUFXOUssT0FBWCxLQUF1QjtBQUN2RCxNQUFJLENBQUNBLE9BQU8sQ0FBQ3dMLE1BQWIsRUFDRSxPQUFPckwsU0FBUDtBQUVGOEssT0FBSyxDQUFDakwsT0FBTyxDQUFDd0wsTUFBVCxFQUFpQnNCLE1BQWpCLENBQUw7O0FBRUEsUUFBTWpDLFdBQVcsR0FBR0MsUUFBUSxDQUFDekIsZUFBVCxDQUF5QnJKLE9BQU8sQ0FBQ3dMLE1BQWpDLENBQXBCLENBTnVELENBUXZEO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBSWpKLElBQUksR0FBR3VJLFFBQVEsQ0FBQ3RMLEtBQVQsQ0FBZWdELE9BQWYsQ0FDVDtBQUFDLCtDQUEyQ3FJO0FBQTVDLEdBRFMsRUFFVDtBQUFDM0ksVUFBTSxFQUFFO0FBQUMsdUNBQWlDO0FBQWxDO0FBQVQsR0FGUyxDQUFYOztBQUlBLE1BQUksQ0FBRUssSUFBTixFQUFZO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBQSxRQUFJLEdBQUd1SSxRQUFRLENBQUN0TCxLQUFULENBQWVnRCxPQUFmLENBQXVCO0FBQzVCb0ksU0FBRyxFQUFFLENBQ0g7QUFBQyxtREFBMkNDO0FBQTVDLE9BREcsRUFFSDtBQUFDLDZDQUFxQzdLLE9BQU8sQ0FBQ3dMO0FBQTlDLE9BRkc7QUFEdUIsS0FBdkIsRUFNUDtBQUNBO0FBQUN0SixZQUFNLEVBQUU7QUFBQyx1Q0FBK0I7QUFBaEM7QUFBVCxLQVBPLENBQVA7QUFRRDs7QUFFRCxNQUFJLENBQUVLLElBQU4sRUFDRSxPQUFPO0FBQ0xtRyxTQUFLLEVBQUUsSUFBSXBKLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsNERBQXRCO0FBREYsR0FBUCxDQWhDcUQsQ0FvQ3ZEO0FBQ0E7QUFDQTs7QUFDQSxNQUFJbVIscUJBQUo7QUFDQSxNQUFJaE0sS0FBSyxHQUFHM0UsSUFBSSxDQUFDZ0osUUFBTCxDQUFjQyxNQUFkLENBQXFCQyxXQUFyQixDQUFpQ1csSUFBakMsQ0FBc0NsRixLQUFLLElBQ3JEQSxLQUFLLENBQUMyRCxXQUFOLEtBQXNCQSxXQURaLENBQVo7O0FBR0EsTUFBSTNELEtBQUosRUFBVztBQUNUZ00seUJBQXFCLEdBQUcsS0FBeEI7QUFDRCxHQUZELE1BRU87QUFDTGhNLFNBQUssR0FBRzNFLElBQUksQ0FBQ2dKLFFBQUwsQ0FBY0MsTUFBZCxDQUFxQkMsV0FBckIsQ0FBaUNXLElBQWpDLENBQXNDbEYsS0FBSyxJQUNqREEsS0FBSyxDQUFDQSxLQUFOLEtBQWdCbEgsT0FBTyxDQUFDd0wsTUFEbEIsQ0FBUjtBQUdBMEgseUJBQXFCLEdBQUcsSUFBeEI7QUFDRDs7QUFFRCxRQUFNMUosWUFBWSxHQUFHc0IsUUFBUSxDQUFDbEcsZ0JBQVQsQ0FBMEJzQyxLQUFLLENBQUNyQyxJQUFoQyxDQUFyQjs7QUFDQSxNQUFJLElBQUlDLElBQUosTUFBYzBFLFlBQWxCLEVBQ0UsT0FBTztBQUNMMUgsVUFBTSxFQUFFUyxJQUFJLENBQUNtTCxHQURSO0FBRUxoRixTQUFLLEVBQUUsSUFBSXBKLE1BQU0sQ0FBQ3lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZ0RBQXRCO0FBRkYsR0FBUCxDQXREcUQsQ0EyRHZEOztBQUNBLE1BQUltUixxQkFBSixFQUEyQjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FwSSxZQUFRLENBQUN0TCxLQUFULENBQWVrTCxNQUFmLENBQ0U7QUFDRWdELFNBQUcsRUFBRW5MLElBQUksQ0FBQ21MLEdBRFo7QUFFRSwyQ0FBcUMxTixPQUFPLENBQUN3TDtBQUYvQyxLQURGLEVBS0U7QUFBQzBELGVBQVMsRUFBRTtBQUNSLHVDQUErQjtBQUM3Qix5QkFBZXJFLFdBRGM7QUFFN0Isa0JBQVEzRCxLQUFLLENBQUNyQztBQUZlO0FBRHZCO0FBQVosS0FMRixFQU55QixDQW1CekI7QUFDQTtBQUNBOztBQUNBaUcsWUFBUSxDQUFDdEwsS0FBVCxDQUFla0wsTUFBZixDQUFzQm5JLElBQUksQ0FBQ21MLEdBQTNCLEVBQWdDO0FBQzlCL0MsV0FBSyxFQUFFO0FBQ0wsdUNBQStCO0FBQUUsbUJBQVMzSyxPQUFPLENBQUN3TDtBQUFuQjtBQUQxQjtBQUR1QixLQUFoQztBQUtEOztBQUVELFNBQU87QUFDTDFKLFVBQU0sRUFBRVMsSUFBSSxDQUFDbUwsR0FEUjtBQUVMMUUscUJBQWlCLEVBQUU7QUFDakI5QixXQUFLLEVBQUVsSCxPQUFPLENBQUN3TCxNQURFO0FBRWpCM0csVUFBSSxFQUFFcUMsS0FBSyxDQUFDckM7QUFGSztBQUZkLEdBQVA7QUFPRCxDQWhHRDs7QUFrR0EsTUFBTXdMLG1CQUFtQixHQUFHLENBQzFCdkYsUUFEMEIsRUFFMUJtRixlQUYwQixFQUcxQkUsV0FIMEIsRUFJMUJyTyxNQUowQixLQUt2QjtBQUNILFFBQU0wTyxVQUFVLEdBQUcxTyxNQUFNLEdBQUc7QUFBQzRMLE9BQUcsRUFBRTVMO0FBQU4sR0FBSCxHQUFtQixFQUE1QztBQUNBLFFBQU1xUixZQUFZLEdBQUc7QUFDbkJ2SSxPQUFHLEVBQUUsQ0FDSDtBQUFFLHNDQUFnQztBQUFFNkYsV0FBRyxFQUFFUjtBQUFQO0FBQWxDLEtBREcsRUFFSDtBQUFFLHNDQUFnQztBQUFFUSxXQUFHLEVBQUUsQ0FBQ1I7QUFBUjtBQUFsQyxLQUZHO0FBRGMsR0FBckI7QUFNQSxRQUFNbUQsWUFBWSxHQUFHO0FBQUVDLFFBQUksRUFBRSxDQUFDbEQsV0FBRCxFQUFjZ0QsWUFBZDtBQUFSLEdBQXJCO0FBRUFySSxVQUFRLENBQUN0TCxLQUFULENBQWVrTCxNQUFmLGlDQUEwQjhGLFVBQTFCLEdBQXlDNEMsWUFBekMsR0FBd0Q7QUFDdER2QixVQUFNLEVBQUU7QUFDTixpQ0FBMkI7QUFEckI7QUFEOEMsR0FBeEQsRUFJRztBQUFFbkIsU0FBSyxFQUFFO0FBQVQsR0FKSDtBQUtELENBcEJEOztBQXNCQSxNQUFNakssdUJBQXVCLEdBQUdxRSxRQUFRLElBQUk7QUFDMUNBLFVBQVEsQ0FBQzhGLG1CQUFULEdBQStCdFIsTUFBTSxDQUFDZ1UsV0FBUCxDQUFtQixNQUFNO0FBQ3REeEksWUFBUSxDQUFDeUYsYUFBVDs7QUFDQXpGLFlBQVEsQ0FBQ2tGLDBCQUFUOztBQUNBbEYsWUFBUSxDQUFDd0YsMkJBQVQ7QUFDRCxHQUo4QixFQUk1QnpRLHlCQUo0QixDQUEvQjtBQUtELENBTkQsQyxDQVFBO0FBQ0E7QUFDQTs7O0FBRUEsTUFBTW9ELGVBQWUsR0FDbkJ2QixPQUFPLENBQUMsa0JBQUQsQ0FBUCxJQUNBQSxPQUFPLENBQUMsa0JBQUQsQ0FBUCxDQUE0QnVCLGVBRjlCOztBQUlBLE1BQU1nSyxvQkFBb0IsR0FBRyxNQUFNO0FBQ2pDLFNBQU9oSyxlQUFlLElBQUlBLGVBQWUsQ0FBQ3NRLFdBQWhCLEVBQTFCO0FBQ0QsQ0FGRCxDLENBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU12Qyx3QkFBd0IsR0FBRyxDQUFDa0IsV0FBRCxFQUFjcFEsTUFBZCxLQUF5QjtBQUN4RE0sUUFBTSxDQUFDRCxJQUFQLENBQVkrUCxXQUFaLEVBQXlCN08sT0FBekIsQ0FBaUNDLEdBQUcsSUFBSTtBQUN0QyxRQUFJcUwsS0FBSyxHQUFHdUQsV0FBVyxDQUFDNU8sR0FBRCxDQUF2QjtBQUNBLFFBQUlMLGVBQWUsSUFBSUEsZUFBZSxDQUFDdVEsUUFBaEIsQ0FBeUI3RSxLQUF6QixDQUF2QixFQUNFQSxLQUFLLEdBQUcxTCxlQUFlLENBQUNrSyxJQUFoQixDQUFxQmxLLGVBQWUsQ0FBQ3dRLElBQWhCLENBQXFCOUUsS0FBckIsQ0FBckIsRUFBa0Q3TSxNQUFsRCxDQUFSO0FBQ0ZvUSxlQUFXLENBQUM1TyxHQUFELENBQVgsR0FBbUJxTCxLQUFuQjtBQUNELEdBTEQ7QUFNRCxDQVBELEMsQ0FVQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQXJQLE1BQU0sQ0FBQ2tDLE9BQVAsQ0FBZSxNQUFNO0FBQ25CLE1BQUksQ0FBRXlMLG9CQUFvQixFQUExQixFQUE4QjtBQUM1QjtBQUNEOztBQUVELFFBQU07QUFBRXhMO0FBQUYsTUFBMkJDLE9BQU8sQ0FBQyx1QkFBRCxDQUF4QztBQUVBRCxzQkFBb0IsQ0FBQ0csY0FBckIsQ0FBb0N3SyxJQUFwQyxDQUF5QztBQUN2Q2lILFFBQUksRUFBRSxDQUFDO0FBQ0xuRyxZQUFNLEVBQUU7QUFBRWtELGVBQU8sRUFBRTtBQUFYO0FBREgsS0FBRCxFQUVIO0FBQ0QsMEJBQW9CO0FBQUVBLGVBQU8sRUFBRTtBQUFYO0FBRG5CLEtBRkc7QUFEaUMsR0FBekMsRUFNRy9NLE9BTkgsQ0FNV1osTUFBTSxJQUFJO0FBQ25CaEIsd0JBQW9CLENBQUNHLGNBQXJCLENBQW9DOEksTUFBcEMsQ0FBMkNqSSxNQUFNLENBQUNpTCxHQUFsRCxFQUF1RDtBQUNyRC9CLFVBQUksRUFBRTtBQUNKdUIsY0FBTSxFQUFFakssZUFBZSxDQUFDa0ssSUFBaEIsQ0FBcUIxSyxNQUFNLENBQUN5SyxNQUE1QjtBQURKO0FBRCtDLEtBQXZEO0FBS0QsR0FaRDtBQWFELENBcEJELEUsQ0FzQkE7QUFDQTs7QUFDQSxNQUFNZ0UscUJBQXFCLEdBQUcsQ0FBQ2xSLE9BQUQsRUFBVXVDLElBQVYsS0FBbUI7QUFDL0MsTUFBSXZDLE9BQU8sQ0FBQytGLE9BQVosRUFDRXhELElBQUksQ0FBQ3dELE9BQUwsR0FBZS9GLE9BQU8sQ0FBQytGLE9BQXZCO0FBQ0YsU0FBT3hELElBQVA7QUFDRCxDQUpELEMsQ0FNQTs7O0FBQ0EsU0FBU3FFLDBCQUFULENBQW9DckUsSUFBcEMsRUFBMEM7QUFDeEMsUUFBTWdQLE1BQU0sR0FBRyxLQUFLdFIsUUFBTCxDQUFjdVIsNkJBQTdCOztBQUNBLE1BQUksQ0FBQ0QsTUFBTCxFQUFhO0FBQ1gsV0FBTyxJQUFQO0FBQ0Q7O0FBRUQsTUFBSW1DLFdBQVcsR0FBRyxLQUFsQjs7QUFDQSxNQUFJblIsSUFBSSxDQUFDMEQsTUFBTCxJQUFlMUQsSUFBSSxDQUFDMEQsTUFBTCxDQUFZNUQsTUFBWixHQUFxQixDQUF4QyxFQUEyQztBQUN6Q3FSLGVBQVcsR0FBR25SLElBQUksQ0FBQzBELE1BQUwsQ0FBWTRILE1BQVosQ0FDWixDQUFDQyxJQUFELEVBQU93RCxLQUFQLEtBQWlCeEQsSUFBSSxJQUFJLEtBQUt1RCxnQkFBTCxDQUFzQkMsS0FBSyxDQUFDcUMsT0FBNUIsQ0FEYixFQUNtRCxLQURuRCxDQUFkO0FBR0QsR0FKRCxNQUlPLElBQUlwUixJQUFJLENBQUNnSixRQUFMLElBQWlCbkosTUFBTSxDQUFDd1IsTUFBUCxDQUFjclIsSUFBSSxDQUFDZ0osUUFBbkIsRUFBNkJsSixNQUE3QixHQUFzQyxDQUEzRCxFQUE4RDtBQUNuRTtBQUNBcVIsZUFBVyxHQUFHdFIsTUFBTSxDQUFDd1IsTUFBUCxDQUFjclIsSUFBSSxDQUFDZ0osUUFBbkIsRUFBNkJzQyxNQUE3QixDQUNaLENBQUNDLElBQUQsRUFBT2pCLE9BQVAsS0FBbUJBLE9BQU8sQ0FBQ3lFLEtBQVIsSUFBaUIsS0FBS0QsZ0JBQUwsQ0FBc0J4RSxPQUFPLENBQUN5RSxLQUE5QixDQUR4QixFQUVaLEtBRlksQ0FBZDtBQUlEOztBQUVELE1BQUlvQyxXQUFKLEVBQWlCO0FBQ2YsV0FBTyxJQUFQO0FBQ0Q7O0FBRUQsTUFBSSxPQUFPbkMsTUFBUCxLQUFrQixRQUF0QixFQUFnQztBQUM5QixVQUFNLElBQUlqUyxNQUFNLENBQUN5QyxLQUFYLENBQWlCLEdBQWpCLGFBQTBCd1AsTUFBMUIscUJBQU47QUFDRCxHQUZELE1BRU87QUFDTCxVQUFNLElBQUlqUyxNQUFNLENBQUN5QyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLG1DQUF0QixDQUFOO0FBQ0Q7QUFDRjs7QUFFRCxNQUFNd0Usb0JBQW9CLEdBQUcvRyxLQUFLLElBQUk7QUFDcEM7QUFDQTtBQUNBO0FBQ0FBLE9BQUssQ0FBQ3FVLEtBQU4sQ0FBWTtBQUNWO0FBQ0E7QUFDQW5KLFVBQU0sRUFBRSxDQUFDNUksTUFBRCxFQUFTUyxJQUFULEVBQWVMLE1BQWYsRUFBdUI0UixRQUF2QixLQUFvQztBQUMxQztBQUNBLFVBQUl2UixJQUFJLENBQUNtTCxHQUFMLEtBQWE1TCxNQUFqQixFQUF5QjtBQUN2QixlQUFPLEtBQVA7QUFDRCxPQUp5QyxDQU0xQztBQUNBO0FBQ0E7OztBQUNBLFVBQUlJLE1BQU0sQ0FBQ0csTUFBUCxLQUFrQixDQUFsQixJQUF1QkgsTUFBTSxDQUFDLENBQUQsQ0FBTixLQUFjLFNBQXpDLEVBQW9EO0FBQ2xELGVBQU8sS0FBUDtBQUNEOztBQUVELGFBQU8sSUFBUDtBQUNELEtBakJTO0FBa0JWNlIsU0FBSyxFQUFFLENBQUMsS0FBRCxDQWxCRyxDQWtCSzs7QUFsQkwsR0FBWixFQUpvQyxDQXlCcEM7O0FBQ0F2VSxPQUFLLENBQUN3VSxZQUFOLENBQW1CLFVBQW5CLEVBQStCO0FBQUVDLFVBQU0sRUFBRSxJQUFWO0FBQWdCQyxVQUFNLEVBQUU7QUFBeEIsR0FBL0I7O0FBQ0ExVSxPQUFLLENBQUN3VSxZQUFOLENBQW1CLGdCQUFuQixFQUFxQztBQUFFQyxVQUFNLEVBQUUsSUFBVjtBQUFnQkMsVUFBTSxFQUFFO0FBQXhCLEdBQXJDOztBQUNBMVUsT0FBSyxDQUFDd1UsWUFBTixDQUFtQix5Q0FBbkIsRUFDRTtBQUFFQyxVQUFNLEVBQUUsSUFBVjtBQUFnQkMsVUFBTSxFQUFFO0FBQXhCLEdBREY7O0FBRUExVSxPQUFLLENBQUN3VSxZQUFOLENBQW1CLG1DQUFuQixFQUNFO0FBQUVDLFVBQU0sRUFBRSxJQUFWO0FBQWdCQyxVQUFNLEVBQUU7QUFBeEIsR0FERixFQTlCb0MsQ0FnQ3BDO0FBQ0E7OztBQUNBMVUsT0FBSyxDQUFDd1UsWUFBTixDQUFtQix5Q0FBbkIsRUFDRTtBQUFFRSxVQUFNLEVBQUU7QUFBVixHQURGLEVBbENvQyxDQW9DcEM7OztBQUNBMVUsT0FBSyxDQUFDd1UsWUFBTixDQUFtQixrQ0FBbkIsRUFBdUQ7QUFBRUUsVUFBTSxFQUFFO0FBQVYsR0FBdkQsRUFyQ29DLENBc0NwQzs7O0FBQ0ExVSxPQUFLLENBQUN3VSxZQUFOLENBQW1CLDhCQUFuQixFQUFtRDtBQUFFRSxVQUFNLEVBQUU7QUFBVixHQUFuRDtBQUNELENBeENELEMiLCJmaWxlIjoiL3BhY2thZ2VzL2FjY291bnRzLWJhc2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY2NvdW50c1NlcnZlciB9IGZyb20gXCIuL2FjY291bnRzX3NlcnZlci5qc1wiO1xuXG4vKipcbiAqIEBuYW1lc3BhY2UgQWNjb3VudHNcbiAqIEBzdW1tYXJ5IFRoZSBuYW1lc3BhY2UgZm9yIGFsbCBzZXJ2ZXItc2lkZSBhY2NvdW50cy1yZWxhdGVkIG1ldGhvZHMuXG4gKi9cbkFjY291bnRzID0gbmV3IEFjY291bnRzU2VydmVyKE1ldGVvci5zZXJ2ZXIpO1xuXG4vLyBVc2VycyB0YWJsZS4gRG9uJ3QgdXNlIHRoZSBub3JtYWwgYXV0b3B1Ymxpc2gsIHNpbmNlIHdlIHdhbnQgdG8gaGlkZVxuLy8gc29tZSBmaWVsZHMuIENvZGUgdG8gYXV0b3B1Ymxpc2ggdGhpcyBpcyBpbiBhY2NvdW50c19zZXJ2ZXIuanMuXG4vLyBYWFggQWxsb3cgdXNlcnMgdG8gY29uZmlndXJlIHRoaXMgY29sbGVjdGlvbiBuYW1lLlxuXG4vKipcbiAqIEBzdW1tYXJ5IEEgW01vbmdvLkNvbGxlY3Rpb25dKCNjb2xsZWN0aW9ucykgY29udGFpbmluZyB1c2VyIGRvY3VtZW50cy5cbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQHR5cGUge01vbmdvLkNvbGxlY3Rpb259XG4gKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4qL1xuTWV0ZW9yLnVzZXJzID0gQWNjb3VudHMudXNlcnM7XG5cbmV4cG9ydCB7XG4gIC8vIFNpbmNlIHRoaXMgZmlsZSBpcyB0aGUgbWFpbiBtb2R1bGUgZm9yIHRoZSBzZXJ2ZXIgdmVyc2lvbiBvZiB0aGVcbiAgLy8gYWNjb3VudHMtYmFzZSBwYWNrYWdlLCBwcm9wZXJ0aWVzIG9mIG5vbi1lbnRyeS1wb2ludCBtb2R1bGVzIG5lZWQgdG9cbiAgLy8gYmUgcmUtZXhwb3J0ZWQgaW4gb3JkZXIgdG8gYmUgYWNjZXNzaWJsZSB0byBtb2R1bGVzIHRoYXQgaW1wb3J0IHRoZVxuICAvLyBhY2NvdW50cy1iYXNlIHBhY2thZ2UuXG4gIEFjY291bnRzU2VydmVyXG59O1xuIiwiLyoqXG4gKiBAc3VtbWFyeSBTdXBlci1jb25zdHJ1Y3RvciBmb3IgQWNjb3VudHNDbGllbnQgYW5kIEFjY291bnRzU2VydmVyLlxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAY2xhc3MgQWNjb3VudHNDb21tb25cbiAqIEBpbnN0YW5jZW5hbWUgYWNjb3VudHNDbGllbnRPclNlcnZlclxuICogQHBhcmFtIG9wdGlvbnMge09iamVjdH0gYW4gb2JqZWN0IHdpdGggZmllbGRzOlxuICogLSBjb25uZWN0aW9uIHtPYmplY3R9IE9wdGlvbmFsIEREUCBjb25uZWN0aW9uIHRvIHJldXNlLlxuICogLSBkZHBVcmwge1N0cmluZ30gT3B0aW9uYWwgVVJMIGZvciBjcmVhdGluZyBhIG5ldyBERFAgY29ubmVjdGlvbi5cbiAqL1xuZXhwb3J0IGNsYXNzIEFjY291bnRzQ29tbW9uIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIC8vIEN1cnJlbnRseSB0aGlzIGlzIHJlYWQgZGlyZWN0bHkgYnkgcGFja2FnZXMgbGlrZSBhY2NvdW50cy1wYXNzd29yZFxuICAgIC8vIGFuZCBhY2NvdW50cy11aS11bnN0eWxlZC5cbiAgICB0aGlzLl9vcHRpb25zID0ge307XG5cbiAgICAvLyBOb3RlIHRoYXQgc2V0dGluZyB0aGlzLmNvbm5lY3Rpb24gPSBudWxsIGNhdXNlcyB0aGlzLnVzZXJzIHRvIGJlIGFcbiAgICAvLyBMb2NhbENvbGxlY3Rpb24sIHdoaWNoIGlzIG5vdCB3aGF0IHdlIHdhbnQuXG4gICAgdGhpcy5jb25uZWN0aW9uID0gdW5kZWZpbmVkO1xuICAgIHRoaXMuX2luaXRDb25uZWN0aW9uKG9wdGlvbnMgfHwge30pO1xuXG4gICAgLy8gVGhlcmUgaXMgYW4gYWxsb3cgY2FsbCBpbiBhY2NvdW50c19zZXJ2ZXIuanMgdGhhdCByZXN0cmljdHMgd3JpdGVzIHRvXG4gICAgLy8gdGhpcyBjb2xsZWN0aW9uLlxuICAgIHRoaXMudXNlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInVzZXJzXCIsIHtcbiAgICAgIF9wcmV2ZW50QXV0b3B1Ymxpc2g6IHRydWUsXG4gICAgICBjb25uZWN0aW9uOiB0aGlzLmNvbm5lY3Rpb25cbiAgICB9KTtcblxuICAgIC8vIENhbGxiYWNrIGV4Y2VwdGlvbnMgYXJlIHByaW50ZWQgd2l0aCBNZXRlb3IuX2RlYnVnIGFuZCBpZ25vcmVkLlxuICAgIHRoaXMuX29uTG9naW5Ib29rID0gbmV3IEhvb2soe1xuICAgICAgYmluZEVudmlyb25tZW50OiBmYWxzZSxcbiAgICAgIGRlYnVnUHJpbnRFeGNlcHRpb25zOiBcIm9uTG9naW4gY2FsbGJhY2tcIlxuICAgIH0pO1xuXG4gICAgdGhpcy5fb25Mb2dpbkZhaWx1cmVIb29rID0gbmV3IEhvb2soe1xuICAgICAgYmluZEVudmlyb25tZW50OiBmYWxzZSxcbiAgICAgIGRlYnVnUHJpbnRFeGNlcHRpb25zOiBcIm9uTG9naW5GYWlsdXJlIGNhbGxiYWNrXCJcbiAgICB9KTtcblxuICAgIHRoaXMuX29uTG9nb3V0SG9vayA9IG5ldyBIb29rKHtcbiAgICAgIGJpbmRFbnZpcm9ubWVudDogZmFsc2UsXG4gICAgICBkZWJ1Z1ByaW50RXhjZXB0aW9uczogXCJvbkxvZ291dCBjYWxsYmFja1wiXG4gICAgfSk7XG5cbiAgICAvLyBFeHBvc2UgZm9yIHRlc3RpbmcuXG4gICAgdGhpcy5ERUZBVUxUX0xPR0lOX0VYUElSQVRJT05fREFZUyA9IERFRkFVTFRfTE9HSU5fRVhQSVJBVElPTl9EQVlTO1xuICAgIHRoaXMuTE9HSU5fVU5FWFBJUklOR19UT0tFTl9EQVlTID0gTE9HSU5fVU5FWFBJUklOR19UT0tFTl9EQVlTO1xuXG4gICAgLy8gVGhyb3duIHdoZW4gdGhlIHVzZXIgY2FuY2VscyB0aGUgbG9naW4gcHJvY2VzcyAoZWcsIGNsb3NlcyBhbiBvYXV0aFxuICAgIC8vIHBvcHVwLCBkZWNsaW5lcyByZXRpbmEgc2NhbiwgZXRjKVxuICAgIGNvbnN0IGxjZU5hbWUgPSAnQWNjb3VudHMuTG9naW5DYW5jZWxsZWRFcnJvcic7XG4gICAgdGhpcy5Mb2dpbkNhbmNlbGxlZEVycm9yID0gTWV0ZW9yLm1ha2VFcnJvclR5cGUoXG4gICAgICBsY2VOYW1lLFxuICAgICAgZnVuY3Rpb24gKGRlc2NyaXB0aW9uKSB7XG4gICAgICAgIHRoaXMubWVzc2FnZSA9IGRlc2NyaXB0aW9uO1xuICAgICAgfVxuICAgICk7XG4gICAgdGhpcy5Mb2dpbkNhbmNlbGxlZEVycm9yLnByb3RvdHlwZS5uYW1lID0gbGNlTmFtZTtcblxuICAgIC8vIFRoaXMgaXMgdXNlZCB0byB0cmFuc21pdCBzcGVjaWZpYyBzdWJjbGFzcyBlcnJvcnMgb3ZlciB0aGUgd2lyZS4gV2VcbiAgICAvLyBzaG91bGQgY29tZSB1cCB3aXRoIGEgbW9yZSBnZW5lcmljIHdheSB0byBkbyB0aGlzIChlZywgd2l0aCBzb21lIHNvcnQgb2ZcbiAgICAvLyBzeW1ib2xpYyBlcnJvciBjb2RlIHJhdGhlciB0aGFuIGEgbnVtYmVyKS5cbiAgICB0aGlzLkxvZ2luQ2FuY2VsbGVkRXJyb3IubnVtZXJpY0Vycm9yID0gMHg4YWNkYzJmO1xuXG4gICAgLy8gbG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbiBhbmQgQ29uZmlnRXJyb3IgYXJlIG1haW50YWluZWQgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5XG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgICAgY29uc3QgeyBTZXJ2aWNlQ29uZmlndXJhdGlvbiB9ID0gUGFja2FnZVsnc2VydmljZS1jb25maWd1cmF0aW9uJ107XG4gICAgICB0aGlzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24gPSBTZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucztcbiAgICAgIHRoaXMuQ29uZmlnRXJyb3IgPSBTZXJ2aWNlQ29uZmlndXJhdGlvbi5Db25maWdFcnJvcjtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBHZXQgdGhlIGN1cnJlbnQgdXNlciBpZCwgb3IgYG51bGxgIGlmIG5vIHVzZXIgaXMgbG9nZ2VkIGluLiBBIHJlYWN0aXZlIGRhdGEgc291cmNlLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICovXG4gIHVzZXJJZCgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VySWQgbWV0aG9kIG5vdCBpbXBsZW1lbnRlZFwiKTtcbiAgfVxuXG4gIC8vIG1lcmdlIHRoZSBkZWZhdWx0RmllbGRTZWxlY3RvciB3aXRoIGFuIGV4aXN0aW5nIG9wdGlvbnMgb2JqZWN0XG4gIF9hZGREZWZhdWx0RmllbGRTZWxlY3RvcihvcHRpb25zID0ge30pIHtcbiAgICAvLyB0aGlzIHdpbGwgYmUgdGhlIG1vc3QgY29tbW9uIGNhc2UgZm9yIG1vc3QgcGVvcGxlLCBzbyBtYWtlIGl0IHF1aWNrXG4gICAgaWYgKCF0aGlzLl9vcHRpb25zLmRlZmF1bHRGaWVsZFNlbGVjdG9yKSByZXR1cm4gb3B0aW9ucztcblxuICAgIC8vIGlmIG5vIGZpZWxkIHNlbGVjdG9yIHRoZW4ganVzdCB1c2UgZGVmYXVsdEZpZWxkU2VsZWN0b3JcbiAgICBpZiAoIW9wdGlvbnMuZmllbGRzKSByZXR1cm4ge1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIGZpZWxkczogdGhpcy5fb3B0aW9ucy5kZWZhdWx0RmllbGRTZWxlY3RvcixcbiAgICB9O1xuXG4gICAgLy8gaWYgZW1wdHkgZmllbGQgc2VsZWN0b3IgdGhlbiB0aGUgZnVsbCB1c2VyIG9iamVjdCBpcyBleHBsaWNpdGx5IHJlcXVlc3RlZCwgc28gb2JleVxuICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zLmZpZWxkcyk7XG4gICAgaWYgKCFrZXlzLmxlbmd0aCkgcmV0dXJuIG9wdGlvbnM7XG5cbiAgICAvLyBpZiB0aGUgcmVxdWVzdGVkIGZpZWxkcyBhcmUgK3ZlIHRoZW4gaWdub3JlIGRlZmF1bHRGaWVsZFNlbGVjdG9yXG4gICAgLy8gYXNzdW1lIHRoZXkgYXJlIGFsbCBlaXRoZXIgK3ZlIG9yIC12ZSBiZWNhdXNlIE1vbmdvIGRvZXNuJ3QgbGlrZSBtaXhlZFxuICAgIGlmICghIW9wdGlvbnMuZmllbGRzW2tleXNbMF1dKSByZXR1cm4gb3B0aW9ucztcblxuICAgIC8vIFRoZSByZXF1ZXN0ZWQgZmllbGRzIGFyZSAtdmUuXG4gICAgLy8gSWYgdGhlIGRlZmF1bHRGaWVsZFNlbGVjdG9yIGlzICt2ZSB0aGVuIHVzZSByZXF1ZXN0ZWQgZmllbGRzLCBvdGhlcndpc2UgbWVyZ2UgdGhlbVxuICAgIGNvbnN0IGtleXMyID0gT2JqZWN0LmtleXModGhpcy5fb3B0aW9ucy5kZWZhdWx0RmllbGRTZWxlY3Rvcik7XG4gICAgcmV0dXJuIHRoaXMuX29wdGlvbnMuZGVmYXVsdEZpZWxkU2VsZWN0b3Jba2V5czJbMF1dID8gb3B0aW9ucyA6IHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBmaWVsZHM6IHtcbiAgICAgICAgLi4ub3B0aW9ucy5maWVsZHMsXG4gICAgICAgIC4uLnRoaXMuX29wdGlvbnMuZGVmYXVsdEZpZWxkU2VsZWN0b3IsXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEdldCB0aGUgY3VycmVudCB1c2VyIHJlY29yZCwgb3IgYG51bGxgIGlmIG5vIHVzZXIgaXMgbG9nZ2VkIGluLiBBIHJlYWN0aXZlIGRhdGEgc291cmNlLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgKiBAcGFyYW0ge01vbmdvRmllbGRTcGVjaWZpZXJ9IG9wdGlvbnMuZmllbGRzIERpY3Rpb25hcnkgb2YgZmllbGRzIHRvIHJldHVybiBvciBleGNsdWRlLlxuICAgKi9cbiAgdXNlcihvcHRpb25zKSB7XG4gICAgY29uc3QgdXNlcklkID0gdGhpcy51c2VySWQoKTtcbiAgICByZXR1cm4gdXNlcklkID8gdGhpcy51c2Vycy5maW5kT25lKHVzZXJJZCwgdGhpcy5fYWRkRGVmYXVsdEZpZWxkU2VsZWN0b3Iob3B0aW9ucykpIDogbnVsbDtcbiAgfVxuXG4gIC8vIFNldCB1cCBjb25maWcgZm9yIHRoZSBhY2NvdW50cyBzeXN0ZW0uIENhbGwgdGhpcyBvbiBib3RoIHRoZSBjbGllbnRcbiAgLy8gYW5kIHRoZSBzZXJ2ZXIuXG4gIC8vXG4gIC8vIE5vdGUgdGhhdCB0aGlzIG1ldGhvZCBnZXRzIG92ZXJyaWRkZW4gb24gQWNjb3VudHNTZXJ2ZXIucHJvdG90eXBlLCBidXRcbiAgLy8gdGhlIG92ZXJyaWRpbmcgbWV0aG9kIGNhbGxzIHRoZSBvdmVycmlkZGVuIG1ldGhvZC5cbiAgLy9cbiAgLy8gWFhYIHdlIHNob3VsZCBhZGQgc29tZSBlbmZvcmNlbWVudCB0aGF0IHRoaXMgaXMgY2FsbGVkIG9uIGJvdGggdGhlXG4gIC8vIGNsaWVudCBhbmQgdGhlIHNlcnZlci4gT3RoZXJ3aXNlLCBhIHVzZXIgY2FuXG4gIC8vICdmb3JiaWRDbGllbnRBY2NvdW50Q3JlYXRpb24nIG9ubHkgb24gdGhlIGNsaWVudCBhbmQgd2hpbGUgaXQgbG9va3NcbiAgLy8gbGlrZSB0aGVpciBhcHAgaXMgc2VjdXJlLCB0aGUgc2VydmVyIHdpbGwgc3RpbGwgYWNjZXB0IGNyZWF0ZVVzZXJcbiAgLy8gY2FsbHMuIGh0dHBzOi8vZ2l0aHViLmNvbS9tZXRlb3IvbWV0ZW9yL2lzc3Vlcy84MjhcbiAgLy9cbiAgLy8gQHBhcmFtIG9wdGlvbnMge09iamVjdH0gYW4gb2JqZWN0IHdpdGggZmllbGRzOlxuICAvLyAtIHNlbmRWZXJpZmljYXRpb25FbWFpbCB7Qm9vbGVhbn1cbiAgLy8gICAgIFNlbmQgZW1haWwgYWRkcmVzcyB2ZXJpZmljYXRpb24gZW1haWxzIHRvIG5ldyB1c2VycyBjcmVhdGVkIGZyb21cbiAgLy8gICAgIGNsaWVudCBzaWdudXBzLlxuICAvLyAtIGZvcmJpZENsaWVudEFjY291bnRDcmVhdGlvbiB7Qm9vbGVhbn1cbiAgLy8gICAgIERvIG5vdCBhbGxvdyBjbGllbnRzIHRvIGNyZWF0ZSBhY2NvdW50cyBkaXJlY3RseS5cbiAgLy8gLSByZXN0cmljdENyZWF0aW9uQnlFbWFpbERvbWFpbiB7RnVuY3Rpb24gb3IgU3RyaW5nfVxuICAvLyAgICAgUmVxdWlyZSBjcmVhdGVkIHVzZXJzIHRvIGhhdmUgYW4gZW1haWwgbWF0Y2hpbmcgdGhlIGZ1bmN0aW9uIG9yXG4gIC8vICAgICBoYXZpbmcgdGhlIHN0cmluZyBhcyBkb21haW4uXG4gIC8vIC0gbG9naW5FeHBpcmF0aW9uSW5EYXlzIHtOdW1iZXJ9XG4gIC8vICAgICBOdW1iZXIgb2YgZGF5cyBzaW5jZSBsb2dpbiB1bnRpbCBhIHVzZXIgaXMgbG9nZ2VkIG91dCAobG9naW4gdG9rZW5cbiAgLy8gICAgIGV4cGlyZXMpLlxuICAvLyAtIHBhc3N3b3JkUmVzZXRUb2tlbkV4cGlyYXRpb25JbkRheXMge051bWJlcn1cbiAgLy8gICAgIE51bWJlciBvZiBkYXlzIHNpbmNlIHBhc3N3b3JkIHJlc2V0IHRva2VuIGNyZWF0aW9uIHVudGlsIHRoZVxuICAvLyAgICAgdG9rZW4gY2FubnQgYmUgdXNlZCBhbnkgbG9uZ2VyIChwYXNzd29yZCByZXNldCB0b2tlbiBleHBpcmVzKS5cbiAgLy8gLSBhbWJpZ3VvdXNFcnJvck1lc3NhZ2VzIHtCb29sZWFufVxuICAvLyAgICAgUmV0dXJuIGFtYmlndW91cyBlcnJvciBtZXNzYWdlcyBmcm9tIGxvZ2luIGZhaWx1cmVzIHRvIHByZXZlbnRcbiAgLy8gICAgIHVzZXIgZW51bWVyYXRpb24uXG4gIC8vIC0gYmNyeXB0Um91bmRzIHtOdW1iZXJ9XG4gIC8vICAgICBBbGxvd3Mgb3ZlcnJpZGUgb2YgbnVtYmVyIG9mIGJjcnlwdCByb3VuZHMgKGFrYSB3b3JrIGZhY3RvcikgdXNlZFxuICAvLyAgICAgdG8gc3RvcmUgcGFzc3dvcmRzLlxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBTZXQgZ2xvYmFsIGFjY291bnRzIG9wdGlvbnMuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsIE5ldyB1c2VycyB3aXRoIGFuIGVtYWlsIGFkZHJlc3Mgd2lsbCByZWNlaXZlIGFuIGFkZHJlc3MgdmVyaWZpY2F0aW9uIGVtYWlsLlxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMuZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uIENhbGxzIHRvIFtgY3JlYXRlVXNlcmBdKCNhY2NvdW50c19jcmVhdGV1c2VyKSBmcm9tIHRoZSBjbGllbnQgd2lsbCBiZSByZWplY3RlZC4gSW4gYWRkaXRpb24sIGlmIHlvdSBhcmUgdXNpbmcgW2FjY291bnRzLXVpXSgjYWNjb3VudHN1aSksIHRoZSBcIkNyZWF0ZSBhY2NvdW50XCIgbGluayB3aWxsIG5vdCBiZSBhdmFpbGFibGUuXG4gICAqIEBwYXJhbSB7U3RyaW5nIHwgRnVuY3Rpb259IG9wdGlvbnMucmVzdHJpY3RDcmVhdGlvbkJ5RW1haWxEb21haW4gSWYgc2V0IHRvIGEgc3RyaW5nLCBvbmx5IGFsbG93cyBuZXcgdXNlcnMgaWYgdGhlIGRvbWFpbiBwYXJ0IG9mIHRoZWlyIGVtYWlsIGFkZHJlc3MgbWF0Y2hlcyB0aGUgc3RyaW5nLiBJZiBzZXQgdG8gYSBmdW5jdGlvbiwgb25seSBhbGxvd3MgbmV3IHVzZXJzIGlmIHRoZSBmdW5jdGlvbiByZXR1cm5zIHRydWUuICBUaGUgZnVuY3Rpb24gaXMgcGFzc2VkIHRoZSBmdWxsIGVtYWlsIGFkZHJlc3Mgb2YgdGhlIHByb3Bvc2VkIG5ldyB1c2VyLiAgV29ya3Mgd2l0aCBwYXNzd29yZC1iYXNlZCBzaWduLWluIGFuZCBleHRlcm5hbCBzZXJ2aWNlcyB0aGF0IGV4cG9zZSBlbWFpbCBhZGRyZXNzZXMgKEdvb2dsZSwgRmFjZWJvb2ssIEdpdEh1YikuIEFsbCBleGlzdGluZyB1c2VycyBzdGlsbCBjYW4gbG9nIGluIGFmdGVyIGVuYWJsaW5nIHRoaXMgb3B0aW9uLiBFeGFtcGxlOiBgQWNjb3VudHMuY29uZmlnKHsgcmVzdHJpY3RDcmVhdGlvbkJ5RW1haWxEb21haW46ICdzY2hvb2wuZWR1JyB9KWAuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLmxvZ2luRXhwaXJhdGlvbkluRGF5cyBUaGUgbnVtYmVyIG9mIGRheXMgZnJvbSB3aGVuIGEgdXNlciBsb2dzIGluIHVudGlsIHRoZWlyIHRva2VuIGV4cGlyZXMgYW5kIHRoZXkgYXJlIGxvZ2dlZCBvdXQuIERlZmF1bHRzIHRvIDkwLiBTZXQgdG8gYG51bGxgIHRvIGRpc2FibGUgbG9naW4gZXhwaXJhdGlvbi5cbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdGlvbnMub2F1dGhTZWNyZXRLZXkgV2hlbiB1c2luZyB0aGUgYG9hdXRoLWVuY3J5cHRpb25gIHBhY2thZ2UsIHRoZSAxNiBieXRlIGtleSB1c2luZyB0byBlbmNyeXB0IHNlbnNpdGl2ZSBhY2NvdW50IGNyZWRlbnRpYWxzIGluIHRoZSBkYXRhYmFzZSwgZW5jb2RlZCBpbiBiYXNlNjQuICBUaGlzIG9wdGlvbiBtYXkgb25seSBiZSBzcGVjaWZlZCBvbiB0aGUgc2VydmVyLiAgU2VlIHBhY2thZ2VzL29hdXRoLWVuY3J5cHRpb24vUkVBRE1FLm1kIGZvciBkZXRhaWxzLlxuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0aW9ucy5wYXNzd29yZFJlc2V0VG9rZW5FeHBpcmF0aW9uSW5EYXlzIFRoZSBudW1iZXIgb2YgZGF5cyBmcm9tIHdoZW4gYSBsaW5rIHRvIHJlc2V0IHBhc3N3b3JkIGlzIHNlbnQgdW50aWwgdG9rZW4gZXhwaXJlcyBhbmQgdXNlciBjYW4ndCByZXNldCBwYXNzd29yZCB3aXRoIHRoZSBsaW5rIGFueW1vcmUuIERlZmF1bHRzIHRvIDMuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLnBhc3N3b3JkRW5yb2xsVG9rZW5FeHBpcmF0aW9uSW5EYXlzIFRoZSBudW1iZXIgb2YgZGF5cyBmcm9tIHdoZW4gYSBsaW5rIHRvIHNldCBpbml0YWwgcGFzc3dvcmQgaXMgc2VudCB1bnRpbCB0b2tlbiBleHBpcmVzIGFuZCB1c2VyIGNhbid0IHNldCBwYXNzd29yZCB3aXRoIHRoZSBsaW5rIGFueW1vcmUuIERlZmF1bHRzIHRvIDMwLlxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMuYW1iaWd1b3VzRXJyb3JNZXNzYWdlcyBSZXR1cm4gYW1iaWd1b3VzIGVycm9yIG1lc3NhZ2VzIGZyb20gbG9naW4gZmFpbHVyZXMgdG8gcHJldmVudCB1c2VyIGVudW1lcmF0aW9uLiBEZWZhdWx0cyB0byBmYWxzZS5cbiAgICogQHBhcmFtIHtNb25nb0ZpZWxkU3BlY2lmaWVyfSBvcHRpb25zLmRlZmF1bHRGaWVsZFNlbGVjdG9yIFRvIGV4Y2x1ZGUgYnkgZGVmYXVsdCBsYXJnZSBjdXN0b20gZmllbGRzIGZyb20gYE1ldGVvci51c2VyKClgIGFuZCBgTWV0ZW9yLmZpbmRVc2VyQnkuLi4oKWAgZnVuY3Rpb25zIHdoZW4gY2FsbGVkIHdpdGhvdXQgYSBmaWVsZCBzZWxlY3RvciwgYW5kIGFsbCBgb25Mb2dpbmAsIGBvbkxvZ2luRmFpbHVyZWAgYW5kIGBvbkxvZ291dGAgY2FsbGJhY2tzLiAgRXhhbXBsZTogYEFjY291bnRzLmNvbmZpZyh7IGRlZmF1bHRGaWVsZFNlbGVjdG9yOiB7IG15QmlnQXJyYXk6IDAgfX0pYC5cbiAgICovXG4gIGNvbmZpZyhvcHRpb25zKSB7XG4gICAgLy8gV2UgZG9uJ3Qgd2FudCB1c2VycyB0byBhY2NpZGVudGFsbHkgb25seSBjYWxsIEFjY291bnRzLmNvbmZpZyBvbiB0aGVcbiAgICAvLyBjbGllbnQsIHdoZXJlIHNvbWUgb2YgdGhlIG9wdGlvbnMgd2lsbCBoYXZlIHBhcnRpYWwgZWZmZWN0cyAoZWcgcmVtb3ZpbmdcbiAgICAvLyB0aGUgXCJjcmVhdGUgYWNjb3VudFwiIGJ1dHRvbiBmcm9tIGFjY291bnRzLXVpIGlmIGZvcmJpZENsaWVudEFjY291bnRDcmVhdGlvblxuICAgIC8vIGlzIHNldCwgb3IgcmVkaXJlY3RpbmcgR29vZ2xlIGxvZ2luIHRvIGEgc3BlY2lmaWMtZG9tYWluIHBhZ2UpIHdpdGhvdXRcbiAgICAvLyBoYXZpbmcgdGhlaXIgZnVsbCBlZmZlY3RzLlxuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIF9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18uYWNjb3VudHNDb25maWdDYWxsZWQgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAoIV9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18uYWNjb3VudHNDb25maWdDYWxsZWQpIHtcbiAgICAgIC8vIFhYWCB3b3VsZCBiZSBuaWNlIHRvIFwiY3Jhc2hcIiB0aGUgY2xpZW50IGFuZCByZXBsYWNlIHRoZSBVSSB3aXRoIGFuIGVycm9yXG4gICAgICAvLyBtZXNzYWdlLCBidXQgdGhlcmUncyBubyB0cml2aWFsIHdheSB0byBkbyB0aGlzLlxuICAgICAgTWV0ZW9yLl9kZWJ1ZyhcIkFjY291bnRzLmNvbmZpZyB3YXMgY2FsbGVkIG9uIHRoZSBjbGllbnQgYnV0IG5vdCBvbiB0aGUgXCIgK1xuICAgICAgICAgICAgICAgICAgICBcInNlcnZlcjsgc29tZSBjb25maWd1cmF0aW9uIG9wdGlvbnMgbWF5IG5vdCB0YWtlIGVmZmVjdC5cIik7XG4gICAgfVxuXG4gICAgLy8gV2UgbmVlZCB0byB2YWxpZGF0ZSB0aGUgb2F1dGhTZWNyZXRLZXkgb3B0aW9uIGF0IHRoZSB0aW1lXG4gICAgLy8gQWNjb3VudHMuY29uZmlnIGlzIGNhbGxlZC4gV2UgYWxzbyBkZWxpYmVyYXRlbHkgZG9uJ3Qgc3RvcmUgdGhlXG4gICAgLy8gb2F1dGhTZWNyZXRLZXkgaW4gQWNjb3VudHMuX29wdGlvbnMuXG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvcHRpb25zLCAnb2F1dGhTZWNyZXRLZXknKSkge1xuICAgICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGUgb2F1dGhTZWNyZXRLZXkgb3B0aW9uIG1heSBvbmx5IGJlIHNwZWNpZmllZCBvbiB0aGUgc2VydmVyXCIpO1xuICAgICAgfVxuICAgICAgaWYgKCEgUGFja2FnZVtcIm9hdXRoLWVuY3J5cHRpb25cIl0pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhlIG9hdXRoLWVuY3J5cHRpb24gcGFja2FnZSBtdXN0IGJlIGxvYWRlZCB0byBzZXQgb2F1dGhTZWNyZXRLZXlcIik7XG4gICAgICB9XG4gICAgICBQYWNrYWdlW1wib2F1dGgtZW5jcnlwdGlvblwiXS5PQXV0aEVuY3J5cHRpb24ubG9hZEtleShvcHRpb25zLm9hdXRoU2VjcmV0S2V5KTtcbiAgICAgIG9wdGlvbnMgPSB7IC4uLm9wdGlvbnMgfTtcbiAgICAgIGRlbGV0ZSBvcHRpb25zLm9hdXRoU2VjcmV0S2V5O1xuICAgIH1cblxuICAgIC8vIHZhbGlkYXRlIG9wdGlvbiBrZXlzXG4gICAgY29uc3QgVkFMSURfS0VZUyA9IFtcInNlbmRWZXJpZmljYXRpb25FbWFpbFwiLCBcImZvcmJpZENsaWVudEFjY291bnRDcmVhdGlvblwiLCBcInBhc3N3b3JkRW5yb2xsVG9rZW5FeHBpcmF0aW9uSW5EYXlzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgXCJyZXN0cmljdENyZWF0aW9uQnlFbWFpbERvbWFpblwiLCBcImxvZ2luRXhwaXJhdGlvbkluRGF5c1wiLCBcInBhc3N3b3JkUmVzZXRUb2tlbkV4cGlyYXRpb25JbkRheXNcIixcbiAgICAgICAgICAgICAgICAgICAgICBcImFtYmlndW91c0Vycm9yTWVzc2FnZXNcIiwgXCJiY3J5cHRSb3VuZHNcIiwgXCJkZWZhdWx0RmllbGRTZWxlY3RvclwiXTtcblxuICAgIE9iamVjdC5rZXlzKG9wdGlvbnMpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgIGlmICghVkFMSURfS0VZUy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgQWNjb3VudHMuY29uZmlnOiBJbnZhbGlkIGtleTogJHtrZXl9YCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBzZXQgdmFsdWVzIGluIEFjY291bnRzLl9vcHRpb25zXG4gICAgVkFMSURfS0VZUy5mb3JFYWNoKGtleSA9PiB7XG4gICAgICBpZiAoa2V5IGluIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGtleSBpbiB0aGlzLl9vcHRpb25zKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDYW4ndCBzZXQgXFxgJHtrZXl9XFxgIG1vcmUgdGhhbiBvbmNlYCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fb3B0aW9uc1trZXldID0gb3B0aW9uc1trZXldO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFJlZ2lzdGVyIGEgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIGFmdGVyIGEgbG9naW4gYXR0ZW1wdCBzdWNjZWVkcy5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgVGhlIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCB3aGVuIGxvZ2luIGlzIHN1Y2Nlc3NmdWwuXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgVGhlIGNhbGxiYWNrIHJlY2VpdmVzIGEgc2luZ2xlIG9iamVjdCB0aGF0XG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgaG9sZHMgbG9naW4gZGV0YWlscy4gVGhpcyBvYmplY3QgY29udGFpbnMgdGhlIGxvZ2luXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0IHR5cGUgKHBhc3N3b3JkLCByZXN1bWUsIGV0Yy4pIG9uIGJvdGggdGhlXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50IGFuZCBzZXJ2ZXIuIGBvbkxvZ2luYCBjYWxsYmFja3MgcmVnaXN0ZXJlZFxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgIG9uIHRoZSBzZXJ2ZXIgYWxzbyByZWNlaXZlIGV4dHJhIGRhdGEsIHN1Y2hcbiAgICogICAgICAgICAgICAgICAgICAgICAgICBhcyB1c2VyIGRldGFpbHMsIGNvbm5lY3Rpb24gaW5mb3JtYXRpb24sIGV0Yy5cbiAgICovXG4gIG9uTG9naW4oZnVuYykge1xuICAgIGxldCByZXQgPSB0aGlzLl9vbkxvZ2luSG9vay5yZWdpc3RlcihmdW5jKTtcbiAgICAvLyBjYWxsIHRoZSBqdXN0IHJlZ2lzdGVyZWQgY2FsbGJhY2sgaWYgYWxyZWFkeSBsb2dnZWQgaW5cbiAgICB0aGlzLl9zdGFydHVwQ2FsbGJhY2socmV0LmNhbGxiYWNrKTtcbiAgICByZXR1cm4gcmV0O1xuICB9XG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFJlZ2lzdGVyIGEgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIGFmdGVyIGEgbG9naW4gYXR0ZW1wdCBmYWlscy5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgVGhlIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBhZnRlciB0aGUgbG9naW4gaGFzIGZhaWxlZC5cbiAgICovXG4gIG9uTG9naW5GYWlsdXJlKGZ1bmMpIHtcbiAgICByZXR1cm4gdGhpcy5fb25Mb2dpbkZhaWx1cmVIb29rLnJlZ2lzdGVyKGZ1bmMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFJlZ2lzdGVyIGEgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIGFmdGVyIGEgbG9nb3V0IGF0dGVtcHQgc3VjY2VlZHMuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBmdW5jIFRoZSBjYWxsYmFjayB0byBiZSBjYWxsZWQgd2hlbiBsb2dvdXQgaXMgc3VjY2Vzc2Z1bC5cbiAgICovXG4gIG9uTG9nb3V0KGZ1bmMpIHtcbiAgICByZXR1cm4gdGhpcy5fb25Mb2dvdXRIb29rLnJlZ2lzdGVyKGZ1bmMpO1xuICB9XG5cbiAgX2luaXRDb25uZWN0aW9uKG9wdGlvbnMpIHtcbiAgICBpZiAoISBNZXRlb3IuaXNDbGllbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBUaGUgY29ubmVjdGlvbiB1c2VkIGJ5IHRoZSBBY2NvdW50cyBzeXN0ZW0uIFRoaXMgaXMgdGhlIGNvbm5lY3Rpb25cbiAgICAvLyB0aGF0IHdpbGwgZ2V0IGxvZ2dlZCBpbiBieSBNZXRlb3IubG9naW4oKSwgYW5kIHRoaXMgaXMgdGhlXG4gICAgLy8gY29ubmVjdGlvbiB3aG9zZSBsb2dpbiBzdGF0ZSB3aWxsIGJlIHJlZmxlY3RlZCBieSBNZXRlb3IudXNlcklkKCkuXG4gICAgLy9cbiAgICAvLyBJdCB3b3VsZCBiZSBtdWNoIHByZWZlcmFibGUgZm9yIHRoaXMgdG8gYmUgaW4gYWNjb3VudHNfY2xpZW50LmpzLFxuICAgIC8vIGJ1dCBpdCBoYXMgdG8gYmUgaGVyZSBiZWNhdXNlIGl0J3MgbmVlZGVkIHRvIGNyZWF0ZSB0aGVcbiAgICAvLyBNZXRlb3IudXNlcnMgY29sbGVjdGlvbi5cbiAgICBpZiAob3B0aW9ucy5jb25uZWN0aW9uKSB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24gPSBvcHRpb25zLmNvbm5lY3Rpb247XG4gICAgfSBlbHNlIGlmIChvcHRpb25zLmRkcFVybCkge1xuICAgICAgdGhpcy5jb25uZWN0aW9uID0gRERQLmNvbm5lY3Qob3B0aW9ucy5kZHBVcmwpO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIF9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18gIT09IFwidW5kZWZpbmVkXCIgJiZcbiAgICAgICAgICAgICAgIF9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18uQUNDT1VOVFNfQ09OTkVDVElPTl9VUkwpIHtcbiAgICAgIC8vIFRlbXBvcmFyeSwgaW50ZXJuYWwgaG9vayB0byBhbGxvdyB0aGUgc2VydmVyIHRvIHBvaW50IHRoZSBjbGllbnRcbiAgICAgIC8vIHRvIGEgZGlmZmVyZW50IGF1dGhlbnRpY2F0aW9uIHNlcnZlci4gVGhpcyBpcyBmb3IgYSB2ZXJ5XG4gICAgICAvLyBwYXJ0aWN1bGFyIHVzZSBjYXNlIHRoYXQgY29tZXMgdXAgd2hlbiBpbXBsZW1lbnRpbmcgYSBvYXV0aFxuICAgICAgLy8gc2VydmVyLiBVbnN1cHBvcnRlZCBhbmQgbWF5IGdvIGF3YXkgYXQgYW55IHBvaW50IGluIHRpbWUuXG4gICAgICAvL1xuICAgICAgLy8gV2Ugd2lsbCBldmVudHVhbGx5IHByb3ZpZGUgYSBnZW5lcmFsIHdheSB0byB1c2UgYWNjb3VudC1iYXNlXG4gICAgICAvLyBhZ2FpbnN0IGFueSBERFAgY29ubmVjdGlvbiwgbm90IGp1c3Qgb25lIHNwZWNpYWwgb25lLlxuICAgICAgdGhpcy5jb25uZWN0aW9uID1cbiAgICAgICAgRERQLmNvbm5lY3QoX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5BQ0NPVU5UU19DT05ORUNUSU9OX1VSTCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbiA9IE1ldGVvci5jb25uZWN0aW9uO1xuICAgIH1cbiAgfVxuXG4gIF9nZXRUb2tlbkxpZmV0aW1lTXMoKSB7XG4gICAgLy8gV2hlbiBsb2dpbkV4cGlyYXRpb25JbkRheXMgaXMgc2V0IHRvIG51bGwsIHdlJ2xsIHVzZSBhIHJlYWxseSBoaWdoXG4gICAgLy8gbnVtYmVyIG9mIGRheXMgKExPR0lOX1VORVhQSVJBQkxFX1RPS0VOX0RBWVMpIHRvIHNpbXVsYXRlIGFuXG4gICAgLy8gdW5leHBpcmluZyB0b2tlbi5cbiAgICBjb25zdCBsb2dpbkV4cGlyYXRpb25JbkRheXMgPVxuICAgICAgKHRoaXMuX29wdGlvbnMubG9naW5FeHBpcmF0aW9uSW5EYXlzID09PSBudWxsKVxuICAgICAgICA/IExPR0lOX1VORVhQSVJJTkdfVE9LRU5fREFZU1xuICAgICAgICA6IHRoaXMuX29wdGlvbnMubG9naW5FeHBpcmF0aW9uSW5EYXlzO1xuICAgIHJldHVybiAobG9naW5FeHBpcmF0aW9uSW5EYXlzXG4gICAgICAgIHx8IERFRkFVTFRfTE9HSU5fRVhQSVJBVElPTl9EQVlTKSAqIDI0ICogNjAgKiA2MCAqIDEwMDA7XG4gIH1cblxuICBfZ2V0UGFzc3dvcmRSZXNldFRva2VuTGlmZXRpbWVNcygpIHtcbiAgICByZXR1cm4gKHRoaXMuX29wdGlvbnMucGFzc3dvcmRSZXNldFRva2VuRXhwaXJhdGlvbkluRGF5cyB8fFxuICAgICAgICAgICAgREVGQVVMVF9QQVNTV09SRF9SRVNFVF9UT0tFTl9FWFBJUkFUSU9OX0RBWVMpICogMjQgKiA2MCAqIDYwICogMTAwMDtcbiAgfVxuXG4gIF9nZXRQYXNzd29yZEVucm9sbFRva2VuTGlmZXRpbWVNcygpIHtcbiAgICByZXR1cm4gKHRoaXMuX29wdGlvbnMucGFzc3dvcmRFbnJvbGxUb2tlbkV4cGlyYXRpb25JbkRheXMgfHxcbiAgICAgICAgREVGQVVMVF9QQVNTV09SRF9FTlJPTExfVE9LRU5fRVhQSVJBVElPTl9EQVlTKSAqIDI0ICogNjAgKiA2MCAqIDEwMDA7XG4gIH1cblxuICBfdG9rZW5FeHBpcmF0aW9uKHdoZW4pIHtcbiAgICAvLyBXZSBwYXNzIHdoZW4gdGhyb3VnaCB0aGUgRGF0ZSBjb25zdHJ1Y3RvciBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHk7XG4gICAgLy8gYHdoZW5gIHVzZWQgdG8gYmUgYSBudW1iZXIuXG4gICAgcmV0dXJuIG5ldyBEYXRlKChuZXcgRGF0ZSh3aGVuKSkuZ2V0VGltZSgpICsgdGhpcy5fZ2V0VG9rZW5MaWZldGltZU1zKCkpO1xuICB9XG5cbiAgX3Rva2VuRXhwaXJlc1Nvb24od2hlbikge1xuICAgIGxldCBtaW5MaWZldGltZU1zID0gLjEgKiB0aGlzLl9nZXRUb2tlbkxpZmV0aW1lTXMoKTtcbiAgICBjb25zdCBtaW5MaWZldGltZUNhcE1zID0gTUlOX1RPS0VOX0xJRkVUSU1FX0NBUF9TRUNTICogMTAwMDtcbiAgICBpZiAobWluTGlmZXRpbWVNcyA+IG1pbkxpZmV0aW1lQ2FwTXMpIHtcbiAgICAgIG1pbkxpZmV0aW1lTXMgPSBtaW5MaWZldGltZUNhcE1zO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IERhdGUoKSA+IChuZXcgRGF0ZSh3aGVuKSAtIG1pbkxpZmV0aW1lTXMpO1xuICB9XG5cbiAgLy8gTm8tb3Agb24gdGhlIHNlcnZlciwgb3ZlcnJpZGRlbiBvbiB0aGUgY2xpZW50LlxuICBfc3RhcnR1cENhbGxiYWNrKGNhbGxiYWNrKSB7fVxufVxuXG4vLyBOb3RlIHRoYXQgQWNjb3VudHMgaXMgZGVmaW5lZCBzZXBhcmF0ZWx5IGluIGFjY291bnRzX2NsaWVudC5qcyBhbmRcbi8vIGFjY291bnRzX3NlcnZlci5qcy5cblxuLyoqXG4gKiBAc3VtbWFyeSBHZXQgdGhlIGN1cnJlbnQgdXNlciBpZCwgb3IgYG51bGxgIGlmIG5vIHVzZXIgaXMgbG9nZ2VkIGluLiBBIHJlYWN0aXZlIGRhdGEgc291cmNlLlxuICogQGxvY3VzIEFueXdoZXJlIGJ1dCBwdWJsaXNoIGZ1bmN0aW9uc1xuICogQGltcG9ydEZyb21QYWNrYWdlIG1ldGVvclxuICovXG5NZXRlb3IudXNlcklkID0gKCkgPT4gQWNjb3VudHMudXNlcklkKCk7XG5cbi8qKlxuICogQHN1bW1hcnkgR2V0IHRoZSBjdXJyZW50IHVzZXIgcmVjb3JkLCBvciBgbnVsbGAgaWYgbm8gdXNlciBpcyBsb2dnZWQgaW4uIEEgcmVhY3RpdmUgZGF0YSBzb3VyY2UuXG4gKiBAbG9jdXMgQW55d2hlcmUgYnV0IHB1Ymxpc2ggZnVuY3Rpb25zXG4gKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcGFyYW0ge01vbmdvRmllbGRTcGVjaWZpZXJ9IG9wdGlvbnMuZmllbGRzIERpY3Rpb25hcnkgb2YgZmllbGRzIHRvIHJldHVybiBvciBleGNsdWRlLlxuICovXG5NZXRlb3IudXNlciA9IChvcHRpb25zKSA9PiBBY2NvdW50cy51c2VyKG9wdGlvbnMpO1xuXG4vLyBob3cgbG9uZyAoaW4gZGF5cykgdW50aWwgYSBsb2dpbiB0b2tlbiBleHBpcmVzXG5jb25zdCBERUZBVUxUX0xPR0lOX0VYUElSQVRJT05fREFZUyA9IDkwO1xuLy8gaG93IGxvbmcgKGluIGRheXMpIHVudGlsIHJlc2V0IHBhc3N3b3JkIHRva2VuIGV4cGlyZXNcbmNvbnN0IERFRkFVTFRfUEFTU1dPUkRfUkVTRVRfVE9LRU5fRVhQSVJBVElPTl9EQVlTID0gMztcbi8vIGhvdyBsb25nIChpbiBkYXlzKSB1bnRpbCBlbnJvbCBwYXNzd29yZCB0b2tlbiBleHBpcmVzXG5jb25zdCBERUZBVUxUX1BBU1NXT1JEX0VOUk9MTF9UT0tFTl9FWFBJUkFUSU9OX0RBWVMgPSAzMDtcbi8vIENsaWVudHMgZG9uJ3QgdHJ5IHRvIGF1dG8tbG9naW4gd2l0aCBhIHRva2VuIHRoYXQgaXMgZ29pbmcgdG8gZXhwaXJlIHdpdGhpblxuLy8gLjEgKiBERUZBVUxUX0xPR0lOX0VYUElSQVRJT05fREFZUywgY2FwcGVkIGF0IE1JTl9UT0tFTl9MSUZFVElNRV9DQVBfU0VDUy5cbi8vIFRyaWVzIHRvIGF2b2lkIGFicnVwdCBkaXNjb25uZWN0cyBmcm9tIGV4cGlyaW5nIHRva2Vucy5cbmNvbnN0IE1JTl9UT0tFTl9MSUZFVElNRV9DQVBfU0VDUyA9IDM2MDA7IC8vIG9uZSBob3VyXG4vLyBob3cgb2Z0ZW4gKGluIG1pbGxpc2Vjb25kcykgd2UgY2hlY2sgZm9yIGV4cGlyZWQgdG9rZW5zXG5leHBvcnQgY29uc3QgRVhQSVJFX1RPS0VOU19JTlRFUlZBTF9NUyA9IDYwMCAqIDEwMDA7IC8vIDEwIG1pbnV0ZXNcbi8vIGhvdyBsb25nIHdlIHdhaXQgYmVmb3JlIGxvZ2dpbmcgb3V0IGNsaWVudHMgd2hlbiBNZXRlb3IubG9nb3V0T3RoZXJDbGllbnRzIGlzXG4vLyBjYWxsZWRcbmV4cG9ydCBjb25zdCBDT05ORUNUSU9OX0NMT1NFX0RFTEFZX01TID0gMTAgKiAxMDAwO1xuLy8gQSBsYXJnZSBudW1iZXIgb2YgZXhwaXJhdGlvbiBkYXlzIChhcHByb3hpbWF0ZWx5IDEwMCB5ZWFycyB3b3J0aCkgdGhhdCBpc1xuLy8gdXNlZCB3aGVuIGNyZWF0aW5nIHVuZXhwaXJpbmcgdG9rZW5zLlxuY29uc3QgTE9HSU5fVU5FWFBJUklOR19UT0tFTl9EQVlTID0gMzY1ICogMTAwO1xuIiwiaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0IHtcbiAgQWNjb3VudHNDb21tb24sXG4gIEVYUElSRV9UT0tFTlNfSU5URVJWQUxfTVMsXG4gIENPTk5FQ1RJT05fQ0xPU0VfREVMQVlfTVNcbn0gZnJvbSAnLi9hY2NvdW50c19jb21tb24uanMnO1xuXG5jb25zdCBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG4vKipcbiAqIEBzdW1tYXJ5IENvbnN0cnVjdG9yIGZvciB0aGUgYEFjY291bnRzYCBuYW1lc3BhY2Ugb24gdGhlIHNlcnZlci5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBjbGFzcyBBY2NvdW50c1NlcnZlclxuICogQGV4dGVuZHMgQWNjb3VudHNDb21tb25cbiAqIEBpbnN0YW5jZW5hbWUgYWNjb3VudHNTZXJ2ZXJcbiAqIEBwYXJhbSB7T2JqZWN0fSBzZXJ2ZXIgQSBzZXJ2ZXIgb2JqZWN0IHN1Y2ggYXMgYE1ldGVvci5zZXJ2ZXJgLlxuICovXG5leHBvcnQgY2xhc3MgQWNjb3VudHNTZXJ2ZXIgZXh0ZW5kcyBBY2NvdW50c0NvbW1vbiB7XG4gIC8vIE5vdGUgdGhhdCB0aGlzIGNvbnN0cnVjdG9yIGlzIGxlc3MgbGlrZWx5IHRvIGJlIGluc3RhbnRpYXRlZCBtdWx0aXBsZVxuICAvLyB0aW1lcyB0aGFuIHRoZSBgQWNjb3VudHNDbGllbnRgIGNvbnN0cnVjdG9yLCBiZWNhdXNlIGEgc2luZ2xlIHNlcnZlclxuICAvLyBjYW4gcHJvdmlkZSBvbmx5IG9uZSBzZXQgb2YgbWV0aG9kcy5cbiAgY29uc3RydWN0b3Ioc2VydmVyKSB7XG4gICAgc3VwZXIoKTtcblxuICAgIHRoaXMuX3NlcnZlciA9IHNlcnZlciB8fCBNZXRlb3Iuc2VydmVyO1xuICAgIC8vIFNldCB1cCB0aGUgc2VydmVyJ3MgbWV0aG9kcywgYXMgaWYgYnkgY2FsbGluZyBNZXRlb3IubWV0aG9kcy5cbiAgICB0aGlzLl9pbml0U2VydmVyTWV0aG9kcygpO1xuXG4gICAgdGhpcy5faW5pdEFjY291bnREYXRhSG9va3MoKTtcblxuICAgIC8vIElmIGF1dG9wdWJsaXNoIGlzIG9uLCBwdWJsaXNoIHRoZXNlIHVzZXIgZmllbGRzLiBMb2dpbiBzZXJ2aWNlXG4gICAgLy8gcGFja2FnZXMgKGVnIGFjY291bnRzLWdvb2dsZSkgYWRkIHRvIHRoZXNlIGJ5IGNhbGxpbmdcbiAgICAvLyBhZGRBdXRvcHVibGlzaEZpZWxkcy4gIE5vdGFibHksIHRoaXMgaXNuJ3QgaW1wbGVtZW50ZWQgd2l0aCBtdWx0aXBsZVxuICAgIC8vIHB1Ymxpc2hlcyBzaW5jZSBERFAgb25seSBtZXJnZXMgb25seSBhY3Jvc3MgdG9wLWxldmVsIGZpZWxkcywgbm90XG4gICAgLy8gc3ViZmllbGRzIChzdWNoIGFzICdzZXJ2aWNlcy5mYWNlYm9vay5hY2Nlc3NUb2tlbicpXG4gICAgdGhpcy5fYXV0b3B1Ymxpc2hGaWVsZHMgPSB7XG4gICAgICBsb2dnZWRJblVzZXI6IFsncHJvZmlsZScsICd1c2VybmFtZScsICdlbWFpbHMnXSxcbiAgICAgIG90aGVyVXNlcnM6IFsncHJvZmlsZScsICd1c2VybmFtZSddXG4gICAgfTtcblxuICAgIC8vIHVzZSBvYmplY3QgdG8ga2VlcCB0aGUgcmVmZXJlbmNlIHdoZW4gdXNlZCBpbiBmdW5jdGlvbnNcbiAgICAvLyB3aGVyZSBfZGVmYXVsdFB1Ymxpc2hGaWVsZHMgaXMgZGVzdHJ1Y3R1cmVkIGludG8gbGV4aWNhbCBzY29wZVxuICAgIC8vIGZvciBwdWJsaXNoIGNhbGxiYWNrcyB0aGF0IG5lZWQgYHRoaXNgXG4gICAgdGhpcy5fZGVmYXVsdFB1Ymxpc2hGaWVsZHMgPSB7XG4gICAgICBwcm9qZWN0aW9uOiB7XG4gICAgICAgIHByb2ZpbGU6IDEsXG4gICAgICAgIHVzZXJuYW1lOiAxLFxuICAgICAgICBlbWFpbHM6IDEsXG4gICAgICB9XG4gICAgfTtcblxuICAgIHRoaXMuX2luaXRTZXJ2ZXJQdWJsaWNhdGlvbnMoKTtcblxuICAgIC8vIGNvbm5lY3Rpb25JZCAtPiB7Y29ubmVjdGlvbiwgbG9naW5Ub2tlbn1cbiAgICB0aGlzLl9hY2NvdW50RGF0YSA9IHt9O1xuXG4gICAgLy8gY29ubmVjdGlvbiBpZCAtPiBvYnNlcnZlIGhhbmRsZSBmb3IgdGhlIGxvZ2luIHRva2VuIHRoYXQgdGhpcyBjb25uZWN0aW9uIGlzXG4gICAgLy8gY3VycmVudGx5IGFzc29jaWF0ZWQgd2l0aCwgb3IgYSBudW1iZXIuIFRoZSBudW1iZXIgaW5kaWNhdGVzIHRoYXQgd2UgYXJlIGluXG4gICAgLy8gdGhlIHByb2Nlc3Mgb2Ygc2V0dGluZyB1cCB0aGUgb2JzZXJ2ZSAodXNpbmcgYSBudW1iZXIgaW5zdGVhZCBvZiBhIHNpbmdsZVxuICAgIC8vIHNlbnRpbmVsIGFsbG93cyBtdWx0aXBsZSBhdHRlbXB0cyB0byBzZXQgdXAgdGhlIG9ic2VydmUgdG8gaWRlbnRpZnkgd2hpY2hcbiAgICAvLyBvbmUgd2FzIHRoZWlycykuXG4gICAgdGhpcy5fdXNlck9ic2VydmVzRm9yQ29ubmVjdGlvbnMgPSB7fTtcbiAgICB0aGlzLl9uZXh0VXNlck9ic2VydmVOdW1iZXIgPSAxOyAgLy8gZm9yIHRoZSBudW1iZXIgZGVzY3JpYmVkIGFib3ZlLlxuXG4gICAgLy8gbGlzdCBvZiBhbGwgcmVnaXN0ZXJlZCBoYW5kbGVycy5cbiAgICB0aGlzLl9sb2dpbkhhbmRsZXJzID0gW107XG5cbiAgICBzZXR1cFVzZXJzQ29sbGVjdGlvbih0aGlzLnVzZXJzKTtcbiAgICBzZXR1cERlZmF1bHRMb2dpbkhhbmRsZXJzKHRoaXMpO1xuICAgIHNldEV4cGlyZVRva2Vuc0ludGVydmFsKHRoaXMpO1xuXG4gICAgdGhpcy5fdmFsaWRhdGVMb2dpbkhvb2sgPSBuZXcgSG9vayh7IGJpbmRFbnZpcm9ubWVudDogZmFsc2UgfSk7XG4gICAgdGhpcy5fdmFsaWRhdGVOZXdVc2VySG9va3MgPSBbXG4gICAgICBkZWZhdWx0VmFsaWRhdGVOZXdVc2VySG9vay5iaW5kKHRoaXMpXG4gICAgXTtcblxuICAgIHRoaXMuX2RlbGV0ZVNhdmVkVG9rZW5zRm9yQWxsVXNlcnNPblN0YXJ0dXAoKTtcblxuICAgIHRoaXMuX3NraXBDYXNlSW5zZW5zaXRpdmVDaGVja3NGb3JUZXN0ID0ge307XG5cbiAgICAvLyBYWFggVGhlc2Ugc2hvdWxkIHByb2JhYmx5IG5vdCBhY3R1YWxseSBiZSBwdWJsaWM/XG4gICAgdGhpcy51cmxzID0ge1xuICAgICAgcmVzZXRQYXNzd29yZDogdG9rZW4gPT4gTWV0ZW9yLmFic29sdXRlVXJsKGAjL3Jlc2V0LXBhc3N3b3JkLyR7dG9rZW59YCksXG4gICAgICB2ZXJpZnlFbWFpbDogdG9rZW4gPT4gTWV0ZW9yLmFic29sdXRlVXJsKGAjL3ZlcmlmeS1lbWFpbC8ke3Rva2VufWApLFxuICAgICAgZW5yb2xsQWNjb3VudDogdG9rZW4gPT4gTWV0ZW9yLmFic29sdXRlVXJsKGAjL2Vucm9sbC1hY2NvdW50LyR7dG9rZW59YCksXG4gICAgfTtcblxuICAgIHRoaXMuYWRkRGVmYXVsdFJhdGVMaW1pdCgpO1xuICB9XG5cbiAgLy8vXG4gIC8vLyBDVVJSRU5UIFVTRVJcbiAgLy8vXG5cbiAgLy8gQG92ZXJyaWRlIG9mIFwiYWJzdHJhY3RcIiBub24taW1wbGVtZW50YXRpb24gaW4gYWNjb3VudHNfY29tbW9uLmpzXG4gIHVzZXJJZCgpIHtcbiAgICAvLyBUaGlzIGZ1bmN0aW9uIG9ubHkgd29ya3MgaWYgY2FsbGVkIGluc2lkZSBhIG1ldGhvZCBvciBhIHB1YmljYXRpb24uXG4gICAgLy8gVXNpbmcgYW55IG9mIHRoZSBpbmZvbWF0aW9uIGZyb20gTWV0ZW9yLnVzZXIoKSBpbiBhIG1ldGhvZCBvclxuICAgIC8vIHB1Ymxpc2ggZnVuY3Rpb24gd2lsbCBhbHdheXMgdXNlIHRoZSB2YWx1ZSBmcm9tIHdoZW4gdGhlIGZ1bmN0aW9uIGZpcnN0XG4gICAgLy8gcnVucy4gVGhpcyBpcyBsaWtlbHkgbm90IHdoYXQgdGhlIHVzZXIgZXhwZWN0cy4gVGhlIHdheSB0byBtYWtlIHRoaXMgd29ya1xuICAgIC8vIGluIGEgbWV0aG9kIG9yIHB1Ymxpc2ggZnVuY3Rpb24gaXMgdG8gZG8gTWV0ZW9yLmZpbmQodGhpcy51c2VySWQpLm9ic2VydmVcbiAgICAvLyBhbmQgcmVjb21wdXRlIHdoZW4gdGhlIHVzZXIgcmVjb3JkIGNoYW5nZXMuXG4gICAgY29uc3QgY3VycmVudEludm9jYXRpb24gPSBERFAuX0N1cnJlbnRNZXRob2RJbnZvY2F0aW9uLmdldCgpIHx8IEREUC5fQ3VycmVudFB1YmxpY2F0aW9uSW52b2NhdGlvbi5nZXQoKTtcbiAgICBpZiAoIWN1cnJlbnRJbnZvY2F0aW9uKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0ZW9yLnVzZXJJZCBjYW4gb25seSBiZSBpbnZva2VkIGluIG1ldGhvZCBjYWxscyBvciBwdWJsaWNhdGlvbnMuXCIpO1xuICAgIHJldHVybiBjdXJyZW50SW52b2NhdGlvbi51c2VySWQ7XG4gIH1cblxuICAvLy9cbiAgLy8vIExPR0lOIEhPT0tTXG4gIC8vL1xuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBWYWxpZGF0ZSBsb2dpbiBhdHRlbXB0cy5cbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBmdW5jIENhbGxlZCB3aGVuZXZlciBhIGxvZ2luIGlzIGF0dGVtcHRlZCAoZWl0aGVyIHN1Y2Nlc3NmdWwgb3IgdW5zdWNjZXNzZnVsKS4gIEEgbG9naW4gY2FuIGJlIGFib3J0ZWQgYnkgcmV0dXJuaW5nIGEgZmFsc3kgdmFsdWUgb3IgdGhyb3dpbmcgYW4gZXhjZXB0aW9uLlxuICAgKi9cbiAgdmFsaWRhdGVMb2dpbkF0dGVtcHQoZnVuYykge1xuICAgIC8vIEV4Y2VwdGlvbnMgaW5zaWRlIHRoZSBob29rIGNhbGxiYWNrIGFyZSBwYXNzZWQgdXAgdG8gdXMuXG4gICAgcmV0dXJuIHRoaXMuX3ZhbGlkYXRlTG9naW5Ib29rLnJlZ2lzdGVyKGZ1bmMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFNldCByZXN0cmljdGlvbnMgb24gbmV3IHVzZXIgY3JlYXRpb24uXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBDYWxsZWQgd2hlbmV2ZXIgYSBuZXcgdXNlciBpcyBjcmVhdGVkLiBUYWtlcyB0aGUgbmV3IHVzZXIgb2JqZWN0LCBhbmQgcmV0dXJucyB0cnVlIHRvIGFsbG93IHRoZSBjcmVhdGlvbiBvciBmYWxzZSB0byBhYm9ydC5cbiAgICovXG4gIHZhbGlkYXRlTmV3VXNlcihmdW5jKSB7XG4gICAgdGhpcy5fdmFsaWRhdGVOZXdVc2VySG9va3MucHVzaChmdW5jKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBWYWxpZGF0ZSBsb2dpbiBmcm9tIGV4dGVybmFsIHNlcnZpY2VcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBmdW5jIENhbGxlZCB3aGVuZXZlciBsb2dpbi91c2VyIGNyZWF0aW9uIGZyb20gZXh0ZXJuYWwgc2VydmljZSBpcyBhdHRlbXB0ZWQuIExvZ2luIG9yIHVzZXIgY3JlYXRpb24gYmFzZWQgb24gdGhpcyBsb2dpbiBjYW4gYmUgYWJvcnRlZCBieSBwYXNzaW5nIGEgZmFsc3kgdmFsdWUgb3IgdGhyb3dpbmcgYW4gZXhjZXB0aW9uLlxuICAgKi9cbiAgYmVmb3JlRXh0ZXJuYWxMb2dpbihmdW5jKSB7XG4gICAgaWYgKHRoaXMuX2JlZm9yZUV4dGVybmFsTG9naW5Ib29rKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW4gb25seSBjYWxsIGJlZm9yZUV4dGVybmFsTG9naW4gb25jZVwiKTtcbiAgICB9XG5cbiAgICB0aGlzLl9iZWZvcmVFeHRlcm5hbExvZ2luSG9vayA9IGZ1bmM7XG4gIH1cblxuICAvLy9cbiAgLy8vIENSRUFURSBVU0VSIEhPT0tTXG4gIC8vL1xuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBDdXN0b21pemUgbmV3IHVzZXIgY3JlYXRpb24uXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBDYWxsZWQgd2hlbmV2ZXIgYSBuZXcgdXNlciBpcyBjcmVhdGVkLiBSZXR1cm4gdGhlIG5ldyB1c2VyIG9iamVjdCwgb3IgdGhyb3cgYW4gYEVycm9yYCB0byBhYm9ydCB0aGUgY3JlYXRpb24uXG4gICAqL1xuICBvbkNyZWF0ZVVzZXIoZnVuYykge1xuICAgIGlmICh0aGlzLl9vbkNyZWF0ZVVzZXJIb29rKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW4gb25seSBjYWxsIG9uQ3JlYXRlVXNlciBvbmNlXCIpO1xuICAgIH1cblxuICAgIHRoaXMuX29uQ3JlYXRlVXNlckhvb2sgPSBmdW5jO1xuICB9XG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEN1c3RvbWl6ZSBvYXV0aCB1c2VyIHByb2ZpbGUgdXBkYXRlc1xuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgQ2FsbGVkIHdoZW5ldmVyIGEgdXNlciBpcyBsb2dnZWQgaW4gdmlhIG9hdXRoLiBSZXR1cm4gdGhlIHByb2ZpbGUgb2JqZWN0IHRvIGJlIG1lcmdlZCwgb3IgdGhyb3cgYW4gYEVycm9yYCB0byBhYm9ydCB0aGUgY3JlYXRpb24uXG4gICAqL1xuICBvbkV4dGVybmFsTG9naW4oZnVuYykge1xuICAgIGlmICh0aGlzLl9vbkV4dGVybmFsTG9naW5Ib29rKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW4gb25seSBjYWxsIG9uRXh0ZXJuYWxMb2dpbiBvbmNlXCIpO1xuICAgIH1cblxuICAgIHRoaXMuX29uRXh0ZXJuYWxMb2dpbkhvb2sgPSBmdW5jO1xuICB9XG5cbiAgX3ZhbGlkYXRlTG9naW4oY29ubmVjdGlvbiwgYXR0ZW1wdCkge1xuICAgIHRoaXMuX3ZhbGlkYXRlTG9naW5Ib29rLmVhY2goY2FsbGJhY2sgPT4ge1xuICAgICAgbGV0IHJldDtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldCA9IGNhbGxiYWNrKGNsb25lQXR0ZW1wdFdpdGhDb25uZWN0aW9uKGNvbm5lY3Rpb24sIGF0dGVtcHQpKTtcbiAgICAgIH1cbiAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGF0dGVtcHQuYWxsb3dlZCA9IGZhbHNlO1xuICAgICAgICAvLyBYWFggdGhpcyBtZWFucyB0aGUgbGFzdCB0aHJvd24gZXJyb3Igb3ZlcnJpZGVzIHByZXZpb3VzIGVycm9yXG4gICAgICAgIC8vIG1lc3NhZ2VzLiBNYXliZSB0aGlzIGlzIHN1cnByaXNpbmcgdG8gdXNlcnMgYW5kIHdlIHNob3VsZCBtYWtlXG4gICAgICAgIC8vIG92ZXJyaWRpbmcgZXJyb3JzIG1vcmUgZXhwbGljaXQuIChzZWVcbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL21ldGVvci9tZXRlb3IvaXNzdWVzLzE5NjApXG4gICAgICAgIGF0dGVtcHQuZXJyb3IgPSBlO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICghIHJldCkge1xuICAgICAgICBhdHRlbXB0LmFsbG93ZWQgPSBmYWxzZTtcbiAgICAgICAgLy8gZG9uJ3Qgb3ZlcnJpZGUgYSBzcGVjaWZpYyBlcnJvciBwcm92aWRlZCBieSBhIHByZXZpb3VzXG4gICAgICAgIC8vIHZhbGlkYXRvciBvciB0aGUgaW5pdGlhbCBhdHRlbXB0IChlZyBcImluY29ycmVjdCBwYXNzd29yZFwiKS5cbiAgICAgICAgaWYgKCFhdHRlbXB0LmVycm9yKVxuICAgICAgICAgIGF0dGVtcHQuZXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJMb2dpbiBmb3JiaWRkZW5cIik7XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgfTtcblxuICBfc3VjY2Vzc2Z1bExvZ2luKGNvbm5lY3Rpb24sIGF0dGVtcHQpIHtcbiAgICB0aGlzLl9vbkxvZ2luSG9vay5lYWNoKGNhbGxiYWNrID0+IHtcbiAgICAgIGNhbGxiYWNrKGNsb25lQXR0ZW1wdFdpdGhDb25uZWN0aW9uKGNvbm5lY3Rpb24sIGF0dGVtcHQpKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuICB9O1xuXG4gIF9mYWlsZWRMb2dpbihjb25uZWN0aW9uLCBhdHRlbXB0KSB7XG4gICAgdGhpcy5fb25Mb2dpbkZhaWx1cmVIb29rLmVhY2goY2FsbGJhY2sgPT4ge1xuICAgICAgY2FsbGJhY2soY2xvbmVBdHRlbXB0V2l0aENvbm5lY3Rpb24oY29ubmVjdGlvbiwgYXR0ZW1wdCkpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG4gIH07XG5cbiAgX3N1Y2Nlc3NmdWxMb2dvdXQoY29ubmVjdGlvbiwgdXNlcklkKSB7XG4gICAgLy8gZG9uJ3QgZmV0Y2ggdGhlIHVzZXIgb2JqZWN0IHVubGVzcyB0aGVyZSBhcmUgc29tZSBjYWxsYmFja3MgcmVnaXN0ZXJlZFxuICAgIGxldCB1c2VyO1xuICAgIHRoaXMuX29uTG9nb3V0SG9vay5lYWNoKGNhbGxiYWNrID0+IHtcbiAgICAgIGlmICghdXNlciAmJiB1c2VySWQpIHVzZXIgPSB0aGlzLnVzZXJzLmZpbmRPbmUodXNlcklkLCB7ZmllbGRzOiB0aGlzLl9vcHRpb25zLmRlZmF1bHRGaWVsZFNlbGVjdG9yfSk7XG4gICAgICBjYWxsYmFjayh7IHVzZXIsIGNvbm5lY3Rpb24gfSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgfTtcblxuICAvLy9cbiAgLy8vIExPR0lOIE1FVEhPRFNcbiAgLy8vXG5cbiAgLy8gTG9naW4gbWV0aG9kcyByZXR1cm4gdG8gdGhlIGNsaWVudCBhbiBvYmplY3QgY29udGFpbmluZyB0aGVzZVxuICAvLyBmaWVsZHMgd2hlbiB0aGUgdXNlciB3YXMgbG9nZ2VkIGluIHN1Y2Nlc3NmdWxseTpcbiAgLy9cbiAgLy8gICBpZDogdXNlcklkXG4gIC8vICAgdG9rZW46ICpcbiAgLy8gICB0b2tlbkV4cGlyZXM6ICpcbiAgLy9cbiAgLy8gdG9rZW5FeHBpcmVzIGlzIG9wdGlvbmFsIGFuZCBpbnRlbmRzIHRvIHByb3ZpZGUgYSBoaW50IHRvIHRoZVxuICAvLyBjbGllbnQgYXMgdG8gd2hlbiB0aGUgdG9rZW4gd2lsbCBleHBpcmUuIElmIG5vdCBwcm92aWRlZCwgdGhlXG4gIC8vIGNsaWVudCB3aWxsIGNhbGwgQWNjb3VudHMuX3Rva2VuRXhwaXJhdGlvbiwgcGFzc2luZyBpdCB0aGUgZGF0ZVxuICAvLyB0aGF0IGl0IHJlY2VpdmVkIHRoZSB0b2tlbi5cbiAgLy9cbiAgLy8gVGhlIGxvZ2luIG1ldGhvZCB3aWxsIHRocm93IGFuIGVycm9yIGJhY2sgdG8gdGhlIGNsaWVudCBpZiB0aGUgdXNlclxuICAvLyBmYWlsZWQgdG8gbG9nIGluLlxuICAvL1xuICAvL1xuICAvLyBMb2dpbiBoYW5kbGVycyBhbmQgc2VydmljZSBzcGVjaWZpYyBsb2dpbiBtZXRob2RzIHN1Y2ggYXNcbiAgLy8gYGNyZWF0ZVVzZXJgIGludGVybmFsbHkgcmV0dXJuIGEgYHJlc3VsdGAgb2JqZWN0IGNvbnRhaW5pbmcgdGhlc2VcbiAgLy8gZmllbGRzOlxuICAvL1xuICAvLyAgIHR5cGU6XG4gIC8vICAgICBvcHRpb25hbCBzdHJpbmc7IHRoZSBzZXJ2aWNlIG5hbWUsIG92ZXJyaWRlcyB0aGUgaGFuZGxlclxuICAvLyAgICAgZGVmYXVsdCBpZiBwcmVzZW50LlxuICAvL1xuICAvLyAgIGVycm9yOlxuICAvLyAgICAgZXhjZXB0aW9uOyBpZiB0aGUgdXNlciBpcyBub3QgYWxsb3dlZCB0byBsb2dpbiwgdGhlIHJlYXNvbiB3aHkuXG4gIC8vXG4gIC8vICAgdXNlcklkOlxuICAvLyAgICAgc3RyaW5nOyB0aGUgdXNlciBpZCBvZiB0aGUgdXNlciBhdHRlbXB0aW5nIHRvIGxvZ2luIChpZlxuICAvLyAgICAga25vd24pLCByZXF1aXJlZCBmb3IgYW4gYWxsb3dlZCBsb2dpbi5cbiAgLy9cbiAgLy8gICBvcHRpb25zOlxuICAvLyAgICAgb3B0aW9uYWwgb2JqZWN0IG1lcmdlZCBpbnRvIHRoZSByZXN1bHQgcmV0dXJuZWQgYnkgdGhlIGxvZ2luXG4gIC8vICAgICBtZXRob2Q7IHVzZWQgYnkgSEFNSyBmcm9tIFNSUC5cbiAgLy9cbiAgLy8gICBzdGFtcGVkTG9naW5Ub2tlbjpcbiAgLy8gICAgIG9wdGlvbmFsIG9iamVjdCB3aXRoIGB0b2tlbmAgYW5kIGB3aGVuYCBpbmRpY2F0aW5nIHRoZSBsb2dpblxuICAvLyAgICAgdG9rZW4gaXMgYWxyZWFkeSBwcmVzZW50IGluIHRoZSBkYXRhYmFzZSwgcmV0dXJuZWQgYnkgdGhlXG4gIC8vICAgICBcInJlc3VtZVwiIGxvZ2luIGhhbmRsZXIuXG4gIC8vXG4gIC8vIEZvciBjb252ZW5pZW5jZSwgbG9naW4gbWV0aG9kcyBjYW4gYWxzbyB0aHJvdyBhbiBleGNlcHRpb24sIHdoaWNoXG4gIC8vIGlzIGNvbnZlcnRlZCBpbnRvIGFuIHtlcnJvcn0gcmVzdWx0LiAgSG93ZXZlciwgaWYgdGhlIGlkIG9mIHRoZVxuICAvLyB1c2VyIGF0dGVtcHRpbmcgdGhlIGxvZ2luIGlzIGtub3duLCBhIHt1c2VySWQsIGVycm9yfSByZXN1bHQgc2hvdWxkXG4gIC8vIGJlIHJldHVybmVkIGluc3RlYWQgc2luY2UgdGhlIHVzZXIgaWQgaXMgbm90IGNhcHR1cmVkIHdoZW4gYW5cbiAgLy8gZXhjZXB0aW9uIGlzIHRocm93bi5cbiAgLy9cbiAgLy8gVGhpcyBpbnRlcm5hbCBgcmVzdWx0YCBvYmplY3QgaXMgYXV0b21hdGljYWxseSBjb252ZXJ0ZWQgaW50byB0aGVcbiAgLy8gcHVibGljIHtpZCwgdG9rZW4sIHRva2VuRXhwaXJlc30gb2JqZWN0IHJldHVybmVkIHRvIHRoZSBjbGllbnQuXG5cbiAgLy8gVHJ5IGEgbG9naW4gbWV0aG9kLCBjb252ZXJ0aW5nIHRocm93biBleGNlcHRpb25zIGludG8gYW4ge2Vycm9yfVxuICAvLyByZXN1bHQuICBUaGUgYHR5cGVgIGFyZ3VtZW50IGlzIGEgZGVmYXVsdCwgaW5zZXJ0ZWQgaW50byB0aGUgcmVzdWx0XG4gIC8vIG9iamVjdCBpZiBub3QgZXhwbGljaXRseSByZXR1cm5lZC5cbiAgLy9cbiAgLy8gTG9nIGluIGEgdXNlciBvbiBhIGNvbm5lY3Rpb24uXG4gIC8vXG4gIC8vIFdlIHVzZSB0aGUgbWV0aG9kIGludm9jYXRpb24gdG8gc2V0IHRoZSB1c2VyIGlkIG9uIHRoZSBjb25uZWN0aW9uLFxuICAvLyBub3QgdGhlIGNvbm5lY3Rpb24gb2JqZWN0IGRpcmVjdGx5LiBzZXRVc2VySWQgaXMgdGllZCB0byBtZXRob2RzIHRvXG4gIC8vIGVuZm9yY2UgY2xlYXIgb3JkZXJpbmcgb2YgbWV0aG9kIGFwcGxpY2F0aW9uICh1c2luZyB3YWl0IG1ldGhvZHMgb25cbiAgLy8gdGhlIGNsaWVudCwgYW5kIGEgbm8gc2V0VXNlcklkIGFmdGVyIHVuYmxvY2sgcmVzdHJpY3Rpb24gb24gdGhlXG4gIC8vIHNlcnZlcilcbiAgLy9cbiAgLy8gVGhlIGBzdGFtcGVkTG9naW5Ub2tlbmAgcGFyYW1ldGVyIGlzIG9wdGlvbmFsLiAgV2hlbiBwcmVzZW50LCBpdFxuICAvLyBpbmRpY2F0ZXMgdGhhdCB0aGUgbG9naW4gdG9rZW4gaGFzIGFscmVhZHkgYmVlbiBpbnNlcnRlZCBpbnRvIHRoZVxuICAvLyBkYXRhYmFzZSBhbmQgZG9lc24ndCBuZWVkIHRvIGJlIGluc2VydGVkIGFnYWluLiAgKEl0J3MgdXNlZCBieSB0aGVcbiAgLy8gXCJyZXN1bWVcIiBsb2dpbiBoYW5kbGVyKS5cbiAgX2xvZ2luVXNlcihtZXRob2RJbnZvY2F0aW9uLCB1c2VySWQsIHN0YW1wZWRMb2dpblRva2VuKSB7XG4gICAgaWYgKCEgc3RhbXBlZExvZ2luVG9rZW4pIHtcbiAgICAgIHN0YW1wZWRMb2dpblRva2VuID0gdGhpcy5fZ2VuZXJhdGVTdGFtcGVkTG9naW5Ub2tlbigpO1xuICAgICAgdGhpcy5faW5zZXJ0TG9naW5Ub2tlbih1c2VySWQsIHN0YW1wZWRMb2dpblRva2VuKTtcbiAgICB9XG5cbiAgICAvLyBUaGlzIG9yZGVyIChhbmQgdGhlIGF2b2lkYW5jZSBvZiB5aWVsZHMpIGlzIGltcG9ydGFudCB0byBtYWtlXG4gICAgLy8gc3VyZSB0aGF0IHdoZW4gcHVibGlzaCBmdW5jdGlvbnMgYXJlIHJlcnVuLCB0aGV5IHNlZSBhXG4gICAgLy8gY29uc2lzdGVudCB2aWV3IG9mIHRoZSB3b3JsZDogdGhlIHVzZXJJZCBpcyBzZXQgYW5kIG1hdGNoZXNcbiAgICAvLyB0aGUgbG9naW4gdG9rZW4gb24gdGhlIGNvbm5lY3Rpb24gKG5vdCB0aGF0IHRoZXJlIGlzXG4gICAgLy8gY3VycmVudGx5IGEgcHVibGljIEFQSSBmb3IgcmVhZGluZyB0aGUgbG9naW4gdG9rZW4gb24gYVxuICAgIC8vIGNvbm5lY3Rpb24pLlxuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKCgpID0+XG4gICAgICB0aGlzLl9zZXRMb2dpblRva2VuKFxuICAgICAgICB1c2VySWQsXG4gICAgICAgIG1ldGhvZEludm9jYXRpb24uY29ubmVjdGlvbixcbiAgICAgICAgdGhpcy5faGFzaExvZ2luVG9rZW4oc3RhbXBlZExvZ2luVG9rZW4udG9rZW4pXG4gICAgICApXG4gICAgKTtcblxuICAgIG1ldGhvZEludm9jYXRpb24uc2V0VXNlcklkKHVzZXJJZCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgaWQ6IHVzZXJJZCxcbiAgICAgIHRva2VuOiBzdGFtcGVkTG9naW5Ub2tlbi50b2tlbixcbiAgICAgIHRva2VuRXhwaXJlczogdGhpcy5fdG9rZW5FeHBpcmF0aW9uKHN0YW1wZWRMb2dpblRva2VuLndoZW4pXG4gICAgfTtcbiAgfTtcblxuICAvLyBBZnRlciBhIGxvZ2luIG1ldGhvZCBoYXMgY29tcGxldGVkLCBjYWxsIHRoZSBsb2dpbiBob29rcy4gIE5vdGVcbiAgLy8gdGhhdCBgYXR0ZW1wdExvZ2luYCBpcyBjYWxsZWQgZm9yICphbGwqIGxvZ2luIGF0dGVtcHRzLCBldmVuIG9uZXNcbiAgLy8gd2hpY2ggYXJlbid0IHN1Y2Nlc3NmdWwgKHN1Y2ggYXMgYW4gaW52YWxpZCBwYXNzd29yZCwgZXRjKS5cbiAgLy9cbiAgLy8gSWYgdGhlIGxvZ2luIGlzIGFsbG93ZWQgYW5kIGlzbid0IGFib3J0ZWQgYnkgYSB2YWxpZGF0ZSBsb2dpbiBob29rXG4gIC8vIGNhbGxiYWNrLCBsb2cgaW4gdGhlIHVzZXIuXG4gIC8vXG4gIF9hdHRlbXB0TG9naW4oXG4gICAgbWV0aG9kSW52b2NhdGlvbixcbiAgICBtZXRob2ROYW1lLFxuICAgIG1ldGhvZEFyZ3MsXG4gICAgcmVzdWx0XG4gICkge1xuICAgIGlmICghcmVzdWx0KVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwicmVzdWx0IGlzIHJlcXVpcmVkXCIpO1xuXG4gICAgLy8gWFhYIEEgcHJvZ3JhbW1pbmcgZXJyb3IgaW4gYSBsb2dpbiBoYW5kbGVyIGNhbiBsZWFkIHRvIHRoaXMgb2NjdXJpbmcsIGFuZFxuICAgIC8vIHRoZW4gd2UgZG9uJ3QgY2FsbCBvbkxvZ2luIG9yIG9uTG9naW5GYWlsdXJlIGNhbGxiYWNrcy4gU2hvdWxkXG4gICAgLy8gdHJ5TG9naW5NZXRob2QgY2F0Y2ggdGhpcyBjYXNlIGFuZCB0dXJuIGl0IGludG8gYW4gZXJyb3I/XG4gICAgaWYgKCFyZXN1bHQudXNlcklkICYmICFyZXN1bHQuZXJyb3IpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJBIGxvZ2luIG1ldGhvZCBtdXN0IHNwZWNpZnkgYSB1c2VySWQgb3IgYW4gZXJyb3JcIik7XG5cbiAgICBsZXQgdXNlcjtcbiAgICBpZiAocmVzdWx0LnVzZXJJZClcbiAgICAgIHVzZXIgPSB0aGlzLnVzZXJzLmZpbmRPbmUocmVzdWx0LnVzZXJJZCwge2ZpZWxkczogdGhpcy5fb3B0aW9ucy5kZWZhdWx0RmllbGRTZWxlY3Rvcn0pO1xuXG4gICAgY29uc3QgYXR0ZW1wdCA9IHtcbiAgICAgIHR5cGU6IHJlc3VsdC50eXBlIHx8IFwidW5rbm93blwiLFxuICAgICAgYWxsb3dlZDogISEgKHJlc3VsdC51c2VySWQgJiYgIXJlc3VsdC5lcnJvciksXG4gICAgICBtZXRob2ROYW1lOiBtZXRob2ROYW1lLFxuICAgICAgbWV0aG9kQXJndW1lbnRzOiBBcnJheS5mcm9tKG1ldGhvZEFyZ3MpXG4gICAgfTtcbiAgICBpZiAocmVzdWx0LmVycm9yKSB7XG4gICAgICBhdHRlbXB0LmVycm9yID0gcmVzdWx0LmVycm9yO1xuICAgIH1cbiAgICBpZiAodXNlcikge1xuICAgICAgYXR0ZW1wdC51c2VyID0gdXNlcjtcbiAgICB9XG5cbiAgICAvLyBfdmFsaWRhdGVMb2dpbiBtYXkgbXV0YXRlIGBhdHRlbXB0YCBieSBhZGRpbmcgYW4gZXJyb3IgYW5kIGNoYW5naW5nIGFsbG93ZWRcbiAgICAvLyB0byBmYWxzZSwgYnV0IHRoYXQncyB0aGUgb25seSBjaGFuZ2UgaXQgY2FuIG1ha2UgKGFuZCB0aGUgdXNlcidzIGNhbGxiYWNrc1xuICAgIC8vIG9ubHkgZ2V0IGEgY2xvbmUgb2YgYGF0dGVtcHRgKS5cbiAgICB0aGlzLl92YWxpZGF0ZUxvZ2luKG1ldGhvZEludm9jYXRpb24uY29ubmVjdGlvbiwgYXR0ZW1wdCk7XG5cbiAgICBpZiAoYXR0ZW1wdC5hbGxvd2VkKSB7XG4gICAgICBjb25zdCByZXQgPSB7XG4gICAgICAgIC4uLnRoaXMuX2xvZ2luVXNlcihcbiAgICAgICAgICBtZXRob2RJbnZvY2F0aW9uLFxuICAgICAgICAgIHJlc3VsdC51c2VySWQsXG4gICAgICAgICAgcmVzdWx0LnN0YW1wZWRMb2dpblRva2VuXG4gICAgICAgICksXG4gICAgICAgIC4uLnJlc3VsdC5vcHRpb25zXG4gICAgICB9O1xuICAgICAgcmV0LnR5cGUgPSBhdHRlbXB0LnR5cGU7XG4gICAgICB0aGlzLl9zdWNjZXNzZnVsTG9naW4obWV0aG9kSW52b2NhdGlvbi5jb25uZWN0aW9uLCBhdHRlbXB0KTtcbiAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5fZmFpbGVkTG9naW4obWV0aG9kSW52b2NhdGlvbi5jb25uZWN0aW9uLCBhdHRlbXB0KTtcbiAgICAgIHRocm93IGF0dGVtcHQuZXJyb3I7XG4gICAgfVxuICB9O1xuXG4gIC8vIEFsbCBzZXJ2aWNlIHNwZWNpZmljIGxvZ2luIG1ldGhvZHMgc2hvdWxkIGdvIHRocm91Z2ggdGhpcyBmdW5jdGlvbi5cbiAgLy8gRW5zdXJlIHRoYXQgdGhyb3duIGV4Y2VwdGlvbnMgYXJlIGNhdWdodCBhbmQgdGhhdCBsb2dpbiBob29rXG4gIC8vIGNhbGxiYWNrcyBhcmUgc3RpbGwgY2FsbGVkLlxuICAvL1xuICBfbG9naW5NZXRob2QoXG4gICAgbWV0aG9kSW52b2NhdGlvbixcbiAgICBtZXRob2ROYW1lLFxuICAgIG1ldGhvZEFyZ3MsXG4gICAgdHlwZSxcbiAgICBmblxuICApIHtcbiAgICByZXR1cm4gdGhpcy5fYXR0ZW1wdExvZ2luKFxuICAgICAgbWV0aG9kSW52b2NhdGlvbixcbiAgICAgIG1ldGhvZE5hbWUsXG4gICAgICBtZXRob2RBcmdzLFxuICAgICAgdHJ5TG9naW5NZXRob2QodHlwZSwgZm4pXG4gICAgKTtcbiAgfTtcblxuXG4gIC8vIFJlcG9ydCBhIGxvZ2luIGF0dGVtcHQgZmFpbGVkIG91dHNpZGUgdGhlIGNvbnRleHQgb2YgYSBub3JtYWwgbG9naW5cbiAgLy8gbWV0aG9kLiBUaGlzIGlzIGZvciB1c2UgaW4gdGhlIGNhc2Ugd2hlcmUgdGhlcmUgaXMgYSBtdWx0aS1zdGVwIGxvZ2luXG4gIC8vIHByb2NlZHVyZSAoZWcgU1JQIGJhc2VkIHBhc3N3b3JkIGxvZ2luKS4gSWYgYSBtZXRob2QgZWFybHkgaW4gdGhlXG4gIC8vIGNoYWluIGZhaWxzLCBpdCBzaG91bGQgY2FsbCB0aGlzIGZ1bmN0aW9uIHRvIHJlcG9ydCBhIGZhaWx1cmUuIFRoZXJlXG4gIC8vIGlzIG5vIGNvcnJlc3BvbmRpbmcgbWV0aG9kIGZvciBhIHN1Y2Nlc3NmdWwgbG9naW47IG1ldGhvZHMgdGhhdCBjYW5cbiAgLy8gc3VjY2VlZCBhdCBsb2dnaW5nIGEgdXNlciBpbiBzaG91bGQgYWx3YXlzIGJlIGFjdHVhbCBsb2dpbiBtZXRob2RzXG4gIC8vICh1c2luZyBlaXRoZXIgQWNjb3VudHMuX2xvZ2luTWV0aG9kIG9yIEFjY291bnRzLnJlZ2lzdGVyTG9naW5IYW5kbGVyKS5cbiAgX3JlcG9ydExvZ2luRmFpbHVyZShcbiAgICBtZXRob2RJbnZvY2F0aW9uLFxuICAgIG1ldGhvZE5hbWUsXG4gICAgbWV0aG9kQXJncyxcbiAgICByZXN1bHRcbiAgKSB7XG4gICAgY29uc3QgYXR0ZW1wdCA9IHtcbiAgICAgIHR5cGU6IHJlc3VsdC50eXBlIHx8IFwidW5rbm93blwiLFxuICAgICAgYWxsb3dlZDogZmFsc2UsXG4gICAgICBlcnJvcjogcmVzdWx0LmVycm9yLFxuICAgICAgbWV0aG9kTmFtZTogbWV0aG9kTmFtZSxcbiAgICAgIG1ldGhvZEFyZ3VtZW50czogQXJyYXkuZnJvbShtZXRob2RBcmdzKVxuICAgIH07XG5cbiAgICBpZiAocmVzdWx0LnVzZXJJZCkge1xuICAgICAgYXR0ZW1wdC51c2VyID0gdGhpcy51c2Vycy5maW5kT25lKHJlc3VsdC51c2VySWQsIHtmaWVsZHM6IHRoaXMuX29wdGlvbnMuZGVmYXVsdEZpZWxkU2VsZWN0b3J9KTtcbiAgICB9XG5cbiAgICB0aGlzLl92YWxpZGF0ZUxvZ2luKG1ldGhvZEludm9jYXRpb24uY29ubmVjdGlvbiwgYXR0ZW1wdCk7XG4gICAgdGhpcy5fZmFpbGVkTG9naW4obWV0aG9kSW52b2NhdGlvbi5jb25uZWN0aW9uLCBhdHRlbXB0KTtcblxuICAgIC8vIF92YWxpZGF0ZUxvZ2luIG1heSBtdXRhdGUgYXR0ZW1wdCB0byBzZXQgYSBuZXcgZXJyb3IgbWVzc2FnZS4gUmV0dXJuXG4gICAgLy8gdGhlIG1vZGlmaWVkIHZlcnNpb24uXG4gICAgcmV0dXJuIGF0dGVtcHQ7XG4gIH07XG5cbiAgLy8vXG4gIC8vLyBMT0dJTiBIQU5ETEVSU1xuICAvLy9cblxuICAvLyBUaGUgbWFpbiBlbnRyeSBwb2ludCBmb3IgYXV0aCBwYWNrYWdlcyB0byBob29rIGluIHRvIGxvZ2luLlxuICAvL1xuICAvLyBBIGxvZ2luIGhhbmRsZXIgaXMgYSBsb2dpbiBtZXRob2Qgd2hpY2ggY2FuIHJldHVybiBgdW5kZWZpbmVkYCB0b1xuICAvLyBpbmRpY2F0ZSB0aGF0IHRoZSBsb2dpbiByZXF1ZXN0IGlzIG5vdCBoYW5kbGVkIGJ5IHRoaXMgaGFuZGxlci5cbiAgLy9cbiAgLy8gQHBhcmFtIG5hbWUge1N0cmluZ30gT3B0aW9uYWwuICBUaGUgc2VydmljZSBuYW1lLCB1c2VkIGJ5IGRlZmF1bHRcbiAgLy8gaWYgYSBzcGVjaWZpYyBzZXJ2aWNlIG5hbWUgaXNuJ3QgcmV0dXJuZWQgaW4gdGhlIHJlc3VsdC5cbiAgLy9cbiAgLy8gQHBhcmFtIGhhbmRsZXIge0Z1bmN0aW9ufSBBIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgYW4gb3B0aW9ucyBvYmplY3RcbiAgLy8gKGFzIHBhc3NlZCBhcyBhbiBhcmd1bWVudCB0byB0aGUgYGxvZ2luYCBtZXRob2QpIGFuZCByZXR1cm5zIG9uZSBvZjpcbiAgLy8gLSBgdW5kZWZpbmVkYCwgbWVhbmluZyBkb24ndCBoYW5kbGU7XG4gIC8vIC0gYSBsb2dpbiBtZXRob2QgcmVzdWx0IG9iamVjdFxuXG4gIHJlZ2lzdGVyTG9naW5IYW5kbGVyKG5hbWUsIGhhbmRsZXIpIHtcbiAgICBpZiAoISBoYW5kbGVyKSB7XG4gICAgICBoYW5kbGVyID0gbmFtZTtcbiAgICAgIG5hbWUgPSBudWxsO1xuICAgIH1cblxuICAgIHRoaXMuX2xvZ2luSGFuZGxlcnMucHVzaCh7XG4gICAgICBuYW1lOiBuYW1lLFxuICAgICAgaGFuZGxlcjogaGFuZGxlclxuICAgIH0pO1xuICB9O1xuXG5cbiAgLy8gQ2hlY2tzIGEgdXNlcidzIGNyZWRlbnRpYWxzIGFnYWluc3QgYWxsIHRoZSByZWdpc3RlcmVkIGxvZ2luXG4gIC8vIGhhbmRsZXJzLCBhbmQgcmV0dXJucyBhIGxvZ2luIHRva2VuIGlmIHRoZSBjcmVkZW50aWFscyBhcmUgdmFsaWQuIEl0XG4gIC8vIGlzIGxpa2UgdGhlIGxvZ2luIG1ldGhvZCwgZXhjZXB0IHRoYXQgaXQgZG9lc24ndCBzZXQgdGhlIGxvZ2dlZC1pblxuICAvLyB1c2VyIG9uIHRoZSBjb25uZWN0aW9uLiBUaHJvd3MgYSBNZXRlb3IuRXJyb3IgaWYgbG9nZ2luZyBpbiBmYWlscyxcbiAgLy8gaW5jbHVkaW5nIHRoZSBjYXNlIHdoZXJlIG5vbmUgb2YgdGhlIGxvZ2luIGhhbmRsZXJzIGhhbmRsZWQgdGhlIGxvZ2luXG4gIC8vIHJlcXVlc3QuIE90aGVyd2lzZSwgcmV0dXJucyB7aWQ6IHVzZXJJZCwgdG9rZW46ICosIHRva2VuRXhwaXJlczogKn0uXG4gIC8vXG4gIC8vIEZvciBleGFtcGxlLCBpZiB5b3Ugd2FudCB0byBsb2dpbiB3aXRoIGEgcGxhaW50ZXh0IHBhc3N3b3JkLCBgb3B0aW9uc2AgY291bGQgYmVcbiAgLy8gICB7IHVzZXI6IHsgdXNlcm5hbWU6IDx1c2VybmFtZT4gfSwgcGFzc3dvcmQ6IDxwYXNzd29yZD4gfSwgb3JcbiAgLy8gICB7IHVzZXI6IHsgZW1haWw6IDxlbWFpbD4gfSwgcGFzc3dvcmQ6IDxwYXNzd29yZD4gfS5cblxuICAvLyBUcnkgYWxsIG9mIHRoZSByZWdpc3RlcmVkIGxvZ2luIGhhbmRsZXJzIHVudGlsIG9uZSBvZiB0aGVtIGRvZXNuJ3RcbiAgLy8gcmV0dXJuIGB1bmRlZmluZWRgLCBtZWFuaW5nIGl0IGhhbmRsZWQgdGhpcyBjYWxsIHRvIGBsb2dpbmAuIFJldHVyblxuICAvLyB0aGF0IHJldHVybiB2YWx1ZS5cbiAgX3J1bkxvZ2luSGFuZGxlcnMobWV0aG9kSW52b2NhdGlvbiwgb3B0aW9ucykge1xuICAgIGZvciAobGV0IGhhbmRsZXIgb2YgdGhpcy5fbG9naW5IYW5kbGVycykge1xuICAgICAgY29uc3QgcmVzdWx0ID0gdHJ5TG9naW5NZXRob2QoXG4gICAgICAgIGhhbmRsZXIubmFtZSxcbiAgICAgICAgKCkgPT4gaGFuZGxlci5oYW5kbGVyLmNhbGwobWV0aG9kSW52b2NhdGlvbiwgb3B0aW9ucylcbiAgICAgICk7XG5cbiAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH1cblxuICAgICAgaWYgKHJlc3VsdCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCBcIkEgbG9naW4gaGFuZGxlciBzaG91bGQgcmV0dXJuIGEgcmVzdWx0IG9yIHVuZGVmaW5lZFwiKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogbnVsbCxcbiAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgXCJVbnJlY29nbml6ZWQgb3B0aW9ucyBmb3IgbG9naW4gcmVxdWVzdFwiKVxuICAgIH07XG4gIH07XG5cbiAgLy8gRGVsZXRlcyB0aGUgZ2l2ZW4gbG9naW5Ub2tlbiBmcm9tIHRoZSBkYXRhYmFzZS5cbiAgLy9cbiAgLy8gRm9yIG5ldy1zdHlsZSBoYXNoZWQgdG9rZW4sIHRoaXMgd2lsbCBjYXVzZSBhbGwgY29ubmVjdGlvbnNcbiAgLy8gYXNzb2NpYXRlZCB3aXRoIHRoZSB0b2tlbiB0byBiZSBjbG9zZWQuXG4gIC8vXG4gIC8vIEFueSBjb25uZWN0aW9ucyBhc3NvY2lhdGVkIHdpdGggb2xkLXN0eWxlIHVuaGFzaGVkIHRva2VucyB3aWxsIGJlXG4gIC8vIGluIHRoZSBwcm9jZXNzIG9mIGJlY29taW5nIGFzc29jaWF0ZWQgd2l0aCBoYXNoZWQgdG9rZW5zIGFuZCB0aGVuXG4gIC8vIHRoZXknbGwgZ2V0IGNsb3NlZC5cbiAgZGVzdHJveVRva2VuKHVzZXJJZCwgbG9naW5Ub2tlbikge1xuICAgIHRoaXMudXNlcnMudXBkYXRlKHVzZXJJZCwge1xuICAgICAgJHB1bGw6IHtcbiAgICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNcIjoge1xuICAgICAgICAgICRvcjogW1xuICAgICAgICAgICAgeyBoYXNoZWRUb2tlbjogbG9naW5Ub2tlbiB9LFxuICAgICAgICAgICAgeyB0b2tlbjogbG9naW5Ub2tlbiB9XG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG5cbiAgX2luaXRTZXJ2ZXJNZXRob2RzKCkge1xuICAgIC8vIFRoZSBtZXRob2RzIGNyZWF0ZWQgaW4gdGhpcyBmdW5jdGlvbiBuZWVkIHRvIGJlIGNyZWF0ZWQgaGVyZSBzbyB0aGF0XG4gICAgLy8gdGhpcyB2YXJpYWJsZSBpcyBhdmFpbGFibGUgaW4gdGhlaXIgc2NvcGUuXG4gICAgY29uc3QgYWNjb3VudHMgPSB0aGlzO1xuXG5cbiAgICAvLyBUaGlzIG9iamVjdCB3aWxsIGJlIHBvcHVsYXRlZCB3aXRoIG1ldGhvZHMgYW5kIHRoZW4gcGFzc2VkIHRvXG4gICAgLy8gYWNjb3VudHMuX3NlcnZlci5tZXRob2RzIGZ1cnRoZXIgYmVsb3cuXG4gICAgY29uc3QgbWV0aG9kcyA9IHt9O1xuXG4gICAgLy8gQHJldHVybnMge09iamVjdHxudWxsfVxuICAgIC8vICAgSWYgc3VjY2Vzc2Z1bCwgcmV0dXJucyB7dG9rZW46IHJlY29ubmVjdFRva2VuLCBpZDogdXNlcklkfVxuICAgIC8vICAgSWYgdW5zdWNjZXNzZnVsIChmb3IgZXhhbXBsZSwgaWYgdGhlIHVzZXIgY2xvc2VkIHRoZSBvYXV0aCBsb2dpbiBwb3B1cCksXG4gICAgLy8gICAgIHRocm93cyBhbiBlcnJvciBkZXNjcmliaW5nIHRoZSByZWFzb25cbiAgICBtZXRob2RzLmxvZ2luID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgICAgIC8vIExvZ2luIGhhbmRsZXJzIHNob3VsZCByZWFsbHkgYWxzbyBjaGVjayB3aGF0ZXZlciBmaWVsZCB0aGV5IGxvb2sgYXQgaW5cbiAgICAgIC8vIG9wdGlvbnMsIGJ1dCB3ZSBkb24ndCBlbmZvcmNlIGl0LlxuICAgICAgY2hlY2sob3B0aW9ucywgT2JqZWN0KTtcblxuICAgICAgY29uc3QgcmVzdWx0ID0gYWNjb3VudHMuX3J1bkxvZ2luSGFuZGxlcnModGhpcywgb3B0aW9ucyk7XG5cbiAgICAgIHJldHVybiBhY2NvdW50cy5fYXR0ZW1wdExvZ2luKHRoaXMsIFwibG9naW5cIiwgYXJndW1lbnRzLCByZXN1bHQpO1xuICAgIH07XG5cbiAgICBtZXRob2RzLmxvZ291dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGNvbnN0IHRva2VuID0gYWNjb3VudHMuX2dldExvZ2luVG9rZW4odGhpcy5jb25uZWN0aW9uLmlkKTtcbiAgICAgIGFjY291bnRzLl9zZXRMb2dpblRva2VuKHRoaXMudXNlcklkLCB0aGlzLmNvbm5lY3Rpb24sIG51bGwpO1xuICAgICAgaWYgKHRva2VuICYmIHRoaXMudXNlcklkKSB7XG4gICAgICAgIGFjY291bnRzLmRlc3Ryb3lUb2tlbih0aGlzLnVzZXJJZCwgdG9rZW4pO1xuICAgICAgfVxuICAgICAgYWNjb3VudHMuX3N1Y2Nlc3NmdWxMb2dvdXQodGhpcy5jb25uZWN0aW9uLCB0aGlzLnVzZXJJZCk7XG4gICAgICB0aGlzLnNldFVzZXJJZChudWxsKTtcbiAgICB9O1xuXG4gICAgLy8gRGVsZXRlIGFsbCB0aGUgY3VycmVudCB1c2VyJ3MgdG9rZW5zIGFuZCBjbG9zZSBhbGwgb3BlbiBjb25uZWN0aW9ucyBsb2dnZWRcbiAgICAvLyBpbiBhcyB0aGlzIHVzZXIuIFJldHVybnMgYSBmcmVzaCBuZXcgbG9naW4gdG9rZW4gdGhhdCB0aGlzIGNsaWVudCBjYW5cbiAgICAvLyB1c2UuIFRlc3RzIHNldCBBY2NvdW50cy5fbm9Db25uZWN0aW9uQ2xvc2VEZWxheUZvclRlc3QgdG8gZGVsZXRlIHRva2Vuc1xuICAgIC8vIGltbWVkaWF0ZWx5IGluc3RlYWQgb2YgdXNpbmcgYSBkZWxheS5cbiAgICAvL1xuICAgIC8vIFhYWCBDT01QQVQgV0lUSCAwLjcuMlxuICAgIC8vIFRoaXMgc2luZ2xlIGBsb2dvdXRPdGhlckNsaWVudHNgIG1ldGhvZCBoYXMgYmVlbiByZXBsYWNlZCB3aXRoIHR3b1xuICAgIC8vIG1ldGhvZHMsIG9uZSB0aGF0IHlvdSBjYWxsIHRvIGdldCBhIG5ldyB0b2tlbiwgYW5kIGFub3RoZXIgdGhhdCB5b3VcbiAgICAvLyBjYWxsIHRvIHJlbW92ZSBhbGwgdG9rZW5zIGV4Y2VwdCB5b3VyIG93bi4gVGhlIG5ldyBkZXNpZ24gYWxsb3dzXG4gICAgLy8gY2xpZW50cyB0byBrbm93IHdoZW4gb3RoZXIgY2xpZW50cyBoYXZlIGFjdHVhbGx5IGJlZW4gbG9nZ2VkXG4gICAgLy8gb3V0LiAoVGhlIGBsb2dvdXRPdGhlckNsaWVudHNgIG1ldGhvZCBndWFyYW50ZWVzIHRoZSBjYWxsZXIgdGhhdFxuICAgIC8vIHRoZSBvdGhlciBjbGllbnRzIHdpbGwgYmUgbG9nZ2VkIG91dCBhdCBzb21lIHBvaW50LCBidXQgbWFrZXMgbm9cbiAgICAvLyBndWFyYW50ZWVzIGFib3V0IHdoZW4uKSBUaGlzIG1ldGhvZCBpcyBsZWZ0IGluIGZvciBiYWNrd2FyZHNcbiAgICAvLyBjb21wYXRpYmlsaXR5LCBlc3BlY2lhbGx5IHNpbmNlIGFwcGxpY2F0aW9uIGNvZGUgbWlnaHQgYmUgY2FsbGluZ1xuICAgIC8vIHRoaXMgbWV0aG9kIGRpcmVjdGx5LlxuICAgIC8vXG4gICAgLy8gQHJldHVybnMge09iamVjdH0gT2JqZWN0IHdpdGggdG9rZW4gYW5kIHRva2VuRXhwaXJlcyBrZXlzLlxuICAgIG1ldGhvZHMubG9nb3V0T3RoZXJDbGllbnRzID0gZnVuY3Rpb24gKCkge1xuICAgICAgY29uc3QgdXNlciA9IGFjY291bnRzLnVzZXJzLmZpbmRPbmUodGhpcy51c2VySWQsIHtcbiAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNcIjogdHJ1ZVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGlmICh1c2VyKSB7XG4gICAgICAgIC8vIFNhdmUgdGhlIGN1cnJlbnQgdG9rZW5zIGluIHRoZSBkYXRhYmFzZSB0byBiZSBkZWxldGVkIGluXG4gICAgICAgIC8vIENPTk5FQ1RJT05fQ0xPU0VfREVMQVlfTVMgbXMuIFRoaXMgZ2l2ZXMgb3RoZXIgY29ubmVjdGlvbnMgaW4gdGhlXG4gICAgICAgIC8vIGNhbGxlcidzIGJyb3dzZXIgdGltZSB0byBmaW5kIHRoZSBmcmVzaCB0b2tlbiBpbiBsb2NhbFN0b3JhZ2UuIFdlIHNhdmVcbiAgICAgICAgLy8gdGhlIHRva2VucyBpbiB0aGUgZGF0YWJhc2UgaW4gY2FzZSB3ZSBjcmFzaCBiZWZvcmUgYWN0dWFsbHkgZGVsZXRpbmdcbiAgICAgICAgLy8gdGhlbS5cbiAgICAgICAgY29uc3QgdG9rZW5zID0gdXNlci5zZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnM7XG4gICAgICAgIGNvbnN0IG5ld1Rva2VuID0gYWNjb3VudHMuX2dlbmVyYXRlU3RhbXBlZExvZ2luVG9rZW4oKTtcbiAgICAgICAgYWNjb3VudHMudXNlcnMudXBkYXRlKHRoaXMudXNlcklkLCB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNUb0RlbGV0ZVwiOiB0b2tlbnMsXG4gICAgICAgICAgICBcInNlcnZpY2VzLnJlc3VtZS5oYXZlTG9naW5Ub2tlbnNUb0RlbGV0ZVwiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICAkcHVzaDogeyBcInNlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vuc1wiOiBhY2NvdW50cy5faGFzaFN0YW1wZWRUb2tlbihuZXdUb2tlbikgfVxuICAgICAgICB9KTtcbiAgICAgICAgTWV0ZW9yLnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIC8vIFRoZSBvYnNlcnZlIG9uIE1ldGVvci51c2VycyB3aWxsIHRha2UgY2FyZSBvZiBjbG9zaW5nIHRoZSBjb25uZWN0aW9uc1xuICAgICAgICAgIC8vIGFzc29jaWF0ZWQgd2l0aCBgdG9rZW5zYC5cbiAgICAgICAgICBhY2NvdW50cy5fZGVsZXRlU2F2ZWRUb2tlbnNGb3JVc2VyKHRoaXMudXNlcklkLCB0b2tlbnMpO1xuICAgICAgICB9LCBhY2NvdW50cy5fbm9Db25uZWN0aW9uQ2xvc2VEZWxheUZvclRlc3QgPyAwIDpcbiAgICAgICAgICBDT05ORUNUSU9OX0NMT1NFX0RFTEFZX01TKTtcbiAgICAgICAgLy8gV2UgZG8gbm90IHNldCB0aGUgbG9naW4gdG9rZW4gb24gdGhpcyBjb25uZWN0aW9uLCBidXQgaW5zdGVhZCB0aGVcbiAgICAgICAgLy8gb2JzZXJ2ZSBjbG9zZXMgdGhlIGNvbm5lY3Rpb24gYW5kIHRoZSBjbGllbnQgd2lsbCByZWNvbm5lY3Qgd2l0aCB0aGVcbiAgICAgICAgLy8gbmV3IHRva2VuLlxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHRva2VuOiBuZXdUb2tlbi50b2tlbixcbiAgICAgICAgICB0b2tlbkV4cGlyZXM6IGFjY291bnRzLl90b2tlbkV4cGlyYXRpb24obmV3VG9rZW4ud2hlbilcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJZb3UgYXJlIG5vdCBsb2dnZWQgaW4uXCIpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBHZW5lcmF0ZXMgYSBuZXcgbG9naW4gdG9rZW4gd2l0aCB0aGUgc2FtZSBleHBpcmF0aW9uIGFzIHRoZVxuICAgIC8vIGNvbm5lY3Rpb24ncyBjdXJyZW50IHRva2VuIGFuZCBzYXZlcyBpdCB0byB0aGUgZGF0YWJhc2UuIEFzc29jaWF0ZXNcbiAgICAvLyB0aGUgY29ubmVjdGlvbiB3aXRoIHRoaXMgbmV3IHRva2VuIGFuZCByZXR1cm5zIGl0LiBUaHJvd3MgYW4gZXJyb3JcbiAgICAvLyBpZiBjYWxsZWQgb24gYSBjb25uZWN0aW9uIHRoYXQgaXNuJ3QgbG9nZ2VkIGluLlxuICAgIC8vXG4gICAgLy8gQHJldHVybnMgT2JqZWN0XG4gICAgLy8gICBJZiBzdWNjZXNzZnVsLCByZXR1cm5zIHsgdG9rZW46IDxuZXcgdG9rZW4+LCBpZDogPHVzZXIgaWQ+LFxuICAgIC8vICAgdG9rZW5FeHBpcmVzOiA8ZXhwaXJhdGlvbiBkYXRlPiB9LlxuICAgIG1ldGhvZHMuZ2V0TmV3VG9rZW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICBjb25zdCB1c2VyID0gYWNjb3VudHMudXNlcnMuZmluZE9uZSh0aGlzLnVzZXJJZCwge1xuICAgICAgICBmaWVsZHM6IHsgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNcIjogMSB9XG4gICAgICB9KTtcbiAgICAgIGlmICghIHRoaXMudXNlcklkIHx8ICEgdXNlcikge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiWW91IGFyZSBub3QgbG9nZ2VkIGluLlwiKTtcbiAgICAgIH1cbiAgICAgIC8vIEJlIGNhcmVmdWwgbm90IHRvIGdlbmVyYXRlIGEgbmV3IHRva2VuIHRoYXQgaGFzIGEgbGF0ZXJcbiAgICAgIC8vIGV4cGlyYXRpb24gdGhhbiB0aGUgY3VycmVuIHRva2VuLiBPdGhlcndpc2UsIGEgYmFkIGd1eSB3aXRoIGFcbiAgICAgIC8vIHN0b2xlbiB0b2tlbiBjb3VsZCB1c2UgdGhpcyBtZXRob2QgdG8gc3RvcCBoaXMgc3RvbGVuIHRva2VuIGZyb21cbiAgICAgIC8vIGV2ZXIgZXhwaXJpbmcuXG4gICAgICBjb25zdCBjdXJyZW50SGFzaGVkVG9rZW4gPSBhY2NvdW50cy5fZ2V0TG9naW5Ub2tlbih0aGlzLmNvbm5lY3Rpb24uaWQpO1xuICAgICAgY29uc3QgY3VycmVudFN0YW1wZWRUb2tlbiA9IHVzZXIuc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zLmZpbmQoXG4gICAgICAgIHN0YW1wZWRUb2tlbiA9PiBzdGFtcGVkVG9rZW4uaGFzaGVkVG9rZW4gPT09IGN1cnJlbnRIYXNoZWRUb2tlblxuICAgICAgKTtcbiAgICAgIGlmICghIGN1cnJlbnRTdGFtcGVkVG9rZW4pIHsgLy8gc2FmZXR5IGJlbHQ6IHRoaXMgc2hvdWxkIG5ldmVyIGhhcHBlblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiSW52YWxpZCBsb2dpbiB0b2tlblwiKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5ld1N0YW1wZWRUb2tlbiA9IGFjY291bnRzLl9nZW5lcmF0ZVN0YW1wZWRMb2dpblRva2VuKCk7XG4gICAgICBuZXdTdGFtcGVkVG9rZW4ud2hlbiA9IGN1cnJlbnRTdGFtcGVkVG9rZW4ud2hlbjtcbiAgICAgIGFjY291bnRzLl9pbnNlcnRMb2dpblRva2VuKHRoaXMudXNlcklkLCBuZXdTdGFtcGVkVG9rZW4pO1xuICAgICAgcmV0dXJuIGFjY291bnRzLl9sb2dpblVzZXIodGhpcywgdGhpcy51c2VySWQsIG5ld1N0YW1wZWRUb2tlbik7XG4gICAgfTtcblxuICAgIC8vIFJlbW92ZXMgYWxsIHRva2VucyBleGNlcHQgdGhlIHRva2VuIGFzc29jaWF0ZWQgd2l0aCB0aGUgY3VycmVudFxuICAgIC8vIGNvbm5lY3Rpb24uIFRocm93cyBhbiBlcnJvciBpZiB0aGUgY29ubmVjdGlvbiBpcyBub3QgbG9nZ2VkXG4gICAgLy8gaW4uIFJldHVybnMgbm90aGluZyBvbiBzdWNjZXNzLlxuICAgIG1ldGhvZHMucmVtb3ZlT3RoZXJUb2tlbnMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiWW91IGFyZSBub3QgbG9nZ2VkIGluLlwiKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGN1cnJlbnRUb2tlbiA9IGFjY291bnRzLl9nZXRMb2dpblRva2VuKHRoaXMuY29ubmVjdGlvbi5pZCk7XG4gICAgICBhY2NvdW50cy51c2Vycy51cGRhdGUodGhpcy51c2VySWQsIHtcbiAgICAgICAgJHB1bGw6IHtcbiAgICAgICAgICBcInNlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vuc1wiOiB7IGhhc2hlZFRva2VuOiB7ICRuZTogY3VycmVudFRva2VuIH0gfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgLy8gQWxsb3cgYSBvbmUtdGltZSBjb25maWd1cmF0aW9uIGZvciBhIGxvZ2luIHNlcnZpY2UuIE1vZGlmaWNhdGlvbnNcbiAgICAvLyB0byB0aGlzIGNvbGxlY3Rpb24gYXJlIGFsc28gYWxsb3dlZCBpbiBpbnNlY3VyZSBtb2RlLlxuICAgIG1ldGhvZHMuY29uZmlndXJlTG9naW5TZXJ2aWNlID0gKG9wdGlvbnMpID0+IHtcbiAgICAgIGNoZWNrKG9wdGlvbnMsIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7c2VydmljZTogU3RyaW5nfSkpO1xuICAgICAgLy8gRG9uJ3QgbGV0IHJhbmRvbSB1c2VycyBjb25maWd1cmUgYSBzZXJ2aWNlIHdlIGhhdmVuJ3QgYWRkZWQgeWV0IChzb1xuICAgICAgLy8gdGhhdCB3aGVuIHdlIGRvIGxhdGVyIGFkZCBpdCwgaXQncyBzZXQgdXAgd2l0aCB0aGVpciBjb25maWd1cmF0aW9uXG4gICAgICAvLyBpbnN0ZWFkIG9mIG91cnMpLlxuICAgICAgLy8gWFhYIGlmIHNlcnZpY2UgY29uZmlndXJhdGlvbiBpcyBvYXV0aC1zcGVjaWZpYyB0aGVuIHRoaXMgY29kZSBzaG91bGRcbiAgICAgIC8vICAgICBiZSBpbiBhY2NvdW50cy1vYXV0aDsgaWYgaXQncyBub3QgdGhlbiB0aGUgcmVnaXN0cnkgc2hvdWxkIGJlXG4gICAgICAvLyAgICAgaW4gdGhpcyBwYWNrYWdlXG4gICAgICBpZiAoIShhY2NvdW50cy5vYXV0aFxuICAgICAgICAmJiBhY2NvdW50cy5vYXV0aC5zZXJ2aWNlTmFtZXMoKS5pbmNsdWRlcyhvcHRpb25zLnNlcnZpY2UpKSkge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJTZXJ2aWNlIHVua25vd25cIik7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgU2VydmljZUNvbmZpZ3VyYXRpb24gfSA9IFBhY2thZ2VbJ3NlcnZpY2UtY29uZmlndXJhdGlvbiddO1xuICAgICAgaWYgKFNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLmZpbmRPbmUoe3NlcnZpY2U6IG9wdGlvbnMuc2VydmljZX0pKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgYFNlcnZpY2UgJHtvcHRpb25zLnNlcnZpY2V9IGFscmVhZHkgY29uZmlndXJlZGApO1xuXG4gICAgICBpZiAoaGFzT3duLmNhbGwob3B0aW9ucywgJ3NlY3JldCcpICYmIHVzaW5nT0F1dGhFbmNyeXB0aW9uKCkpXG4gICAgICAgIG9wdGlvbnMuc2VjcmV0ID0gT0F1dGhFbmNyeXB0aW9uLnNlYWwob3B0aW9ucy5zZWNyZXQpO1xuXG4gICAgICBTZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5pbnNlcnQob3B0aW9ucyk7XG4gICAgfTtcblxuICAgIGFjY291bnRzLl9zZXJ2ZXIubWV0aG9kcyhtZXRob2RzKTtcbiAgfTtcblxuICBfaW5pdEFjY291bnREYXRhSG9va3MoKSB7XG4gICAgdGhpcy5fc2VydmVyLm9uQ29ubmVjdGlvbihjb25uZWN0aW9uID0+IHtcbiAgICAgIHRoaXMuX2FjY291bnREYXRhW2Nvbm5lY3Rpb24uaWRdID0ge1xuICAgICAgICBjb25uZWN0aW9uOiBjb25uZWN0aW9uXG4gICAgICB9O1xuXG4gICAgICBjb25uZWN0aW9uLm9uQ2xvc2UoKCkgPT4ge1xuICAgICAgICB0aGlzLl9yZW1vdmVUb2tlbkZyb21Db25uZWN0aW9uKGNvbm5lY3Rpb24uaWQpO1xuICAgICAgICBkZWxldGUgdGhpcy5fYWNjb3VudERhdGFbY29ubmVjdGlvbi5pZF07XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfTtcblxuICBfaW5pdFNlcnZlclB1YmxpY2F0aW9ucygpIHtcbiAgICAvLyBCcmluZyBpbnRvIGxleGljYWwgc2NvcGUgZm9yIHB1Ymxpc2ggY2FsbGJhY2tzIHRoYXQgbmVlZCBgdGhpc2BcbiAgICBjb25zdCB7IHVzZXJzLCBfYXV0b3B1Ymxpc2hGaWVsZHMsIF9kZWZhdWx0UHVibGlzaEZpZWxkcyB9ID0gdGhpcztcblxuICAgIC8vIFB1Ymxpc2ggYWxsIGxvZ2luIHNlcnZpY2UgY29uZmlndXJhdGlvbiBmaWVsZHMgb3RoZXIgdGhhbiBzZWNyZXQuXG4gICAgdGhpcy5fc2VydmVyLnB1Ymxpc2goXCJtZXRlb3IubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvblwiLCAoKSA9PiB7XG4gICAgICBjb25zdCB7IFNlcnZpY2VDb25maWd1cmF0aW9uIH0gPSBQYWNrYWdlWydzZXJ2aWNlLWNvbmZpZ3VyYXRpb24nXTtcbiAgICAgIHJldHVybiBTZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5maW5kKHt9LCB7ZmllbGRzOiB7c2VjcmV0OiAwfX0pO1xuICAgIH0sIHtpc19hdXRvOiB0cnVlfSk7IC8vIG5vdCB0ZWNoaW5jYWxseSBhdXRvcHVibGlzaCwgYnV0IHN0b3BzIHRoZSB3YXJuaW5nLlxuXG4gICAgLy8gVXNlIE1ldGVvci5zdGFydHVwIHRvIGdpdmUgb3RoZXIgcGFja2FnZXMgYSBjaGFuY2UgdG8gY2FsbFxuICAgIC8vIHNldERlZmF1bHRQdWJsaXNoRmllbGRzLlxuICAgIE1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgICAgIC8vIFB1Ymxpc2ggdGhlIGN1cnJlbnQgdXNlcidzIHJlY29yZCB0byB0aGUgY2xpZW50LlxuICAgICAgdGhpcy5fc2VydmVyLnB1Ymxpc2gobnVsbCwgZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy51c2VySWQpIHtcbiAgICAgICAgICByZXR1cm4gdXNlcnMuZmluZCh7XG4gICAgICAgICAgICBfaWQ6IHRoaXMudXNlcklkXG4gICAgICAgICAgfSwge1xuICAgICAgICAgICAgZmllbGRzOiBfZGVmYXVsdFB1Ymxpc2hGaWVsZHMucHJvamVjdGlvbixcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfSwgLypzdXBwcmVzcyBhdXRvcHVibGlzaCB3YXJuaW5nKi97aXNfYXV0bzogdHJ1ZX0pO1xuICAgIH0pO1xuXG4gICAgLy8gVXNlIE1ldGVvci5zdGFydHVwIHRvIGdpdmUgb3RoZXIgcGFja2FnZXMgYSBjaGFuY2UgdG8gY2FsbFxuICAgIC8vIGFkZEF1dG9wdWJsaXNoRmllbGRzLlxuICAgIFBhY2thZ2UuYXV0b3B1Ymxpc2ggJiYgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgICAgLy8gWydwcm9maWxlJywgJ3VzZXJuYW1lJ10gLT4ge3Byb2ZpbGU6IDEsIHVzZXJuYW1lOiAxfVxuICAgICAgY29uc3QgdG9GaWVsZFNlbGVjdG9yID0gZmllbGRzID0+IGZpZWxkcy5yZWR1Y2UoKHByZXYsIGZpZWxkKSA9PiAoXG4gICAgICAgICAgeyAuLi5wcmV2LCBbZmllbGRdOiAxIH0pLFxuICAgICAgICB7fVxuICAgICAgKTtcbiAgICAgIHRoaXMuX3NlcnZlci5wdWJsaXNoKG51bGwsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMudXNlcklkKSB7XG4gICAgICAgICAgcmV0dXJuIHVzZXJzLmZpbmQoeyBfaWQ6IHRoaXMudXNlcklkIH0sIHtcbiAgICAgICAgICAgIGZpZWxkczogdG9GaWVsZFNlbGVjdG9yKF9hdXRvcHVibGlzaEZpZWxkcy5sb2dnZWRJblVzZXIpLFxuICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgIH0sIC8qc3VwcHJlc3MgYXV0b3B1Ymxpc2ggd2FybmluZyove2lzX2F1dG86IHRydWV9KTtcblxuICAgICAgLy8gWFhYIHRoaXMgcHVibGlzaCBpcyBuZWl0aGVyIGRlZHVwLWFibGUgbm9yIGlzIGl0IG9wdGltaXplZCBieSBvdXIgc3BlY2lhbFxuICAgICAgLy8gdHJlYXRtZW50IG9mIHF1ZXJpZXMgb24gYSBzcGVjaWZpYyBfaWQuIFRoZXJlZm9yZSB0aGlzIHdpbGwgaGF2ZSBPKG5eMilcbiAgICAgIC8vIHJ1bi10aW1lIHBlcmZvcm1hbmNlIGV2ZXJ5IHRpbWUgYSB1c2VyIGRvY3VtZW50IGlzIGNoYW5nZWQgKGVnIHNvbWVvbmVcbiAgICAgIC8vIGxvZ2dpbmcgaW4pLiBJZiB0aGlzIGlzIGEgcHJvYmxlbSwgd2UgY2FuIGluc3RlYWQgd3JpdGUgYSBtYW51YWwgcHVibGlzaFxuICAgICAgLy8gZnVuY3Rpb24gd2hpY2ggZmlsdGVycyBvdXQgZmllbGRzIGJhc2VkIG9uICd0aGlzLnVzZXJJZCcuXG4gICAgICB0aGlzLl9zZXJ2ZXIucHVibGlzaChudWxsLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNvbnN0IHNlbGVjdG9yID0gdGhpcy51c2VySWQgPyB7IF9pZDogeyAkbmU6IHRoaXMudXNlcklkIH0gfSA6IHt9O1xuICAgICAgICByZXR1cm4gdXNlcnMuZmluZChzZWxlY3Rvciwge1xuICAgICAgICAgIGZpZWxkczogdG9GaWVsZFNlbGVjdG9yKF9hdXRvcHVibGlzaEZpZWxkcy5vdGhlclVzZXJzKSxcbiAgICAgICAgfSlcbiAgICAgIH0sIC8qc3VwcHJlc3MgYXV0b3B1Ymxpc2ggd2FybmluZyove2lzX2F1dG86IHRydWV9KTtcbiAgICB9KTtcbiAgfTtcblxuICAvLyBBZGQgdG8gdGhlIGxpc3Qgb2YgZmllbGRzIG9yIHN1YmZpZWxkcyB0byBiZSBhdXRvbWF0aWNhbGx5XG4gIC8vIHB1Ymxpc2hlZCBpZiBhdXRvcHVibGlzaCBpcyBvbi4gTXVzdCBiZSBjYWxsZWQgZnJvbSB0b3AtbGV2ZWxcbiAgLy8gY29kZSAoaWUsIGJlZm9yZSBNZXRlb3Iuc3RhcnR1cCBob29rcyBydW4pLlxuICAvL1xuICAvLyBAcGFyYW0gb3B0cyB7T2JqZWN0fSB3aXRoOlxuICAvLyAgIC0gZm9yTG9nZ2VkSW5Vc2VyIHtBcnJheX0gQXJyYXkgb2YgZmllbGRzIHB1Ymxpc2hlZCB0byB0aGUgbG9nZ2VkLWluIHVzZXJcbiAgLy8gICAtIGZvck90aGVyVXNlcnMge0FycmF5fSBBcnJheSBvZiBmaWVsZHMgcHVibGlzaGVkIHRvIHVzZXJzIHRoYXQgYXJlbid0IGxvZ2dlZCBpblxuICBhZGRBdXRvcHVibGlzaEZpZWxkcyhvcHRzKSB7XG4gICAgdGhpcy5fYXV0b3B1Ymxpc2hGaWVsZHMubG9nZ2VkSW5Vc2VyLnB1c2guYXBwbHkoXG4gICAgICB0aGlzLl9hdXRvcHVibGlzaEZpZWxkcy5sb2dnZWRJblVzZXIsIG9wdHMuZm9yTG9nZ2VkSW5Vc2VyKTtcbiAgICB0aGlzLl9hdXRvcHVibGlzaEZpZWxkcy5vdGhlclVzZXJzLnB1c2guYXBwbHkoXG4gICAgICB0aGlzLl9hdXRvcHVibGlzaEZpZWxkcy5vdGhlclVzZXJzLCBvcHRzLmZvck90aGVyVXNlcnMpO1xuICB9O1xuXG4gIC8vIFJlcGxhY2VzIHRoZSBmaWVsZHMgdG8gYmUgYXV0b21hdGljYWxseVxuICAvLyBwdWJsaXNoZWQgd2hlbiB0aGUgdXNlciBsb2dzIGluXG4gIC8vXG4gIC8vIEBwYXJhbSB7TW9uZ29GaWVsZFNwZWNpZmllcn0gZmllbGRzIERpY3Rpb25hcnkgb2YgZmllbGRzIHRvIHJldHVybiBvciBleGNsdWRlLlxuICBzZXREZWZhdWx0UHVibGlzaEZpZWxkcyhmaWVsZHMpIHtcbiAgICB0aGlzLl9kZWZhdWx0UHVibGlzaEZpZWxkcy5wcm9qZWN0aW9uID0gZmllbGRzO1xuICB9O1xuXG4gIC8vL1xuICAvLy8gQUNDT1VOVCBEQVRBXG4gIC8vL1xuXG4gIC8vIEhBQ0s6IFRoaXMgaXMgdXNlZCBieSAnbWV0ZW9yLWFjY291bnRzJyB0byBnZXQgdGhlIGxvZ2luVG9rZW4gZm9yIGFcbiAgLy8gY29ubmVjdGlvbi4gTWF5YmUgdGhlcmUgc2hvdWxkIGJlIGEgcHVibGljIHdheSB0byBkbyB0aGF0LlxuICBfZ2V0QWNjb3VudERhdGEoY29ubmVjdGlvbklkLCBmaWVsZCkge1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLl9hY2NvdW50RGF0YVtjb25uZWN0aW9uSWRdO1xuICAgIHJldHVybiBkYXRhICYmIGRhdGFbZmllbGRdO1xuICB9O1xuXG4gIF9zZXRBY2NvdW50RGF0YShjb25uZWN0aW9uSWQsIGZpZWxkLCB2YWx1ZSkge1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLl9hY2NvdW50RGF0YVtjb25uZWN0aW9uSWRdO1xuXG4gICAgLy8gc2FmZXR5IGJlbHQuIHNob3VsZG4ndCBoYXBwZW4uIGFjY291bnREYXRhIGlzIHNldCBpbiBvbkNvbm5lY3Rpb24sXG4gICAgLy8gd2UgZG9uJ3QgaGF2ZSBhIGNvbm5lY3Rpb25JZCB1bnRpbCBpdCBpcyBzZXQuXG4gICAgaWYgKCFkYXRhKVxuICAgICAgcmV0dXJuO1xuXG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpXG4gICAgICBkZWxldGUgZGF0YVtmaWVsZF07XG4gICAgZWxzZVxuICAgICAgZGF0YVtmaWVsZF0gPSB2YWx1ZTtcbiAgfTtcblxuICAvLy9cbiAgLy8vIFJFQ09OTkVDVCBUT0tFTlNcbiAgLy8vXG4gIC8vLyBzdXBwb3J0IHJlY29ubmVjdGluZyB1c2luZyBhIG1ldGVvciBsb2dpbiB0b2tlblxuXG4gIF9oYXNoTG9naW5Ub2tlbihsb2dpblRva2VuKSB7XG4gICAgY29uc3QgaGFzaCA9IGNyeXB0by5jcmVhdGVIYXNoKCdzaGEyNTYnKTtcbiAgICBoYXNoLnVwZGF0ZShsb2dpblRva2VuKTtcbiAgICByZXR1cm4gaGFzaC5kaWdlc3QoJ2Jhc2U2NCcpO1xuICB9O1xuXG4gIC8vIHt0b2tlbiwgd2hlbn0gPT4ge2hhc2hlZFRva2VuLCB3aGVufVxuICBfaGFzaFN0YW1wZWRUb2tlbihzdGFtcGVkVG9rZW4pIHtcbiAgICBjb25zdCB7IHRva2VuLCAuLi5oYXNoZWRTdGFtcGVkVG9rZW4gfSA9IHN0YW1wZWRUb2tlbjtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uaGFzaGVkU3RhbXBlZFRva2VuLFxuICAgICAgaGFzaGVkVG9rZW46IHRoaXMuX2hhc2hMb2dpblRva2VuKHRva2VuKVxuICAgIH07XG4gIH07XG5cbiAgLy8gVXNpbmcgJGFkZFRvU2V0IGF2b2lkcyBnZXR0aW5nIGFuIGluZGV4IGVycm9yIGlmIGFub3RoZXIgY2xpZW50XG4gIC8vIGxvZ2dpbmcgaW4gc2ltdWx0YW5lb3VzbHkgaGFzIGFscmVhZHkgaW5zZXJ0ZWQgdGhlIG5ldyBoYXNoZWRcbiAgLy8gdG9rZW4uXG4gIF9pbnNlcnRIYXNoZWRMb2dpblRva2VuKHVzZXJJZCwgaGFzaGVkVG9rZW4sIHF1ZXJ5KSB7XG4gICAgcXVlcnkgPSBxdWVyeSA/IHsgLi4ucXVlcnkgfSA6IHt9O1xuICAgIHF1ZXJ5Ll9pZCA9IHVzZXJJZDtcbiAgICB0aGlzLnVzZXJzLnVwZGF0ZShxdWVyeSwge1xuICAgICAgJGFkZFRvU2V0OiB7XG4gICAgICAgIFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zXCI6IGhhc2hlZFRva2VuXG4gICAgICB9XG4gICAgfSk7XG4gIH07XG5cbiAgLy8gRXhwb3J0ZWQgZm9yIHRlc3RzLlxuICBfaW5zZXJ0TG9naW5Ub2tlbih1c2VySWQsIHN0YW1wZWRUb2tlbiwgcXVlcnkpIHtcbiAgICB0aGlzLl9pbnNlcnRIYXNoZWRMb2dpblRva2VuKFxuICAgICAgdXNlcklkLFxuICAgICAgdGhpcy5faGFzaFN0YW1wZWRUb2tlbihzdGFtcGVkVG9rZW4pLFxuICAgICAgcXVlcnlcbiAgICApO1xuICB9O1xuXG4gIF9jbGVhckFsbExvZ2luVG9rZW5zKHVzZXJJZCkge1xuICAgIHRoaXMudXNlcnMudXBkYXRlKHVzZXJJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICAnc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zJzogW11cbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcblxuICAvLyB0ZXN0IGhvb2tcbiAgX2dldFVzZXJPYnNlcnZlKGNvbm5lY3Rpb25JZCkge1xuICAgIHJldHVybiB0aGlzLl91c2VyT2JzZXJ2ZXNGb3JDb25uZWN0aW9uc1tjb25uZWN0aW9uSWRdO1xuICB9O1xuXG4gIC8vIENsZWFuIHVwIHRoaXMgY29ubmVjdGlvbidzIGFzc29jaWF0aW9uIHdpdGggdGhlIHRva2VuOiB0aGF0IGlzLCBzdG9wXG4gIC8vIHRoZSBvYnNlcnZlIHRoYXQgd2Ugc3RhcnRlZCB3aGVuIHdlIGFzc29jaWF0ZWQgdGhlIGNvbm5lY3Rpb24gd2l0aFxuICAvLyB0aGlzIHRva2VuLlxuICBfcmVtb3ZlVG9rZW5Gcm9tQ29ubmVjdGlvbihjb25uZWN0aW9uSWQpIHtcbiAgICBpZiAoaGFzT3duLmNhbGwodGhpcy5fdXNlck9ic2VydmVzRm9yQ29ubmVjdGlvbnMsIGNvbm5lY3Rpb25JZCkpIHtcbiAgICAgIGNvbnN0IG9ic2VydmUgPSB0aGlzLl91c2VyT2JzZXJ2ZXNGb3JDb25uZWN0aW9uc1tjb25uZWN0aW9uSWRdO1xuICAgICAgaWYgKHR5cGVvZiBvYnNlcnZlID09PSAnbnVtYmVyJykge1xuICAgICAgICAvLyBXZSdyZSBpbiB0aGUgcHJvY2VzcyBvZiBzZXR0aW5nIHVwIGFuIG9ic2VydmUgZm9yIHRoaXMgY29ubmVjdGlvbi4gV2VcbiAgICAgICAgLy8gY2FuJ3QgY2xlYW4gdXAgdGhhdCBvYnNlcnZlIHlldCwgYnV0IGlmIHdlIGRlbGV0ZSB0aGUgcGxhY2Vob2xkZXIgZm9yXG4gICAgICAgIC8vIHRoaXMgY29ubmVjdGlvbiwgdGhlbiB0aGUgb2JzZXJ2ZSB3aWxsIGdldCBjbGVhbmVkIHVwIGFzIHNvb24gYXMgaXQgaGFzXG4gICAgICAgIC8vIGJlZW4gc2V0IHVwLlxuICAgICAgICBkZWxldGUgdGhpcy5fdXNlck9ic2VydmVzRm9yQ29ubmVjdGlvbnNbY29ubmVjdGlvbklkXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRlbGV0ZSB0aGlzLl91c2VyT2JzZXJ2ZXNGb3JDb25uZWN0aW9uc1tjb25uZWN0aW9uSWRdO1xuICAgICAgICBvYnNlcnZlLnN0b3AoKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgX2dldExvZ2luVG9rZW4oY29ubmVjdGlvbklkKSB7XG4gICAgcmV0dXJuIHRoaXMuX2dldEFjY291bnREYXRhKGNvbm5lY3Rpb25JZCwgJ2xvZ2luVG9rZW4nKTtcbiAgfTtcblxuICAvLyBuZXdUb2tlbiBpcyBhIGhhc2hlZCB0b2tlbi5cbiAgX3NldExvZ2luVG9rZW4odXNlcklkLCBjb25uZWN0aW9uLCBuZXdUb2tlbikge1xuICAgIHRoaXMuX3JlbW92ZVRva2VuRnJvbUNvbm5lY3Rpb24oY29ubmVjdGlvbi5pZCk7XG4gICAgdGhpcy5fc2V0QWNjb3VudERhdGEoY29ubmVjdGlvbi5pZCwgJ2xvZ2luVG9rZW4nLCBuZXdUb2tlbik7XG5cbiAgICBpZiAobmV3VG9rZW4pIHtcbiAgICAgIC8vIFNldCB1cCBhbiBvYnNlcnZlIGZvciB0aGlzIHRva2VuLiBJZiB0aGUgdG9rZW4gZ29lcyBhd2F5LCB3ZSBuZWVkXG4gICAgICAvLyB0byBjbG9zZSB0aGUgY29ubmVjdGlvbi4gIFdlIGRlZmVyIHRoZSBvYnNlcnZlIGJlY2F1c2UgdGhlcmUnc1xuICAgICAgLy8gbm8gbmVlZCBmb3IgaXQgdG8gYmUgb24gdGhlIGNyaXRpY2FsIHBhdGggZm9yIGxvZ2luOyB3ZSBqdXN0IG5lZWRcbiAgICAgIC8vIHRvIGVuc3VyZSB0aGF0IHRoZSBjb25uZWN0aW9uIHdpbGwgZ2V0IGNsb3NlZCBhdCBzb21lIHBvaW50IGlmXG4gICAgICAvLyB0aGUgdG9rZW4gZ2V0cyBkZWxldGVkLlxuICAgICAgLy9cbiAgICAgIC8vIEluaXRpYWxseSwgd2Ugc2V0IHRoZSBvYnNlcnZlIGZvciB0aGlzIGNvbm5lY3Rpb24gdG8gYSBudW1iZXI7IHRoaXNcbiAgICAgIC8vIHNpZ25pZmllcyB0byBvdGhlciBjb2RlICh3aGljaCBtaWdodCBydW4gd2hpbGUgd2UgeWllbGQpIHRoYXQgd2UgYXJlIGluXG4gICAgICAvLyB0aGUgcHJvY2VzcyBvZiBzZXR0aW5nIHVwIGFuIG9ic2VydmUgZm9yIHRoaXMgY29ubmVjdGlvbi4gT25jZSB0aGVcbiAgICAgIC8vIG9ic2VydmUgaXMgcmVhZHkgdG8gZ28sIHdlIHJlcGxhY2UgdGhlIG51bWJlciB3aXRoIHRoZSByZWFsIG9ic2VydmVcbiAgICAgIC8vIGhhbmRsZSAodW5sZXNzIHRoZSBwbGFjZWhvbGRlciBoYXMgYmVlbiBkZWxldGVkIG9yIHJlcGxhY2VkIGJ5IGFcbiAgICAgIC8vIGRpZmZlcmVudCBwbGFjZWhvbGQgbnVtYmVyLCBzaWduaWZ5aW5nIHRoYXQgdGhlIGNvbm5lY3Rpb24gd2FzIGNsb3NlZFxuICAgICAgLy8gYWxyZWFkeSAtLSBpbiB0aGlzIGNhc2Ugd2UganVzdCBjbGVhbiB1cCB0aGUgb2JzZXJ2ZSB0aGF0IHdlIHN0YXJ0ZWQpLlxuICAgICAgY29uc3QgbXlPYnNlcnZlTnVtYmVyID0gKyt0aGlzLl9uZXh0VXNlck9ic2VydmVOdW1iZXI7XG4gICAgICB0aGlzLl91c2VyT2JzZXJ2ZXNGb3JDb25uZWN0aW9uc1tjb25uZWN0aW9uLmlkXSA9IG15T2JzZXJ2ZU51bWJlcjtcbiAgICAgIE1ldGVvci5kZWZlcigoKSA9PiB7XG4gICAgICAgIC8vIElmIHNvbWV0aGluZyBlbHNlIGhhcHBlbmVkIG9uIHRoaXMgY29ubmVjdGlvbiBpbiB0aGUgbWVhbnRpbWUgKGl0IGdvdFxuICAgICAgICAvLyBjbG9zZWQsIG9yIGFub3RoZXIgY2FsbCB0byBfc2V0TG9naW5Ub2tlbiBoYXBwZW5lZCksIGp1c3QgZG9cbiAgICAgICAgLy8gbm90aGluZy4gV2UgZG9uJ3QgbmVlZCB0byBzdGFydCBhbiBvYnNlcnZlIGZvciBhbiBvbGQgY29ubmVjdGlvbiBvciBvbGRcbiAgICAgICAgLy8gdG9rZW4uXG4gICAgICAgIGlmICh0aGlzLl91c2VyT2JzZXJ2ZXNGb3JDb25uZWN0aW9uc1tjb25uZWN0aW9uLmlkXSAhPT0gbXlPYnNlcnZlTnVtYmVyKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IGZvdW5kTWF0Y2hpbmdVc2VyO1xuICAgICAgICAvLyBCZWNhdXNlIHdlIHVwZ3JhZGUgdW5oYXNoZWQgbG9naW4gdG9rZW5zIHRvIGhhc2hlZCB0b2tlbnMgYXRcbiAgICAgICAgLy8gbG9naW4gdGltZSwgc2Vzc2lvbnMgd2lsbCBvbmx5IGJlIGxvZ2dlZCBpbiB3aXRoIGEgaGFzaGVkXG4gICAgICAgIC8vIHRva2VuLiBUaHVzIHdlIG9ubHkgbmVlZCB0byBvYnNlcnZlIGhhc2hlZCB0b2tlbnMgaGVyZS5cbiAgICAgICAgY29uc3Qgb2JzZXJ2ZSA9IHRoaXMudXNlcnMuZmluZCh7XG4gICAgICAgICAgX2lkOiB1c2VySWQsXG4gICAgICAgICAgJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucy5oYXNoZWRUb2tlbic6IG5ld1Rva2VuXG4gICAgICAgIH0sIHsgZmllbGRzOiB7IF9pZDogMSB9IH0pLm9ic2VydmVDaGFuZ2VzKHtcbiAgICAgICAgICBhZGRlZDogKCkgPT4ge1xuICAgICAgICAgICAgZm91bmRNYXRjaGluZ1VzZXIgPSB0cnVlO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVtb3ZlZDogY29ubmVjdGlvbi5jbG9zZSxcbiAgICAgICAgICAvLyBUaGUgb25DbG9zZSBjYWxsYmFjayBmb3IgdGhlIGNvbm5lY3Rpb24gdGFrZXMgY2FyZSBvZlxuICAgICAgICAgIC8vIGNsZWFuaW5nIHVwIHRoZSBvYnNlcnZlIGhhbmRsZSBhbmQgYW55IG90aGVyIHN0YXRlIHdlIGhhdmVcbiAgICAgICAgICAvLyBseWluZyBhcm91bmQuXG4gICAgICAgIH0sIHsgbm9uTXV0YXRpbmdDYWxsYmFja3M6IHRydWUgfSk7XG5cbiAgICAgICAgLy8gSWYgdGhlIHVzZXIgcmFuIGFub3RoZXIgbG9naW4gb3IgbG9nb3V0IGNvbW1hbmQgd2Ugd2VyZSB3YWl0aW5nIGZvciB0aGVcbiAgICAgICAgLy8gZGVmZXIgb3IgYWRkZWQgdG8gZmlyZSAoaWUsIGFub3RoZXIgY2FsbCB0byBfc2V0TG9naW5Ub2tlbiBvY2N1cnJlZCksXG4gICAgICAgIC8vIHRoZW4gd2UgbGV0IHRoZSBsYXRlciBvbmUgd2luIChzdGFydCBhbiBvYnNlcnZlLCBldGMpIGFuZCBqdXN0IHN0b3Agb3VyXG4gICAgICAgIC8vIG9ic2VydmUgbm93LlxuICAgICAgICAvL1xuICAgICAgICAvLyBTaW1pbGFybHksIGlmIHRoZSBjb25uZWN0aW9uIHdhcyBhbHJlYWR5IGNsb3NlZCwgdGhlbiB0aGUgb25DbG9zZVxuICAgICAgICAvLyBjYWxsYmFjayB3b3VsZCBoYXZlIGNhbGxlZCBfcmVtb3ZlVG9rZW5Gcm9tQ29ubmVjdGlvbiBhbmQgdGhlcmUgd29uJ3RcbiAgICAgICAgLy8gYmUgYW4gZW50cnkgaW4gX3VzZXJPYnNlcnZlc0ZvckNvbm5lY3Rpb25zLiBXZSBjYW4gc3RvcCB0aGUgb2JzZXJ2ZS5cbiAgICAgICAgaWYgKHRoaXMuX3VzZXJPYnNlcnZlc0ZvckNvbm5lY3Rpb25zW2Nvbm5lY3Rpb24uaWRdICE9PSBteU9ic2VydmVOdW1iZXIpIHtcbiAgICAgICAgICBvYnNlcnZlLnN0b3AoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl91c2VyT2JzZXJ2ZXNGb3JDb25uZWN0aW9uc1tjb25uZWN0aW9uLmlkXSA9IG9ic2VydmU7XG5cbiAgICAgICAgaWYgKCEgZm91bmRNYXRjaGluZ1VzZXIpIHtcbiAgICAgICAgICAvLyBXZSd2ZSBzZXQgdXAgYW4gb2JzZXJ2ZSBvbiB0aGUgdXNlciBhc3NvY2lhdGVkIHdpdGggYG5ld1Rva2VuYCxcbiAgICAgICAgICAvLyBzbyBpZiB0aGUgbmV3IHRva2VuIGlzIHJlbW92ZWQgZnJvbSB0aGUgZGF0YWJhc2UsIHdlJ2xsIGNsb3NlXG4gICAgICAgICAgLy8gdGhlIGNvbm5lY3Rpb24uIEJ1dCB0aGUgdG9rZW4gbWlnaHQgaGF2ZSBhbHJlYWR5IGJlZW4gZGVsZXRlZFxuICAgICAgICAgIC8vIGJlZm9yZSB3ZSBzZXQgdXAgdGhlIG9ic2VydmUsIHdoaWNoIHdvdWxkbid0IGhhdmUgY2xvc2VkIHRoZVxuICAgICAgICAgIC8vIGNvbm5lY3Rpb24gYmVjYXVzZSB0aGUgb2JzZXJ2ZSB3YXNuJ3QgcnVubmluZyB5ZXQuXG4gICAgICAgICAgY29ubmVjdGlvbi5jbG9zZSgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy8gKEFsc28gdXNlZCBieSBNZXRlb3IgQWNjb3VudHMgc2VydmVyIGFuZCB0ZXN0cykuXG4gIC8vXG4gIF9nZW5lcmF0ZVN0YW1wZWRMb2dpblRva2VuKCkge1xuICAgIHJldHVybiB7XG4gICAgICB0b2tlbjogUmFuZG9tLnNlY3JldCgpLFxuICAgICAgd2hlbjogbmV3IERhdGVcbiAgICB9O1xuICB9O1xuXG4gIC8vL1xuICAvLy8gVE9LRU4gRVhQSVJBVElPTlxuICAvLy9cblxuICAvLyBEZWxldGVzIGV4cGlyZWQgcGFzc3dvcmQgcmVzZXQgdG9rZW5zIGZyb20gdGhlIGRhdGFiYXNlLlxuICAvL1xuICAvLyBFeHBvcnRlZCBmb3IgdGVzdHMuIEFsc28sIHRoZSBhcmd1bWVudHMgYXJlIG9ubHkgdXNlZCBieVxuICAvLyB0ZXN0cy4gb2xkZXN0VmFsaWREYXRlIGlzIHNpbXVsYXRlIGV4cGlyaW5nIHRva2VucyB3aXRob3V0IHdhaXRpbmdcbiAgLy8gZm9yIHRoZW0gdG8gYWN0dWFsbHkgZXhwaXJlLiB1c2VySWQgaXMgdXNlZCBieSB0ZXN0cyB0byBvbmx5IGV4cGlyZVxuICAvLyB0b2tlbnMgZm9yIHRoZSB0ZXN0IHVzZXIuXG4gIF9leHBpcmVQYXNzd29yZFJlc2V0VG9rZW5zKG9sZGVzdFZhbGlkRGF0ZSwgdXNlcklkKSB7XG4gICAgY29uc3QgdG9rZW5MaWZldGltZU1zID0gdGhpcy5fZ2V0UGFzc3dvcmRSZXNldFRva2VuTGlmZXRpbWVNcygpO1xuXG4gICAgLy8gd2hlbiBjYWxsaW5nIGZyb20gYSB0ZXN0IHdpdGggZXh0cmEgYXJndW1lbnRzLCB5b3UgbXVzdCBzcGVjaWZ5IGJvdGghXG4gICAgaWYgKChvbGRlc3RWYWxpZERhdGUgJiYgIXVzZXJJZCkgfHwgKCFvbGRlc3RWYWxpZERhdGUgJiYgdXNlcklkKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQmFkIHRlc3QuIE11c3Qgc3BlY2lmeSBib3RoIG9sZGVzdFZhbGlkRGF0ZSBhbmQgdXNlcklkLlwiKTtcbiAgICB9XG5cbiAgICBvbGRlc3RWYWxpZERhdGUgPSBvbGRlc3RWYWxpZERhdGUgfHxcbiAgICAgIChuZXcgRGF0ZShuZXcgRGF0ZSgpIC0gdG9rZW5MaWZldGltZU1zKSk7XG5cbiAgICBjb25zdCB0b2tlbkZpbHRlciA9IHtcbiAgICAgICRvcjogW1xuICAgICAgICB7IFwic2VydmljZXMucGFzc3dvcmQucmVzZXQucmVhc29uXCI6IFwicmVzZXRcIn0sXG4gICAgICAgIHsgXCJzZXJ2aWNlcy5wYXNzd29yZC5yZXNldC5yZWFzb25cIjogeyRleGlzdHM6IGZhbHNlfX1cbiAgICAgIF1cbiAgICB9O1xuXG4gICAgZXhwaXJlUGFzc3dvcmRUb2tlbih0aGlzLCBvbGRlc3RWYWxpZERhdGUsIHRva2VuRmlsdGVyLCB1c2VySWQpO1xuICB9XG5cbiAgLy8gRGVsZXRlcyBleHBpcmVkIHBhc3N3b3JkIGVucm9sbCB0b2tlbnMgZnJvbSB0aGUgZGF0YWJhc2UuXG4gIC8vXG4gIC8vIEV4cG9ydGVkIGZvciB0ZXN0cy4gQWxzbywgdGhlIGFyZ3VtZW50cyBhcmUgb25seSB1c2VkIGJ5XG4gIC8vIHRlc3RzLiBvbGRlc3RWYWxpZERhdGUgaXMgc2ltdWxhdGUgZXhwaXJpbmcgdG9rZW5zIHdpdGhvdXQgd2FpdGluZ1xuICAvLyBmb3IgdGhlbSB0byBhY3R1YWxseSBleHBpcmUuIHVzZXJJZCBpcyB1c2VkIGJ5IHRlc3RzIHRvIG9ubHkgZXhwaXJlXG4gIC8vIHRva2VucyBmb3IgdGhlIHRlc3QgdXNlci5cbiAgX2V4cGlyZVBhc3N3b3JkRW5yb2xsVG9rZW5zKG9sZGVzdFZhbGlkRGF0ZSwgdXNlcklkKSB7XG4gICAgY29uc3QgdG9rZW5MaWZldGltZU1zID0gdGhpcy5fZ2V0UGFzc3dvcmRFbnJvbGxUb2tlbkxpZmV0aW1lTXMoKTtcblxuICAgIC8vIHdoZW4gY2FsbGluZyBmcm9tIGEgdGVzdCB3aXRoIGV4dHJhIGFyZ3VtZW50cywgeW91IG11c3Qgc3BlY2lmeSBib3RoIVxuICAgIGlmICgob2xkZXN0VmFsaWREYXRlICYmICF1c2VySWQpIHx8ICghb2xkZXN0VmFsaWREYXRlICYmIHVzZXJJZCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkJhZCB0ZXN0LiBNdXN0IHNwZWNpZnkgYm90aCBvbGRlc3RWYWxpZERhdGUgYW5kIHVzZXJJZC5cIik7XG4gICAgfVxuXG4gICAgb2xkZXN0VmFsaWREYXRlID0gb2xkZXN0VmFsaWREYXRlIHx8XG4gICAgICAobmV3IERhdGUobmV3IERhdGUoKSAtIHRva2VuTGlmZXRpbWVNcykpO1xuXG4gICAgY29uc3QgdG9rZW5GaWx0ZXIgPSB7XG4gICAgICBcInNlcnZpY2VzLnBhc3N3b3JkLnJlc2V0LnJlYXNvblwiOiBcImVucm9sbFwiXG4gICAgfTtcblxuICAgIGV4cGlyZVBhc3N3b3JkVG9rZW4odGhpcywgb2xkZXN0VmFsaWREYXRlLCB0b2tlbkZpbHRlciwgdXNlcklkKTtcbiAgfVxuXG4gIC8vIERlbGV0ZXMgZXhwaXJlZCB0b2tlbnMgZnJvbSB0aGUgZGF0YWJhc2UgYW5kIGNsb3NlcyBhbGwgb3BlbiBjb25uZWN0aW9uc1xuICAvLyBhc3NvY2lhdGVkIHdpdGggdGhlc2UgdG9rZW5zLlxuICAvL1xuICAvLyBFeHBvcnRlZCBmb3IgdGVzdHMuIEFsc28sIHRoZSBhcmd1bWVudHMgYXJlIG9ubHkgdXNlZCBieVxuICAvLyB0ZXN0cy4gb2xkZXN0VmFsaWREYXRlIGlzIHNpbXVsYXRlIGV4cGlyaW5nIHRva2VucyB3aXRob3V0IHdhaXRpbmdcbiAgLy8gZm9yIHRoZW0gdG8gYWN0dWFsbHkgZXhwaXJlLiB1c2VySWQgaXMgdXNlZCBieSB0ZXN0cyB0byBvbmx5IGV4cGlyZVxuICAvLyB0b2tlbnMgZm9yIHRoZSB0ZXN0IHVzZXIuXG4gIF9leHBpcmVUb2tlbnMob2xkZXN0VmFsaWREYXRlLCB1c2VySWQpIHtcbiAgICBjb25zdCB0b2tlbkxpZmV0aW1lTXMgPSB0aGlzLl9nZXRUb2tlbkxpZmV0aW1lTXMoKTtcblxuICAgIC8vIHdoZW4gY2FsbGluZyBmcm9tIGEgdGVzdCB3aXRoIGV4dHJhIGFyZ3VtZW50cywgeW91IG11c3Qgc3BlY2lmeSBib3RoIVxuICAgIGlmICgob2xkZXN0VmFsaWREYXRlICYmICF1c2VySWQpIHx8ICghb2xkZXN0VmFsaWREYXRlICYmIHVzZXJJZCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkJhZCB0ZXN0LiBNdXN0IHNwZWNpZnkgYm90aCBvbGRlc3RWYWxpZERhdGUgYW5kIHVzZXJJZC5cIik7XG4gICAgfVxuXG4gICAgb2xkZXN0VmFsaWREYXRlID0gb2xkZXN0VmFsaWREYXRlIHx8XG4gICAgICAobmV3IERhdGUobmV3IERhdGUoKSAtIHRva2VuTGlmZXRpbWVNcykpO1xuICAgIGNvbnN0IHVzZXJGaWx0ZXIgPSB1c2VySWQgPyB7X2lkOiB1c2VySWR9IDoge307XG5cblxuICAgIC8vIEJhY2t3YXJkcyBjb21wYXRpYmxlIHdpdGggb2xkZXIgdmVyc2lvbnMgb2YgbWV0ZW9yIHRoYXQgc3RvcmVkIGxvZ2luIHRva2VuXG4gICAgLy8gdGltZXN0YW1wcyBhcyBudW1iZXJzLlxuICAgIHRoaXMudXNlcnMudXBkYXRlKHsgLi4udXNlckZpbHRlcixcbiAgICAgICRvcjogW1xuICAgICAgICB7IFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zLndoZW5cIjogeyAkbHQ6IG9sZGVzdFZhbGlkRGF0ZSB9IH0sXG4gICAgICAgIHsgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMud2hlblwiOiB7ICRsdDogK29sZGVzdFZhbGlkRGF0ZSB9IH1cbiAgICAgIF1cbiAgICB9LCB7XG4gICAgICAkcHVsbDoge1xuICAgICAgICBcInNlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vuc1wiOiB7XG4gICAgICAgICAgJG9yOiBbXG4gICAgICAgICAgICB7IHdoZW46IHsgJGx0OiBvbGRlc3RWYWxpZERhdGUgfSB9LFxuICAgICAgICAgICAgeyB3aGVuOiB7ICRsdDogK29sZGVzdFZhbGlkRGF0ZSB9IH1cbiAgICAgICAgICBdXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCB7IG11bHRpOiB0cnVlIH0pO1xuICAgIC8vIFRoZSBvYnNlcnZlIG9uIE1ldGVvci51c2VycyB3aWxsIHRha2UgY2FyZSBvZiBjbG9zaW5nIGNvbm5lY3Rpb25zIGZvclxuICAgIC8vIGV4cGlyZWQgdG9rZW5zLlxuICB9O1xuXG4gIC8vIEBvdmVycmlkZSBmcm9tIGFjY291bnRzX2NvbW1vbi5qc1xuICBjb25maWcob3B0aW9ucykge1xuICAgIC8vIENhbGwgdGhlIG92ZXJyaWRkZW4gaW1wbGVtZW50YXRpb24gb2YgdGhlIG1ldGhvZC5cbiAgICBjb25zdCBzdXBlclJlc3VsdCA9IEFjY291bnRzQ29tbW9uLnByb3RvdHlwZS5jb25maWcuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuICAgIC8vIElmIHRoZSB1c2VyIHNldCBsb2dpbkV4cGlyYXRpb25JbkRheXMgdG8gbnVsbCwgdGhlbiB3ZSBuZWVkIHRvIGNsZWFyIHRoZVxuICAgIC8vIHRpbWVyIHRoYXQgcGVyaW9kaWNhbGx5IGV4cGlyZXMgdG9rZW5zLlxuICAgIGlmIChoYXNPd24uY2FsbCh0aGlzLl9vcHRpb25zLCAnbG9naW5FeHBpcmF0aW9uSW5EYXlzJykgJiZcbiAgICAgIHRoaXMuX29wdGlvbnMubG9naW5FeHBpcmF0aW9uSW5EYXlzID09PSBudWxsICYmXG4gICAgICB0aGlzLmV4cGlyZVRva2VuSW50ZXJ2YWwpIHtcbiAgICAgIE1ldGVvci5jbGVhckludGVydmFsKHRoaXMuZXhwaXJlVG9rZW5JbnRlcnZhbCk7XG4gICAgICB0aGlzLmV4cGlyZVRva2VuSW50ZXJ2YWwgPSBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiBzdXBlclJlc3VsdDtcbiAgfTtcblxuICAvLyBDYWxsZWQgYnkgYWNjb3VudHMtcGFzc3dvcmRcbiAgaW5zZXJ0VXNlckRvYyhvcHRpb25zLCB1c2VyKSB7XG4gICAgLy8gLSBjbG9uZSB1c2VyIGRvY3VtZW50LCB0byBwcm90ZWN0IGZyb20gbW9kaWZpY2F0aW9uXG4gICAgLy8gLSBhZGQgY3JlYXRlZEF0IHRpbWVzdGFtcFxuICAgIC8vIC0gcHJlcGFyZSBhbiBfaWQsIHNvIHRoYXQgeW91IGNhbiBtb2RpZnkgb3RoZXIgY29sbGVjdGlvbnMgKGVnXG4gICAgLy8gY3JlYXRlIGEgZmlyc3QgdGFzayBmb3IgZXZlcnkgbmV3IHVzZXIpXG4gICAgLy9cbiAgICAvLyBYWFggSWYgdGhlIG9uQ3JlYXRlVXNlciBvciB2YWxpZGF0ZU5ld1VzZXIgaG9va3MgZmFpbCwgd2UgbWlnaHRcbiAgICAvLyBlbmQgdXAgaGF2aW5nIG1vZGlmaWVkIHNvbWUgb3RoZXIgY29sbGVjdGlvblxuICAgIC8vIGluYXBwcm9wcmlhdGVseS4gVGhlIHNvbHV0aW9uIGlzIHByb2JhYmx5IHRvIGhhdmUgb25DcmVhdGVVc2VyXG4gICAgLy8gYWNjZXB0IHR3byBjYWxsYmFja3MgLSBvbmUgdGhhdCBnZXRzIGNhbGxlZCBiZWZvcmUgaW5zZXJ0aW5nXG4gICAgLy8gdGhlIHVzZXIgZG9jdW1lbnQgKGluIHdoaWNoIHlvdSBjYW4gbW9kaWZ5IGl0cyBjb250ZW50cyksIGFuZFxuICAgIC8vIG9uZSB0aGF0IGdldHMgY2FsbGVkIGFmdGVyIChpbiB3aGljaCB5b3Ugc2hvdWxkIGNoYW5nZSBvdGhlclxuICAgIC8vIGNvbGxlY3Rpb25zKVxuICAgIHVzZXIgPSB7XG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICBfaWQ6IFJhbmRvbS5pZCgpLFxuICAgICAgLi4udXNlcixcbiAgICB9O1xuXG4gICAgaWYgKHVzZXIuc2VydmljZXMpIHtcbiAgICAgIE9iamVjdC5rZXlzKHVzZXIuc2VydmljZXMpLmZvckVhY2goc2VydmljZSA9PlxuICAgICAgICBwaW5FbmNyeXB0ZWRGaWVsZHNUb1VzZXIodXNlci5zZXJ2aWNlc1tzZXJ2aWNlXSwgdXNlci5faWQpXG4gICAgICApO1xuICAgIH1cblxuICAgIGxldCBmdWxsVXNlcjtcbiAgICBpZiAodGhpcy5fb25DcmVhdGVVc2VySG9vaykge1xuICAgICAgZnVsbFVzZXIgPSB0aGlzLl9vbkNyZWF0ZVVzZXJIb29rKG9wdGlvbnMsIHVzZXIpO1xuXG4gICAgICAvLyBUaGlzIGlzICpub3QqIHBhcnQgb2YgdGhlIEFQSS4gV2UgbmVlZCB0aGlzIGJlY2F1c2Ugd2UgY2FuJ3QgaXNvbGF0ZVxuICAgICAgLy8gdGhlIGdsb2JhbCBzZXJ2ZXIgZW52aXJvbm1lbnQgYmV0d2VlbiB0ZXN0cywgbWVhbmluZyB3ZSBjYW4ndCB0ZXN0XG4gICAgICAvLyBib3RoIGhhdmluZyBhIGNyZWF0ZSB1c2VyIGhvb2sgc2V0IGFuZCBub3QgaGF2aW5nIG9uZSBzZXQuXG4gICAgICBpZiAoZnVsbFVzZXIgPT09ICdURVNUIERFRkFVTFQgSE9PSycpXG4gICAgICAgIGZ1bGxVc2VyID0gZGVmYXVsdENyZWF0ZVVzZXJIb29rKG9wdGlvbnMsIHVzZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmdWxsVXNlciA9IGRlZmF1bHRDcmVhdGVVc2VySG9vayhvcHRpb25zLCB1c2VyKTtcbiAgICB9XG5cbiAgICB0aGlzLl92YWxpZGF0ZU5ld1VzZXJIb29rcy5mb3JFYWNoKGhvb2sgPT4ge1xuICAgICAgaWYgKCEgaG9vayhmdWxsVXNlcikpXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlVzZXIgdmFsaWRhdGlvbiBmYWlsZWRcIik7XG4gICAgfSk7XG5cbiAgICBsZXQgdXNlcklkO1xuICAgIHRyeSB7XG4gICAgICB1c2VySWQgPSB0aGlzLnVzZXJzLmluc2VydChmdWxsVXNlcik7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gWFhYIHN0cmluZyBwYXJzaW5nIHN1Y2tzLCBtYXliZVxuICAgICAgLy8gaHR0cHM6Ly9qaXJhLm1vbmdvZGIub3JnL2Jyb3dzZS9TRVJWRVItMzA2OSB3aWxsIGdldCBmaXhlZCBvbmUgZGF5XG4gICAgICBpZiAoIWUuZXJybXNnKSB0aHJvdyBlO1xuICAgICAgaWYgKGUuZXJybXNnLmluY2x1ZGVzKCdlbWFpbHMuYWRkcmVzcycpKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJFbWFpbCBhbHJlYWR5IGV4aXN0cy5cIik7XG4gICAgICBpZiAoZS5lcnJtc2cuaW5jbHVkZXMoJ3VzZXJuYW1lJykpXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlVzZXJuYW1lIGFscmVhZHkgZXhpc3RzLlwiKTtcbiAgICAgIHRocm93IGU7XG4gICAgfVxuICAgIHJldHVybiB1c2VySWQ7XG4gIH07XG5cbiAgLy8gSGVscGVyIGZ1bmN0aW9uOiByZXR1cm5zIGZhbHNlIGlmIGVtYWlsIGRvZXMgbm90IG1hdGNoIGNvbXBhbnkgZG9tYWluIGZyb21cbiAgLy8gdGhlIGNvbmZpZ3VyYXRpb24uXG4gIF90ZXN0RW1haWxEb21haW4oZW1haWwpIHtcbiAgICBjb25zdCBkb21haW4gPSB0aGlzLl9vcHRpb25zLnJlc3RyaWN0Q3JlYXRpb25CeUVtYWlsRG9tYWluO1xuXG4gICAgcmV0dXJuICFkb21haW4gfHxcbiAgICAgICh0eXBlb2YgZG9tYWluID09PSAnZnVuY3Rpb24nICYmIGRvbWFpbihlbWFpbCkpIHx8XG4gICAgICAodHlwZW9mIGRvbWFpbiA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgKG5ldyBSZWdFeHAoYEAke01ldGVvci5fZXNjYXBlUmVnRXhwKGRvbWFpbil9JGAsICdpJykpLnRlc3QoZW1haWwpKTtcbiAgfTtcblxuICAvLy9cbiAgLy8vIENMRUFOIFVQIEZPUiBgbG9nb3V0T3RoZXJDbGllbnRzYFxuICAvLy9cblxuICBfZGVsZXRlU2F2ZWRUb2tlbnNGb3JVc2VyKHVzZXJJZCwgdG9rZW5zVG9EZWxldGUpIHtcbiAgICBpZiAodG9rZW5zVG9EZWxldGUpIHtcbiAgICAgIHRoaXMudXNlcnMudXBkYXRlKHVzZXJJZCwge1xuICAgICAgICAkdW5zZXQ6IHtcbiAgICAgICAgICBcInNlcnZpY2VzLnJlc3VtZS5oYXZlTG9naW5Ub2tlbnNUb0RlbGV0ZVwiOiAxLFxuICAgICAgICAgIFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zVG9EZWxldGVcIjogMVxuICAgICAgICB9LFxuICAgICAgICAkcHVsbEFsbDoge1xuICAgICAgICAgIFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zXCI6IHRva2Vuc1RvRGVsZXRlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBfZGVsZXRlU2F2ZWRUb2tlbnNGb3JBbGxVc2Vyc09uU3RhcnR1cCgpIHtcbiAgICAvLyBJZiB3ZSBmaW5kIHVzZXJzIHdobyBoYXZlIHNhdmVkIHRva2VucyB0byBkZWxldGUgb24gc3RhcnR1cCwgZGVsZXRlXG4gICAgLy8gdGhlbSBub3cuIEl0J3MgcG9zc2libGUgdGhhdCB0aGUgc2VydmVyIGNvdWxkIGhhdmUgY3Jhc2hlZCBhbmQgY29tZVxuICAgIC8vIGJhY2sgdXAgYmVmb3JlIG5ldyB0b2tlbnMgYXJlIGZvdW5kIGluIGxvY2FsU3RvcmFnZSwgYnV0IHRoaXNcbiAgICAvLyBzaG91bGRuJ3QgaGFwcGVuIHZlcnkgb2Z0ZW4uIFdlIHNob3VsZG4ndCBwdXQgYSBkZWxheSBoZXJlIGJlY2F1c2VcbiAgICAvLyB0aGF0IHdvdWxkIGdpdmUgYSBsb3Qgb2YgcG93ZXIgdG8gYW4gYXR0YWNrZXIgd2l0aCBhIHN0b2xlbiBsb2dpblxuICAgIC8vIHRva2VuIGFuZCB0aGUgYWJpbGl0eSB0byBjcmFzaCB0aGUgc2VydmVyLlxuICAgIE1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgICAgIHRoaXMudXNlcnMuZmluZCh7XG4gICAgICAgIFwic2VydmljZXMucmVzdW1lLmhhdmVMb2dpblRva2Vuc1RvRGVsZXRlXCI6IHRydWVcbiAgICAgIH0sIHtmaWVsZHM6IHtcbiAgICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNUb0RlbGV0ZVwiOiAxXG4gICAgICB9fSkuZm9yRWFjaCh1c2VyID0+IHtcbiAgICAgICAgdGhpcy5fZGVsZXRlU2F2ZWRUb2tlbnNGb3JVc2VyKFxuICAgICAgICAgIHVzZXIuX2lkLFxuICAgICAgICAgIHVzZXIuc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zVG9EZWxldGVcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9O1xuXG4gIC8vL1xuICAvLy8gTUFOQUdJTkcgVVNFUiBPQkpFQ1RTXG4gIC8vL1xuXG4gIC8vIFVwZGF0ZXMgb3IgY3JlYXRlcyBhIHVzZXIgYWZ0ZXIgd2UgYXV0aGVudGljYXRlIHdpdGggYSAzcmQgcGFydHkuXG4gIC8vXG4gIC8vIEBwYXJhbSBzZXJ2aWNlTmFtZSB7U3RyaW5nfSBTZXJ2aWNlIG5hbWUgKGVnLCB0d2l0dGVyKS5cbiAgLy8gQHBhcmFtIHNlcnZpY2VEYXRhIHtPYmplY3R9IERhdGEgdG8gc3RvcmUgaW4gdGhlIHVzZXIncyByZWNvcmRcbiAgLy8gICAgICAgIHVuZGVyIHNlcnZpY2VzW3NlcnZpY2VOYW1lXS4gTXVzdCBpbmNsdWRlIGFuIFwiaWRcIiBmaWVsZFxuICAvLyAgICAgICAgd2hpY2ggaXMgYSB1bmlxdWUgaWRlbnRpZmllciBmb3IgdGhlIHVzZXIgaW4gdGhlIHNlcnZpY2UuXG4gIC8vIEBwYXJhbSBvcHRpb25zIHtPYmplY3QsIG9wdGlvbmFsfSBPdGhlciBvcHRpb25zIHRvIHBhc3MgdG8gaW5zZXJ0VXNlckRvY1xuICAvLyAgICAgICAgKGVnLCBwcm9maWxlKVxuICAvLyBAcmV0dXJucyB7T2JqZWN0fSBPYmplY3Qgd2l0aCB0b2tlbiBhbmQgaWQga2V5cywgbGlrZSB0aGUgcmVzdWx0XG4gIC8vICAgICAgICBvZiB0aGUgXCJsb2dpblwiIG1ldGhvZC5cbiAgLy9cbiAgdXBkYXRlT3JDcmVhdGVVc2VyRnJvbUV4dGVybmFsU2VydmljZShcbiAgICBzZXJ2aWNlTmFtZSxcbiAgICBzZXJ2aWNlRGF0YSxcbiAgICBvcHRpb25zXG4gICkge1xuICAgIG9wdGlvbnMgPSB7IC4uLm9wdGlvbnMgfTtcblxuICAgIGlmIChzZXJ2aWNlTmFtZSA9PT0gXCJwYXNzd29yZFwiIHx8IHNlcnZpY2VOYW1lID09PSBcInJlc3VtZVwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIFwiQ2FuJ3QgdXNlIHVwZGF0ZU9yQ3JlYXRlVXNlckZyb21FeHRlcm5hbFNlcnZpY2Ugd2l0aCBpbnRlcm5hbCBzZXJ2aWNlIFwiXG4gICAgICAgICsgc2VydmljZU5hbWUpO1xuICAgIH1cbiAgICBpZiAoIWhhc093bi5jYWxsKHNlcnZpY2VEYXRhLCAnaWQnKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgU2VydmljZSBkYXRhIGZvciBzZXJ2aWNlICR7c2VydmljZU5hbWV9IG11c3QgaW5jbHVkZSBpZGApO1xuICAgIH1cblxuICAgIC8vIExvb2sgZm9yIGEgdXNlciB3aXRoIHRoZSBhcHByb3ByaWF0ZSBzZXJ2aWNlIHVzZXIgaWQuXG4gICAgY29uc3Qgc2VsZWN0b3IgPSB7fTtcbiAgICBjb25zdCBzZXJ2aWNlSWRLZXkgPSBgc2VydmljZXMuJHtzZXJ2aWNlTmFtZX0uaWRgO1xuXG4gICAgLy8gWFhYIFRlbXBvcmFyeSBzcGVjaWFsIGNhc2UgZm9yIFR3aXR0ZXIuIChJc3N1ZSAjNjI5KVxuICAgIC8vICAgVGhlIHNlcnZpY2VEYXRhLmlkIHdpbGwgYmUgYSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgYW4gaW50ZWdlci5cbiAgICAvLyAgIFdlIHdhbnQgaXQgdG8gbWF0Y2ggZWl0aGVyIGEgc3RvcmVkIHN0cmluZyBvciBpbnQgcmVwcmVzZW50YXRpb24uXG4gICAgLy8gICBUaGlzIGlzIHRvIGNhdGVyIHRvIGVhcmxpZXIgdmVyc2lvbnMgb2YgTWV0ZW9yIHN0b3JpbmcgdHdpdHRlclxuICAgIC8vICAgdXNlciBJRHMgaW4gbnVtYmVyIGZvcm0sIGFuZCByZWNlbnQgdmVyc2lvbnMgc3RvcmluZyB0aGVtIGFzIHN0cmluZ3MuXG4gICAgLy8gICBUaGlzIGNhbiBiZSByZW1vdmVkIG9uY2UgbWlncmF0aW9uIHRlY2hub2xvZ3kgaXMgaW4gcGxhY2UsIGFuZCB0d2l0dGVyXG4gICAgLy8gICB1c2VycyBzdG9yZWQgd2l0aCBpbnRlZ2VyIElEcyBoYXZlIGJlZW4gbWlncmF0ZWQgdG8gc3RyaW5nIElEcy5cbiAgICBpZiAoc2VydmljZU5hbWUgPT09IFwidHdpdHRlclwiICYmICFpc05hTihzZXJ2aWNlRGF0YS5pZCkpIHtcbiAgICAgIHNlbGVjdG9yW1wiJG9yXCJdID0gW3t9LHt9XTtcbiAgICAgIHNlbGVjdG9yW1wiJG9yXCJdWzBdW3NlcnZpY2VJZEtleV0gPSBzZXJ2aWNlRGF0YS5pZDtcbiAgICAgIHNlbGVjdG9yW1wiJG9yXCJdWzFdW3NlcnZpY2VJZEtleV0gPSBwYXJzZUludChzZXJ2aWNlRGF0YS5pZCwgMTApO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxlY3RvcltzZXJ2aWNlSWRLZXldID0gc2VydmljZURhdGEuaWQ7XG4gICAgfVxuXG4gICAgbGV0IHVzZXIgPSB0aGlzLnVzZXJzLmZpbmRPbmUoc2VsZWN0b3IsIHtmaWVsZHM6IHRoaXMuX29wdGlvbnMuZGVmYXVsdEZpZWxkU2VsZWN0b3J9KTtcblxuICAgIC8vIEJlZm9yZSBjb250aW51aW5nLCBydW4gdXNlciBob29rIHRvIHNlZSBpZiB3ZSBzaG91bGQgY29udGludWVcbiAgICBpZiAodGhpcy5fYmVmb3JlRXh0ZXJuYWxMb2dpbkhvb2sgJiYgIXRoaXMuX2JlZm9yZUV4dGVybmFsTG9naW5Ib29rKHNlcnZpY2VOYW1lLCBzZXJ2aWNlRGF0YSwgdXNlcikpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkxvZ2luIGZvcmJpZGRlblwiKTtcbiAgICB9XG5cbiAgICAvLyBXaGVuIGNyZWF0aW5nIGEgbmV3IHVzZXIgd2UgcGFzcyB0aHJvdWdoIGFsbCBvcHRpb25zLiBXaGVuIHVwZGF0aW5nIGFuXG4gICAgLy8gZXhpc3RpbmcgdXNlciwgYnkgZGVmYXVsdCB3ZSBvbmx5IHByb2Nlc3MvcGFzcyB0aHJvdWdoIHRoZSBzZXJ2aWNlRGF0YVxuICAgIC8vIChlZywgc28gdGhhdCB3ZSBrZWVwIGFuIHVuZXhwaXJlZCBhY2Nlc3MgdG9rZW4gYW5kIGRvbid0IGNhY2hlIG9sZCBlbWFpbFxuICAgIC8vIGFkZHJlc3NlcyBpbiBzZXJ2aWNlRGF0YS5lbWFpbCkuIFRoZSBvbkV4dGVybmFsTG9naW4gaG9vayBjYW4gYmUgdXNlZCB3aGVuXG4gICAgLy8gY3JlYXRpbmcgb3IgdXBkYXRpbmcgYSB1c2VyLCB0byBtb2RpZnkgb3IgcGFzcyB0aHJvdWdoIG1vcmUgb3B0aW9ucyBhc1xuICAgIC8vIG5lZWRlZC5cbiAgICBsZXQgb3B0cyA9IHVzZXIgPyB7fSA6IG9wdGlvbnM7XG4gICAgaWYgKHRoaXMuX29uRXh0ZXJuYWxMb2dpbkhvb2spIHtcbiAgICAgIG9wdHMgPSB0aGlzLl9vbkV4dGVybmFsTG9naW5Ib29rKG9wdGlvbnMsIHVzZXIpO1xuICAgIH1cblxuICAgIGlmICh1c2VyKSB7XG4gICAgICBwaW5FbmNyeXB0ZWRGaWVsZHNUb1VzZXIoc2VydmljZURhdGEsIHVzZXIuX2lkKTtcblxuICAgICAgbGV0IHNldEF0dHJzID0ge307XG4gICAgICBPYmplY3Qua2V5cyhzZXJ2aWNlRGF0YSkuZm9yRWFjaChrZXkgPT5cbiAgICAgICAgc2V0QXR0cnNbYHNlcnZpY2VzLiR7c2VydmljZU5hbWV9LiR7a2V5fWBdID0gc2VydmljZURhdGFba2V5XVxuICAgICAgKTtcblxuICAgICAgLy8gWFhYIE1heWJlIHdlIHNob3VsZCByZS11c2UgdGhlIHNlbGVjdG9yIGFib3ZlIGFuZCBub3RpY2UgaWYgdGhlIHVwZGF0ZVxuICAgICAgLy8gICAgIHRvdWNoZXMgbm90aGluZz9cbiAgICAgIHNldEF0dHJzID0geyAuLi5zZXRBdHRycywgLi4ub3B0cyB9O1xuICAgICAgdGhpcy51c2Vycy51cGRhdGUodXNlci5faWQsIHtcbiAgICAgICAgJHNldDogc2V0QXR0cnNcbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiBzZXJ2aWNlTmFtZSxcbiAgICAgICAgdXNlcklkOiB1c2VyLl9pZFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQ3JlYXRlIGEgbmV3IHVzZXIgd2l0aCB0aGUgc2VydmljZSBkYXRhLlxuICAgICAgdXNlciA9IHtzZXJ2aWNlczoge319O1xuICAgICAgdXNlci5zZXJ2aWNlc1tzZXJ2aWNlTmFtZV0gPSBzZXJ2aWNlRGF0YTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6IHNlcnZpY2VOYW1lLFxuICAgICAgICB1c2VySWQ6IHRoaXMuaW5zZXJ0VXNlckRvYyhvcHRzLCB1c2VyKVxuICAgICAgfTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUmVtb3ZlcyBkZWZhdWx0IHJhdGUgbGltaXRpbmcgcnVsZVxuICByZW1vdmVEZWZhdWx0UmF0ZUxpbWl0KCkge1xuICAgIGNvbnN0IHJlc3AgPSBERFBSYXRlTGltaXRlci5yZW1vdmVSdWxlKHRoaXMuZGVmYXVsdFJhdGVMaW1pdGVyUnVsZUlkKTtcbiAgICB0aGlzLmRlZmF1bHRSYXRlTGltaXRlclJ1bGVJZCA9IG51bGw7XG4gICAgcmV0dXJuIHJlc3A7XG4gIH07XG5cbiAgLy8gQWRkIGEgZGVmYXVsdCBydWxlIG9mIGxpbWl0aW5nIGxvZ2lucywgY3JlYXRpbmcgbmV3IHVzZXJzIGFuZCBwYXNzd29yZCByZXNldFxuICAvLyB0byA1IHRpbWVzIGV2ZXJ5IDEwIHNlY29uZHMgcGVyIGNvbm5lY3Rpb24uXG4gIGFkZERlZmF1bHRSYXRlTGltaXQoKSB7XG4gICAgaWYgKCF0aGlzLmRlZmF1bHRSYXRlTGltaXRlclJ1bGVJZCkge1xuICAgICAgdGhpcy5kZWZhdWx0UmF0ZUxpbWl0ZXJSdWxlSWQgPSBERFBSYXRlTGltaXRlci5hZGRSdWxlKHtcbiAgICAgICAgdXNlcklkOiBudWxsLFxuICAgICAgICBjbGllbnRBZGRyZXNzOiBudWxsLFxuICAgICAgICB0eXBlOiAnbWV0aG9kJyxcbiAgICAgICAgbmFtZTogbmFtZSA9PiBbJ2xvZ2luJywgJ2NyZWF0ZVVzZXInLCAncmVzZXRQYXNzd29yZCcsICdmb3Jnb3RQYXNzd29yZCddXG4gICAgICAgICAgLmluY2x1ZGVzKG5hbWUpLFxuICAgICAgICBjb25uZWN0aW9uSWQ6IChjb25uZWN0aW9uSWQpID0+IHRydWUsXG4gICAgICB9LCA1LCAxMDAwMCk7XG4gICAgfVxuICB9O1xuXG59XG5cbi8vIEdpdmUgZWFjaCBsb2dpbiBob29rIGNhbGxiYWNrIGEgZnJlc2ggY2xvbmVkIGNvcHkgb2YgdGhlIGF0dGVtcHRcbi8vIG9iamVjdCwgYnV0IGRvbid0IGNsb25lIHRoZSBjb25uZWN0aW9uLlxuLy9cbmNvbnN0IGNsb25lQXR0ZW1wdFdpdGhDb25uZWN0aW9uID0gKGNvbm5lY3Rpb24sIGF0dGVtcHQpID0+IHtcbiAgY29uc3QgY2xvbmVkQXR0ZW1wdCA9IEVKU09OLmNsb25lKGF0dGVtcHQpO1xuICBjbG9uZWRBdHRlbXB0LmNvbm5lY3Rpb24gPSBjb25uZWN0aW9uO1xuICByZXR1cm4gY2xvbmVkQXR0ZW1wdDtcbn07XG5cbmNvbnN0IHRyeUxvZ2luTWV0aG9kID0gKHR5cGUsIGZuKSA9PiB7XG4gIGxldCByZXN1bHQ7XG4gIHRyeSB7XG4gICAgcmVzdWx0ID0gZm4oKTtcbiAgfVxuICBjYXRjaCAoZSkge1xuICAgIHJlc3VsdCA9IHtlcnJvcjogZX07XG4gIH1cblxuICBpZiAocmVzdWx0ICYmICFyZXN1bHQudHlwZSAmJiB0eXBlKVxuICAgIHJlc3VsdC50eXBlID0gdHlwZTtcblxuICByZXR1cm4gcmVzdWx0O1xufTtcblxuY29uc3Qgc2V0dXBEZWZhdWx0TG9naW5IYW5kbGVycyA9IGFjY291bnRzID0+IHtcbiAgYWNjb3VudHMucmVnaXN0ZXJMb2dpbkhhbmRsZXIoXCJyZXN1bWVcIiwgZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gZGVmYXVsdFJlc3VtZUxvZ2luSGFuZGxlci5jYWxsKHRoaXMsIGFjY291bnRzLCBvcHRpb25zKTtcbiAgfSk7XG59O1xuXG4vLyBMb2dpbiBoYW5kbGVyIGZvciByZXN1bWUgdG9rZW5zLlxuY29uc3QgZGVmYXVsdFJlc3VtZUxvZ2luSGFuZGxlciA9IChhY2NvdW50cywgb3B0aW9ucykgPT4ge1xuICBpZiAoIW9wdGlvbnMucmVzdW1lKVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG5cbiAgY2hlY2sob3B0aW9ucy5yZXN1bWUsIFN0cmluZyk7XG5cbiAgY29uc3QgaGFzaGVkVG9rZW4gPSBhY2NvdW50cy5faGFzaExvZ2luVG9rZW4ob3B0aW9ucy5yZXN1bWUpO1xuXG4gIC8vIEZpcnN0IGxvb2sgZm9yIGp1c3QgdGhlIG5ldy1zdHlsZSBoYXNoZWQgbG9naW4gdG9rZW4sIHRvIGF2b2lkXG4gIC8vIHNlbmRpbmcgdGhlIHVuaGFzaGVkIHRva2VuIHRvIHRoZSBkYXRhYmFzZSBpbiBhIHF1ZXJ5IGlmIHdlIGRvbid0XG4gIC8vIG5lZWQgdG8uXG4gIGxldCB1c2VyID0gYWNjb3VudHMudXNlcnMuZmluZE9uZShcbiAgICB7XCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMuaGFzaGVkVG9rZW5cIjogaGFzaGVkVG9rZW59LFxuICAgIHtmaWVsZHM6IHtcInNlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucy4kXCI6IDF9fSk7XG5cbiAgaWYgKCEgdXNlcikge1xuICAgIC8vIElmIHdlIGRpZG4ndCBmaW5kIHRoZSBoYXNoZWQgbG9naW4gdG9rZW4sIHRyeSBhbHNvIGxvb2tpbmcgZm9yXG4gICAgLy8gdGhlIG9sZC1zdHlsZSB1bmhhc2hlZCB0b2tlbi4gIEJ1dCB3ZSBuZWVkIHRvIGxvb2sgZm9yIGVpdGhlclxuICAgIC8vIHRoZSBvbGQtc3R5bGUgdG9rZW4gT1IgdGhlIG5ldy1zdHlsZSB0b2tlbiwgYmVjYXVzZSBhbm90aGVyXG4gICAgLy8gY2xpZW50IGNvbm5lY3Rpb24gbG9nZ2luZyBpbiBzaW11bHRhbmVvdXNseSBtaWdodCBoYXZlIGFscmVhZHlcbiAgICAvLyBjb252ZXJ0ZWQgdGhlIHRva2VuLlxuICAgIHVzZXIgPSBhY2NvdW50cy51c2Vycy5maW5kT25lKHtcbiAgICAgICRvcjogW1xuICAgICAgICB7XCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMuaGFzaGVkVG9rZW5cIjogaGFzaGVkVG9rZW59LFxuICAgICAgICB7XCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMudG9rZW5cIjogb3B0aW9ucy5yZXN1bWV9XG4gICAgICBdXG4gICAgfSxcbiAgICAvLyBOb3RlOiBDYW5ub3QgdXNlIC4uLmxvZ2luVG9rZW5zLiQgcG9zaXRpb25hbCBvcGVyYXRvciB3aXRoICRvciBxdWVyeS5cbiAgICB7ZmllbGRzOiB7XCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNcIjogMX19KTtcbiAgfVxuXG4gIGlmICghIHVzZXIpXG4gICAgcmV0dXJuIHtcbiAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJZb3UndmUgYmVlbiBsb2dnZWQgb3V0IGJ5IHRoZSBzZXJ2ZXIuIFBsZWFzZSBsb2cgaW4gYWdhaW4uXCIpXG4gICAgfTtcblxuICAvLyBGaW5kIHRoZSB0b2tlbiwgd2hpY2ggd2lsbCBlaXRoZXIgYmUgYW4gb2JqZWN0IHdpdGggZmllbGRzXG4gIC8vIHtoYXNoZWRUb2tlbiwgd2hlbn0gZm9yIGEgaGFzaGVkIHRva2VuIG9yIHt0b2tlbiwgd2hlbn0gZm9yIGFuXG4gIC8vIHVuaGFzaGVkIHRva2VuLlxuICBsZXQgb2xkVW5oYXNoZWRTdHlsZVRva2VuO1xuICBsZXQgdG9rZW4gPSB1c2VyLnNlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucy5maW5kKHRva2VuID0+XG4gICAgdG9rZW4uaGFzaGVkVG9rZW4gPT09IGhhc2hlZFRva2VuXG4gICk7XG4gIGlmICh0b2tlbikge1xuICAgIG9sZFVuaGFzaGVkU3R5bGVUb2tlbiA9IGZhbHNlO1xuICB9IGVsc2Uge1xuICAgIHRva2VuID0gdXNlci5zZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMuZmluZCh0b2tlbiA9PlxuICAgICAgdG9rZW4udG9rZW4gPT09IG9wdGlvbnMucmVzdW1lXG4gICAgKTtcbiAgICBvbGRVbmhhc2hlZFN0eWxlVG9rZW4gPSB0cnVlO1xuICB9XG5cbiAgY29uc3QgdG9rZW5FeHBpcmVzID0gYWNjb3VudHMuX3Rva2VuRXhwaXJhdGlvbih0b2tlbi53aGVuKTtcbiAgaWYgKG5ldyBEYXRlKCkgPj0gdG9rZW5FeHBpcmVzKVxuICAgIHJldHVybiB7XG4gICAgICB1c2VySWQ6IHVzZXIuX2lkLFxuICAgICAgZXJyb3I6IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIllvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIGxvZyBpbiBhZ2Fpbi5cIilcbiAgICB9O1xuXG4gIC8vIFVwZGF0ZSB0byBhIGhhc2hlZCB0b2tlbiB3aGVuIGFuIHVuaGFzaGVkIHRva2VuIGlzIGVuY291bnRlcmVkLlxuICBpZiAob2xkVW5oYXNoZWRTdHlsZVRva2VuKSB7XG4gICAgLy8gT25seSBhZGQgdGhlIG5ldyBoYXNoZWQgdG9rZW4gaWYgdGhlIG9sZCB1bmhhc2hlZCB0b2tlbiBzdGlsbFxuICAgIC8vIGV4aXN0cyAodGhpcyBhdm9pZHMgcmVzdXJyZWN0aW5nIHRoZSB0b2tlbiBpZiBpdCB3YXMgZGVsZXRlZFxuICAgIC8vIGFmdGVyIHdlIHJlYWQgaXQpLiAgVXNpbmcgJGFkZFRvU2V0IGF2b2lkcyBnZXR0aW5nIGFuIGluZGV4XG4gICAgLy8gZXJyb3IgaWYgYW5vdGhlciBjbGllbnQgbG9nZ2luZyBpbiBzaW11bHRhbmVvdXNseSBoYXMgYWxyZWFkeVxuICAgIC8vIGluc2VydGVkIHRoZSBuZXcgaGFzaGVkIHRva2VuLlxuICAgIGFjY291bnRzLnVzZXJzLnVwZGF0ZShcbiAgICAgIHtcbiAgICAgICAgX2lkOiB1c2VyLl9pZCxcbiAgICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMudG9rZW5cIjogb3B0aW9ucy5yZXN1bWVcbiAgICAgIH0sXG4gICAgICB7JGFkZFRvU2V0OiB7XG4gICAgICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNcIjoge1xuICAgICAgICAgICAgXCJoYXNoZWRUb2tlblwiOiBoYXNoZWRUb2tlbixcbiAgICAgICAgICAgIFwid2hlblwiOiB0b2tlbi53aGVuXG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICk7XG5cbiAgICAvLyBSZW1vdmUgdGhlIG9sZCB0b2tlbiAqYWZ0ZXIqIGFkZGluZyB0aGUgbmV3LCBzaW5jZSBvdGhlcndpc2VcbiAgICAvLyBhbm90aGVyIGNsaWVudCB0cnlpbmcgdG8gbG9naW4gYmV0d2VlbiBvdXIgcmVtb3ZpbmcgdGhlIG9sZCBhbmRcbiAgICAvLyBhZGRpbmcgdGhlIG5ldyB3b3VsZG4ndCBmaW5kIGEgdG9rZW4gdG8gbG9naW4gd2l0aC5cbiAgICBhY2NvdW50cy51c2Vycy51cGRhdGUodXNlci5faWQsIHtcbiAgICAgICRwdWxsOiB7XG4gICAgICAgIFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zXCI6IHsgXCJ0b2tlblwiOiBvcHRpb25zLnJlc3VtZSB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHVzZXJJZDogdXNlci5faWQsXG4gICAgc3RhbXBlZExvZ2luVG9rZW46IHtcbiAgICAgIHRva2VuOiBvcHRpb25zLnJlc3VtZSxcbiAgICAgIHdoZW46IHRva2VuLndoZW5cbiAgICB9XG4gIH07XG59O1xuXG5jb25zdCBleHBpcmVQYXNzd29yZFRva2VuID0gKFxuICBhY2NvdW50cyxcbiAgb2xkZXN0VmFsaWREYXRlLFxuICB0b2tlbkZpbHRlcixcbiAgdXNlcklkXG4pID0+IHtcbiAgY29uc3QgdXNlckZpbHRlciA9IHVzZXJJZCA/IHtfaWQ6IHVzZXJJZH0gOiB7fTtcbiAgY29uc3QgcmVzZXRSYW5nZU9yID0ge1xuICAgICRvcjogW1xuICAgICAgeyBcInNlcnZpY2VzLnBhc3N3b3JkLnJlc2V0LndoZW5cIjogeyAkbHQ6IG9sZGVzdFZhbGlkRGF0ZSB9IH0sXG4gICAgICB7IFwic2VydmljZXMucGFzc3dvcmQucmVzZXQud2hlblwiOiB7ICRsdDogK29sZGVzdFZhbGlkRGF0ZSB9IH1cbiAgICBdXG4gIH07XG4gIGNvbnN0IGV4cGlyZUZpbHRlciA9IHsgJGFuZDogW3Rva2VuRmlsdGVyLCByZXNldFJhbmdlT3JdIH07XG5cbiAgYWNjb3VudHMudXNlcnMudXBkYXRlKHsuLi51c2VyRmlsdGVyLCAuLi5leHBpcmVGaWx0ZXJ9LCB7XG4gICAgJHVuc2V0OiB7XG4gICAgICBcInNlcnZpY2VzLnBhc3N3b3JkLnJlc2V0XCI6IFwiXCJcbiAgICB9XG4gIH0sIHsgbXVsdGk6IHRydWUgfSk7XG59O1xuXG5jb25zdCBzZXRFeHBpcmVUb2tlbnNJbnRlcnZhbCA9IGFjY291bnRzID0+IHtcbiAgYWNjb3VudHMuZXhwaXJlVG9rZW5JbnRlcnZhbCA9IE1ldGVvci5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgYWNjb3VudHMuX2V4cGlyZVRva2VucygpO1xuICAgIGFjY291bnRzLl9leHBpcmVQYXNzd29yZFJlc2V0VG9rZW5zKCk7XG4gICAgYWNjb3VudHMuX2V4cGlyZVBhc3N3b3JkRW5yb2xsVG9rZW5zKCk7XG4gIH0sIEVYUElSRV9UT0tFTlNfSU5URVJWQUxfTVMpO1xufTtcblxuLy8vXG4vLy8gT0F1dGggRW5jcnlwdGlvbiBTdXBwb3J0XG4vLy9cblxuY29uc3QgT0F1dGhFbmNyeXB0aW9uID1cbiAgUGFja2FnZVtcIm9hdXRoLWVuY3J5cHRpb25cIl0gJiZcbiAgUGFja2FnZVtcIm9hdXRoLWVuY3J5cHRpb25cIl0uT0F1dGhFbmNyeXB0aW9uO1xuXG5jb25zdCB1c2luZ09BdXRoRW5jcnlwdGlvbiA9ICgpID0+IHtcbiAgcmV0dXJuIE9BdXRoRW5jcnlwdGlvbiAmJiBPQXV0aEVuY3J5cHRpb24ua2V5SXNMb2FkZWQoKTtcbn07XG5cbi8vIE9BdXRoIHNlcnZpY2UgZGF0YSBpcyB0ZW1wb3JhcmlseSBzdG9yZWQgaW4gdGhlIHBlbmRpbmcgY3JlZGVudGlhbHNcbi8vIGNvbGxlY3Rpb24gZHVyaW5nIHRoZSBvYXV0aCBhdXRoZW50aWNhdGlvbiBwcm9jZXNzLiAgU2Vuc2l0aXZlIGRhdGFcbi8vIHN1Y2ggYXMgYWNjZXNzIHRva2VucyBhcmUgZW5jcnlwdGVkIHdpdGhvdXQgdGhlIHVzZXIgaWQgYmVjYXVzZVxuLy8gd2UgZG9uJ3Qga25vdyB0aGUgdXNlciBpZCB5ZXQuICBXZSByZS1lbmNyeXB0IHRoZXNlIGZpZWxkcyB3aXRoIHRoZVxuLy8gdXNlciBpZCBpbmNsdWRlZCB3aGVuIHN0b3JpbmcgdGhlIHNlcnZpY2UgZGF0YSBwZXJtYW5lbnRseSBpblxuLy8gdGhlIHVzZXJzIGNvbGxlY3Rpb24uXG4vL1xuY29uc3QgcGluRW5jcnlwdGVkRmllbGRzVG9Vc2VyID0gKHNlcnZpY2VEYXRhLCB1c2VySWQpID0+IHtcbiAgT2JqZWN0LmtleXMoc2VydmljZURhdGEpLmZvckVhY2goa2V5ID0+IHtcbiAgICBsZXQgdmFsdWUgPSBzZXJ2aWNlRGF0YVtrZXldO1xuICAgIGlmIChPQXV0aEVuY3J5cHRpb24gJiYgT0F1dGhFbmNyeXB0aW9uLmlzU2VhbGVkKHZhbHVlKSlcbiAgICAgIHZhbHVlID0gT0F1dGhFbmNyeXB0aW9uLnNlYWwoT0F1dGhFbmNyeXB0aW9uLm9wZW4odmFsdWUpLCB1c2VySWQpO1xuICAgIHNlcnZpY2VEYXRhW2tleV0gPSB2YWx1ZTtcbiAgfSk7XG59O1xuXG5cbi8vIEVuY3J5cHQgdW5lbmNyeXB0ZWQgbG9naW4gc2VydmljZSBzZWNyZXRzIHdoZW4gb2F1dGgtZW5jcnlwdGlvbiBpc1xuLy8gYWRkZWQuXG4vL1xuLy8gWFhYIEZvciB0aGUgb2F1dGhTZWNyZXRLZXkgdG8gYmUgYXZhaWxhYmxlIGhlcmUgYXQgc3RhcnR1cCwgdGhlXG4vLyBkZXZlbG9wZXIgbXVzdCBjYWxsIEFjY291bnRzLmNvbmZpZyh7b2F1dGhTZWNyZXRLZXk6IC4uLn0pIGF0IGxvYWRcbi8vIHRpbWUsIGluc3RlYWQgb2YgaW4gYSBNZXRlb3Iuc3RhcnR1cCBibG9jaywgYmVjYXVzZSB0aGUgc3RhcnR1cFxuLy8gYmxvY2sgaW4gdGhlIGFwcCBjb2RlIHdpbGwgcnVuIGFmdGVyIHRoaXMgYWNjb3VudHMtYmFzZSBzdGFydHVwXG4vLyBibG9jay4gIFBlcmhhcHMgd2UgbmVlZCBhIHBvc3Qtc3RhcnR1cCBjYWxsYmFjaz9cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICBpZiAoISB1c2luZ09BdXRoRW5jcnlwdGlvbigpKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgeyBTZXJ2aWNlQ29uZmlndXJhdGlvbiB9ID0gUGFja2FnZVsnc2VydmljZS1jb25maWd1cmF0aW9uJ107XG5cbiAgU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMuZmluZCh7XG4gICAgJGFuZDogW3tcbiAgICAgIHNlY3JldDogeyAkZXhpc3RzOiB0cnVlIH1cbiAgICB9LCB7XG4gICAgICBcInNlY3JldC5hbGdvcml0aG1cIjogeyAkZXhpc3RzOiBmYWxzZSB9XG4gICAgfV1cbiAgfSkuZm9yRWFjaChjb25maWcgPT4ge1xuICAgIFNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLnVwZGF0ZShjb25maWcuX2lkLCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIHNlY3JldDogT0F1dGhFbmNyeXB0aW9uLnNlYWwoY29uZmlnLnNlY3JldClcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59KTtcblxuLy8gWFhYIHNlZSBjb21tZW50IG9uIEFjY291bnRzLmNyZWF0ZVVzZXIgaW4gcGFzc3dvcmRzX3NlcnZlciBhYm91dCBhZGRpbmcgYVxuLy8gc2Vjb25kIFwic2VydmVyIG9wdGlvbnNcIiBhcmd1bWVudC5cbmNvbnN0IGRlZmF1bHRDcmVhdGVVc2VySG9vayA9IChvcHRpb25zLCB1c2VyKSA9PiB7XG4gIGlmIChvcHRpb25zLnByb2ZpbGUpXG4gICAgdXNlci5wcm9maWxlID0gb3B0aW9ucy5wcm9maWxlO1xuICByZXR1cm4gdXNlcjtcbn07XG5cbi8vIFZhbGlkYXRlIG5ldyB1c2VyJ3MgZW1haWwgb3IgR29vZ2xlL0ZhY2Vib29rL0dpdEh1YiBhY2NvdW50J3MgZW1haWxcbmZ1bmN0aW9uIGRlZmF1bHRWYWxpZGF0ZU5ld1VzZXJIb29rKHVzZXIpIHtcbiAgY29uc3QgZG9tYWluID0gdGhpcy5fb3B0aW9ucy5yZXN0cmljdENyZWF0aW9uQnlFbWFpbERvbWFpbjtcbiAgaWYgKCFkb21haW4pIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGxldCBlbWFpbElzR29vZCA9IGZhbHNlO1xuICBpZiAodXNlci5lbWFpbHMgJiYgdXNlci5lbWFpbHMubGVuZ3RoID4gMCkge1xuICAgIGVtYWlsSXNHb29kID0gdXNlci5lbWFpbHMucmVkdWNlKFxuICAgICAgKHByZXYsIGVtYWlsKSA9PiBwcmV2IHx8IHRoaXMuX3Rlc3RFbWFpbERvbWFpbihlbWFpbC5hZGRyZXNzKSwgZmFsc2VcbiAgICApO1xuICB9IGVsc2UgaWYgKHVzZXIuc2VydmljZXMgJiYgT2JqZWN0LnZhbHVlcyh1c2VyLnNlcnZpY2VzKS5sZW5ndGggPiAwKSB7XG4gICAgLy8gRmluZCBhbnkgZW1haWwgb2YgYW55IHNlcnZpY2UgYW5kIGNoZWNrIGl0XG4gICAgZW1haWxJc0dvb2QgPSBPYmplY3QudmFsdWVzKHVzZXIuc2VydmljZXMpLnJlZHVjZShcbiAgICAgIChwcmV2LCBzZXJ2aWNlKSA9PiBzZXJ2aWNlLmVtYWlsICYmIHRoaXMuX3Rlc3RFbWFpbERvbWFpbihzZXJ2aWNlLmVtYWlsKSxcbiAgICAgIGZhbHNlLFxuICAgICk7XG4gIH1cblxuICBpZiAoZW1haWxJc0dvb2QpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGlmICh0eXBlb2YgZG9tYWluID09PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBgQCR7ZG9tYWlufSBlbWFpbCByZXF1aXJlZGApO1xuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkVtYWlsIGRvZXNuJ3QgbWF0Y2ggdGhlIGNyaXRlcmlhLlwiKTtcbiAgfVxufVxuXG5jb25zdCBzZXR1cFVzZXJzQ29sbGVjdGlvbiA9IHVzZXJzID0+IHtcbiAgLy8vXG4gIC8vLyBSRVNUUklDVElORyBXUklURVMgVE8gVVNFUiBPQkpFQ1RTXG4gIC8vL1xuICB1c2Vycy5hbGxvdyh7XG4gICAgLy8gY2xpZW50cyBjYW4gbW9kaWZ5IHRoZSBwcm9maWxlIGZpZWxkIG9mIHRoZWlyIG93biBkb2N1bWVudCwgYW5kXG4gICAgLy8gbm90aGluZyBlbHNlLlxuICAgIHVwZGF0ZTogKHVzZXJJZCwgdXNlciwgZmllbGRzLCBtb2RpZmllcikgPT4ge1xuICAgICAgLy8gbWFrZSBzdXJlIGl0IGlzIG91ciByZWNvcmRcbiAgICAgIGlmICh1c2VyLl9pZCAhPT0gdXNlcklkKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cblxuICAgICAgLy8gdXNlciBjYW4gb25seSBtb2RpZnkgdGhlICdwcm9maWxlJyBmaWVsZC4gc2V0cyB0byBtdWx0aXBsZVxuICAgICAgLy8gc3ViLWtleXMgKGVnIHByb2ZpbGUuZm9vIGFuZCBwcm9maWxlLmJhcikgYXJlIG1lcmdlZCBpbnRvIGVudHJ5XG4gICAgICAvLyBpbiB0aGUgZmllbGRzIGxpc3QuXG4gICAgICBpZiAoZmllbGRzLmxlbmd0aCAhPT0gMSB8fCBmaWVsZHNbMF0gIT09ICdwcm9maWxlJykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG4gICAgZmV0Y2g6IFsnX2lkJ10gLy8gd2Ugb25seSBsb29rIGF0IF9pZC5cbiAgfSk7XG5cbiAgLy8vIERFRkFVTFQgSU5ERVhFUyBPTiBVU0VSU1xuICB1c2Vycy5fZW5zdXJlSW5kZXgoJ3VzZXJuYW1lJywgeyB1bmlxdWU6IHRydWUsIHNwYXJzZTogdHJ1ZSB9KTtcbiAgdXNlcnMuX2Vuc3VyZUluZGV4KCdlbWFpbHMuYWRkcmVzcycsIHsgdW5pcXVlOiB0cnVlLCBzcGFyc2U6IHRydWUgfSk7XG4gIHVzZXJzLl9lbnN1cmVJbmRleCgnc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zLmhhc2hlZFRva2VuJyxcbiAgICB7IHVuaXF1ZTogdHJ1ZSwgc3BhcnNlOiB0cnVlIH0pO1xuICB1c2Vycy5fZW5zdXJlSW5kZXgoJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucy50b2tlbicsXG4gICAgeyB1bmlxdWU6IHRydWUsIHNwYXJzZTogdHJ1ZSB9KTtcbiAgLy8gRm9yIHRha2luZyBjYXJlIG9mIGxvZ291dE90aGVyQ2xpZW50cyBjYWxscyB0aGF0IGNyYXNoZWQgYmVmb3JlIHRoZVxuICAvLyB0b2tlbnMgd2VyZSBkZWxldGVkLlxuICB1c2Vycy5fZW5zdXJlSW5kZXgoJ3NlcnZpY2VzLnJlc3VtZS5oYXZlTG9naW5Ub2tlbnNUb0RlbGV0ZScsXG4gICAgeyBzcGFyc2U6IHRydWUgfSk7XG4gIC8vIEZvciBleHBpcmluZyBsb2dpbiB0b2tlbnNcbiAgdXNlcnMuX2Vuc3VyZUluZGV4KFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zLndoZW5cIiwgeyBzcGFyc2U6IHRydWUgfSk7XG4gIC8vIEZvciBleHBpcmluZyBwYXNzd29yZCB0b2tlbnNcbiAgdXNlcnMuX2Vuc3VyZUluZGV4KCdzZXJ2aWNlcy5wYXNzd29yZC5yZXNldC53aGVuJywgeyBzcGFyc2U6IHRydWUgfSk7XG59O1xuIl19
