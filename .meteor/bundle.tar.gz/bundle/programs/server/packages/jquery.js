(function () {



/* Exports */
Package._define("jquery");

})();
