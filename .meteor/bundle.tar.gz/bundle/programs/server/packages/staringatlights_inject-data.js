(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var EJSON = Package.ejson.EJSON;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var InjectData;

var require = meteorInstall({"node_modules":{"meteor":{"staringatlights:inject-data":{"lib":{"namespace.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/staringatlights_inject-data/lib/namespace.js                                  //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
module.export({
  InjectData: () => InjectData
});
const InjectData = {};

// Replace meteorhacks:inject-data with our new API, this is for compatibility
// with third party packages that still depend upon the meteorhacks version.
if (Package['meteorhacks:inject-data']) {
  Package['meteorhacks:inject-data'].InjectData = InjectData;
}
////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/staringatlights_inject-data/lib/utils.js                                      //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
let EJSON;
module.link("meteor/ejson", {
  EJSON(v) {
    EJSON = v;
  }

}, 0);
let InjectData;
module.link("./namespace", {
  InjectData(v) {
    InjectData = v;
  }

}, 1);

/**
 * Returns an encoded string that represents an object.
 * @param {object} ejson
 */
InjectData.encode = InjectData._encode = function (ejson) {
  var ejsonString = EJSON.stringify(ejson);
  return encodeURIComponent(ejsonString);
};
/**
 * Decodes an encoded string into an object.
 * @param {string} encodedEjson
 */


InjectData.decode = InjectData._decode = function (encodedEjson) {
  var decodedEjsonString = decodeURIComponent(encodedEjson);
  if (!decodedEjsonString) return null;
  return EJSON.parse(decodedEjsonString);
};
////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/staringatlights_inject-data/lib/server.js                                     //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
let InjectData;
module.link("./namespace", {
  InjectData(v) {
    InjectData = v;
  }

}, 0);
let WebAppInternals;
module.link("meteor/webapp", {
  WebAppInternals(v) {
    WebAppInternals = v;
  }

}, 1);
// Supports legacy uses of inject data, SSR users should turn this to false
InjectData.injectToHead = true;
WebAppInternals.registerBoilerplateDataCallback('inject-data', (req, data, arch) => {
  if (req && req.headers && req.headers._injectPayload && !InjectData.disableInjection) {
    const payload = "<script type=\"text/inject-data\">".concat(InjectData.encode(req.headers._injectPayload), "</script>");

    if (InjectData.injectToHead) {
      if (!data.dynamicHead) {
        data.dynamicHead = '';
      }

      data.dynamicHead += payload;
    } else {
      if (!data.dynamicBody) {
        data.dynamicBody = '';
      }

      data.dynamicBody += payload;
    }
  }

  return false;
});
/**
 * Pushes data into the InjectData payload.
 * @param {object} node request object
 * @param {string} key
 * @param {*} value
 */

InjectData.pushData = function pushData(req, key, value) {
  if (!req.headers) {
    req.headers = {};
  }

  if (!req.headers._injectPayload) {
    req.headers._injectPayload = {};
  }

  req.headers._injectPayload[key] = value;
};
/**
 * Returns the object associated with the specified key.
 * @param {string} key
 */


InjectData.getData = function getData(req, key) {
  if (req.headers && req.headers._injectPayload) {
    return Object.assign({}, req.headers._injectPayload[key]);
  } else {
    return null;
  }
};
////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/staringatlights:inject-data/lib/namespace.js");
require("/node_modules/meteor/staringatlights:inject-data/lib/utils.js");
require("/node_modules/meteor/staringatlights:inject-data/lib/server.js");

/* Exports */
Package._define("staringatlights:inject-data", exports, {
  InjectData: InjectData
});

})();

//# sourceURL=meteor://💻app/packages/staringatlights_inject-data.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvc3RhcmluZ2F0bGlnaHRzOmluamVjdC1kYXRhL2xpYi9uYW1lc3BhY2UuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3N0YXJpbmdhdGxpZ2h0czppbmplY3QtZGF0YS9saWIvdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3N0YXJpbmdhdGxpZ2h0czppbmplY3QtZGF0YS9saWIvc2VydmVyLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkluamVjdERhdGEiLCJQYWNrYWdlIiwiRUpTT04iLCJsaW5rIiwidiIsImVuY29kZSIsIl9lbmNvZGUiLCJlanNvbiIsImVqc29uU3RyaW5nIiwic3RyaW5naWZ5IiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiZGVjb2RlIiwiX2RlY29kZSIsImVuY29kZWRFanNvbiIsImRlY29kZWRFanNvblN0cmluZyIsImRlY29kZVVSSUNvbXBvbmVudCIsInBhcnNlIiwiV2ViQXBwSW50ZXJuYWxzIiwiaW5qZWN0VG9IZWFkIiwicmVnaXN0ZXJCb2lsZXJwbGF0ZURhdGFDYWxsYmFjayIsInJlcSIsImRhdGEiLCJhcmNoIiwiaGVhZGVycyIsIl9pbmplY3RQYXlsb2FkIiwiZGlzYWJsZUluamVjdGlvbiIsInBheWxvYWQiLCJkeW5hbWljSGVhZCIsImR5bmFtaWNCb2R5IiwicHVzaERhdGEiLCJrZXkiLCJ2YWx1ZSIsImdldERhdGEiLCJPYmplY3QiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFDTyxNQUFNQSxVQUFVLEdBQUcsRUFBbkI7O0FBRVA7QUFDQTtBQUNBLElBQUlDLE9BQU8sQ0FBQyx5QkFBRCxDQUFYLEVBQXdDO0FBQ3ZDQSxTQUFPLENBQUMseUJBQUQsQ0FBUCxDQUFtQ0QsVUFBbkMsR0FBZ0RBLFVBQWhEO0FBQ0EsQzs7Ozs7Ozs7Ozs7QUNQRCxJQUFJRSxLQUFKO0FBQVVKLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0QsT0FBSyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsU0FBSyxHQUFDRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlKLFVBQUo7QUFBZUYsTUFBTSxDQUFDSyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDSCxZQUFVLENBQUNJLENBQUQsRUFBRztBQUFDSixjQUFVLEdBQUNJLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUIsRUFBd0QsQ0FBeEQ7O0FBRzNFO0FBQ0E7QUFDQTtBQUNBO0FBQ0FKLFVBQVUsQ0FBQ0ssTUFBWCxHQUFvQkwsVUFBVSxDQUFDTSxPQUFYLEdBQXFCLFVBQVNDLEtBQVQsRUFBZ0I7QUFDeEQsTUFBSUMsV0FBVyxHQUFHTixLQUFLLENBQUNPLFNBQU4sQ0FBZ0JGLEtBQWhCLENBQWxCO0FBQ0EsU0FBT0csa0JBQWtCLENBQUNGLFdBQUQsQ0FBekI7QUFDQSxDQUhEO0FBS0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBUixVQUFVLENBQUNXLE1BQVgsR0FBb0JYLFVBQVUsQ0FBQ1ksT0FBWCxHQUFxQixVQUFTQyxZQUFULEVBQXVCO0FBQy9ELE1BQUlDLGtCQUFrQixHQUFHQyxrQkFBa0IsQ0FBQ0YsWUFBRCxDQUEzQztBQUNBLE1BQUksQ0FBQ0Msa0JBQUwsRUFBeUIsT0FBTyxJQUFQO0FBRXpCLFNBQU9aLEtBQUssQ0FBQ2MsS0FBTixDQUFZRixrQkFBWixDQUFQO0FBQ0EsQ0FMRCxDOzs7Ozs7Ozs7OztBQ2hCQSxJQUFJZCxVQUFKO0FBQWVGLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0gsWUFBVSxDQUFDSSxDQUFELEVBQUc7QUFBQ0osY0FBVSxHQUFDSSxDQUFYO0FBQWE7O0FBQTVCLENBQTFCLEVBQXdELENBQXhEO0FBQTJELElBQUlhLGVBQUo7QUFBb0JuQixNQUFNLENBQUNLLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNjLGlCQUFlLENBQUNiLENBQUQsRUFBRztBQUFDYSxtQkFBZSxHQUFDYixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBNUIsRUFBb0UsQ0FBcEU7QUFJOUY7QUFDQUosVUFBVSxDQUFDa0IsWUFBWCxHQUEwQixJQUExQjtBQUVBRCxlQUFlLENBQUNFLCtCQUFoQixDQUNDLGFBREQsRUFFQyxDQUFDQyxHQUFELEVBQU1DLElBQU4sRUFBWUMsSUFBWixLQUFxQjtBQUNwQixNQUNDRixHQUFHLElBQ0hBLEdBQUcsQ0FBQ0csT0FESixJQUVBSCxHQUFHLENBQUNHLE9BQUosQ0FBWUMsY0FGWixJQUdBLENBQUN4QixVQUFVLENBQUN5QixnQkFKYixFQUtFO0FBQ0QsVUFBTUMsT0FBTywrQ0FBc0MxQixVQUFVLENBQUNLLE1BQVgsQ0FDbERlLEdBQUcsQ0FBQ0csT0FBSixDQUFZQyxjQURzQyxDQUF0QyxjQUFiOztBQUlBLFFBQUl4QixVQUFVLENBQUNrQixZQUFmLEVBQTZCO0FBQzVCLFVBQUksQ0FBQ0csSUFBSSxDQUFDTSxXQUFWLEVBQXVCO0FBQ3RCTixZQUFJLENBQUNNLFdBQUwsR0FBbUIsRUFBbkI7QUFDQTs7QUFDRE4sVUFBSSxDQUFDTSxXQUFMLElBQW9CRCxPQUFwQjtBQUNBLEtBTEQsTUFLTztBQUNOLFVBQUksQ0FBQ0wsSUFBSSxDQUFDTyxXQUFWLEVBQXVCO0FBQ3RCUCxZQUFJLENBQUNPLFdBQUwsR0FBbUIsRUFBbkI7QUFDQTs7QUFDRFAsVUFBSSxDQUFDTyxXQUFMLElBQW9CRixPQUFwQjtBQUNBO0FBQ0Q7O0FBQ0QsU0FBTyxLQUFQO0FBQ0EsQ0ExQkY7QUE2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBMUIsVUFBVSxDQUFDNkIsUUFBWCxHQUFzQixTQUFTQSxRQUFULENBQWtCVCxHQUFsQixFQUF1QlUsR0FBdkIsRUFBNEJDLEtBQTVCLEVBQW1DO0FBQ3hELE1BQUksQ0FBQ1gsR0FBRyxDQUFDRyxPQUFULEVBQWtCO0FBQ2pCSCxPQUFHLENBQUNHLE9BQUosR0FBYyxFQUFkO0FBQ0E7O0FBQ0QsTUFBSSxDQUFDSCxHQUFHLENBQUNHLE9BQUosQ0FBWUMsY0FBakIsRUFBaUM7QUFDaENKLE9BQUcsQ0FBQ0csT0FBSixDQUFZQyxjQUFaLEdBQTZCLEVBQTdCO0FBQ0E7O0FBRURKLEtBQUcsQ0FBQ0csT0FBSixDQUFZQyxjQUFaLENBQTJCTSxHQUEzQixJQUFrQ0MsS0FBbEM7QUFDQSxDQVREO0FBV0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBL0IsVUFBVSxDQUFDZ0MsT0FBWCxHQUFxQixTQUFTQSxPQUFULENBQWlCWixHQUFqQixFQUFzQlUsR0FBdEIsRUFBMkI7QUFDL0MsTUFBSVYsR0FBRyxDQUFDRyxPQUFKLElBQWVILEdBQUcsQ0FBQ0csT0FBSixDQUFZQyxjQUEvQixFQUErQztBQUM5QyxXQUFPUyxNQUFNLENBQUNDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCZCxHQUFHLENBQUNHLE9BQUosQ0FBWUMsY0FBWixDQUEyQk0sR0FBM0IsQ0FBbEIsQ0FBUDtBQUNBLEdBRkQsTUFFTztBQUNOLFdBQU8sSUFBUDtBQUNBO0FBQ0QsQ0FORCxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9zdGFyaW5nYXRsaWdodHNfaW5qZWN0LWRhdGEuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBnbG9iYWwgUGFja2FnZSAqL1xuZXhwb3J0IGNvbnN0IEluamVjdERhdGEgPSB7fVxuXG4vLyBSZXBsYWNlIG1ldGVvcmhhY2tzOmluamVjdC1kYXRhIHdpdGggb3VyIG5ldyBBUEksIHRoaXMgaXMgZm9yIGNvbXBhdGliaWxpdHlcbi8vIHdpdGggdGhpcmQgcGFydHkgcGFja2FnZXMgdGhhdCBzdGlsbCBkZXBlbmQgdXBvbiB0aGUgbWV0ZW9yaGFja3MgdmVyc2lvbi5cbmlmIChQYWNrYWdlWydtZXRlb3JoYWNrczppbmplY3QtZGF0YSddKSB7XG5cdFBhY2thZ2VbJ21ldGVvcmhhY2tzOmluamVjdC1kYXRhJ10uSW5qZWN0RGF0YSA9IEluamVjdERhdGFcbn1cbiIsImltcG9ydCB7IEVKU09OIH0gZnJvbSAnbWV0ZW9yL2Vqc29uJ1xuaW1wb3J0IHsgSW5qZWN0RGF0YSB9IGZyb20gJy4vbmFtZXNwYWNlJ1xuXG4vKipcbiAqIFJldHVybnMgYW4gZW5jb2RlZCBzdHJpbmcgdGhhdCByZXByZXNlbnRzIGFuIG9iamVjdC5cbiAqIEBwYXJhbSB7b2JqZWN0fSBlanNvblxuICovXG5JbmplY3REYXRhLmVuY29kZSA9IEluamVjdERhdGEuX2VuY29kZSA9IGZ1bmN0aW9uKGVqc29uKSB7XG5cdHZhciBlanNvblN0cmluZyA9IEVKU09OLnN0cmluZ2lmeShlanNvbilcblx0cmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChlanNvblN0cmluZylcbn1cblxuLyoqXG4gKiBEZWNvZGVzIGFuIGVuY29kZWQgc3RyaW5nIGludG8gYW4gb2JqZWN0LlxuICogQHBhcmFtIHtzdHJpbmd9IGVuY29kZWRFanNvblxuICovXG5JbmplY3REYXRhLmRlY29kZSA9IEluamVjdERhdGEuX2RlY29kZSA9IGZ1bmN0aW9uKGVuY29kZWRFanNvbikge1xuXHR2YXIgZGVjb2RlZEVqc29uU3RyaW5nID0gZGVjb2RlVVJJQ29tcG9uZW50KGVuY29kZWRFanNvbilcblx0aWYgKCFkZWNvZGVkRWpzb25TdHJpbmcpIHJldHVybiBudWxsXG5cblx0cmV0dXJuIEVKU09OLnBhcnNlKGRlY29kZWRFanNvblN0cmluZylcbn1cbiIsIlxuaW1wb3J0IHsgSW5qZWN0RGF0YSB9IGZyb20gJy4vbmFtZXNwYWNlJ1xuaW1wb3J0IHsgV2ViQXBwSW50ZXJuYWxzIH0gZnJvbSAnbWV0ZW9yL3dlYmFwcCdcblxuLy8gU3VwcG9ydHMgbGVnYWN5IHVzZXMgb2YgaW5qZWN0IGRhdGEsIFNTUiB1c2VycyBzaG91bGQgdHVybiB0aGlzIHRvIGZhbHNlXG5JbmplY3REYXRhLmluamVjdFRvSGVhZCA9IHRydWVcblxuV2ViQXBwSW50ZXJuYWxzLnJlZ2lzdGVyQm9pbGVycGxhdGVEYXRhQ2FsbGJhY2soXG5cdCdpbmplY3QtZGF0YScsXG5cdChyZXEsIGRhdGEsIGFyY2gpID0+IHtcblx0XHRpZiAoXG5cdFx0XHRyZXEgJiZcblx0XHRcdHJlcS5oZWFkZXJzICYmXG5cdFx0XHRyZXEuaGVhZGVycy5faW5qZWN0UGF5bG9hZCAmJlxuXHRcdFx0IUluamVjdERhdGEuZGlzYWJsZUluamVjdGlvblxuXHRcdCkge1xuXHRcdFx0Y29uc3QgcGF5bG9hZCA9IGA8c2NyaXB0IHR5cGU9XCJ0ZXh0L2luamVjdC1kYXRhXCI+JHtJbmplY3REYXRhLmVuY29kZShcblx0XHRcdFx0cmVxLmhlYWRlcnMuX2luamVjdFBheWxvYWRcblx0XHRcdCl9PC9zY3JpcHQ+YFxuXG5cdFx0XHRpZiAoSW5qZWN0RGF0YS5pbmplY3RUb0hlYWQpIHtcblx0XHRcdFx0aWYgKCFkYXRhLmR5bmFtaWNIZWFkKSB7XG5cdFx0XHRcdFx0ZGF0YS5keW5hbWljSGVhZCA9ICcnXG5cdFx0XHRcdH1cblx0XHRcdFx0ZGF0YS5keW5hbWljSGVhZCArPSBwYXlsb2FkXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRpZiAoIWRhdGEuZHluYW1pY0JvZHkpIHtcblx0XHRcdFx0XHRkYXRhLmR5bmFtaWNCb2R5ID0gJydcblx0XHRcdFx0fVxuXHRcdFx0XHRkYXRhLmR5bmFtaWNCb2R5ICs9IHBheWxvYWRcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGZhbHNlXG5cdH1cbilcblxuLyoqXG4gKiBQdXNoZXMgZGF0YSBpbnRvIHRoZSBJbmplY3REYXRhIHBheWxvYWQuXG4gKiBAcGFyYW0ge29iamVjdH0gbm9kZSByZXF1ZXN0IG9iamVjdFxuICogQHBhcmFtIHtzdHJpbmd9IGtleVxuICogQHBhcmFtIHsqfSB2YWx1ZVxuICovXG5JbmplY3REYXRhLnB1c2hEYXRhID0gZnVuY3Rpb24gcHVzaERhdGEocmVxLCBrZXksIHZhbHVlKSB7XG5cdGlmICghcmVxLmhlYWRlcnMpIHtcblx0XHRyZXEuaGVhZGVycyA9IHt9XG5cdH1cblx0aWYgKCFyZXEuaGVhZGVycy5faW5qZWN0UGF5bG9hZCkge1xuXHRcdHJlcS5oZWFkZXJzLl9pbmplY3RQYXlsb2FkID0ge31cblx0fVxuXG5cdHJlcS5oZWFkZXJzLl9pbmplY3RQYXlsb2FkW2tleV0gPSB2YWx1ZVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIG9iamVjdCBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBrZXkuXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5XG4gKi9cbkluamVjdERhdGEuZ2V0RGF0YSA9IGZ1bmN0aW9uIGdldERhdGEocmVxLCBrZXkpIHtcblx0aWYgKHJlcS5oZWFkZXJzICYmIHJlcS5oZWFkZXJzLl9pbmplY3RQYXlsb2FkKSB7XG5cdFx0cmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIHJlcS5oZWFkZXJzLl9pbmplY3RQYXlsb2FkW2tleV0pO1xuXHR9IGVsc2Uge1xuXHRcdHJldHVybiBudWxsXG5cdH1cbn1cbiJdfQ==
