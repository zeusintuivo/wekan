(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var DDPServer = Package['ddp-server'].DDPServer;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;
var DDP = Package['ddp-client'].DDP;

/* Package-scope variables */
var PublishRelations, callbacks, collection, onAdded;

var require = meteorInstall({"node_modules":{"meteor":{"cottz:publish-relations":{"lib":{"server":{"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/index.js                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let PublishRelations;
module.link("./publish_relations", {
  default(v) {
    PublishRelations = v;
  }

}, 0);
module.link("./methods");
module.exportDefault(PublishRelations);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"handler_controller.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/handler_controller.js                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => HandlerController
});

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);

class HandlerController {
  constructor() {
    this.handlers = {};
  }

  set(handler) {
    return this.handler = handler;
  }

  addBasic(collection, handler) {
    const oldHandler = this.handlers[collection];
    return oldHandler || (this.handlers[collection] = handler || new HandlerController());
  }

  add(cursor, options) {
    if (!cursor) throw new Error("you're not sending the cursor");
    const description = cursor._cursorDescription;
    const collection = options.collection || description.collectionName;
    const selector = description.selector;
    /*
      the selector uses references, in cases that a selector has objects inside
      this validation isn't gonna work
     let oldHandler = this.handlers[collection];
    if (oldHandler) {
      // when the selector equals method stops running, no change occurs and everything
      // will still work properly without running the same observer again
      oldHandler.equalSelector = _.isEqual(oldHandler.selector, selector);
      if (oldHandler.equalSelector)
        return oldHandler;
       oldHandler.stop();
    }*/

    const newHandler = options.handler ? cursor[options.handler](options.callbacks) : new HandlerController();
    newHandler.selector = selector;
    return this.handlers[collection] = newHandler;
  }

  stop() {
    let handlers = this.handlers;
    this.handler && this.handler.stop();

    for (let key in handlers) {
      handlers[key].stop();
    }

    ;
    this.handlers = [];
  }

  remove(_id) {
    let handler = this.handlers[_id];

    if (handler) {
      handler.stop();
      delete this.handlers[_id];
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/methods.js                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 1);
let DDPServer;
module.link("meteor/ddp-server", {
  DDPServer(v) {
    DDPServer = v;
  }

}, 2);
const crossbar = DDPServer._InvalidationCrossbar;
Meteor.methods({
  'PR.changePagination'(data) {
    check(data, {
      _id: String,
      field: String,
      skip: Match.Integer
    });
    crossbar.fire(_.extend({
      collection: 'paginations',
      id: this.connection.id
    }, data));
  },

  'PR.fireListener'(collection, options) {
    check(collection, String);
    check(options, Object);
    crossbar.fire(_.extend({
      collection: 'listen-' + collection,
      id: this.connection.id
    }, options));
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish_relations.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/publish_relations.js                                            //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  PublishRelations: () => PublishRelations
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HandlerController;
module.link("./handler_controller", {
  default(v) {
    HandlerController = v;
  }

}, 1);
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 2);
module.runSetters(PublishRelations = function (name, callback) {
  return Meteor.publish(name, function () {
    let handler = new HandlerController(),
        cursors = new CursorMethods(this, handler);
    this._publicationName = name;
    this.onStop(() => handler.stop());

    for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
      params[_key] = arguments[_key];
    }

    let cb = callback.apply(_.extend(cursors, this), params); // kadira show me alerts when I use this return (but works well)
    // return cb || (!this._ready && this.ready());

    return cb;
  });
});
Meteor.publishRelations = PublishRelations;
module.exportDefault(PublishRelations);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cursor":{"change_parent_doc.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/change_parent_doc.js                                     //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 0);

// DEPRECATED
// designed to change something in the master document while the callbacks are executed
// changes to the document are sent to the main document with the return of the callbacks
CursorMethods.prototype.changeParentDoc = function (cursor, callbacks, onRemoved) {
  const sub = this.sub;
  const _id = this._id;
  const collection = this.collection;
  let result = this;
  if (!_id || !collection) throw new Error("you can't use this method without being within a document");
  callbacks = this._getCallbacks(callbacks, onRemoved);
  this.handler.add(cursor, {
    handler: 'observeChanges',
    callbacks: {
      added(id, doc) {
        result._addedWithCPD = callbacks.added(id, doc);
      },

      changed(id, doc) {
        var changes = callbacks.changed(id, doc);
        if (changes) sub.changed(collection, _id, changes);
      },

      removed(id) {
        var changes = callbacks.removed(id);
        if (changes) sub.changed(collection, _id, changes);
      }

    }
  });
  return result._addedWithCPD || {};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"crossbar.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/crossbar.js                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 1);
let DDPServer;
module.link("meteor/ddp-server", {
  DDPServer(v) {
    DDPServer = v;
  }

}, 2);
const crossbar = DDPServer._InvalidationCrossbar; // designed to paginate a list, works in conjunction with the methods
// do not call back to the main callback, only the array is changed in the collection

CursorMethods.prototype.paginate = function (fieldData, limit, infinite) {
  const sub = this.sub;
  const collection = this.collection;
  if (!this._id || !collection) throw new Error("you can't use this method without being within a document");
  const field = Object.keys(fieldData)[0];

  const copy = _.clone(fieldData)[field];

  const max = copy.length;
  const connectionId = sub.connection.id;
  fieldData[field] = copy.slice(0, limit);
  const listener = crossbar.listen({
    collection: 'paginations',
    id: connectionId
  }, data => {
    if (!data.id || data.id !== connectionId) return;
    let skip = data.skip;
    if (skip >= max && !infinite) return;
    fieldData[field] = infinite ? copy.slice(0, skip) : copy.slice(skip, skip + limit);
    sub.changed(collection, data._id, fieldData);
  });
  this.handler.addBasic(field, listener);
  return fieldData[field];
};

CursorMethods.prototype.listen = function (options, callback, run) {
  const sub = this.sub;
  const name = 'listen-' + this._publicationName;
  const listener = crossbar.listen({
    collection: name,
    id: sub.connection.id
  }, data => {
    if (!data.id || data.id !== sub.connection.id) return;

    _.extend(options, _.omit(data, 'collection', 'id'));

    callback(false);
  });
  const handler = this.handler.addBasic(name);
  if (run !== false) callback(true);
  return handler.set(listener);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cursor.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/cursor.js                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => CursorMethods
});

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let CursorMethodsNR;
module.link("./nonreactive", {
  default(v) {
    CursorMethodsNR = v;
  }

}, 1);

class CursorMethods extends CursorMethodsNR {
  constructor(sub, handler, _id, collection) {
    super(sub);
    this.handler = handler;
    this._id = _id;
    this.collection = collection;
  }

  cursor(cursor, collection, callbacks) {
    const sub = this.sub;

    if (!_.isString(collection)) {
      callbacks = collection;
      collection = cursor._getCollectionName();
    }

    const handler = this.handler.add(cursor, {
      collection: collection
    }); // if (handler.equalSelector)
    //   return handler;

    if (callbacks) callbacks = this._getCallbacks(callbacks);

    function applyCallback(id, doc, method) {
      const cb = callbacks && callbacks[method];

      if (cb) {
        let methods = new CursorMethods(sub, handler.addBasic(id), id, collection),
            isChanged = method === 'changed';
        return cb.call(methods, id, doc, isChanged) || doc;
      } else return doc;
    }

    ;
    let observeChanges = cursor.observeChanges({
      added(id, doc) {
        sub.added(collection, id, applyCallback(id, doc, 'added'));
      },

      changed(id, doc) {
        sub.changed(collection, id, applyCallback(id, doc, 'changed'));
      },

      removed(id) {
        if (callbacks) {
          callbacks.removed(id);
          handler.remove(id);
        }

        sub.removed(collection, id);
      }

    });
    return handler.set(observeChanges);
  }

}

;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/index.js                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 0);
module.link("./join");
module.link("./observe");
module.link("./change_parent_doc");
module.link("./crossbar");
module.link("./utils");
module.exportDefault(CursorMethods);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"join.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/join.js                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 1);

CursorMethods.prototype.join = function () {
  for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
    params[_key] = arguments[_key];
  }

  return new CursorJoin(this, ...params);
};

class CursorJoin {
  constructor(methods, collection, options, name) {
    this.methods = methods;
    this.collection = collection;
    this.options = options;
    this.name = name;
    this.data = [];
    this.sent = false;
  }

  push() {
    let changed;

    for (var _len2 = arguments.length, _ids = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      _ids[_key2] = arguments[_key2];
    }

    _.each(_ids, _id => {
      if (!_id || _.contains(this.data, _id)) return;
      this.data.push(_id);
      changed = true;
    });

    if (this.sent && changed) return this._cursor();
  }

  send() {
    this.sent = true;
    if (!this.data.length) return;
    return this._cursor();
  }

  _selector() {
    let _id = {
      $in: this.data
    };
    return _.isFunction(this.selector) ? this.selector(_id) : {
      _id: _id
    };
  }

  _cursor() {
    return this.methods.cursor(this.collection.find(this._selector(), this.options), this.name);
  }

}

;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observe.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/observe.js                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 0);

CursorMethods.prototype.observe = function (cursor, callbacks) {
  this.handler.add(cursor, {
    handler: 'observe',
    callbacks: callbacks
  });
};

CursorMethods.prototype.observeChanges = function (cursor, callbacks) {
  this.handler.add(cursor, {
    handler: 'observeChanges',
    callbacks: callbacks
  });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/utils.js                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let CursorMethods;
module.link("./cursor", {
  default(v) {
    CursorMethods = v;
  }

}, 1);

function getCB(cb, method) {
  var callback = cb[method];
  if (callback && !_.isFunction(callback)) throw new Error(method + ' should be a function or undefined');
  return callback || function () {};
}

;

CursorMethods.prototype._getCallbacks = function (cb, onRemoved) {
  if (_.isFunction(cb)) {
    return {
      added: cb,
      changed: cb,
      removed: getCB({
        onRemoved: onRemoved
      }, 'onRemoved')
    };
  }

  return {
    added: getCB(cb, 'added'),
    changed: getCB(cb, 'changed'),
    removed: getCB(cb, 'removed')
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"nonreactive":{"cursor.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/nonreactive/cursor.js                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => CursorMethodsNR
});

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);

class CursorMethodsNR {
  constructor(sub) {
    this.sub = sub;
  }

  cursorNonreactive(cursor, collection, onAdded) {
    const sub = this.sub;

    if (!_.isString(collection)) {
      onAdded = collection;
      collection = cursor._getCollectionName();
    }

    if (!_.isFunction(onAdded)) onAdded = function () {};
    cursor.forEach(doc => {
      let _id = doc._id;
      sub.added(collection, _id, onAdded.call(new CursorMethodsNR(sub), _id, doc) || doc);
    });
  }

}

;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/nonreactive/index.js                                     //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let CursorMethodsNR;
module.link("./cursor", {
  default(v) {
    CursorMethodsNR = v;
  }

}, 0);
module.link("./join");
module.exportDefault(CursorMethodsNR);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"join.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/cottz_publish-relations/lib/server/cursor/nonreactive/join.js                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let CursorMethodsNR;
module.link("./cursor", {
  default(v) {
    CursorMethodsNR = v;
  }

}, 1);

CursorMethodsNR.prototype.joinNonreactive = function () {
  for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
    params[_key] = arguments[_key];
  }

  return new CursorJoinNonreactive(this.sub, ...params);
};

class CursorJoinNonreactive {
  constructor(sub, collection, options, name) {
    this.sub = sub;
    this.collection = collection;
    this.options = options;
    this.name = name || collection._name;
    this.data = [];
    this.sent = false;
  }

  _selector() {
    let _id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
      $in: this.data
    };

    return _.isFunction(this.selector) ? this.selector(_id) : {
      _id: _id
    };
  }

  push() {
    let newIds = [];

    for (var _len2 = arguments.length, _ids = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      _ids[_key2] = arguments[_key2];
    }

    _.each(_ids, _id => {
      if (!_id || _.contains(this.data, _id)) return;
      this.data.push(_id);
      newIds.push(_id);
    });

    if (this.sent && newIds.length) return this.added(newIds.length > 1 ? {
      $in: newIds
    } : newIds[0]);
  }

  send() {
    this.sent = true;
    if (!this.data.length) return;
    return this.added();
  }

  added(_id) {
    this.collection.find(this._selector(_id), this.options).forEach(doc => {
      this.sub.added(this.name, doc._id, _.omit(doc, '_id'));
    });
  }

}

;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/cottz:publish-relations/lib/server/index.js");

/* Exports */
Package._define("cottz:publish-relations", exports, {
  PublishRelations: PublishRelations
});

})();

//# sourceURL=meteor://💻app/packages/cottz_publish-relations.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY290dHo6cHVibGlzaC1yZWxhdGlvbnMvbGliL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY290dHo6cHVibGlzaC1yZWxhdGlvbnMvbGliL3NlcnZlci9oYW5kbGVyX2NvbnRyb2xsZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2NvdHR6OnB1Ymxpc2gtcmVsYXRpb25zL2xpYi9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY290dHo6cHVibGlzaC1yZWxhdGlvbnMvbGliL3NlcnZlci9wdWJsaXNoX3JlbGF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY290dHo6cHVibGlzaC1yZWxhdGlvbnMvbGliL3NlcnZlci9jdXJzb3IvY2hhbmdlX3BhcmVudF9kb2MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2NvdHR6OnB1Ymxpc2gtcmVsYXRpb25zL2xpYi9zZXJ2ZXIvY3Vyc29yL2Nyb3NzYmFyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9jb3R0ejpwdWJsaXNoLXJlbGF0aW9ucy9saWIvc2VydmVyL2N1cnNvci9jdXJzb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2NvdHR6OnB1Ymxpc2gtcmVsYXRpb25zL2xpYi9zZXJ2ZXIvY3Vyc29yL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9jb3R0ejpwdWJsaXNoLXJlbGF0aW9ucy9saWIvc2VydmVyL2N1cnNvci9qb2luLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9jb3R0ejpwdWJsaXNoLXJlbGF0aW9ucy9saWIvc2VydmVyL2N1cnNvci9vYnNlcnZlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9jb3R0ejpwdWJsaXNoLXJlbGF0aW9ucy9saWIvc2VydmVyL2N1cnNvci91dGlscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY290dHo6cHVibGlzaC1yZWxhdGlvbnMvbGliL3NlcnZlci9jdXJzb3Ivbm9ucmVhY3RpdmUvY3Vyc29yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9jb3R0ejpwdWJsaXNoLXJlbGF0aW9ucy9saWIvc2VydmVyL2N1cnNvci9ub25yZWFjdGl2ZS9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY290dHo6cHVibGlzaC1yZWxhdGlvbnMvbGliL3NlcnZlci9jdXJzb3Ivbm9ucmVhY3RpdmUvam9pbi5qcyJdLCJuYW1lcyI6WyJQdWJsaXNoUmVsYXRpb25zIiwibW9kdWxlIiwibGluayIsImRlZmF1bHQiLCJ2IiwiZXhwb3J0RGVmYXVsdCIsImV4cG9ydCIsIkhhbmRsZXJDb250cm9sbGVyIiwiXyIsImNvbnN0cnVjdG9yIiwiaGFuZGxlcnMiLCJzZXQiLCJoYW5kbGVyIiwiYWRkQmFzaWMiLCJjb2xsZWN0aW9uIiwib2xkSGFuZGxlciIsImFkZCIsImN1cnNvciIsIm9wdGlvbnMiLCJFcnJvciIsImRlc2NyaXB0aW9uIiwiX2N1cnNvckRlc2NyaXB0aW9uIiwiY29sbGVjdGlvbk5hbWUiLCJzZWxlY3RvciIsIm5ld0hhbmRsZXIiLCJjYWxsYmFja3MiLCJzdG9wIiwia2V5IiwicmVtb3ZlIiwiX2lkIiwiTWV0ZW9yIiwiY2hlY2siLCJNYXRjaCIsIkREUFNlcnZlciIsImNyb3NzYmFyIiwiX0ludmFsaWRhdGlvbkNyb3NzYmFyIiwibWV0aG9kcyIsImRhdGEiLCJTdHJpbmciLCJmaWVsZCIsInNraXAiLCJJbnRlZ2VyIiwiZmlyZSIsImV4dGVuZCIsImlkIiwiY29ubmVjdGlvbiIsIk9iamVjdCIsIkN1cnNvck1ldGhvZHMiLCJuYW1lIiwiY2FsbGJhY2siLCJwdWJsaXNoIiwiY3Vyc29ycyIsIl9wdWJsaWNhdGlvbk5hbWUiLCJvblN0b3AiLCJwYXJhbXMiLCJjYiIsImFwcGx5IiwicHVibGlzaFJlbGF0aW9ucyIsInByb3RvdHlwZSIsImNoYW5nZVBhcmVudERvYyIsIm9uUmVtb3ZlZCIsInN1YiIsInJlc3VsdCIsIl9nZXRDYWxsYmFja3MiLCJhZGRlZCIsImRvYyIsIl9hZGRlZFdpdGhDUEQiLCJjaGFuZ2VkIiwiY2hhbmdlcyIsInJlbW92ZWQiLCJwYWdpbmF0ZSIsImZpZWxkRGF0YSIsImxpbWl0IiwiaW5maW5pdGUiLCJrZXlzIiwiY29weSIsImNsb25lIiwibWF4IiwibGVuZ3RoIiwiY29ubmVjdGlvbklkIiwic2xpY2UiLCJsaXN0ZW5lciIsImxpc3RlbiIsInJ1biIsIm9taXQiLCJDdXJzb3JNZXRob2RzTlIiLCJpc1N0cmluZyIsIl9nZXRDb2xsZWN0aW9uTmFtZSIsImFwcGx5Q2FsbGJhY2siLCJtZXRob2QiLCJpc0NoYW5nZWQiLCJjYWxsIiwib2JzZXJ2ZUNoYW5nZXMiLCJqb2luIiwiQ3Vyc29ySm9pbiIsInNlbnQiLCJwdXNoIiwiX2lkcyIsImVhY2giLCJjb250YWlucyIsIl9jdXJzb3IiLCJzZW5kIiwiX3NlbGVjdG9yIiwiJGluIiwiaXNGdW5jdGlvbiIsImZpbmQiLCJvYnNlcnZlIiwiZ2V0Q0IiLCJjdXJzb3JOb25yZWFjdGl2ZSIsIm9uQWRkZWQiLCJmb3JFYWNoIiwiam9pbk5vbnJlYWN0aXZlIiwiQ3Vyc29ySm9pbk5vbnJlYWN0aXZlIiwiX25hbWUiLCJuZXdJZHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsZ0JBQUo7QUFBcUJDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNKLG9CQUFnQixHQUFDSSxDQUFqQjtBQUFtQjs7QUFBL0IsQ0FBbEMsRUFBbUUsQ0FBbkU7QUFBc0VILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7QUFBM0ZELE1BQU0sQ0FBQ0ksYUFBUCxDQUdlTCxnQkFIZixFOzs7Ozs7Ozs7OztBQ0FBQyxNQUFNLENBQUNLLE1BQVAsQ0FBYztBQUFDSCxTQUFPLEVBQUMsTUFBSUk7QUFBYixDQUFkOztBQUErQyxJQUFJQyxDQUFKOztBQUFNUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDTSxHQUFDLENBQUNKLENBQUQsRUFBRztBQUFDSSxLQUFDLEdBQUNKLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1Qzs7QUFJdEMsTUFBTUcsaUJBQU4sQ0FBd0I7QUFDckNFLGFBQVcsR0FBSTtBQUNiLFNBQUtDLFFBQUwsR0FBZ0IsRUFBaEI7QUFDRDs7QUFDREMsS0FBRyxDQUFFQyxPQUFGLEVBQVc7QUFDWixXQUFPLEtBQUtBLE9BQUwsR0FBZUEsT0FBdEI7QUFDRDs7QUFDREMsVUFBUSxDQUFFQyxVQUFGLEVBQWNGLE9BQWQsRUFBdUI7QUFDN0IsVUFBTUcsVUFBVSxHQUFHLEtBQUtMLFFBQUwsQ0FBY0ksVUFBZCxDQUFuQjtBQUNBLFdBQU9DLFVBQVUsS0FBSyxLQUFLTCxRQUFMLENBQWNJLFVBQWQsSUFBNEJGLE9BQU8sSUFBSSxJQUFJTCxpQkFBSixFQUE1QyxDQUFqQjtBQUNEOztBQUNEUyxLQUFHLENBQUVDLE1BQUYsRUFBVUMsT0FBVixFQUFtQjtBQUNwQixRQUFJLENBQUNELE1BQUwsRUFDRSxNQUFNLElBQUlFLEtBQUosQ0FBVSwrQkFBVixDQUFOO0FBRUYsVUFBTUMsV0FBVyxHQUFHSCxNQUFNLENBQUNJLGtCQUEzQjtBQUNBLFVBQU1QLFVBQVUsR0FBR0ksT0FBTyxDQUFDSixVQUFSLElBQXNCTSxXQUFXLENBQUNFLGNBQXJEO0FBQ0EsVUFBTUMsUUFBUSxHQUFHSCxXQUFXLENBQUNHLFFBQTdCO0FBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlJLFVBQU1DLFVBQVUsR0FBR04sT0FBTyxDQUFDTixPQUFSLEdBQ2pCSyxNQUFNLENBQUNDLE9BQU8sQ0FBQ04sT0FBVCxDQUFOLENBQXdCTSxPQUFPLENBQUNPLFNBQWhDLENBRGlCLEdBRWpCLElBQUlsQixpQkFBSixFQUZGO0FBSUFpQixjQUFVLENBQUNELFFBQVgsR0FBc0JBLFFBQXRCO0FBRUEsV0FBTyxLQUFLYixRQUFMLENBQWNJLFVBQWQsSUFBNEJVLFVBQW5DO0FBQ0Q7O0FBQ0RFLE1BQUksR0FBSTtBQUNOLFFBQUloQixRQUFRLEdBQUcsS0FBS0EsUUFBcEI7QUFFQSxTQUFLRSxPQUFMLElBQWdCLEtBQUtBLE9BQUwsQ0FBYWMsSUFBYixFQUFoQjs7QUFFQSxTQUFLLElBQUlDLEdBQVQsSUFBZ0JqQixRQUFoQixFQUEwQjtBQUN4QkEsY0FBUSxDQUFDaUIsR0FBRCxDQUFSLENBQWNELElBQWQ7QUFDRDs7QUFBQTtBQUVELFNBQUtoQixRQUFMLEdBQWdCLEVBQWhCO0FBQ0Q7O0FBQ0RrQixRQUFNLENBQUVDLEdBQUYsRUFBTztBQUNYLFFBQUlqQixPQUFPLEdBQUcsS0FBS0YsUUFBTCxDQUFjbUIsR0FBZCxDQUFkOztBQUNBLFFBQUlqQixPQUFKLEVBQWE7QUFDWEEsYUFBTyxDQUFDYyxJQUFSO0FBQ0EsYUFBTyxLQUFLaEIsUUFBTCxDQUFjbUIsR0FBZCxDQUFQO0FBQ0Q7QUFDRjs7QUExRG9DLEM7Ozs7Ozs7Ozs7O0FDSnZDLElBQUlDLE1BQUo7QUFBVzdCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQzRCLFFBQU0sQ0FBQzFCLENBQUQsRUFBRztBQUFDMEIsVUFBTSxHQUFDMUIsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMkIsS0FBSixFQUFVQyxLQUFWO0FBQWdCL0IsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNkIsT0FBSyxDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQixTQUFLLEdBQUMzQixDQUFOO0FBQVEsR0FBbEI7O0FBQW1CNEIsT0FBSyxDQUFDNUIsQ0FBRCxFQUFHO0FBQUM0QixTQUFLLEdBQUM1QixDQUFOO0FBQVE7O0FBQXBDLENBQTNCLEVBQWlFLENBQWpFO0FBQW9FLElBQUk2QixTQUFKO0FBQWNoQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDK0IsV0FBUyxDQUFDN0IsQ0FBRCxFQUFHO0FBQUM2QixhQUFTLEdBQUM3QixDQUFWO0FBQVk7O0FBQTFCLENBQWhDLEVBQTRELENBQTVEO0FBSWxLLE1BQU04QixRQUFRLEdBQUdELFNBQVMsQ0FBQ0UscUJBQTNCO0FBRUFMLE1BQU0sQ0FBQ00sT0FBUCxDQUFlO0FBQ2Isd0JBQXVCQyxJQUF2QixFQUE2QjtBQUMzQk4sU0FBSyxDQUFDTSxJQUFELEVBQU87QUFDVlIsU0FBRyxFQUFFUyxNQURLO0FBRVZDLFdBQUssRUFBRUQsTUFGRztBQUdWRSxVQUFJLEVBQUVSLEtBQUssQ0FBQ1M7QUFIRixLQUFQLENBQUw7QUFNQVAsWUFBUSxDQUFDUSxJQUFULENBQWNsQyxDQUFDLENBQUNtQyxNQUFGLENBQVM7QUFDckI3QixnQkFBVSxFQUFFLGFBRFM7QUFFckI4QixRQUFFLEVBQUUsS0FBS0MsVUFBTCxDQUFnQkQ7QUFGQyxLQUFULEVBR1hQLElBSFcsQ0FBZDtBQUlELEdBWlk7O0FBYWIsb0JBQW1CdkIsVUFBbkIsRUFBK0JJLE9BQS9CLEVBQXdDO0FBQ3RDYSxTQUFLLENBQUNqQixVQUFELEVBQWF3QixNQUFiLENBQUw7QUFDQVAsU0FBSyxDQUFDYixPQUFELEVBQVU0QixNQUFWLENBQUw7QUFFQVosWUFBUSxDQUFDUSxJQUFULENBQWNsQyxDQUFDLENBQUNtQyxNQUFGLENBQVM7QUFDckI3QixnQkFBVSxFQUFFLFlBQVlBLFVBREg7QUFFckI4QixRQUFFLEVBQUUsS0FBS0MsVUFBTCxDQUFnQkQ7QUFGQyxLQUFULEVBR1gxQixPQUhXLENBQWQ7QUFJRDs7QUFyQlksQ0FBZixFOzs7Ozs7Ozs7OztBQ05BakIsTUFBTSxDQUFDSyxNQUFQLENBQWM7QUFBQ04sa0JBQWdCLEVBQUMsTUFBSUE7QUFBdEIsQ0FBZDtBQUF1RCxJQUFJOEIsTUFBSjtBQUFXN0IsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDNEIsUUFBTSxDQUFDMUIsQ0FBRCxFQUFHO0FBQUMwQixVQUFNLEdBQUMxQixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlHLGlCQUFKO0FBQXNCTixNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDRyxxQkFBaUIsR0FBQ0gsQ0FBbEI7QUFBb0I7O0FBQWhDLENBQW5DLEVBQXFFLENBQXJFO0FBQXdFLElBQUkyQyxhQUFKO0FBQWtCOUMsTUFBTSxDQUFDQyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDMkMsaUJBQWEsR0FBQzNDLENBQWQ7QUFBZ0I7O0FBQTVCLENBQXZCLEVBQXFELENBQXJEO0FBSXZPLGtCQUFBSixnQkFBZ0IsR0FBRyxVQUFVZ0QsSUFBVixFQUFnQkMsUUFBaEIsRUFBMEI7QUFDM0MsU0FBT25CLE1BQU0sQ0FBQ29CLE9BQVAsQ0FBZUYsSUFBZixFQUFxQixZQUFxQjtBQUMvQyxRQUFJcEMsT0FBTyxHQUFHLElBQUlMLGlCQUFKLEVBQWQ7QUFBQSxRQUNBNEMsT0FBTyxHQUFHLElBQUlKLGFBQUosQ0FBa0IsSUFBbEIsRUFBd0JuQyxPQUF4QixDQURWO0FBR0EsU0FBS3dDLGdCQUFMLEdBQXdCSixJQUF4QjtBQUNBLFNBQUtLLE1BQUwsQ0FBWSxNQUFNekMsT0FBTyxDQUFDYyxJQUFSLEVBQWxCOztBQUwrQyxzQ0FBUjRCLE1BQVE7QUFBUkEsWUFBUTtBQUFBOztBQU8vQyxRQUFJQyxFQUFFLEdBQUdOLFFBQVEsQ0FBQ08sS0FBVCxDQUFlaEQsQ0FBQyxDQUFDbUMsTUFBRixDQUFTUSxPQUFULEVBQWtCLElBQWxCLENBQWYsRUFBd0NHLE1BQXhDLENBQVQsQ0FQK0MsQ0FRL0M7QUFDQTs7QUFDQSxXQUFPQyxFQUFQO0FBQ0QsR0FYTSxDQUFQO0FBWUQsQ0FiRDtBQWVBekIsTUFBTSxDQUFDMkIsZ0JBQVAsR0FBMEJ6RCxnQkFBMUI7QUFuQkFDLE1BQU0sQ0FBQ0ksYUFBUCxDQXFCZUwsZ0JBckJmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSStDLGFBQUo7QUFBa0I5QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMyQyxpQkFBYSxHQUFDM0MsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBdkIsRUFBcUQsQ0FBckQ7O0FBQ2xCO0FBQ0E7QUFDQTtBQUNBMkMsYUFBYSxDQUFDVyxTQUFkLENBQXdCQyxlQUF4QixHQUEwQyxVQUFVMUMsTUFBVixFQUFrQlEsU0FBbEIsRUFBNkJtQyxTQUE3QixFQUF3QztBQUNoRixRQUFNQyxHQUFHLEdBQUcsS0FBS0EsR0FBakI7QUFDQSxRQUFNaEMsR0FBRyxHQUFHLEtBQUtBLEdBQWpCO0FBQ0EsUUFBTWYsVUFBVSxHQUFHLEtBQUtBLFVBQXhCO0FBRUEsTUFBSWdELE1BQU0sR0FBRyxJQUFiO0FBRUEsTUFBSSxDQUFDakMsR0FBRCxJQUFRLENBQUNmLFVBQWIsRUFDRSxNQUFNLElBQUlLLEtBQUosQ0FBVSwyREFBVixDQUFOO0FBRUZNLFdBQVMsR0FBRyxLQUFLc0MsYUFBTCxDQUFtQnRDLFNBQW5CLEVBQThCbUMsU0FBOUIsQ0FBWjtBQUVBLE9BQUtoRCxPQUFMLENBQWFJLEdBQWIsQ0FBaUJDLE1BQWpCLEVBQXlCO0FBQ3ZCTCxXQUFPLEVBQUUsZ0JBRGM7QUFFdkJhLGFBQVMsRUFBRTtBQUNUdUMsV0FBSyxDQUFFcEIsRUFBRixFQUFNcUIsR0FBTixFQUFXO0FBQ2RILGNBQU0sQ0FBQ0ksYUFBUCxHQUF1QnpDLFNBQVMsQ0FBQ3VDLEtBQVYsQ0FBZ0JwQixFQUFoQixFQUFvQnFCLEdBQXBCLENBQXZCO0FBQ0QsT0FIUTs7QUFJVEUsYUFBTyxDQUFFdkIsRUFBRixFQUFNcUIsR0FBTixFQUFXO0FBQ2hCLFlBQUlHLE9BQU8sR0FBRzNDLFNBQVMsQ0FBQzBDLE9BQVYsQ0FBa0J2QixFQUFsQixFQUFzQnFCLEdBQXRCLENBQWQ7QUFDQSxZQUFJRyxPQUFKLEVBQ0VQLEdBQUcsQ0FBQ00sT0FBSixDQUFZckQsVUFBWixFQUF3QmUsR0FBeEIsRUFBNkJ1QyxPQUE3QjtBQUNILE9BUlE7O0FBU1RDLGFBQU8sQ0FBRXpCLEVBQUYsRUFBTTtBQUNYLFlBQUl3QixPQUFPLEdBQUczQyxTQUFTLENBQUM0QyxPQUFWLENBQWtCekIsRUFBbEIsQ0FBZDtBQUNBLFlBQUl3QixPQUFKLEVBQ0VQLEdBQUcsQ0FBQ00sT0FBSixDQUFZckQsVUFBWixFQUF3QmUsR0FBeEIsRUFBNkJ1QyxPQUE3QjtBQUNIOztBQWJRO0FBRlksR0FBekI7QUFtQkEsU0FBT04sTUFBTSxDQUFDSSxhQUFQLElBQXdCLEVBQS9CO0FBQ0QsQ0FoQ0QsQzs7Ozs7Ozs7Ozs7QUNKQSxJQUFJMUQsQ0FBSjs7QUFBTVAsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ00sR0FBQyxDQUFDSixDQUFELEVBQUc7QUFBQ0ksS0FBQyxHQUFDSixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTJDLGFBQUo7QUFBa0I5QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMyQyxpQkFBYSxHQUFDM0MsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBdkIsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSTZCLFNBQUo7QUFBY2hDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUMrQixXQUFTLENBQUM3QixDQUFELEVBQUc7QUFBQzZCLGFBQVMsR0FBQzdCLENBQVY7QUFBWTs7QUFBMUIsQ0FBaEMsRUFBNEQsQ0FBNUQ7QUFJN0ksTUFBTThCLFFBQVEsR0FBR0QsU0FBUyxDQUFDRSxxQkFBM0IsQyxDQUNBO0FBQ0E7O0FBQ0FZLGFBQWEsQ0FBQ1csU0FBZCxDQUF3QlksUUFBeEIsR0FBbUMsVUFBVUMsU0FBVixFQUFxQkMsS0FBckIsRUFBNEJDLFFBQTVCLEVBQXNDO0FBQ3ZFLFFBQU1aLEdBQUcsR0FBRyxLQUFLQSxHQUFqQjtBQUNBLFFBQU0vQyxVQUFVLEdBQUcsS0FBS0EsVUFBeEI7QUFFQSxNQUFJLENBQUMsS0FBS2UsR0FBTixJQUFhLENBQUNmLFVBQWxCLEVBQ0UsTUFBTSxJQUFJSyxLQUFKLENBQVUsMkRBQVYsQ0FBTjtBQUVGLFFBQU1vQixLQUFLLEdBQUdPLE1BQU0sQ0FBQzRCLElBQVAsQ0FBWUgsU0FBWixFQUF1QixDQUF2QixDQUFkOztBQUNBLFFBQU1JLElBQUksR0FBR25FLENBQUMsQ0FBQ29FLEtBQUYsQ0FBUUwsU0FBUixFQUFtQmhDLEtBQW5CLENBQWI7O0FBQ0EsUUFBTXNDLEdBQUcsR0FBR0YsSUFBSSxDQUFDRyxNQUFqQjtBQUNBLFFBQU1DLFlBQVksR0FBR2xCLEdBQUcsQ0FBQ2hCLFVBQUosQ0FBZUQsRUFBcEM7QUFFQTJCLFdBQVMsQ0FBQ2hDLEtBQUQsQ0FBVCxHQUFtQm9DLElBQUksQ0FBQ0ssS0FBTCxDQUFXLENBQVgsRUFBY1IsS0FBZCxDQUFuQjtBQUVBLFFBQU1TLFFBQVEsR0FBRy9DLFFBQVEsQ0FBQ2dELE1BQVQsQ0FBZ0I7QUFDL0JwRSxjQUFVLEVBQUUsYUFEbUI7QUFFL0I4QixNQUFFLEVBQUVtQztBQUYyQixHQUFoQixFQUdiMUMsSUFBRCxJQUFVO0FBQ1gsUUFBSSxDQUFDQSxJQUFJLENBQUNPLEVBQU4sSUFBWVAsSUFBSSxDQUFDTyxFQUFMLEtBQVltQyxZQUE1QixFQUEwQztBQUUxQyxRQUFJdkMsSUFBSSxHQUFHSCxJQUFJLENBQUNHLElBQWhCO0FBRUEsUUFBSUEsSUFBSSxJQUFJcUMsR0FBUixJQUFlLENBQUNKLFFBQXBCLEVBQ0U7QUFFRkYsYUFBUyxDQUFDaEMsS0FBRCxDQUFULEdBQW1Ca0MsUUFBUSxHQUFHRSxJQUFJLENBQUNLLEtBQUwsQ0FBVyxDQUFYLEVBQWN4QyxJQUFkLENBQUgsR0FBd0JtQyxJQUFJLENBQUNLLEtBQUwsQ0FBV3hDLElBQVgsRUFBaUJBLElBQUksR0FBR2dDLEtBQXhCLENBQW5EO0FBQ0FYLE9BQUcsQ0FBQ00sT0FBSixDQUFZckQsVUFBWixFQUF3QnVCLElBQUksQ0FBQ1IsR0FBN0IsRUFBa0MwQyxTQUFsQztBQUNELEdBYmdCLENBQWpCO0FBZUEsT0FBSzNELE9BQUwsQ0FBYUMsUUFBYixDQUFzQjBCLEtBQXRCLEVBQTZCMEMsUUFBN0I7QUFFQSxTQUFPVixTQUFTLENBQUNoQyxLQUFELENBQWhCO0FBQ0QsQ0FoQ0Q7O0FBa0NBUSxhQUFhLENBQUNXLFNBQWQsQ0FBd0J3QixNQUF4QixHQUFpQyxVQUFVaEUsT0FBVixFQUFtQitCLFFBQW5CLEVBQTZCa0MsR0FBN0IsRUFBa0M7QUFDakUsUUFBTXRCLEdBQUcsR0FBRyxLQUFLQSxHQUFqQjtBQUNBLFFBQU1iLElBQUksR0FBRyxZQUFZLEtBQUtJLGdCQUE5QjtBQUVBLFFBQU02QixRQUFRLEdBQUcvQyxRQUFRLENBQUNnRCxNQUFULENBQWdCO0FBQy9CcEUsY0FBVSxFQUFFa0MsSUFEbUI7QUFFL0JKLE1BQUUsRUFBRWlCLEdBQUcsQ0FBQ2hCLFVBQUosQ0FBZUQ7QUFGWSxHQUFoQixFQUdiUCxJQUFELElBQVU7QUFDWCxRQUFJLENBQUNBLElBQUksQ0FBQ08sRUFBTixJQUFZUCxJQUFJLENBQUNPLEVBQUwsS0FBWWlCLEdBQUcsQ0FBQ2hCLFVBQUosQ0FBZUQsRUFBM0MsRUFBK0M7O0FBRS9DcEMsS0FBQyxDQUFDbUMsTUFBRixDQUFTekIsT0FBVCxFQUFrQlYsQ0FBQyxDQUFDNEUsSUFBRixDQUFPL0MsSUFBUCxFQUFhLFlBQWIsRUFBMkIsSUFBM0IsQ0FBbEI7O0FBQ0FZLFlBQVEsQ0FBQyxLQUFELENBQVI7QUFDRCxHQVJnQixDQUFqQjtBQVVBLFFBQU1yQyxPQUFPLEdBQUcsS0FBS0EsT0FBTCxDQUFhQyxRQUFiLENBQXNCbUMsSUFBdEIsQ0FBaEI7QUFFQSxNQUFJbUMsR0FBRyxLQUFLLEtBQVosRUFBbUJsQyxRQUFRLENBQUMsSUFBRCxDQUFSO0FBRW5CLFNBQU9yQyxPQUFPLENBQUNELEdBQVIsQ0FBWXNFLFFBQVosQ0FBUDtBQUNELENBbkJELEM7Ozs7Ozs7Ozs7O0FDekNBaEYsTUFBTSxDQUFDSyxNQUFQLENBQWM7QUFBQ0gsU0FBTyxFQUFDLE1BQUk0QztBQUFiLENBQWQ7O0FBQTJDLElBQUl2QyxDQUFKOztBQUFNUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDTSxHQUFDLENBQUNKLENBQUQsRUFBRztBQUFDSSxLQUFDLEdBQUNKLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJaUYsZUFBSjtBQUFvQnBGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2lGLG1CQUFlLEdBQUNqRixDQUFoQjtBQUFrQjs7QUFBOUIsQ0FBNUIsRUFBNEQsQ0FBNUQ7O0FBR3JHLE1BQU0yQyxhQUFOLFNBQTRCc0MsZUFBNUIsQ0FBNEM7QUFDekQ1RSxhQUFXLENBQUVvRCxHQUFGLEVBQU9qRCxPQUFQLEVBQWdCaUIsR0FBaEIsRUFBcUJmLFVBQXJCLEVBQWlDO0FBQzFDLFVBQU0rQyxHQUFOO0FBRUEsU0FBS2pELE9BQUwsR0FBZUEsT0FBZjtBQUNBLFNBQUtpQixHQUFMLEdBQVdBLEdBQVg7QUFDQSxTQUFLZixVQUFMLEdBQWtCQSxVQUFsQjtBQUNEOztBQUNERyxRQUFNLENBQUVBLE1BQUYsRUFBVUgsVUFBVixFQUFzQlcsU0FBdEIsRUFBaUM7QUFDckMsVUFBTW9DLEdBQUcsR0FBRyxLQUFLQSxHQUFqQjs7QUFFQSxRQUFJLENBQUNyRCxDQUFDLENBQUM4RSxRQUFGLENBQVd4RSxVQUFYLENBQUwsRUFBNkI7QUFDM0JXLGVBQVMsR0FBR1gsVUFBWjtBQUNBQSxnQkFBVSxHQUFHRyxNQUFNLENBQUNzRSxrQkFBUCxFQUFiO0FBQ0Q7O0FBRUQsVUFBTTNFLE9BQU8sR0FBRyxLQUFLQSxPQUFMLENBQWFJLEdBQWIsQ0FBaUJDLE1BQWpCLEVBQXlCO0FBQUNILGdCQUFVLEVBQUVBO0FBQWIsS0FBekIsQ0FBaEIsQ0FScUMsQ0FTckM7QUFDQTs7QUFFQSxRQUFJVyxTQUFKLEVBQ0VBLFNBQVMsR0FBRyxLQUFLc0MsYUFBTCxDQUFtQnRDLFNBQW5CLENBQVo7O0FBRUYsYUFBUytELGFBQVQsQ0FBd0I1QyxFQUF4QixFQUE0QnFCLEdBQTVCLEVBQWlDd0IsTUFBakMsRUFBeUM7QUFDdkMsWUFBTWxDLEVBQUUsR0FBRzlCLFNBQVMsSUFBSUEsU0FBUyxDQUFDZ0UsTUFBRCxDQUFqQzs7QUFFQSxVQUFJbEMsRUFBSixFQUFRO0FBQ04sWUFBSW5CLE9BQU8sR0FBRyxJQUFJVyxhQUFKLENBQWtCYyxHQUFsQixFQUF1QmpELE9BQU8sQ0FBQ0MsUUFBUixDQUFpQitCLEVBQWpCLENBQXZCLEVBQTZDQSxFQUE3QyxFQUFpRDlCLFVBQWpELENBQWQ7QUFBQSxZQUNBNEUsU0FBUyxHQUFHRCxNQUFNLEtBQUssU0FEdkI7QUFHQSxlQUFPbEMsRUFBRSxDQUFDb0MsSUFBSCxDQUFRdkQsT0FBUixFQUFpQlEsRUFBakIsRUFBcUJxQixHQUFyQixFQUEwQnlCLFNBQTFCLEtBQXdDekIsR0FBL0M7QUFDRCxPQUxELE1BTUUsT0FBT0EsR0FBUDtBQUNIOztBQUFBO0FBRUQsUUFBSTJCLGNBQWMsR0FBRzNFLE1BQU0sQ0FBQzJFLGNBQVAsQ0FBc0I7QUFDekM1QixXQUFLLENBQUVwQixFQUFGLEVBQU1xQixHQUFOLEVBQVc7QUFDZEosV0FBRyxDQUFDRyxLQUFKLENBQVVsRCxVQUFWLEVBQXNCOEIsRUFBdEIsRUFBMEI0QyxhQUFhLENBQUM1QyxFQUFELEVBQUtxQixHQUFMLEVBQVUsT0FBVixDQUF2QztBQUNELE9BSHdDOztBQUl6Q0UsYUFBTyxDQUFFdkIsRUFBRixFQUFNcUIsR0FBTixFQUFXO0FBQ2hCSixXQUFHLENBQUNNLE9BQUosQ0FBWXJELFVBQVosRUFBd0I4QixFQUF4QixFQUE0QjRDLGFBQWEsQ0FBQzVDLEVBQUQsRUFBS3FCLEdBQUwsRUFBVSxTQUFWLENBQXpDO0FBQ0QsT0FOd0M7O0FBT3pDSSxhQUFPLENBQUV6QixFQUFGLEVBQU07QUFDWCxZQUFJbkIsU0FBSixFQUFlO0FBQ2JBLG1CQUFTLENBQUM0QyxPQUFWLENBQWtCekIsRUFBbEI7QUFDQWhDLGlCQUFPLENBQUNnQixNQUFSLENBQWVnQixFQUFmO0FBQ0Q7O0FBRURpQixXQUFHLENBQUNRLE9BQUosQ0FBWXZELFVBQVosRUFBd0I4QixFQUF4QjtBQUNEOztBQWR3QyxLQUF0QixDQUFyQjtBQWlCQSxXQUFPaEMsT0FBTyxDQUFDRCxHQUFSLENBQVlpRixjQUFaLENBQVA7QUFDRDs7QUFyRHdEOztBQXNEMUQsQzs7Ozs7Ozs7Ozs7QUN6REQsSUFBSTdDLGFBQUo7QUFBa0I5QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMyQyxpQkFBYSxHQUFDM0MsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBdkIsRUFBcUQsQ0FBckQ7QUFBd0RILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVo7QUFBc0JELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7QUFBeUJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaO0FBQW1DRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaO0FBQTBCRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaO0FBQXRMRCxNQUFNLENBQUNJLGFBQVAsQ0FPZTBDLGFBUGYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJdkMsQ0FBSjs7QUFBTVAsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ00sR0FBQyxDQUFDSixDQUFELEVBQUc7QUFBQ0ksS0FBQyxHQUFDSixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTJDLGFBQUo7QUFBa0I5QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMyQyxpQkFBYSxHQUFDM0MsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBdkIsRUFBcUQsQ0FBckQ7O0FBR3ZFMkMsYUFBYSxDQUFDVyxTQUFkLENBQXdCbUMsSUFBeEIsR0FBK0IsWUFBcUI7QUFBQSxvQ0FBUnZDLE1BQVE7QUFBUkEsVUFBUTtBQUFBOztBQUNsRCxTQUFPLElBQUl3QyxVQUFKLENBQWUsSUFBZixFQUFxQixHQUFHeEMsTUFBeEIsQ0FBUDtBQUNELENBRkQ7O0FBSUEsTUFBTXdDLFVBQU4sQ0FBaUI7QUFDZnJGLGFBQVcsQ0FBRTJCLE9BQUYsRUFBV3RCLFVBQVgsRUFBdUJJLE9BQXZCLEVBQWdDOEIsSUFBaEMsRUFBc0M7QUFDL0MsU0FBS1osT0FBTCxHQUFlQSxPQUFmO0FBQ0EsU0FBS3RCLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS0ksT0FBTCxHQUFlQSxPQUFmO0FBQ0EsU0FBSzhCLElBQUwsR0FBWUEsSUFBWjtBQUVBLFNBQUtYLElBQUwsR0FBWSxFQUFaO0FBQ0EsU0FBSzBELElBQUwsR0FBWSxLQUFaO0FBQ0Q7O0FBQ0RDLE1BQUksR0FBVztBQUNiLFFBQUk3QixPQUFKOztBQURhLHVDQUFOOEIsSUFBTTtBQUFOQSxVQUFNO0FBQUE7O0FBR2J6RixLQUFDLENBQUMwRixJQUFGLENBQU9ELElBQVAsRUFBYXBFLEdBQUcsSUFBSTtBQUNsQixVQUFJLENBQUNBLEdBQUQsSUFBUXJCLENBQUMsQ0FBQzJGLFFBQUYsQ0FBVyxLQUFLOUQsSUFBaEIsRUFBc0JSLEdBQXRCLENBQVosRUFDRTtBQUVGLFdBQUtRLElBQUwsQ0FBVTJELElBQVYsQ0FBZW5FLEdBQWY7QUFDQXNDLGFBQU8sR0FBRyxJQUFWO0FBQ0QsS0FORDs7QUFRQSxRQUFJLEtBQUs0QixJQUFMLElBQWE1QixPQUFqQixFQUNFLE9BQU8sS0FBS2lDLE9BQUwsRUFBUDtBQUNIOztBQUNEQyxNQUFJLEdBQUk7QUFDTixTQUFLTixJQUFMLEdBQVksSUFBWjtBQUNBLFFBQUksQ0FBQyxLQUFLMUQsSUFBTCxDQUFVeUMsTUFBZixFQUF1QjtBQUV2QixXQUFPLEtBQUtzQixPQUFMLEVBQVA7QUFDRDs7QUFDREUsV0FBUyxHQUFJO0FBQ1gsUUFBSXpFLEdBQUcsR0FBRztBQUFDMEUsU0FBRyxFQUFFLEtBQUtsRTtBQUFYLEtBQVY7QUFDQSxXQUFPN0IsQ0FBQyxDQUFDZ0csVUFBRixDQUFhLEtBQUtqRixRQUFsQixJQUE4QixLQUFLQSxRQUFMLENBQWNNLEdBQWQsQ0FBOUIsR0FBa0Q7QUFBQ0EsU0FBRyxFQUFFQTtBQUFOLEtBQXpEO0FBQ0Q7O0FBQ0R1RSxTQUFPLEdBQUk7QUFDVCxXQUFPLEtBQUtoRSxPQUFMLENBQWFuQixNQUFiLENBQW9CLEtBQUtILFVBQUwsQ0FBZ0IyRixJQUFoQixDQUFxQixLQUFLSCxTQUFMLEVBQXJCLEVBQXVDLEtBQUtwRixPQUE1QyxDQUFwQixFQUEwRSxLQUFLOEIsSUFBL0UsQ0FBUDtBQUNEOztBQXBDYzs7QUFxQ2hCLEM7Ozs7Ozs7Ozs7O0FDNUNELElBQUlELGFBQUo7QUFBa0I5QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMyQyxpQkFBYSxHQUFDM0MsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBdkIsRUFBcUQsQ0FBckQ7O0FBRWxCMkMsYUFBYSxDQUFDVyxTQUFkLENBQXdCZ0QsT0FBeEIsR0FBa0MsVUFBVXpGLE1BQVYsRUFBa0JRLFNBQWxCLEVBQTZCO0FBQzdELE9BQUtiLE9BQUwsQ0FBYUksR0FBYixDQUFpQkMsTUFBakIsRUFBeUI7QUFDdkJMLFdBQU8sRUFBRSxTQURjO0FBRXZCYSxhQUFTLEVBQUVBO0FBRlksR0FBekI7QUFJRCxDQUxEOztBQU9Bc0IsYUFBYSxDQUFDVyxTQUFkLENBQXdCa0MsY0FBeEIsR0FBeUMsVUFBVTNFLE1BQVYsRUFBa0JRLFNBQWxCLEVBQTZCO0FBQ3BFLE9BQUtiLE9BQUwsQ0FBYUksR0FBYixDQUFpQkMsTUFBakIsRUFBeUI7QUFDdkJMLFdBQU8sRUFBRSxnQkFEYztBQUV2QmEsYUFBUyxFQUFFQTtBQUZZLEdBQXpCO0FBSUQsQ0FMRCxDOzs7Ozs7Ozs7OztBQ1RBLElBQUlqQixDQUFKOztBQUFNUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDTSxHQUFDLENBQUNKLENBQUQsRUFBRztBQUFDSSxLQUFDLEdBQUNKLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJMkMsYUFBSjtBQUFrQjlDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQzJDLGlCQUFhLEdBQUMzQyxDQUFkO0FBQWdCOztBQUE1QixDQUF2QixFQUFxRCxDQUFyRDs7QUFHdkUsU0FBU3VHLEtBQVQsQ0FBZ0JwRCxFQUFoQixFQUFvQmtDLE1BQXBCLEVBQTRCO0FBQzFCLE1BQUl4QyxRQUFRLEdBQUdNLEVBQUUsQ0FBQ2tDLE1BQUQsQ0FBakI7QUFDQSxNQUFJeEMsUUFBUSxJQUFJLENBQUN6QyxDQUFDLENBQUNnRyxVQUFGLENBQWF2RCxRQUFiLENBQWpCLEVBQ0UsTUFBTSxJQUFJOUIsS0FBSixDQUFVc0UsTUFBTSxHQUFHLG9DQUFuQixDQUFOO0FBRUYsU0FBT3hDLFFBQVEsSUFBSSxZQUFZLENBQUUsQ0FBakM7QUFDRDs7QUFBQTs7QUFFREYsYUFBYSxDQUFDVyxTQUFkLENBQXdCSyxhQUF4QixHQUF3QyxVQUFVUixFQUFWLEVBQWNLLFNBQWQsRUFBeUI7QUFDL0QsTUFBSXBELENBQUMsQ0FBQ2dHLFVBQUYsQ0FBYWpELEVBQWIsQ0FBSixFQUFzQjtBQUNwQixXQUFPO0FBQ0xTLFdBQUssRUFBRVQsRUFERjtBQUVMWSxhQUFPLEVBQUVaLEVBRko7QUFHTGMsYUFBTyxFQUFFc0MsS0FBSyxDQUFDO0FBQUMvQyxpQkFBUyxFQUFFQTtBQUFaLE9BQUQsRUFBeUIsV0FBekI7QUFIVCxLQUFQO0FBS0Q7O0FBRUQsU0FBTztBQUNMSSxTQUFLLEVBQUUyQyxLQUFLLENBQUNwRCxFQUFELEVBQUssT0FBTCxDQURQO0FBRUxZLFdBQU8sRUFBRXdDLEtBQUssQ0FBQ3BELEVBQUQsRUFBSyxTQUFMLENBRlQ7QUFHTGMsV0FBTyxFQUFFc0MsS0FBSyxDQUFDcEQsRUFBRCxFQUFLLFNBQUw7QUFIVCxHQUFQO0FBS0QsQ0FkRCxDOzs7Ozs7Ozs7OztBQ1hBdEQsTUFBTSxDQUFDSyxNQUFQLENBQWM7QUFBQ0gsU0FBTyxFQUFDLE1BQUlrRjtBQUFiLENBQWQ7O0FBQTZDLElBQUk3RSxDQUFKOztBQUFNUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDTSxHQUFDLENBQUNKLENBQUQsRUFBRztBQUFDSSxLQUFDLEdBQUNKLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1Qzs7QUFFcEMsTUFBTWlGLGVBQU4sQ0FBc0I7QUFDbkM1RSxhQUFXLENBQUVvRCxHQUFGLEVBQU87QUFDaEIsU0FBS0EsR0FBTCxHQUFXQSxHQUFYO0FBQ0Q7O0FBQ0QrQyxtQkFBaUIsQ0FBRTNGLE1BQUYsRUFBVUgsVUFBVixFQUFzQitGLE9BQXRCLEVBQStCO0FBQzlDLFVBQU1oRCxHQUFHLEdBQUcsS0FBS0EsR0FBakI7O0FBRUEsUUFBSSxDQUFDckQsQ0FBQyxDQUFDOEUsUUFBRixDQUFXeEUsVUFBWCxDQUFMLEVBQTZCO0FBQzNCK0YsYUFBTyxHQUFHL0YsVUFBVjtBQUNBQSxnQkFBVSxHQUFHRyxNQUFNLENBQUNzRSxrQkFBUCxFQUFiO0FBQ0Q7O0FBQ0QsUUFBSSxDQUFDL0UsQ0FBQyxDQUFDZ0csVUFBRixDQUFhSyxPQUFiLENBQUwsRUFDRUEsT0FBTyxHQUFHLFlBQVksQ0FBRSxDQUF4QjtBQUVGNUYsVUFBTSxDQUFDNkYsT0FBUCxDQUFnQjdDLEdBQUQsSUFBUztBQUN0QixVQUFJcEMsR0FBRyxHQUFHb0MsR0FBRyxDQUFDcEMsR0FBZDtBQUNBZ0MsU0FBRyxDQUFDRyxLQUFKLENBQVVsRCxVQUFWLEVBQXNCZSxHQUF0QixFQUEyQmdGLE9BQU8sQ0FBQ2xCLElBQVIsQ0FBYSxJQUFJTixlQUFKLENBQW9CeEIsR0FBcEIsQ0FBYixFQUF1Q2hDLEdBQXZDLEVBQTRDb0MsR0FBNUMsS0FBb0RBLEdBQS9FO0FBQ0QsS0FIRDtBQUlEOztBQWxCa0M7O0FBbUJwQyxDOzs7Ozs7Ozs7OztBQ3JCRCxJQUFJb0IsZUFBSjtBQUFvQnBGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2lGLG1CQUFlLEdBQUNqRixDQUFoQjtBQUFrQjs7QUFBOUIsQ0FBdkIsRUFBdUQsQ0FBdkQ7QUFBMERILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVo7QUFBOUVELE1BQU0sQ0FBQ0ksYUFBUCxDQUdlZ0YsZUFIZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUk3RSxDQUFKOztBQUFNUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDTSxHQUFDLENBQUNKLENBQUQsRUFBRztBQUFDSSxLQUFDLEdBQUNKLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJaUYsZUFBSjtBQUFvQnBGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2lGLG1CQUFlLEdBQUNqRixDQUFoQjtBQUFrQjs7QUFBOUIsQ0FBdkIsRUFBdUQsQ0FBdkQ7O0FBR3pFaUYsZUFBZSxDQUFDM0IsU0FBaEIsQ0FBMEJxRCxlQUExQixHQUE0QyxZQUFxQjtBQUFBLG9DQUFSekQsTUFBUTtBQUFSQSxVQUFRO0FBQUE7O0FBQy9ELFNBQU8sSUFBSTBELHFCQUFKLENBQTBCLEtBQUtuRCxHQUEvQixFQUFvQyxHQUFHUCxNQUF2QyxDQUFQO0FBQ0QsQ0FGRDs7QUFJQSxNQUFNMEQscUJBQU4sQ0FBNEI7QUFDMUJ2RyxhQUFXLENBQUVvRCxHQUFGLEVBQU8vQyxVQUFQLEVBQW1CSSxPQUFuQixFQUE0QjhCLElBQTVCLEVBQWtDO0FBQzNDLFNBQUthLEdBQUwsR0FBV0EsR0FBWDtBQUNBLFNBQUsvQyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLFNBQUtJLE9BQUwsR0FBZUEsT0FBZjtBQUNBLFNBQUs4QixJQUFMLEdBQVlBLElBQUksSUFBSWxDLFVBQVUsQ0FBQ21HLEtBQS9CO0FBRUEsU0FBSzVFLElBQUwsR0FBWSxFQUFaO0FBQ0EsU0FBSzBELElBQUwsR0FBWSxLQUFaO0FBQ0Q7O0FBQ0RPLFdBQVMsR0FBMEI7QUFBQSxRQUF4QnpFLEdBQXdCLHVFQUFsQjtBQUFDMEUsU0FBRyxFQUFFLEtBQUtsRTtBQUFYLEtBQWtCOztBQUNqQyxXQUFPN0IsQ0FBQyxDQUFDZ0csVUFBRixDQUFhLEtBQUtqRixRQUFsQixJQUE4QixLQUFLQSxRQUFMLENBQWNNLEdBQWQsQ0FBOUIsR0FBa0Q7QUFBQ0EsU0FBRyxFQUFFQTtBQUFOLEtBQXpEO0FBQ0Q7O0FBQ0RtRSxNQUFJLEdBQVc7QUFDYixRQUFJa0IsTUFBTSxHQUFHLEVBQWI7O0FBRGEsdUNBQU5qQixJQUFNO0FBQU5BLFVBQU07QUFBQTs7QUFHYnpGLEtBQUMsQ0FBQzBGLElBQUYsQ0FBT0QsSUFBUCxFQUFhcEUsR0FBRyxJQUFJO0FBQ2xCLFVBQUksQ0FBQ0EsR0FBRCxJQUFRckIsQ0FBQyxDQUFDMkYsUUFBRixDQUFXLEtBQUs5RCxJQUFoQixFQUFzQlIsR0FBdEIsQ0FBWixFQUNFO0FBRUYsV0FBS1EsSUFBTCxDQUFVMkQsSUFBVixDQUFlbkUsR0FBZjtBQUNBcUYsWUFBTSxDQUFDbEIsSUFBUCxDQUFZbkUsR0FBWjtBQUNELEtBTkQ7O0FBUUEsUUFBSSxLQUFLa0UsSUFBTCxJQUFhbUIsTUFBTSxDQUFDcEMsTUFBeEIsRUFDRSxPQUFPLEtBQUtkLEtBQUwsQ0FBV2tELE1BQU0sQ0FBQ3BDLE1BQVAsR0FBZ0IsQ0FBaEIsR0FBb0I7QUFBQ3lCLFNBQUcsRUFBRVc7QUFBTixLQUFwQixHQUFtQ0EsTUFBTSxDQUFDLENBQUQsQ0FBcEQsQ0FBUDtBQUNIOztBQUNEYixNQUFJLEdBQUk7QUFDTixTQUFLTixJQUFMLEdBQVksSUFBWjtBQUNBLFFBQUksQ0FBQyxLQUFLMUQsSUFBTCxDQUFVeUMsTUFBZixFQUF1QjtBQUV2QixXQUFPLEtBQUtkLEtBQUwsRUFBUDtBQUNEOztBQUNEQSxPQUFLLENBQUVuQyxHQUFGLEVBQU87QUFDVixTQUFLZixVQUFMLENBQWdCMkYsSUFBaEIsQ0FBcUIsS0FBS0gsU0FBTCxDQUFlekUsR0FBZixDQUFyQixFQUEwQyxLQUFLWCxPQUEvQyxFQUF3RDRGLE9BQXhELENBQWdFN0MsR0FBRyxJQUFJO0FBQ3JFLFdBQUtKLEdBQUwsQ0FBU0csS0FBVCxDQUFlLEtBQUtoQixJQUFwQixFQUEwQmlCLEdBQUcsQ0FBQ3BDLEdBQTlCLEVBQW1DckIsQ0FBQyxDQUFDNEUsSUFBRixDQUFPbkIsR0FBUCxFQUFZLEtBQVosQ0FBbkM7QUFDRCxLQUZEO0FBR0Q7O0FBckN5Qjs7QUFzQzNCLEMiLCJmaWxlIjoiL3BhY2thZ2VzL2NvdHR6X3B1Ymxpc2gtcmVsYXRpb25zLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFB1Ymxpc2hSZWxhdGlvbnMgZnJvbSAnLi9wdWJsaXNoX3JlbGF0aW9ucyc7XG5pbXBvcnQgJy4vbWV0aG9kcyc7XG5cbmV4cG9ydCBkZWZhdWx0IFB1Ymxpc2hSZWxhdGlvbnM7IiwiaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJztcbi8vIFRoZSBhaW0gb2YgaGFuZGxlciBDb250cm9sbGVyIGlzIHRvIGtlZXAgYWxsIG9ic2VydmVycyB0aGF0IGNhbiBiZSBjcmVhdGVkIHdpdGhpbiBtZXRob2RzXG4vLyBpdHMgc3RydWN0dXJlIGlzIHZlcnkgc2ltcGxlLCBoYXMgYSAnaGFuZGxlcnMnIG9iamVjdCBjb250YWluaW5nIGFsbCBvYnNlcnZlcnMgY2hpbGRyZW4gYW5kXG4vLyB0aGUgb2JzZXJ2ZXIgZmF0aGVyIGlzIHN0b3JlZCB3aXRoaW4gJ2hhbmRsZXInXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBIYW5kbGVyQ29udHJvbGxlciB7XG4gIGNvbnN0cnVjdG9yICgpIHtcbiAgICB0aGlzLmhhbmRsZXJzID0ge307XG4gIH1cbiAgc2V0IChoYW5kbGVyKSB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlciA9IGhhbmRsZXI7XG4gIH1cbiAgYWRkQmFzaWMgKGNvbGxlY3Rpb24sIGhhbmRsZXIpIHtcbiAgICBjb25zdCBvbGRIYW5kbGVyID0gdGhpcy5oYW5kbGVyc1tjb2xsZWN0aW9uXTtcbiAgICByZXR1cm4gb2xkSGFuZGxlciB8fCAodGhpcy5oYW5kbGVyc1tjb2xsZWN0aW9uXSA9IGhhbmRsZXIgfHwgbmV3IEhhbmRsZXJDb250cm9sbGVyKCkpO1xuICB9XG4gIGFkZCAoY3Vyc29yLCBvcHRpb25zKSB7XG4gICAgaWYgKCFjdXJzb3IpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJ5b3UncmUgbm90IHNlbmRpbmcgdGhlIGN1cnNvclwiKTtcblxuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gY3Vyc29yLl9jdXJzb3JEZXNjcmlwdGlvbjtcbiAgICBjb25zdCBjb2xsZWN0aW9uID0gb3B0aW9ucy5jb2xsZWN0aW9uIHx8IGRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lO1xuICAgIGNvbnN0IHNlbGVjdG9yID0gZGVzY3JpcHRpb24uc2VsZWN0b3I7XG4gICAgLypcbiAgICAgIHRoZSBzZWxlY3RvciB1c2VzIHJlZmVyZW5jZXMsIGluIGNhc2VzIHRoYXQgYSBzZWxlY3RvciBoYXMgb2JqZWN0cyBpbnNpZGVcbiAgICAgIHRoaXMgdmFsaWRhdGlvbiBpc24ndCBnb25uYSB3b3JrXG5cbiAgICBsZXQgb2xkSGFuZGxlciA9IHRoaXMuaGFuZGxlcnNbY29sbGVjdGlvbl07XG4gICAgaWYgKG9sZEhhbmRsZXIpIHtcbiAgICAgIC8vIHdoZW4gdGhlIHNlbGVjdG9yIGVxdWFscyBtZXRob2Qgc3RvcHMgcnVubmluZywgbm8gY2hhbmdlIG9jY3VycyBhbmQgZXZlcnl0aGluZ1xuICAgICAgLy8gd2lsbCBzdGlsbCB3b3JrIHByb3Blcmx5IHdpdGhvdXQgcnVubmluZyB0aGUgc2FtZSBvYnNlcnZlciBhZ2FpblxuICAgICAgb2xkSGFuZGxlci5lcXVhbFNlbGVjdG9yID0gXy5pc0VxdWFsKG9sZEhhbmRsZXIuc2VsZWN0b3IsIHNlbGVjdG9yKTtcbiAgICAgIGlmIChvbGRIYW5kbGVyLmVxdWFsU2VsZWN0b3IpXG4gICAgICAgIHJldHVybiBvbGRIYW5kbGVyO1xuXG4gICAgICBvbGRIYW5kbGVyLnN0b3AoKTtcbiAgICB9Ki9cblxuICAgIGNvbnN0IG5ld0hhbmRsZXIgPSBvcHRpb25zLmhhbmRsZXJcbiAgICA/IGN1cnNvcltvcHRpb25zLmhhbmRsZXJdKG9wdGlvbnMuY2FsbGJhY2tzKVxuICAgIDogbmV3IEhhbmRsZXJDb250cm9sbGVyKCk7XG5cbiAgICBuZXdIYW5kbGVyLnNlbGVjdG9yID0gc2VsZWN0b3I7XG5cbiAgICByZXR1cm4gdGhpcy5oYW5kbGVyc1tjb2xsZWN0aW9uXSA9IG5ld0hhbmRsZXI7XG4gIH1cbiAgc3RvcCAoKSB7XG4gICAgbGV0IGhhbmRsZXJzID0gdGhpcy5oYW5kbGVycztcblxuICAgIHRoaXMuaGFuZGxlciAmJiB0aGlzLmhhbmRsZXIuc3RvcCgpO1xuXG4gICAgZm9yIChsZXQga2V5IGluIGhhbmRsZXJzKSB7XG4gICAgICBoYW5kbGVyc1trZXldLnN0b3AoKTtcbiAgICB9O1xuXG4gICAgdGhpcy5oYW5kbGVycyA9IFtdO1xuICB9XG4gIHJlbW92ZSAoX2lkKSB7XG4gICAgbGV0IGhhbmRsZXIgPSB0aGlzLmhhbmRsZXJzW19pZF07XG4gICAgaWYgKGhhbmRsZXIpIHtcbiAgICAgIGhhbmRsZXIuc3RvcCgpO1xuICAgICAgZGVsZXRlIHRoaXMuaGFuZGxlcnNbX2lkXTtcbiAgICB9XG4gIH1cbn0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrLCBNYXRjaCB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBERFBTZXJ2ZXIgfSBmcm9tICdtZXRlb3IvZGRwLXNlcnZlcic7XG5cbmNvbnN0IGNyb3NzYmFyID0gRERQU2VydmVyLl9JbnZhbGlkYXRpb25Dcm9zc2JhcjtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnUFIuY2hhbmdlUGFnaW5hdGlvbicgKGRhdGEpIHtcbiAgICBjaGVjayhkYXRhLCB7XG4gICAgICBfaWQ6IFN0cmluZyxcbiAgICAgIGZpZWxkOiBTdHJpbmcsXG4gICAgICBza2lwOiBNYXRjaC5JbnRlZ2VyXG4gICAgfSk7XG5cbiAgICBjcm9zc2Jhci5maXJlKF8uZXh0ZW5kKHtcbiAgICAgIGNvbGxlY3Rpb246ICdwYWdpbmF0aW9ucycsXG4gICAgICBpZDogdGhpcy5jb25uZWN0aW9uLmlkXG4gICAgfSwgZGF0YSkpO1xuICB9LFxuICAnUFIuZmlyZUxpc3RlbmVyJyAoY29sbGVjdGlvbiwgb3B0aW9ucykge1xuICAgIGNoZWNrKGNvbGxlY3Rpb24sIFN0cmluZyk7XG4gICAgY2hlY2sob3B0aW9ucywgT2JqZWN0KTtcblxuICAgIGNyb3NzYmFyLmZpcmUoXy5leHRlbmQoe1xuICAgICAgY29sbGVjdGlvbjogJ2xpc3Rlbi0nICsgY29sbGVjdGlvbixcbiAgICAgIGlkOiB0aGlzLmNvbm5lY3Rpb24uaWQsXG4gICAgfSwgb3B0aW9ucykpO1xuICB9XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBIYW5kbGVyQ29udHJvbGxlciBmcm9tICcuL2hhbmRsZXJfY29udHJvbGxlcic7XG5pbXBvcnQgQ3Vyc29yTWV0aG9kcyBmcm9tICcuL2N1cnNvcic7XG5cblB1Ymxpc2hSZWxhdGlvbnMgPSBmdW5jdGlvbiAobmFtZSwgY2FsbGJhY2spIHtcbiAgcmV0dXJuIE1ldGVvci5wdWJsaXNoKG5hbWUsIGZ1bmN0aW9uICguLi5wYXJhbXMpIHtcbiAgICBsZXQgaGFuZGxlciA9IG5ldyBIYW5kbGVyQ29udHJvbGxlcigpLFxuICAgIGN1cnNvcnMgPSBuZXcgQ3Vyc29yTWV0aG9kcyh0aGlzLCBoYW5kbGVyKTtcblxuICAgIHRoaXMuX3B1YmxpY2F0aW9uTmFtZSA9IG5hbWU7XG4gICAgdGhpcy5vblN0b3AoKCkgPT4gaGFuZGxlci5zdG9wKCkpO1xuXG4gICAgbGV0IGNiID0gY2FsbGJhY2suYXBwbHkoXy5leHRlbmQoY3Vyc29ycywgdGhpcyksIHBhcmFtcyk7XG4gICAgLy8ga2FkaXJhIHNob3cgbWUgYWxlcnRzIHdoZW4gSSB1c2UgdGhpcyByZXR1cm4gKGJ1dCB3b3JrcyB3ZWxsKVxuICAgIC8vIHJldHVybiBjYiB8fCAoIXRoaXMuX3JlYWR5ICYmIHRoaXMucmVhZHkoKSk7XG4gICAgcmV0dXJuIGNiO1xuICB9KTtcbn07XG5cbk1ldGVvci5wdWJsaXNoUmVsYXRpb25zID0gUHVibGlzaFJlbGF0aW9ucztcblxuZXhwb3J0IGRlZmF1bHQgUHVibGlzaFJlbGF0aW9ucztcbmV4cG9ydCB7IFB1Ymxpc2hSZWxhdGlvbnMgfTsiLCJpbXBvcnQgQ3Vyc29yTWV0aG9kcyBmcm9tICcuL2N1cnNvcic7XG4vLyBERVBSRUNBVEVEXG4vLyBkZXNpZ25lZCB0byBjaGFuZ2Ugc29tZXRoaW5nIGluIHRoZSBtYXN0ZXIgZG9jdW1lbnQgd2hpbGUgdGhlIGNhbGxiYWNrcyBhcmUgZXhlY3V0ZWRcbi8vIGNoYW5nZXMgdG8gdGhlIGRvY3VtZW50IGFyZSBzZW50IHRvIHRoZSBtYWluIGRvY3VtZW50IHdpdGggdGhlIHJldHVybiBvZiB0aGUgY2FsbGJhY2tzXG5DdXJzb3JNZXRob2RzLnByb3RvdHlwZS5jaGFuZ2VQYXJlbnREb2MgPSBmdW5jdGlvbiAoY3Vyc29yLCBjYWxsYmFja3MsIG9uUmVtb3ZlZCkge1xuICBjb25zdCBzdWIgPSB0aGlzLnN1YjtcbiAgY29uc3QgX2lkID0gdGhpcy5faWQ7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSB0aGlzLmNvbGxlY3Rpb247XG5cbiAgbGV0IHJlc3VsdCA9IHRoaXM7XG5cbiAgaWYgKCFfaWQgfHwgIWNvbGxlY3Rpb24pXG4gICAgdGhyb3cgbmV3IEVycm9yKFwieW91IGNhbid0IHVzZSB0aGlzIG1ldGhvZCB3aXRob3V0IGJlaW5nIHdpdGhpbiBhIGRvY3VtZW50XCIpO1xuXG4gIGNhbGxiYWNrcyA9IHRoaXMuX2dldENhbGxiYWNrcyhjYWxsYmFja3MsIG9uUmVtb3ZlZCk7XG5cbiAgdGhpcy5oYW5kbGVyLmFkZChjdXJzb3IsIHtcbiAgICBoYW5kbGVyOiAnb2JzZXJ2ZUNoYW5nZXMnLFxuICAgIGNhbGxiYWNrczoge1xuICAgICAgYWRkZWQgKGlkLCBkb2MpIHtcbiAgICAgICAgcmVzdWx0Ll9hZGRlZFdpdGhDUEQgPSBjYWxsYmFja3MuYWRkZWQoaWQsIGRvYyk7XG4gICAgICB9LFxuICAgICAgY2hhbmdlZCAoaWQsIGRvYykge1xuICAgICAgICB2YXIgY2hhbmdlcyA9IGNhbGxiYWNrcy5jaGFuZ2VkKGlkLCBkb2MpO1xuICAgICAgICBpZiAoY2hhbmdlcylcbiAgICAgICAgICBzdWIuY2hhbmdlZChjb2xsZWN0aW9uLCBfaWQsIGNoYW5nZXMpO1xuICAgICAgfSxcbiAgICAgIHJlbW92ZWQgKGlkKSB7XG4gICAgICAgIHZhciBjaGFuZ2VzID0gY2FsbGJhY2tzLnJlbW92ZWQoaWQpO1xuICAgICAgICBpZiAoY2hhbmdlcylcbiAgICAgICAgICBzdWIuY2hhbmdlZChjb2xsZWN0aW9uLCBfaWQsIGNoYW5nZXMpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIHJlc3VsdC5fYWRkZWRXaXRoQ1BEIHx8IHt9O1xufTsiLCJpbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnO1xuaW1wb3J0IEN1cnNvck1ldGhvZHMgZnJvbSAnLi9jdXJzb3InO1xuaW1wb3J0IHsgRERQU2VydmVyIH0gZnJvbSAnbWV0ZW9yL2RkcC1zZXJ2ZXInO1xuXG5jb25zdCBjcm9zc2JhciA9IEREUFNlcnZlci5fSW52YWxpZGF0aW9uQ3Jvc3NiYXI7XG4vLyBkZXNpZ25lZCB0byBwYWdpbmF0ZSBhIGxpc3QsIHdvcmtzIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIG1ldGhvZHNcbi8vIGRvIG5vdCBjYWxsIGJhY2sgdG8gdGhlIG1haW4gY2FsbGJhY2ssIG9ubHkgdGhlIGFycmF5IGlzIGNoYW5nZWQgaW4gdGhlIGNvbGxlY3Rpb25cbkN1cnNvck1ldGhvZHMucHJvdG90eXBlLnBhZ2luYXRlID0gZnVuY3Rpb24gKGZpZWxkRGF0YSwgbGltaXQsIGluZmluaXRlKSB7XG4gIGNvbnN0IHN1YiA9IHRoaXMuc3ViO1xuICBjb25zdCBjb2xsZWN0aW9uID0gdGhpcy5jb2xsZWN0aW9uO1xuXG4gIGlmICghdGhpcy5faWQgfHwgIWNvbGxlY3Rpb24pXG4gICAgdGhyb3cgbmV3IEVycm9yKFwieW91IGNhbid0IHVzZSB0aGlzIG1ldGhvZCB3aXRob3V0IGJlaW5nIHdpdGhpbiBhIGRvY3VtZW50XCIpO1xuXG4gIGNvbnN0IGZpZWxkID0gT2JqZWN0LmtleXMoZmllbGREYXRhKVswXTtcbiAgY29uc3QgY29weSA9IF8uY2xvbmUoZmllbGREYXRhKVtmaWVsZF07XG4gIGNvbnN0IG1heCA9IGNvcHkubGVuZ3RoO1xuICBjb25zdCBjb25uZWN0aW9uSWQgPSBzdWIuY29ubmVjdGlvbi5pZDtcblxuICBmaWVsZERhdGFbZmllbGRdID0gY29weS5zbGljZSgwLCBsaW1pdCk7XG5cbiAgY29uc3QgbGlzdGVuZXIgPSBjcm9zc2Jhci5saXN0ZW4oe1xuICAgIGNvbGxlY3Rpb246ICdwYWdpbmF0aW9ucycsXG4gICAgaWQ6IGNvbm5lY3Rpb25JZCxcbiAgfSwgKGRhdGEpID0+IHtcbiAgICBpZiAoIWRhdGEuaWQgfHwgZGF0YS5pZCAhPT0gY29ubmVjdGlvbklkKSByZXR1cm47XG5cbiAgICBsZXQgc2tpcCA9IGRhdGEuc2tpcDtcblxuICAgIGlmIChza2lwID49IG1heCAmJiAhaW5maW5pdGUpXG4gICAgICByZXR1cm47XG5cbiAgICBmaWVsZERhdGFbZmllbGRdID0gaW5maW5pdGUgPyBjb3B5LnNsaWNlKDAsIHNraXApOiBjb3B5LnNsaWNlKHNraXAsIHNraXAgKyBsaW1pdCk7XG4gICAgc3ViLmNoYW5nZWQoY29sbGVjdGlvbiwgZGF0YS5faWQsIGZpZWxkRGF0YSk7XG4gIH0pO1xuXG4gIHRoaXMuaGFuZGxlci5hZGRCYXNpYyhmaWVsZCwgbGlzdGVuZXIpO1xuXG4gIHJldHVybiBmaWVsZERhdGFbZmllbGRdO1xufTtcblxuQ3Vyc29yTWV0aG9kcy5wcm90b3R5cGUubGlzdGVuID0gZnVuY3Rpb24gKG9wdGlvbnMsIGNhbGxiYWNrLCBydW4pIHtcbiAgY29uc3Qgc3ViID0gdGhpcy5zdWI7XG4gIGNvbnN0IG5hbWUgPSAnbGlzdGVuLScgKyB0aGlzLl9wdWJsaWNhdGlvbk5hbWU7XG5cbiAgY29uc3QgbGlzdGVuZXIgPSBjcm9zc2Jhci5saXN0ZW4oe1xuICAgIGNvbGxlY3Rpb246IG5hbWUsXG4gICAgaWQ6IHN1Yi5jb25uZWN0aW9uLmlkXG4gIH0sIChkYXRhKSA9PiB7XG4gICAgaWYgKCFkYXRhLmlkIHx8IGRhdGEuaWQgIT09IHN1Yi5jb25uZWN0aW9uLmlkKSByZXR1cm47XG5cbiAgICBfLmV4dGVuZChvcHRpb25zLCBfLm9taXQoZGF0YSwgJ2NvbGxlY3Rpb24nLCAnaWQnKSk7XG4gICAgY2FsbGJhY2soZmFsc2UpO1xuICB9KTtcblxuICBjb25zdCBoYW5kbGVyID0gdGhpcy5oYW5kbGVyLmFkZEJhc2ljKG5hbWUpO1xuXG4gIGlmIChydW4gIT09IGZhbHNlKSBjYWxsYmFjayh0cnVlKTtcblxuICByZXR1cm4gaGFuZGxlci5zZXQobGlzdGVuZXIpO1xufTsiLCJpbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnO1xuaW1wb3J0IEN1cnNvck1ldGhvZHNOUiBmcm9tICcuL25vbnJlYWN0aXZlJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3Vyc29yTWV0aG9kcyBleHRlbmRzIEN1cnNvck1ldGhvZHNOUiB7XG4gIGNvbnN0cnVjdG9yIChzdWIsIGhhbmRsZXIsIF9pZCwgY29sbGVjdGlvbikge1xuICAgIHN1cGVyKHN1Yik7XG5cbiAgICB0aGlzLmhhbmRsZXIgPSBoYW5kbGVyO1xuICAgIHRoaXMuX2lkID0gX2lkO1xuICAgIHRoaXMuY29sbGVjdGlvbiA9IGNvbGxlY3Rpb247XG4gIH1cbiAgY3Vyc29yIChjdXJzb3IsIGNvbGxlY3Rpb24sIGNhbGxiYWNrcykge1xuICAgIGNvbnN0IHN1YiA9IHRoaXMuc3ViO1xuXG4gICAgaWYgKCFfLmlzU3RyaW5nKGNvbGxlY3Rpb24pKSB7XG4gICAgICBjYWxsYmFja3MgPSBjb2xsZWN0aW9uO1xuICAgICAgY29sbGVjdGlvbiA9IGN1cnNvci5fZ2V0Q29sbGVjdGlvbk5hbWUoKTtcbiAgICB9XG5cbiAgICBjb25zdCBoYW5kbGVyID0gdGhpcy5oYW5kbGVyLmFkZChjdXJzb3IsIHtjb2xsZWN0aW9uOiBjb2xsZWN0aW9ufSk7XG4gICAgLy8gaWYgKGhhbmRsZXIuZXF1YWxTZWxlY3RvcilcbiAgICAvLyAgIHJldHVybiBoYW5kbGVyO1xuXG4gICAgaWYgKGNhbGxiYWNrcylcbiAgICAgIGNhbGxiYWNrcyA9IHRoaXMuX2dldENhbGxiYWNrcyhjYWxsYmFja3MpO1xuXG4gICAgZnVuY3Rpb24gYXBwbHlDYWxsYmFjayAoaWQsIGRvYywgbWV0aG9kKSB7XG4gICAgICBjb25zdCBjYiA9IGNhbGxiYWNrcyAmJiBjYWxsYmFja3NbbWV0aG9kXTtcblxuICAgICAgaWYgKGNiKSB7XG4gICAgICAgIGxldCBtZXRob2RzID0gbmV3IEN1cnNvck1ldGhvZHMoc3ViLCBoYW5kbGVyLmFkZEJhc2ljKGlkKSwgaWQsIGNvbGxlY3Rpb24pLFxuICAgICAgICBpc0NoYW5nZWQgPSBtZXRob2QgPT09ICdjaGFuZ2VkJztcblxuICAgICAgICByZXR1cm4gY2IuY2FsbChtZXRob2RzLCBpZCwgZG9jLCBpc0NoYW5nZWQpIHx8IGRvYztcbiAgICAgIH0gZWxzZVxuICAgICAgICByZXR1cm4gZG9jO1xuICAgIH07XG5cbiAgICBsZXQgb2JzZXJ2ZUNoYW5nZXMgPSBjdXJzb3Iub2JzZXJ2ZUNoYW5nZXMoe1xuICAgICAgYWRkZWQgKGlkLCBkb2MpIHtcbiAgICAgICAgc3ViLmFkZGVkKGNvbGxlY3Rpb24sIGlkLCBhcHBseUNhbGxiYWNrKGlkLCBkb2MsICdhZGRlZCcpKTtcbiAgICAgIH0sXG4gICAgICBjaGFuZ2VkIChpZCwgZG9jKSB7XG4gICAgICAgIHN1Yi5jaGFuZ2VkKGNvbGxlY3Rpb24sIGlkLCBhcHBseUNhbGxiYWNrKGlkLCBkb2MsICdjaGFuZ2VkJykpO1xuICAgICAgfSxcbiAgICAgIHJlbW92ZWQgKGlkKSB7XG4gICAgICAgIGlmIChjYWxsYmFja3MpIHtcbiAgICAgICAgICBjYWxsYmFja3MucmVtb3ZlZChpZCk7XG4gICAgICAgICAgaGFuZGxlci5yZW1vdmUoaWQpO1xuICAgICAgICB9XG5cbiAgICAgICAgc3ViLnJlbW92ZWQoY29sbGVjdGlvbiwgaWQpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGhhbmRsZXIuc2V0KG9ic2VydmVDaGFuZ2VzKTtcbiAgfVxufTsiLCJpbXBvcnQgQ3Vyc29yTWV0aG9kcyBmcm9tICcuL2N1cnNvcic7XG5pbXBvcnQgJy4vam9pbic7XG5pbXBvcnQgJy4vb2JzZXJ2ZSc7XG5pbXBvcnQgJy4vY2hhbmdlX3BhcmVudF9kb2MnO1xuaW1wb3J0ICcuL2Nyb3NzYmFyJztcbmltcG9ydCAnLi91dGlscyc7XG5cbmV4cG9ydCBkZWZhdWx0IEN1cnNvck1ldGhvZHM7IiwiaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJztcbmltcG9ydCBDdXJzb3JNZXRob2RzIGZyb20gJy4vY3Vyc29yJztcblxuQ3Vyc29yTWV0aG9kcy5wcm90b3R5cGUuam9pbiA9IGZ1bmN0aW9uICguLi5wYXJhbXMpIHtcbiAgcmV0dXJuIG5ldyBDdXJzb3JKb2luKHRoaXMsIC4uLnBhcmFtcyk7XG59O1xuXG5jbGFzcyBDdXJzb3JKb2luIHtcbiAgY29uc3RydWN0b3IgKG1ldGhvZHMsIGNvbGxlY3Rpb24sIG9wdGlvbnMsIG5hbWUpIHtcbiAgICB0aGlzLm1ldGhvZHMgPSBtZXRob2RzO1xuICAgIHRoaXMuY29sbGVjdGlvbiA9IGNvbGxlY3Rpb247XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuXG4gICAgdGhpcy5kYXRhID0gW107XG4gICAgdGhpcy5zZW50ID0gZmFsc2U7XG4gIH1cbiAgcHVzaCAoLi4uX2lkcykge1xuICAgIGxldCBjaGFuZ2VkO1xuXG4gICAgXy5lYWNoKF9pZHMsIF9pZCA9PiB7XG4gICAgICBpZiAoIV9pZCB8fCBfLmNvbnRhaW5zKHRoaXMuZGF0YSwgX2lkKSlcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgICB0aGlzLmRhdGEucHVzaChfaWQpO1xuICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5zZW50ICYmIGNoYW5nZWQpXG4gICAgICByZXR1cm4gdGhpcy5fY3Vyc29yKCk7XG4gIH1cbiAgc2VuZCAoKSB7XG4gICAgdGhpcy5zZW50ID0gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuZGF0YS5sZW5ndGgpIHJldHVybjtcblxuICAgIHJldHVybiB0aGlzLl9jdXJzb3IoKTtcbiAgfVxuICBfc2VsZWN0b3IgKCkge1xuICAgIGxldCBfaWQgPSB7JGluOiB0aGlzLmRhdGF9O1xuICAgIHJldHVybiBfLmlzRnVuY3Rpb24odGhpcy5zZWxlY3RvcikgPyB0aGlzLnNlbGVjdG9yKF9pZCk6IHtfaWQ6IF9pZH07XG4gIH1cbiAgX2N1cnNvciAoKSB7XG4gICAgcmV0dXJuIHRoaXMubWV0aG9kcy5jdXJzb3IodGhpcy5jb2xsZWN0aW9uLmZpbmQodGhpcy5fc2VsZWN0b3IoKSwgdGhpcy5vcHRpb25zKSwgdGhpcy5uYW1lKTtcbiAgfVxufTsiLCJpbXBvcnQgQ3Vyc29yTWV0aG9kcyBmcm9tICcuL2N1cnNvcic7XG5cbkN1cnNvck1ldGhvZHMucHJvdG90eXBlLm9ic2VydmUgPSBmdW5jdGlvbiAoY3Vyc29yLCBjYWxsYmFja3MpIHtcbiAgdGhpcy5oYW5kbGVyLmFkZChjdXJzb3IsIHtcbiAgICBoYW5kbGVyOiAnb2JzZXJ2ZScsXG4gICAgY2FsbGJhY2tzOiBjYWxsYmFja3NcbiAgfSk7XG59O1xuXG5DdXJzb3JNZXRob2RzLnByb3RvdHlwZS5vYnNlcnZlQ2hhbmdlcyA9IGZ1bmN0aW9uIChjdXJzb3IsIGNhbGxiYWNrcykge1xuICB0aGlzLmhhbmRsZXIuYWRkKGN1cnNvciwge1xuICAgIGhhbmRsZXI6ICdvYnNlcnZlQ2hhbmdlcycsXG4gICAgY2FsbGJhY2tzOiBjYWxsYmFja3NcbiAgfSk7XG59OyIsImltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSc7XG5pbXBvcnQgQ3Vyc29yTWV0aG9kcyBmcm9tICcuL2N1cnNvcic7XG5cbmZ1bmN0aW9uIGdldENCIChjYiwgbWV0aG9kKSB7XG4gIHZhciBjYWxsYmFjayA9IGNiW21ldGhvZF07XG4gIGlmIChjYWxsYmFjayAmJiAhXy5pc0Z1bmN0aW9uKGNhbGxiYWNrKSlcbiAgICB0aHJvdyBuZXcgRXJyb3IobWV0aG9kICsgJyBzaG91bGQgYmUgYSBmdW5jdGlvbiBvciB1bmRlZmluZWQnKTtcblxuICByZXR1cm4gY2FsbGJhY2sgfHwgZnVuY3Rpb24gKCkge307XG59O1xuXG5DdXJzb3JNZXRob2RzLnByb3RvdHlwZS5fZ2V0Q2FsbGJhY2tzID0gZnVuY3Rpb24gKGNiLCBvblJlbW92ZWQpIHtcbiAgaWYgKF8uaXNGdW5jdGlvbihjYikpIHtcbiAgICByZXR1cm4ge1xuICAgICAgYWRkZWQ6IGNiLFxuICAgICAgY2hhbmdlZDogY2IsXG4gICAgICByZW1vdmVkOiBnZXRDQih7b25SZW1vdmVkOiBvblJlbW92ZWR9LCAnb25SZW1vdmVkJylcbiAgICB9O1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBhZGRlZDogZ2V0Q0IoY2IsICdhZGRlZCcpLFxuICAgIGNoYW5nZWQ6IGdldENCKGNiLCAnY2hhbmdlZCcpLFxuICAgIHJlbW92ZWQ6IGdldENCKGNiLCAncmVtb3ZlZCcpXG4gIH07XG59OyIsImltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEN1cnNvck1ldGhvZHNOUiB7XG4gIGNvbnN0cnVjdG9yIChzdWIpIHtcbiAgICB0aGlzLnN1YiA9IHN1YjtcbiAgfVxuICBjdXJzb3JOb25yZWFjdGl2ZSAoY3Vyc29yLCBjb2xsZWN0aW9uLCBvbkFkZGVkKSB7XG4gICAgY29uc3Qgc3ViID0gdGhpcy5zdWI7XG5cbiAgICBpZiAoIV8uaXNTdHJpbmcoY29sbGVjdGlvbikpIHtcbiAgICAgIG9uQWRkZWQgPSBjb2xsZWN0aW9uO1xuICAgICAgY29sbGVjdGlvbiA9IGN1cnNvci5fZ2V0Q29sbGVjdGlvbk5hbWUoKTtcbiAgICB9XG4gICAgaWYgKCFfLmlzRnVuY3Rpb24ob25BZGRlZCkpXG4gICAgICBvbkFkZGVkID0gZnVuY3Rpb24gKCkge307XG5cbiAgICBjdXJzb3IuZm9yRWFjaCgoZG9jKSA9PiB7XG4gICAgICBsZXQgX2lkID0gZG9jLl9pZDtcbiAgICAgIHN1Yi5hZGRlZChjb2xsZWN0aW9uLCBfaWQsIG9uQWRkZWQuY2FsbChuZXcgQ3Vyc29yTWV0aG9kc05SKHN1YiksIF9pZCwgZG9jKSB8fCBkb2MpO1xuICAgIH0pO1xuICB9XG59OyIsImltcG9ydCBDdXJzb3JNZXRob2RzTlIgZnJvbSAnLi9jdXJzb3InO1xuaW1wb3J0ICcuL2pvaW4nO1xuXG5leHBvcnQgZGVmYXVsdCBDdXJzb3JNZXRob2RzTlI7IiwiaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJztcbmltcG9ydCBDdXJzb3JNZXRob2RzTlIgZnJvbSAnLi9jdXJzb3InO1xuXG5DdXJzb3JNZXRob2RzTlIucHJvdG90eXBlLmpvaW5Ob25yZWFjdGl2ZSA9IGZ1bmN0aW9uICguLi5wYXJhbXMpIHtcbiAgcmV0dXJuIG5ldyBDdXJzb3JKb2luTm9ucmVhY3RpdmUodGhpcy5zdWIsIC4uLnBhcmFtcyk7XG59O1xuXG5jbGFzcyBDdXJzb3JKb2luTm9ucmVhY3RpdmUge1xuICBjb25zdHJ1Y3RvciAoc3ViLCBjb2xsZWN0aW9uLCBvcHRpb25zLCBuYW1lKSB7XG4gICAgdGhpcy5zdWIgPSBzdWI7XG4gICAgdGhpcy5jb2xsZWN0aW9uID0gY29sbGVjdGlvbjtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMubmFtZSA9IG5hbWUgfHwgY29sbGVjdGlvbi5fbmFtZTtcblxuICAgIHRoaXMuZGF0YSA9IFtdO1xuICAgIHRoaXMuc2VudCA9IGZhbHNlO1xuICB9XG4gIF9zZWxlY3RvciAoX2lkID0geyRpbjogdGhpcy5kYXRhfSkge1xuICAgIHJldHVybiBfLmlzRnVuY3Rpb24odGhpcy5zZWxlY3RvcikgPyB0aGlzLnNlbGVjdG9yKF9pZCk6IHtfaWQ6IF9pZH07XG4gIH1cbiAgcHVzaCAoLi4uX2lkcykge1xuICAgIGxldCBuZXdJZHMgPSBbXTtcblxuICAgIF8uZWFjaChfaWRzLCBfaWQgPT4ge1xuICAgICAgaWYgKCFfaWQgfHwgXy5jb250YWlucyh0aGlzLmRhdGEsIF9pZCkpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgdGhpcy5kYXRhLnB1c2goX2lkKTtcbiAgICAgIG5ld0lkcy5wdXNoKF9pZCk7XG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5zZW50ICYmIG5ld0lkcy5sZW5ndGgpXG4gICAgICByZXR1cm4gdGhpcy5hZGRlZChuZXdJZHMubGVuZ3RoID4gMSA/IHskaW46IG5ld0lkc306IG5ld0lkc1swXSk7XG4gIH1cbiAgc2VuZCAoKSB7XG4gICAgdGhpcy5zZW50ID0gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuZGF0YS5sZW5ndGgpIHJldHVybjtcblxuICAgIHJldHVybiB0aGlzLmFkZGVkKCk7XG4gIH1cbiAgYWRkZWQgKF9pZCkge1xuICAgIHRoaXMuY29sbGVjdGlvbi5maW5kKHRoaXMuX3NlbGVjdG9yKF9pZCksIHRoaXMub3B0aW9ucykuZm9yRWFjaChkb2MgPT4ge1xuICAgICAgdGhpcy5zdWIuYWRkZWQodGhpcy5uYW1lLCBkb2MuX2lkLCBfLm9taXQoZG9jLCAnX2lkJykpO1xuICAgIH0pO1xuICB9XG59OyJdfQ==
