(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;
var Accounts = Package['accounts-base'].Accounts;

/* Package-scope variables */
var connection;

var require = meteorInstall({"node_modules":{"meteor":{"lucasantoniassi:accounts-lockout":{"accounts-lockout.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/lucasantoniassi_accounts-lockout/accounts-lockout.js                                         //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
module.export({
  Name: () => Name,
  AccountsLockout: () => AccountsLockout
});
let AccountsLockout;
module.link("./src/accountsLockout", {
  default(v) {
    AccountsLockout = v;
  }

}, 0);
const Name = 'lucasantoniassi:accounts-lockout';
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"src":{"accountsLockout.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/lucasantoniassi_accounts-lockout/src/accountsLockout.js                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
let KnownUser;
module.link("./knownUser", {
  default(v) {
    KnownUser = v;
  }

}, 0);
let UnknownUser;
module.link("./unknownUser", {
  default(v) {
    UnknownUser = v;
  }

}, 1);

class AccountsLockout {
  constructor(_ref) {
    let {
      knownUsers = {
        failuresBeforeLockout: 3,
        lockoutPeriod: 60,
        failureWindow: 15
      },
      unknownUsers = {
        failuresBeforeLockout: 3,
        lockoutPeriod: 60,
        failureWindow: 15
      }
    } = _ref;
    this.settings = {
      knownUsers,
      unknownUsers
    };
  }

  startup() {
    new KnownUser(this.settings.knownUsers).startup();
    new UnknownUser(this.settings.unknownUsers).startup();
  }

}

module.exportDefault(AccountsLockout);
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"accountsLockoutCollection.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/lucasantoniassi_accounts-lockout/src/accountsLockoutCollection.js                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.exportDefault(new Meteor.Collection('AccountsLockout.Connections'));
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"knownUser.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/lucasantoniassi_accounts-lockout/src/knownUser.js                                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);

class KnownUser {
  constructor(settings) {
    this.unchangedSettings = settings;
    this.settings = settings;
  }

  startup() {
    if (!(this.unchangedSettings instanceof Function)) {
      this.updateSettings();
    }

    this.scheduleUnlocksForLockedAccounts();
    KnownUser.unlockAccountsIfLockoutAlreadyExpired();
    this.hookIntoAccounts();
  }

  updateSettings() {
    const settings = KnownUser.knownUsers();

    if (settings) {
      settings.forEach(function updateSetting(_ref) {
        let {
          key,
          value
        } = _ref;
        this.settings[key] = value;
      });
    }

    this.validateSettings();
  }

  validateSettings() {
    if (!this.settings.failuresBeforeLockout || this.settings.failuresBeforeLockout < 0) {
      throw new Error('"failuresBeforeLockout" is not positive integer');
    }

    if (!this.settings.lockoutPeriod || this.settings.lockoutPeriod < 0) {
      throw new Error('"lockoutPeriod" is not positive integer');
    }

    if (!this.settings.failureWindow || this.settings.failureWindow < 0) {
      throw new Error('"failureWindow" is not positive integer');
    }
  }

  scheduleUnlocksForLockedAccounts() {
    const lockedAccountsCursor = Meteor.users.find({
      'services.accounts-lockout.unlockTime': {
        $gt: Number(new Date())
      }
    }, {
      fields: {
        'services.accounts-lockout.unlockTime': 1
      }
    });
    const currentTime = Number(new Date());
    lockedAccountsCursor.forEach(user => {
      let lockDuration = KnownUser.unlockTime(user) - currentTime;

      if (lockDuration >= this.settings.lockoutPeriod) {
        lockDuration = this.settings.lockoutPeriod * 1000;
      }

      if (lockDuration <= 1) {
        lockDuration = 1;
      }

      Meteor.setTimeout(KnownUser.unlockAccount.bind(null, user._id), lockDuration);
    });
  }

  static unlockAccountsIfLockoutAlreadyExpired() {
    const currentTime = Number(new Date());
    const query = {
      'services.accounts-lockout.unlockTime': {
        $lt: currentTime
      }
    };
    const data = {
      $unset: {
        'services.accounts-lockout.unlockTime': 0,
        'services.accounts-lockout.failedAttempts': 0
      }
    };
    Meteor.users.update(query, data);
  }

  hookIntoAccounts() {
    Accounts.validateLoginAttempt(this.validateLoginAttempt.bind(this));
    Accounts.onLogin(KnownUser.onLogin);
  }

  validateLoginAttempt(loginInfo) {
    if ( // don't interrupt non-password logins
    loginInfo.type !== 'password' || loginInfo.user === undefined || // Don't handle errors unless they are due to incorrect password
    loginInfo.error !== undefined && loginInfo.error.reason !== 'Incorrect password') {
      return loginInfo.allowed;
    } // If there was no login error and the account is NOT locked, don't interrupt


    const unlockTime = KnownUser.unlockTime(loginInfo.user);

    if (loginInfo.error === undefined && unlockTime === 0) {
      return loginInfo.allowed;
    }

    if (this.unchangedSettings instanceof Function) {
      this.settings = this.unchangedSettings(loginInfo.user);
      this.validateSettings();
    }

    const userId = loginInfo.user._id;
    let failedAttempts = 1 + KnownUser.failedAttempts(loginInfo.user);
    const firstFailedAttempt = KnownUser.firstFailedAttempt(loginInfo.user);
    const currentTime = Number(new Date());
    const canReset = currentTime - firstFailedAttempt > 1000 * this.settings.failureWindow;

    if (canReset) {
      failedAttempts = 1;
      KnownUser.resetAttempts(failedAttempts, userId);
    }

    const canIncrement = failedAttempts < this.settings.failuresBeforeLockout;

    if (canIncrement) {
      KnownUser.incrementAttempts(failedAttempts, userId);
    }

    const maxAttemptsAllowed = this.settings.failuresBeforeLockout;
    const attemptsRemaining = maxAttemptsAllowed - failedAttempts;

    if (unlockTime > currentTime) {
      let duration = unlockTime - currentTime;
      duration = Math.ceil(duration / 1000);
      duration = duration > 1 ? duration : 1;
      KnownUser.tooManyAttempts(duration);
    }

    if (failedAttempts === maxAttemptsAllowed) {
      this.setNewUnlockTime(failedAttempts, userId);
      let duration = this.settings.lockoutPeriod;
      duration = Math.ceil(duration);
      duration = duration > 1 ? duration : 1;
      return KnownUser.tooManyAttempts(duration);
    }

    return KnownUser.incorrectPassword(failedAttempts, maxAttemptsAllowed, attemptsRemaining);
  }

  static resetAttempts(failedAttempts, userId) {
    const currentTime = Number(new Date());
    const query = {
      _id: userId
    };
    const data = {
      $set: {
        'services.accounts-lockout.failedAttempts': failedAttempts,
        'services.accounts-lockout.lastFailedAttempt': currentTime,
        'services.accounts-lockout.firstFailedAttempt': currentTime
      }
    };
    Meteor.users.update(query, data);
  }

  static incrementAttempts(failedAttempts, userId) {
    const currentTime = Number(new Date());
    const query = {
      _id: userId
    };
    const data = {
      $set: {
        'services.accounts-lockout.failedAttempts': failedAttempts,
        'services.accounts-lockout.lastFailedAttempt': currentTime
      }
    };
    Meteor.users.update(query, data);
  }

  setNewUnlockTime(failedAttempts, userId) {
    const currentTime = Number(new Date());
    const newUnlockTime = 1000 * this.settings.lockoutPeriod + currentTime;
    const query = {
      _id: userId
    };
    const data = {
      $set: {
        'services.accounts-lockout.failedAttempts': failedAttempts,
        'services.accounts-lockout.lastFailedAttempt': currentTime,
        'services.accounts-lockout.unlockTime': newUnlockTime
      }
    };
    Meteor.users.update(query, data);
    Meteor.setTimeout(KnownUser.unlockAccount.bind(null, userId), this.settings.lockoutPeriod * 1000);
  }

  static onLogin(loginInfo) {
    if (loginInfo.type !== 'password') {
      return;
    }

    const userId = loginInfo.user._id;
    const query = {
      _id: userId
    };
    const data = {
      $unset: {
        'services.accounts-lockout.unlockTime': 0,
        'services.accounts-lockout.failedAttempts': 0
      }
    };
    Meteor.users.update(query, data);
  }

  static incorrectPassword(failedAttempts, maxAttemptsAllowed, attemptsRemaining) {
    throw new Meteor.Error(403, 'Incorrect password', JSON.stringify({
      message: 'Incorrect password',
      failedAttempts,
      maxAttemptsAllowed,
      attemptsRemaining
    }));
  }

  static tooManyAttempts(duration) {
    throw new Meteor.Error(403, 'Too many attempts', JSON.stringify({
      message: 'Wrong passwords were submitted too many times. Account is locked for a while.',
      duration
    }));
  }

  static knownUsers() {
    let knownUsers;

    try {
      knownUsers = Meteor.settings['accounts-lockout'].knownUsers;
    } catch (e) {
      knownUsers = false;
    }

    return knownUsers || false;
  }

  static unlockTime(user) {
    let unlockTime;

    try {
      unlockTime = user.services['accounts-lockout'].unlockTime;
    } catch (e) {
      unlockTime = 0;
    }

    return unlockTime || 0;
  }

  static failedAttempts(user) {
    let failedAttempts;

    try {
      failedAttempts = user.services['accounts-lockout'].failedAttempts;
    } catch (e) {
      failedAttempts = 0;
    }

    return failedAttempts || 0;
  }

  static lastFailedAttempt(user) {
    let lastFailedAttempt;

    try {
      lastFailedAttempt = user.services['accounts-lockout'].lastFailedAttempt;
    } catch (e) {
      lastFailedAttempt = 0;
    }

    return lastFailedAttempt || 0;
  }

  static firstFailedAttempt(user) {
    let firstFailedAttempt;

    try {
      firstFailedAttempt = user.services['accounts-lockout'].firstFailedAttempt;
    } catch (e) {
      firstFailedAttempt = 0;
    }

    return firstFailedAttempt || 0;
  }

  static unlockAccount(userId) {
    const query = {
      _id: userId
    };
    const data = {
      $unset: {
        'services.accounts-lockout.unlockTime': 0,
        'services.accounts-lockout.failedAttempts': 0
      }
    };
    Meteor.users.update(query, data);
  }

}

module.exportDefault(KnownUser);
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"unknownUser.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/lucasantoniassi_accounts-lockout/src/unknownUser.js                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);

let _AccountsLockoutCollection;

module.link("./accountsLockoutCollection", {
  default(v) {
    _AccountsLockoutCollection = v;
  }

}, 2);

class UnknownUser {
  constructor(settings) {
    let {
      AccountsLockoutCollection = _AccountsLockoutCollection
    } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.AccountsLockoutCollection = AccountsLockoutCollection;
    this.settings = settings;
  }

  startup() {
    if (!(this.settings instanceof Function)) {
      this.updateSettings();
    }

    this.scheduleUnlocksForLockedAccounts();
    this.unlockAccountsIfLockoutAlreadyExpired();
    this.hookIntoAccounts();
  }

  updateSettings() {
    const settings = UnknownUser.unknownUsers();

    if (settings) {
      settings.forEach(function updateSetting(_ref) {
        let {
          key,
          value
        } = _ref;
        this.settings[key] = value;
      });
    }

    this.validateSettings();
  }

  validateSettings() {
    if (!this.settings.failuresBeforeLockout || this.settings.failuresBeforeLockout < 0) {
      throw new Error('"failuresBeforeLockout" is not positive integer');
    }

    if (!this.settings.lockoutPeriod || this.settings.lockoutPeriod < 0) {
      throw new Error('"lockoutPeriod" is not positive integer');
    }

    if (!this.settings.failureWindow || this.settings.failureWindow < 0) {
      throw new Error('"failureWindow" is not positive integer');
    }
  }

  scheduleUnlocksForLockedAccounts() {
    const lockedAccountsCursor = this.AccountsLockoutCollection.find({
      'services.accounts-lockout.unlockTime': {
        $gt: Number(new Date())
      }
    }, {
      fields: {
        'services.accounts-lockout.unlockTime': 1
      }
    });
    const currentTime = Number(new Date());
    lockedAccountsCursor.forEach(connection => {
      let lockDuration = this.unlockTime(connection) - currentTime;

      if (lockDuration >= this.settings.lockoutPeriod) {
        lockDuration = this.settings.lockoutPeriod * 1000;
      }

      if (lockDuration <= 1) {
        lockDuration = 1;
      }

      Meteor.setTimeout(this.unlockAccount.bind(this, connection.clientAddress), lockDuration);
    });
  }

  unlockAccountsIfLockoutAlreadyExpired() {
    const currentTime = Number(new Date());
    const query = {
      'services.accounts-lockout.unlockTime': {
        $lt: currentTime
      }
    };
    const data = {
      $unset: {
        'services.accounts-lockout.unlockTime': 0,
        'services.accounts-lockout.failedAttempts': 0
      }
    };
    this.AccountsLockoutCollection.update(query, data);
  }

  hookIntoAccounts() {
    Accounts.validateLoginAttempt(this.validateLoginAttempt.bind(this));
    Accounts.onLogin(this.onLogin.bind(this));
  }

  validateLoginAttempt(loginInfo) {
    // don't interrupt non-password logins
    if (loginInfo.type !== 'password' || loginInfo.user !== undefined || loginInfo.error === undefined || loginInfo.error.reason !== 'User not found') {
      return loginInfo.allowed;
    }

    if (this.settings instanceof Function) {
      this.settings = this.settings(loginInfo.connection);
      this.validateSettings();
    }

    const clientAddress = loginInfo.connection.clientAddress;
    const unlockTime = this.unlockTime(loginInfo.connection);
    let failedAttempts = 1 + this.failedAttempts(loginInfo.connection);
    const firstFailedAttempt = this.firstFailedAttempt(loginInfo.connection);
    const currentTime = Number(new Date());
    const canReset = currentTime - firstFailedAttempt > 1000 * this.settings.failureWindow;

    if (canReset) {
      failedAttempts = 1;
      this.resetAttempts(failedAttempts, clientAddress);
    }

    const canIncrement = failedAttempts < this.settings.failuresBeforeLockout;

    if (canIncrement) {
      this.incrementAttempts(failedAttempts, clientAddress);
    }

    const maxAttemptsAllowed = this.settings.failuresBeforeLockout;
    const attemptsRemaining = maxAttemptsAllowed - failedAttempts;

    if (unlockTime > currentTime) {
      let duration = unlockTime - currentTime;
      duration = Math.ceil(duration / 1000);
      duration = duration > 1 ? duration : 1;
      UnknownUser.tooManyAttempts(duration);
    }

    if (failedAttempts === maxAttemptsAllowed) {
      this.setNewUnlockTime(failedAttempts, clientAddress);
      let duration = this.settings.lockoutPeriod;
      duration = Math.ceil(duration);
      duration = duration > 1 ? duration : 1;
      return UnknownUser.tooManyAttempts(duration);
    }

    return UnknownUser.userNotFound(failedAttempts, maxAttemptsAllowed, attemptsRemaining);
  }

  resetAttempts(failedAttempts, clientAddress) {
    const currentTime = Number(new Date());
    const query = {
      clientAddress
    };
    const data = {
      $set: {
        'services.accounts-lockout.failedAttempts': failedAttempts,
        'services.accounts-lockout.lastFailedAttempt': currentTime,
        'services.accounts-lockout.firstFailedAttempt': currentTime
      }
    };
    this.AccountsLockoutCollection.upsert(query, data);
  }

  incrementAttempts(failedAttempts, clientAddress) {
    const currentTime = Number(new Date());
    const query = {
      clientAddress
    };
    const data = {
      $set: {
        'services.accounts-lockout.failedAttempts': failedAttempts,
        'services.accounts-lockout.lastFailedAttempt': currentTime
      }
    };
    this.AccountsLockoutCollection.upsert(query, data);
  }

  setNewUnlockTime(failedAttempts, clientAddress) {
    const currentTime = Number(new Date());
    const newUnlockTime = 1000 * this.settings.lockoutPeriod + currentTime;
    const query = {
      clientAddress
    };
    const data = {
      $set: {
        'services.accounts-lockout.failedAttempts': failedAttempts,
        'services.accounts-lockout.lastFailedAttempt': currentTime,
        'services.accounts-lockout.unlockTime': newUnlockTime
      }
    };
    this.AccountsLockoutCollection.upsert(query, data);
    Meteor.setTimeout(this.unlockAccount.bind(this, clientAddress), this.settings.lockoutPeriod * 1000);
  }

  onLogin(loginInfo) {
    if (loginInfo.type !== 'password') {
      return;
    }

    const clientAddress = loginInfo.connection.clientAddress;
    const query = {
      clientAddress
    };
    const data = {
      $unset: {
        'services.accounts-lockout.unlockTime': 0,
        'services.accounts-lockout.failedAttempts': 0
      }
    };
    this.AccountsLockoutCollection.update(query, data);
  }

  static userNotFound(failedAttempts, maxAttemptsAllowed, attemptsRemaining) {
    throw new Meteor.Error(403, 'User not found', JSON.stringify({
      message: 'User not found',
      failedAttempts,
      maxAttemptsAllowed,
      attemptsRemaining
    }));
  }

  static tooManyAttempts(duration) {
    throw new Meteor.Error(403, 'Too many attempts', JSON.stringify({
      message: 'Wrong emails were submitted too many times. Account is locked for a while.',
      duration
    }));
  }

  static unknownUsers() {
    let unknownUsers;

    try {
      unknownUsers = Meteor.settings['accounts-lockout'].unknownUsers;
    } catch (e) {
      unknownUsers = false;
    }

    return unknownUsers || false;
  }

  findOneByConnection(connection) {
    return this.AccountsLockoutCollection.findOne({
      clientAddress: connection.clientAddress
    });
  }

  unlockTime(connection) {
    connection = this.findOneByConnection(connection);
    let unlockTime;

    try {
      unlockTime = connection.services['accounts-lockout'].unlockTime;
    } catch (e) {
      unlockTime = 0;
    }

    return unlockTime || 0;
  }

  failedAttempts(connection) {
    connection = this.findOneByConnection(connection);
    let failedAttempts;

    try {
      failedAttempts = connection.services['accounts-lockout'].failedAttempts;
    } catch (e) {
      failedAttempts = 0;
    }

    return failedAttempts || 0;
  }

  lastFailedAttempt(connection) {
    connection = this.findOneByConnection(connection);
    let lastFailedAttempt;

    try {
      lastFailedAttempt = connection.services['accounts-lockout'].lastFailedAttempt;
    } catch (e) {
      lastFailedAttempt = 0;
    }

    return lastFailedAttempt || 0;
  }

  firstFailedAttempt(connection) {
    connection = this.findOneByConnection(connection);
    let firstFailedAttempt;

    try {
      firstFailedAttempt = connection.services['accounts-lockout'].firstFailedAttempt;
    } catch (e) {
      firstFailedAttempt = 0;
    }

    return firstFailedAttempt || 0;
  }

  unlockAccount(clientAddress) {
    const query = {
      clientAddress
    };
    const data = {
      $unset: {
        'services.accounts-lockout.unlockTime': 0,
        'services.accounts-lockout.failedAttempts': 0
      }
    };
    this.AccountsLockoutCollection.update(query, data);
  }

}

module.exportDefault(UnknownUser);
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/lucasantoniassi:accounts-lockout/accounts-lockout.js");

/* Exports */
Package._define("lucasantoniassi:accounts-lockout", exports);

})();

//# sourceURL=meteor://💻app/packages/lucasantoniassi_accounts-lockout.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbHVjYXNhbnRvbmlhc3NpOmFjY291bnRzLWxvY2tvdXQvYWNjb3VudHMtbG9ja291dC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbHVjYXNhbnRvbmlhc3NpOmFjY291bnRzLWxvY2tvdXQvc3JjL2FjY291bnRzTG9ja291dC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbHVjYXNhbnRvbmlhc3NpOmFjY291bnRzLWxvY2tvdXQvc3JjL2FjY291bnRzTG9ja291dENvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2x1Y2FzYW50b25pYXNzaTphY2NvdW50cy1sb2Nrb3V0L3NyYy9rbm93blVzZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2x1Y2FzYW50b25pYXNzaTphY2NvdW50cy1sb2Nrb3V0L3NyYy91bmtub3duVXNlci5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJOYW1lIiwiQWNjb3VudHNMb2Nrb3V0IiwibGluayIsImRlZmF1bHQiLCJ2IiwiS25vd25Vc2VyIiwiVW5rbm93blVzZXIiLCJjb25zdHJ1Y3RvciIsImtub3duVXNlcnMiLCJmYWlsdXJlc0JlZm9yZUxvY2tvdXQiLCJsb2Nrb3V0UGVyaW9kIiwiZmFpbHVyZVdpbmRvdyIsInVua25vd25Vc2VycyIsInNldHRpbmdzIiwic3RhcnR1cCIsImV4cG9ydERlZmF1bHQiLCJNZXRlb3IiLCJDb2xsZWN0aW9uIiwiQWNjb3VudHMiLCJ1bmNoYW5nZWRTZXR0aW5ncyIsIkZ1bmN0aW9uIiwidXBkYXRlU2V0dGluZ3MiLCJzY2hlZHVsZVVubG9ja3NGb3JMb2NrZWRBY2NvdW50cyIsInVubG9ja0FjY291bnRzSWZMb2Nrb3V0QWxyZWFkeUV4cGlyZWQiLCJob29rSW50b0FjY291bnRzIiwiZm9yRWFjaCIsInVwZGF0ZVNldHRpbmciLCJrZXkiLCJ2YWx1ZSIsInZhbGlkYXRlU2V0dGluZ3MiLCJFcnJvciIsImxvY2tlZEFjY291bnRzQ3Vyc29yIiwidXNlcnMiLCJmaW5kIiwiJGd0IiwiTnVtYmVyIiwiRGF0ZSIsImZpZWxkcyIsImN1cnJlbnRUaW1lIiwidXNlciIsImxvY2tEdXJhdGlvbiIsInVubG9ja1RpbWUiLCJzZXRUaW1lb3V0IiwidW5sb2NrQWNjb3VudCIsImJpbmQiLCJfaWQiLCJxdWVyeSIsIiRsdCIsImRhdGEiLCIkdW5zZXQiLCJ1cGRhdGUiLCJ2YWxpZGF0ZUxvZ2luQXR0ZW1wdCIsIm9uTG9naW4iLCJsb2dpbkluZm8iLCJ0eXBlIiwidW5kZWZpbmVkIiwiZXJyb3IiLCJyZWFzb24iLCJhbGxvd2VkIiwidXNlcklkIiwiZmFpbGVkQXR0ZW1wdHMiLCJmaXJzdEZhaWxlZEF0dGVtcHQiLCJjYW5SZXNldCIsInJlc2V0QXR0ZW1wdHMiLCJjYW5JbmNyZW1lbnQiLCJpbmNyZW1lbnRBdHRlbXB0cyIsIm1heEF0dGVtcHRzQWxsb3dlZCIsImF0dGVtcHRzUmVtYWluaW5nIiwiZHVyYXRpb24iLCJNYXRoIiwiY2VpbCIsInRvb01hbnlBdHRlbXB0cyIsInNldE5ld1VubG9ja1RpbWUiLCJpbmNvcnJlY3RQYXNzd29yZCIsIiRzZXQiLCJuZXdVbmxvY2tUaW1lIiwiSlNPTiIsInN0cmluZ2lmeSIsIm1lc3NhZ2UiLCJlIiwic2VydmljZXMiLCJsYXN0RmFpbGVkQXR0ZW1wdCIsIl9BY2NvdW50c0xvY2tvdXRDb2xsZWN0aW9uIiwiQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbiIsImNvbm5lY3Rpb24iLCJjbGllbnRBZGRyZXNzIiwidXNlck5vdEZvdW5kIiwidXBzZXJ0IiwiZmluZE9uZUJ5Q29ubmVjdGlvbiIsImZpbmRPbmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsTUFBSSxFQUFDLE1BQUlBLElBQVY7QUFBZUMsaUJBQWUsRUFBQyxNQUFJQTtBQUFuQyxDQUFkO0FBQW1FLElBQUlBLGVBQUo7QUFBb0JILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNILG1CQUFlLEdBQUNHLENBQWhCO0FBQWtCOztBQUE5QixDQUFwQyxFQUFvRSxDQUFwRTtBQUV2RixNQUFNSixJQUFJLEdBQUcsa0NBQWIsQzs7Ozs7Ozs7Ozs7QUNGQSxJQUFJSyxTQUFKO0FBQWNQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0MsYUFBUyxHQUFDRCxDQUFWO0FBQVk7O0FBQXhCLENBQTFCLEVBQW9ELENBQXBEO0FBQXVELElBQUlFLFdBQUo7QUFBZ0JSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0UsZUFBVyxHQUFDRixDQUFaO0FBQWM7O0FBQTFCLENBQTVCLEVBQXdELENBQXhEOztBQUdyRixNQUFNSCxlQUFOLENBQXNCO0FBQ3BCTSxhQUFXLE9BV1I7QUFBQSxRQVhTO0FBQ1ZDLGdCQUFVLEdBQUc7QUFDWEMsNkJBQXFCLEVBQUUsQ0FEWjtBQUVYQyxxQkFBYSxFQUFFLEVBRko7QUFHWEMscUJBQWEsRUFBRTtBQUhKLE9BREg7QUFNVkMsa0JBQVksR0FBRztBQUNiSCw2QkFBcUIsRUFBRSxDQURWO0FBRWJDLHFCQUFhLEVBQUUsRUFGRjtBQUdiQyxxQkFBYSxFQUFFO0FBSEY7QUFOTCxLQVdUO0FBQ0QsU0FBS0UsUUFBTCxHQUFnQjtBQUNkTCxnQkFEYztBQUVkSTtBQUZjLEtBQWhCO0FBSUQ7O0FBRURFLFNBQU8sR0FBRztBQUNQLFFBQUlULFNBQUosQ0FBYyxLQUFLUSxRQUFMLENBQWNMLFVBQTVCLENBQUQsQ0FBMENNLE9BQTFDO0FBQ0MsUUFBSVIsV0FBSixDQUFnQixLQUFLTyxRQUFMLENBQWNELFlBQTlCLENBQUQsQ0FBOENFLE9BQTlDO0FBQ0Q7O0FBdEJtQjs7QUFIdEJoQixNQUFNLENBQUNpQixhQUFQLENBNEJlZCxlQTVCZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUllLE1BQUo7QUFBV2xCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2MsUUFBTSxDQUFDWixDQUFELEVBQUc7QUFBQ1ksVUFBTSxHQUFDWixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQVhOLE1BQU0sQ0FBQ2lCLGFBQVAsQ0FFZSxJQUFJQyxNQUFNLENBQUNDLFVBQVgsQ0FBc0IsNkJBQXRCLENBRmYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJRCxNQUFKO0FBQVdsQixNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNjLFFBQU0sQ0FBQ1osQ0FBRCxFQUFHO0FBQUNZLFVBQU0sR0FBQ1osQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJYyxRQUFKO0FBQWFwQixNQUFNLENBQUNJLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDZ0IsVUFBUSxDQUFDZCxDQUFELEVBQUc7QUFBQ2MsWUFBUSxHQUFDZCxDQUFUO0FBQVc7O0FBQXhCLENBQW5DLEVBQTZELENBQTdEOztBQUs3RSxNQUFNQyxTQUFOLENBQWdCO0FBQ2RFLGFBQVcsQ0FBQ00sUUFBRCxFQUFXO0FBQ3BCLFNBQUtNLGlCQUFMLEdBQXlCTixRQUF6QjtBQUNBLFNBQUtBLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0Q7O0FBRURDLFNBQU8sR0FBRztBQUNSLFFBQUksRUFBRSxLQUFLSyxpQkFBTCxZQUFrQ0MsUUFBcEMsQ0FBSixFQUFtRDtBQUNqRCxXQUFLQyxjQUFMO0FBQ0Q7O0FBQ0QsU0FBS0MsZ0NBQUw7QUFDQWpCLGFBQVMsQ0FBQ2tCLHFDQUFWO0FBQ0EsU0FBS0MsZ0JBQUw7QUFDRDs7QUFFREgsZ0JBQWMsR0FBRztBQUNmLFVBQU1SLFFBQVEsR0FBR1IsU0FBUyxDQUFDRyxVQUFWLEVBQWpCOztBQUNBLFFBQUlLLFFBQUosRUFBYztBQUNaQSxjQUFRLENBQUNZLE9BQVQsQ0FBaUIsU0FBU0MsYUFBVCxPQUF1QztBQUFBLFlBQWhCO0FBQUVDLGFBQUY7QUFBT0M7QUFBUCxTQUFnQjtBQUN0RCxhQUFLZixRQUFMLENBQWNjLEdBQWQsSUFBcUJDLEtBQXJCO0FBQ0QsT0FGRDtBQUdEOztBQUNELFNBQUtDLGdCQUFMO0FBQ0Q7O0FBRURBLGtCQUFnQixHQUFHO0FBQ2pCLFFBQ0UsQ0FBQyxLQUFLaEIsUUFBTCxDQUFjSixxQkFBZixJQUNBLEtBQUtJLFFBQUwsQ0FBY0oscUJBQWQsR0FBc0MsQ0FGeEMsRUFHRTtBQUNBLFlBQU0sSUFBSXFCLEtBQUosQ0FBVSxpREFBVixDQUFOO0FBQ0Q7O0FBQ0QsUUFDRSxDQUFDLEtBQUtqQixRQUFMLENBQWNILGFBQWYsSUFDQSxLQUFLRyxRQUFMLENBQWNILGFBQWQsR0FBOEIsQ0FGaEMsRUFHRTtBQUNBLFlBQU0sSUFBSW9CLEtBQUosQ0FBVSx5Q0FBVixDQUFOO0FBQ0Q7O0FBQ0QsUUFDRSxDQUFDLEtBQUtqQixRQUFMLENBQWNGLGFBQWYsSUFDQSxLQUFLRSxRQUFMLENBQWNGLGFBQWQsR0FBOEIsQ0FGaEMsRUFHRTtBQUNBLFlBQU0sSUFBSW1CLEtBQUosQ0FBVSx5Q0FBVixDQUFOO0FBQ0Q7QUFDRjs7QUFFRFIsa0NBQWdDLEdBQUc7QUFDakMsVUFBTVMsb0JBQW9CLEdBQUdmLE1BQU0sQ0FBQ2dCLEtBQVAsQ0FBYUMsSUFBYixDQUMzQjtBQUNFLDhDQUF3QztBQUN0Q0MsV0FBRyxFQUFFQyxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFEO0FBRDJCO0FBRDFDLEtBRDJCLEVBTTNCO0FBQ0VDLFlBQU0sRUFBRTtBQUNOLGdEQUF3QztBQURsQztBQURWLEtBTjJCLENBQTdCO0FBWUEsVUFBTUMsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBQ0FMLHdCQUFvQixDQUFDTixPQUFyQixDQUE4QmMsSUFBRCxJQUFVO0FBQ3JDLFVBQUlDLFlBQVksR0FBR25DLFNBQVMsQ0FBQ29DLFVBQVYsQ0FBcUJGLElBQXJCLElBQTZCRCxXQUFoRDs7QUFDQSxVQUFJRSxZQUFZLElBQUksS0FBSzNCLFFBQUwsQ0FBY0gsYUFBbEMsRUFBaUQ7QUFDL0M4QixvQkFBWSxHQUFHLEtBQUszQixRQUFMLENBQWNILGFBQWQsR0FBOEIsSUFBN0M7QUFDRDs7QUFDRCxVQUFJOEIsWUFBWSxJQUFJLENBQXBCLEVBQXVCO0FBQ3JCQSxvQkFBWSxHQUFHLENBQWY7QUFDRDs7QUFDRHhCLFlBQU0sQ0FBQzBCLFVBQVAsQ0FDRXJDLFNBQVMsQ0FBQ3NDLGFBQVYsQ0FBd0JDLElBQXhCLENBQTZCLElBQTdCLEVBQW1DTCxJQUFJLENBQUNNLEdBQXhDLENBREYsRUFFRUwsWUFGRjtBQUlELEtBWkQ7QUFhRDs7QUFFRCxTQUFPakIscUNBQVAsR0FBK0M7QUFDN0MsVUFBTWUsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBQ0EsVUFBTVUsS0FBSyxHQUFHO0FBQ1osOENBQXdDO0FBQ3RDQyxXQUFHLEVBQUVUO0FBRGlDO0FBRDVCLEtBQWQ7QUFLQSxVQUFNVSxJQUFJLEdBQUc7QUFDWEMsWUFBTSxFQUFFO0FBQ04sZ0RBQXdDLENBRGxDO0FBRU4sb0RBQTRDO0FBRnRDO0FBREcsS0FBYjtBQU1BakMsVUFBTSxDQUFDZ0IsS0FBUCxDQUFha0IsTUFBYixDQUFvQkosS0FBcEIsRUFBMkJFLElBQTNCO0FBQ0Q7O0FBRUR4QixrQkFBZ0IsR0FBRztBQUNqQk4sWUFBUSxDQUFDaUMsb0JBQVQsQ0FBOEIsS0FBS0Esb0JBQUwsQ0FBMEJQLElBQTFCLENBQStCLElBQS9CLENBQTlCO0FBQ0ExQixZQUFRLENBQUNrQyxPQUFULENBQWlCL0MsU0FBUyxDQUFDK0MsT0FBM0I7QUFDRDs7QUFHREQsc0JBQW9CLENBQUNFLFNBQUQsRUFBWTtBQUM5QixTQUNFO0FBQ0FBLGFBQVMsQ0FBQ0MsSUFBVixLQUFtQixVQUFuQixJQUNBRCxTQUFTLENBQUNkLElBQVYsS0FBbUJnQixTQURuQixJQUVBO0FBQ0NGLGFBQVMsQ0FBQ0csS0FBVixLQUFvQkQsU0FBcEIsSUFBaUNGLFNBQVMsQ0FBQ0csS0FBVixDQUFnQkMsTUFBaEIsS0FBMkIsb0JBTC9ELEVBTUU7QUFDQSxhQUFPSixTQUFTLENBQUNLLE9BQWpCO0FBQ0QsS0FUNkIsQ0FXOUI7OztBQUNBLFVBQU1qQixVQUFVLEdBQUdwQyxTQUFTLENBQUNvQyxVQUFWLENBQXFCWSxTQUFTLENBQUNkLElBQS9CLENBQW5COztBQUNBLFFBQUljLFNBQVMsQ0FBQ0csS0FBVixLQUFvQkQsU0FBcEIsSUFBaUNkLFVBQVUsS0FBSyxDQUFwRCxFQUF1RDtBQUNyRCxhQUFPWSxTQUFTLENBQUNLLE9BQWpCO0FBQ0Q7O0FBRUQsUUFBSSxLQUFLdkMsaUJBQUwsWUFBa0NDLFFBQXRDLEVBQWdEO0FBQzlDLFdBQUtQLFFBQUwsR0FBZ0IsS0FBS00saUJBQUwsQ0FBdUJrQyxTQUFTLENBQUNkLElBQWpDLENBQWhCO0FBQ0EsV0FBS1YsZ0JBQUw7QUFDRDs7QUFFRCxVQUFNOEIsTUFBTSxHQUFHTixTQUFTLENBQUNkLElBQVYsQ0FBZU0sR0FBOUI7QUFDQSxRQUFJZSxjQUFjLEdBQUcsSUFBSXZELFNBQVMsQ0FBQ3VELGNBQVYsQ0FBeUJQLFNBQVMsQ0FBQ2QsSUFBbkMsQ0FBekI7QUFDQSxVQUFNc0Isa0JBQWtCLEdBQUd4RCxTQUFTLENBQUN3RCxrQkFBVixDQUE2QlIsU0FBUyxDQUFDZCxJQUF2QyxDQUEzQjtBQUNBLFVBQU1ELFdBQVcsR0FBR0gsTUFBTSxDQUFDLElBQUlDLElBQUosRUFBRCxDQUExQjtBQUVBLFVBQU0wQixRQUFRLEdBQUl4QixXQUFXLEdBQUd1QixrQkFBZixHQUFzQyxPQUFPLEtBQUtoRCxRQUFMLENBQWNGLGFBQTVFOztBQUNBLFFBQUltRCxRQUFKLEVBQWM7QUFDWkYsb0JBQWMsR0FBRyxDQUFqQjtBQUNBdkQsZUFBUyxDQUFDMEQsYUFBVixDQUF3QkgsY0FBeEIsRUFBd0NELE1BQXhDO0FBQ0Q7O0FBRUQsVUFBTUssWUFBWSxHQUFHSixjQUFjLEdBQUcsS0FBSy9DLFFBQUwsQ0FBY0oscUJBQXBEOztBQUNBLFFBQUl1RCxZQUFKLEVBQWtCO0FBQ2hCM0QsZUFBUyxDQUFDNEQsaUJBQVYsQ0FBNEJMLGNBQTVCLEVBQTRDRCxNQUE1QztBQUNEOztBQUVELFVBQU1PLGtCQUFrQixHQUFHLEtBQUtyRCxRQUFMLENBQWNKLHFCQUF6QztBQUNBLFVBQU0wRCxpQkFBaUIsR0FBR0Qsa0JBQWtCLEdBQUdOLGNBQS9DOztBQUNBLFFBQUluQixVQUFVLEdBQUdILFdBQWpCLEVBQThCO0FBQzVCLFVBQUk4QixRQUFRLEdBQUczQixVQUFVLEdBQUdILFdBQTVCO0FBQ0E4QixjQUFRLEdBQUdDLElBQUksQ0FBQ0MsSUFBTCxDQUFVRixRQUFRLEdBQUcsSUFBckIsQ0FBWDtBQUNBQSxjQUFRLEdBQUdBLFFBQVEsR0FBRyxDQUFYLEdBQWVBLFFBQWYsR0FBMEIsQ0FBckM7QUFDQS9ELGVBQVMsQ0FBQ2tFLGVBQVYsQ0FBMEJILFFBQTFCO0FBQ0Q7O0FBQ0QsUUFBSVIsY0FBYyxLQUFLTSxrQkFBdkIsRUFBMkM7QUFDekMsV0FBS00sZ0JBQUwsQ0FBc0JaLGNBQXRCLEVBQXNDRCxNQUF0QztBQUVBLFVBQUlTLFFBQVEsR0FBRyxLQUFLdkQsUUFBTCxDQUFjSCxhQUE3QjtBQUNBMEQsY0FBUSxHQUFHQyxJQUFJLENBQUNDLElBQUwsQ0FBVUYsUUFBVixDQUFYO0FBQ0FBLGNBQVEsR0FBR0EsUUFBUSxHQUFHLENBQVgsR0FBZUEsUUFBZixHQUEwQixDQUFyQztBQUNBLGFBQU8vRCxTQUFTLENBQUNrRSxlQUFWLENBQTBCSCxRQUExQixDQUFQO0FBQ0Q7O0FBQ0QsV0FBTy9ELFNBQVMsQ0FBQ29FLGlCQUFWLENBQ0xiLGNBREssRUFFTE0sa0JBRkssRUFHTEMsaUJBSEssQ0FBUDtBQUtEOztBQUVELFNBQU9KLGFBQVAsQ0FDRUgsY0FERixFQUVFRCxNQUZGLEVBR0U7QUFDQSxVQUFNckIsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBQ0EsVUFBTVUsS0FBSyxHQUFHO0FBQUVELFNBQUcsRUFBRWM7QUFBUCxLQUFkO0FBQ0EsVUFBTVgsSUFBSSxHQUFHO0FBQ1gwQixVQUFJLEVBQUU7QUFDSixvREFBNENkLGNBRHhDO0FBRUosdURBQStDdEIsV0FGM0M7QUFHSix3REFBZ0RBO0FBSDVDO0FBREssS0FBYjtBQU9BdEIsVUFBTSxDQUFDZ0IsS0FBUCxDQUFha0IsTUFBYixDQUFvQkosS0FBcEIsRUFBMkJFLElBQTNCO0FBQ0Q7O0FBRUQsU0FBT2lCLGlCQUFQLENBQ0VMLGNBREYsRUFFRUQsTUFGRixFQUdFO0FBQ0EsVUFBTXJCLFdBQVcsR0FBR0gsTUFBTSxDQUFDLElBQUlDLElBQUosRUFBRCxDQUExQjtBQUNBLFVBQU1VLEtBQUssR0FBRztBQUFFRCxTQUFHLEVBQUVjO0FBQVAsS0FBZDtBQUNBLFVBQU1YLElBQUksR0FBRztBQUNYMEIsVUFBSSxFQUFFO0FBQ0osb0RBQTRDZCxjQUR4QztBQUVKLHVEQUErQ3RCO0FBRjNDO0FBREssS0FBYjtBQU1BdEIsVUFBTSxDQUFDZ0IsS0FBUCxDQUFha0IsTUFBYixDQUFvQkosS0FBcEIsRUFBMkJFLElBQTNCO0FBQ0Q7O0FBRUR3QixrQkFBZ0IsQ0FDZFosY0FEYyxFQUVkRCxNQUZjLEVBR2Q7QUFDQSxVQUFNckIsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBQ0EsVUFBTXVDLGFBQWEsR0FBSSxPQUFPLEtBQUs5RCxRQUFMLENBQWNILGFBQXRCLEdBQXVDNEIsV0FBN0Q7QUFDQSxVQUFNUSxLQUFLLEdBQUc7QUFBRUQsU0FBRyxFQUFFYztBQUFQLEtBQWQ7QUFDQSxVQUFNWCxJQUFJLEdBQUc7QUFDWDBCLFVBQUksRUFBRTtBQUNKLG9EQUE0Q2QsY0FEeEM7QUFFSix1REFBK0N0QixXQUYzQztBQUdKLGdEQUF3Q3FDO0FBSHBDO0FBREssS0FBYjtBQU9BM0QsVUFBTSxDQUFDZ0IsS0FBUCxDQUFha0IsTUFBYixDQUFvQkosS0FBcEIsRUFBMkJFLElBQTNCO0FBQ0FoQyxVQUFNLENBQUMwQixVQUFQLENBQ0VyQyxTQUFTLENBQUNzQyxhQUFWLENBQXdCQyxJQUF4QixDQUE2QixJQUE3QixFQUFtQ2UsTUFBbkMsQ0FERixFQUVFLEtBQUs5QyxRQUFMLENBQWNILGFBQWQsR0FBOEIsSUFGaEM7QUFJRDs7QUFFRCxTQUFPMEMsT0FBUCxDQUFlQyxTQUFmLEVBQTBCO0FBQ3hCLFFBQUlBLFNBQVMsQ0FBQ0MsSUFBVixLQUFtQixVQUF2QixFQUFtQztBQUNqQztBQUNEOztBQUNELFVBQU1LLE1BQU0sR0FBR04sU0FBUyxDQUFDZCxJQUFWLENBQWVNLEdBQTlCO0FBQ0EsVUFBTUMsS0FBSyxHQUFHO0FBQUVELFNBQUcsRUFBRWM7QUFBUCxLQUFkO0FBQ0EsVUFBTVgsSUFBSSxHQUFHO0FBQ1hDLFlBQU0sRUFBRTtBQUNOLGdEQUF3QyxDQURsQztBQUVOLG9EQUE0QztBQUZ0QztBQURHLEtBQWI7QUFNQWpDLFVBQU0sQ0FBQ2dCLEtBQVAsQ0FBYWtCLE1BQWIsQ0FBb0JKLEtBQXBCLEVBQTJCRSxJQUEzQjtBQUNEOztBQUVELFNBQU95QixpQkFBUCxDQUNFYixjQURGLEVBRUVNLGtCQUZGLEVBR0VDLGlCQUhGLEVBSUU7QUFDQSxVQUFNLElBQUluRCxNQUFNLENBQUNjLEtBQVgsQ0FDSixHQURJLEVBRUosb0JBRkksRUFHSjhDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2JDLGFBQU8sRUFBRSxvQkFESTtBQUVibEIsb0JBRmE7QUFHYk0sd0JBSGE7QUFJYkM7QUFKYSxLQUFmLENBSEksQ0FBTjtBQVVEOztBQUVELFNBQU9JLGVBQVAsQ0FBdUJILFFBQXZCLEVBQWlDO0FBQy9CLFVBQU0sSUFBSXBELE1BQU0sQ0FBQ2MsS0FBWCxDQUNKLEdBREksRUFFSixtQkFGSSxFQUdKOEMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDYkMsYUFBTyxFQUFFLCtFQURJO0FBRWJWO0FBRmEsS0FBZixDQUhJLENBQU47QUFRRDs7QUFFRCxTQUFPNUQsVUFBUCxHQUFvQjtBQUNsQixRQUFJQSxVQUFKOztBQUNBLFFBQUk7QUFDRkEsZ0JBQVUsR0FBR1EsTUFBTSxDQUFDSCxRQUFQLENBQWdCLGtCQUFoQixFQUFvQ0wsVUFBakQ7QUFDRCxLQUZELENBRUUsT0FBT3VFLENBQVAsRUFBVTtBQUNWdkUsZ0JBQVUsR0FBRyxLQUFiO0FBQ0Q7O0FBQ0QsV0FBT0EsVUFBVSxJQUFJLEtBQXJCO0FBQ0Q7O0FBRUQsU0FBT2lDLFVBQVAsQ0FBa0JGLElBQWxCLEVBQXdCO0FBQ3RCLFFBQUlFLFVBQUo7O0FBQ0EsUUFBSTtBQUNGQSxnQkFBVSxHQUFHRixJQUFJLENBQUN5QyxRQUFMLENBQWMsa0JBQWQsRUFBa0N2QyxVQUEvQztBQUNELEtBRkQsQ0FFRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1Z0QyxnQkFBVSxHQUFHLENBQWI7QUFDRDs7QUFDRCxXQUFPQSxVQUFVLElBQUksQ0FBckI7QUFDRDs7QUFFRCxTQUFPbUIsY0FBUCxDQUFzQnJCLElBQXRCLEVBQTRCO0FBQzFCLFFBQUlxQixjQUFKOztBQUNBLFFBQUk7QUFDRkEsb0JBQWMsR0FBR3JCLElBQUksQ0FBQ3lDLFFBQUwsQ0FBYyxrQkFBZCxFQUFrQ3BCLGNBQW5EO0FBQ0QsS0FGRCxDQUVFLE9BQU9tQixDQUFQLEVBQVU7QUFDVm5CLG9CQUFjLEdBQUcsQ0FBakI7QUFDRDs7QUFDRCxXQUFPQSxjQUFjLElBQUksQ0FBekI7QUFDRDs7QUFFRCxTQUFPcUIsaUJBQVAsQ0FBeUIxQyxJQUF6QixFQUErQjtBQUM3QixRQUFJMEMsaUJBQUo7O0FBQ0EsUUFBSTtBQUNGQSx1QkFBaUIsR0FBRzFDLElBQUksQ0FBQ3lDLFFBQUwsQ0FBYyxrQkFBZCxFQUFrQ0MsaUJBQXREO0FBQ0QsS0FGRCxDQUVFLE9BQU9GLENBQVAsRUFBVTtBQUNWRSx1QkFBaUIsR0FBRyxDQUFwQjtBQUNEOztBQUNELFdBQU9BLGlCQUFpQixJQUFJLENBQTVCO0FBQ0Q7O0FBRUQsU0FBT3BCLGtCQUFQLENBQTBCdEIsSUFBMUIsRUFBZ0M7QUFDOUIsUUFBSXNCLGtCQUFKOztBQUNBLFFBQUk7QUFDRkEsd0JBQWtCLEdBQUd0QixJQUFJLENBQUN5QyxRQUFMLENBQWMsa0JBQWQsRUFBa0NuQixrQkFBdkQ7QUFDRCxLQUZELENBRUUsT0FBT2tCLENBQVAsRUFBVTtBQUNWbEIsd0JBQWtCLEdBQUcsQ0FBckI7QUFDRDs7QUFDRCxXQUFPQSxrQkFBa0IsSUFBSSxDQUE3QjtBQUNEOztBQUVELFNBQU9sQixhQUFQLENBQXFCZ0IsTUFBckIsRUFBNkI7QUFDM0IsVUFBTWIsS0FBSyxHQUFHO0FBQUVELFNBQUcsRUFBRWM7QUFBUCxLQUFkO0FBQ0EsVUFBTVgsSUFBSSxHQUFHO0FBQ1hDLFlBQU0sRUFBRTtBQUNOLGdEQUF3QyxDQURsQztBQUVOLG9EQUE0QztBQUZ0QztBQURHLEtBQWI7QUFNQWpDLFVBQU0sQ0FBQ2dCLEtBQVAsQ0FBYWtCLE1BQWIsQ0FBb0JKLEtBQXBCLEVBQTJCRSxJQUEzQjtBQUNEOztBQXhUYTs7QUFMaEJsRCxNQUFNLENBQUNpQixhQUFQLENBZ1VlVixTQWhVZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlXLE1BQUo7QUFBV2xCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2MsUUFBTSxDQUFDWixDQUFELEVBQUc7QUFBQ1ksVUFBTSxHQUFDWixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUljLFFBQUo7QUFBYXBCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNnQixVQUFRLENBQUNkLENBQUQsRUFBRztBQUFDYyxZQUFRLEdBQUNkLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7O0FBQWdFLElBQUk4RSwwQkFBSjs7QUFBK0JwRixNQUFNLENBQUNJLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDOEUsOEJBQTBCLEdBQUM5RSxDQUEzQjtBQUE2Qjs7QUFBekMsQ0FBMUMsRUFBcUYsQ0FBckY7O0FBSTVLLE1BQU1FLFdBQU4sQ0FBa0I7QUFDaEJDLGFBQVcsQ0FDVE0sUUFEUyxFQUtUO0FBQUEsUUFIQTtBQUNFc0UsK0JBQXlCLEdBQUdEO0FBRDlCLEtBR0EsdUVBREksRUFDSjtBQUNBLFNBQUtDLHlCQUFMLEdBQWlDQSx5QkFBakM7QUFDQSxTQUFLdEUsUUFBTCxHQUFnQkEsUUFBaEI7QUFDRDs7QUFFREMsU0FBTyxHQUFHO0FBQ1IsUUFBSSxFQUFFLEtBQUtELFFBQUwsWUFBeUJPLFFBQTNCLENBQUosRUFBMEM7QUFDeEMsV0FBS0MsY0FBTDtBQUNEOztBQUNELFNBQUtDLGdDQUFMO0FBQ0EsU0FBS0MscUNBQUw7QUFDQSxTQUFLQyxnQkFBTDtBQUNEOztBQUVESCxnQkFBYyxHQUFHO0FBQ2YsVUFBTVIsUUFBUSxHQUFHUCxXQUFXLENBQUNNLFlBQVosRUFBakI7O0FBQ0EsUUFBSUMsUUFBSixFQUFjO0FBQ1pBLGNBQVEsQ0FBQ1ksT0FBVCxDQUFpQixTQUFTQyxhQUFULE9BQXVDO0FBQUEsWUFBaEI7QUFBRUMsYUFBRjtBQUFPQztBQUFQLFNBQWdCO0FBQ3RELGFBQUtmLFFBQUwsQ0FBY2MsR0FBZCxJQUFxQkMsS0FBckI7QUFDRCxPQUZEO0FBR0Q7O0FBQ0QsU0FBS0MsZ0JBQUw7QUFDRDs7QUFFREEsa0JBQWdCLEdBQUc7QUFDakIsUUFDRSxDQUFDLEtBQUtoQixRQUFMLENBQWNKLHFCQUFmLElBQ0EsS0FBS0ksUUFBTCxDQUFjSixxQkFBZCxHQUFzQyxDQUZ4QyxFQUdFO0FBQ0EsWUFBTSxJQUFJcUIsS0FBSixDQUFVLGlEQUFWLENBQU47QUFDRDs7QUFDRCxRQUNFLENBQUMsS0FBS2pCLFFBQUwsQ0FBY0gsYUFBZixJQUNBLEtBQUtHLFFBQUwsQ0FBY0gsYUFBZCxHQUE4QixDQUZoQyxFQUdFO0FBQ0EsWUFBTSxJQUFJb0IsS0FBSixDQUFVLHlDQUFWLENBQU47QUFDRDs7QUFDRCxRQUNFLENBQUMsS0FBS2pCLFFBQUwsQ0FBY0YsYUFBZixJQUNBLEtBQUtFLFFBQUwsQ0FBY0YsYUFBZCxHQUE4QixDQUZoQyxFQUdFO0FBQ0EsWUFBTSxJQUFJbUIsS0FBSixDQUFVLHlDQUFWLENBQU47QUFDRDtBQUNGOztBQUVEUixrQ0FBZ0MsR0FBRztBQUNqQyxVQUFNUyxvQkFBb0IsR0FBRyxLQUFLb0QseUJBQUwsQ0FBK0JsRCxJQUEvQixDQUMzQjtBQUNFLDhDQUF3QztBQUN0Q0MsV0FBRyxFQUFFQyxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFEO0FBRDJCO0FBRDFDLEtBRDJCLEVBTTNCO0FBQ0VDLFlBQU0sRUFBRTtBQUNOLGdEQUF3QztBQURsQztBQURWLEtBTjJCLENBQTdCO0FBWUEsVUFBTUMsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBQ0FMLHdCQUFvQixDQUFDTixPQUFyQixDQUE4QjJELFVBQUQsSUFBZ0I7QUFDM0MsVUFBSTVDLFlBQVksR0FBRyxLQUFLQyxVQUFMLENBQWdCMkMsVUFBaEIsSUFBOEI5QyxXQUFqRDs7QUFDQSxVQUFJRSxZQUFZLElBQUksS0FBSzNCLFFBQUwsQ0FBY0gsYUFBbEMsRUFBaUQ7QUFDL0M4QixvQkFBWSxHQUFHLEtBQUszQixRQUFMLENBQWNILGFBQWQsR0FBOEIsSUFBN0M7QUFDRDs7QUFDRCxVQUFJOEIsWUFBWSxJQUFJLENBQXBCLEVBQXVCO0FBQ3JCQSxvQkFBWSxHQUFHLENBQWY7QUFDRDs7QUFDRHhCLFlBQU0sQ0FBQzBCLFVBQVAsQ0FDRSxLQUFLQyxhQUFMLENBQW1CQyxJQUFuQixDQUF3QixJQUF4QixFQUE4QndDLFVBQVUsQ0FBQ0MsYUFBekMsQ0FERixFQUVFN0MsWUFGRjtBQUlELEtBWkQ7QUFhRDs7QUFFRGpCLHVDQUFxQyxHQUFHO0FBQ3RDLFVBQU1lLFdBQVcsR0FBR0gsTUFBTSxDQUFDLElBQUlDLElBQUosRUFBRCxDQUExQjtBQUNBLFVBQU1VLEtBQUssR0FBRztBQUNaLDhDQUF3QztBQUN0Q0MsV0FBRyxFQUFFVDtBQURpQztBQUQ1QixLQUFkO0FBS0EsVUFBTVUsSUFBSSxHQUFHO0FBQ1hDLFlBQU0sRUFBRTtBQUNOLGdEQUF3QyxDQURsQztBQUVOLG9EQUE0QztBQUZ0QztBQURHLEtBQWI7QUFNQSxTQUFLa0MseUJBQUwsQ0FBK0JqQyxNQUEvQixDQUFzQ0osS0FBdEMsRUFBNkNFLElBQTdDO0FBQ0Q7O0FBRUR4QixrQkFBZ0IsR0FBRztBQUNqQk4sWUFBUSxDQUFDaUMsb0JBQVQsQ0FBOEIsS0FBS0Esb0JBQUwsQ0FBMEJQLElBQTFCLENBQStCLElBQS9CLENBQTlCO0FBQ0ExQixZQUFRLENBQUNrQyxPQUFULENBQWlCLEtBQUtBLE9BQUwsQ0FBYVIsSUFBYixDQUFrQixJQUFsQixDQUFqQjtBQUNEOztBQUVETyxzQkFBb0IsQ0FBQ0UsU0FBRCxFQUFZO0FBQzlCO0FBQ0EsUUFDRUEsU0FBUyxDQUFDQyxJQUFWLEtBQW1CLFVBQW5CLElBQ0FELFNBQVMsQ0FBQ2QsSUFBVixLQUFtQmdCLFNBRG5CLElBRUFGLFNBQVMsQ0FBQ0csS0FBVixLQUFvQkQsU0FGcEIsSUFHQUYsU0FBUyxDQUFDRyxLQUFWLENBQWdCQyxNQUFoQixLQUEyQixnQkFKN0IsRUFLRTtBQUNBLGFBQU9KLFNBQVMsQ0FBQ0ssT0FBakI7QUFDRDs7QUFFRCxRQUFJLEtBQUs3QyxRQUFMLFlBQXlCTyxRQUE3QixFQUF1QztBQUNyQyxXQUFLUCxRQUFMLEdBQWdCLEtBQUtBLFFBQUwsQ0FBY3dDLFNBQVMsQ0FBQytCLFVBQXhCLENBQWhCO0FBQ0EsV0FBS3ZELGdCQUFMO0FBQ0Q7O0FBRUQsVUFBTXdELGFBQWEsR0FBR2hDLFNBQVMsQ0FBQytCLFVBQVYsQ0FBcUJDLGFBQTNDO0FBQ0EsVUFBTTVDLFVBQVUsR0FBRyxLQUFLQSxVQUFMLENBQWdCWSxTQUFTLENBQUMrQixVQUExQixDQUFuQjtBQUNBLFFBQUl4QixjQUFjLEdBQUcsSUFBSSxLQUFLQSxjQUFMLENBQW9CUCxTQUFTLENBQUMrQixVQUE5QixDQUF6QjtBQUNBLFVBQU12QixrQkFBa0IsR0FBRyxLQUFLQSxrQkFBTCxDQUF3QlIsU0FBUyxDQUFDK0IsVUFBbEMsQ0FBM0I7QUFDQSxVQUFNOUMsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBRUEsVUFBTTBCLFFBQVEsR0FBSXhCLFdBQVcsR0FBR3VCLGtCQUFmLEdBQXNDLE9BQU8sS0FBS2hELFFBQUwsQ0FBY0YsYUFBNUU7O0FBQ0EsUUFBSW1ELFFBQUosRUFBYztBQUNaRixvQkFBYyxHQUFHLENBQWpCO0FBQ0EsV0FBS0csYUFBTCxDQUFtQkgsY0FBbkIsRUFBbUN5QixhQUFuQztBQUNEOztBQUVELFVBQU1yQixZQUFZLEdBQUdKLGNBQWMsR0FBRyxLQUFLL0MsUUFBTCxDQUFjSixxQkFBcEQ7O0FBQ0EsUUFBSXVELFlBQUosRUFBa0I7QUFDaEIsV0FBS0MsaUJBQUwsQ0FBdUJMLGNBQXZCLEVBQXVDeUIsYUFBdkM7QUFDRDs7QUFFRCxVQUFNbkIsa0JBQWtCLEdBQUcsS0FBS3JELFFBQUwsQ0FBY0oscUJBQXpDO0FBQ0EsVUFBTTBELGlCQUFpQixHQUFHRCxrQkFBa0IsR0FBR04sY0FBL0M7O0FBQ0EsUUFBSW5CLFVBQVUsR0FBR0gsV0FBakIsRUFBOEI7QUFDNUIsVUFBSThCLFFBQVEsR0FBRzNCLFVBQVUsR0FBR0gsV0FBNUI7QUFDQThCLGNBQVEsR0FBR0MsSUFBSSxDQUFDQyxJQUFMLENBQVVGLFFBQVEsR0FBRyxJQUFyQixDQUFYO0FBQ0FBLGNBQVEsR0FBR0EsUUFBUSxHQUFHLENBQVgsR0FBZUEsUUFBZixHQUEwQixDQUFyQztBQUNBOUQsaUJBQVcsQ0FBQ2lFLGVBQVosQ0FBNEJILFFBQTVCO0FBQ0Q7O0FBQ0QsUUFBSVIsY0FBYyxLQUFLTSxrQkFBdkIsRUFBMkM7QUFDekMsV0FBS00sZ0JBQUwsQ0FBc0JaLGNBQXRCLEVBQXNDeUIsYUFBdEM7QUFFQSxVQUFJakIsUUFBUSxHQUFHLEtBQUt2RCxRQUFMLENBQWNILGFBQTdCO0FBQ0EwRCxjQUFRLEdBQUdDLElBQUksQ0FBQ0MsSUFBTCxDQUFVRixRQUFWLENBQVg7QUFDQUEsY0FBUSxHQUFHQSxRQUFRLEdBQUcsQ0FBWCxHQUFlQSxRQUFmLEdBQTBCLENBQXJDO0FBQ0EsYUFBTzlELFdBQVcsQ0FBQ2lFLGVBQVosQ0FBNEJILFFBQTVCLENBQVA7QUFDRDs7QUFDRCxXQUFPOUQsV0FBVyxDQUFDZ0YsWUFBWixDQUNMMUIsY0FESyxFQUVMTSxrQkFGSyxFQUdMQyxpQkFISyxDQUFQO0FBS0Q7O0FBRURKLGVBQWEsQ0FDWEgsY0FEVyxFQUVYeUIsYUFGVyxFQUdYO0FBQ0EsVUFBTS9DLFdBQVcsR0FBR0gsTUFBTSxDQUFDLElBQUlDLElBQUosRUFBRCxDQUExQjtBQUNBLFVBQU1VLEtBQUssR0FBRztBQUFFdUM7QUFBRixLQUFkO0FBQ0EsVUFBTXJDLElBQUksR0FBRztBQUNYMEIsVUFBSSxFQUFFO0FBQ0osb0RBQTRDZCxjQUR4QztBQUVKLHVEQUErQ3RCLFdBRjNDO0FBR0osd0RBQWdEQTtBQUg1QztBQURLLEtBQWI7QUFPQSxTQUFLNkMseUJBQUwsQ0FBK0JJLE1BQS9CLENBQXNDekMsS0FBdEMsRUFBNkNFLElBQTdDO0FBQ0Q7O0FBRURpQixtQkFBaUIsQ0FDZkwsY0FEZSxFQUVmeUIsYUFGZSxFQUdmO0FBQ0EsVUFBTS9DLFdBQVcsR0FBR0gsTUFBTSxDQUFDLElBQUlDLElBQUosRUFBRCxDQUExQjtBQUNBLFVBQU1VLEtBQUssR0FBRztBQUFFdUM7QUFBRixLQUFkO0FBQ0EsVUFBTXJDLElBQUksR0FBRztBQUNYMEIsVUFBSSxFQUFFO0FBQ0osb0RBQTRDZCxjQUR4QztBQUVKLHVEQUErQ3RCO0FBRjNDO0FBREssS0FBYjtBQU1BLFNBQUs2Qyx5QkFBTCxDQUErQkksTUFBL0IsQ0FBc0N6QyxLQUF0QyxFQUE2Q0UsSUFBN0M7QUFDRDs7QUFFRHdCLGtCQUFnQixDQUNkWixjQURjLEVBRWR5QixhQUZjLEVBR2Q7QUFDQSxVQUFNL0MsV0FBVyxHQUFHSCxNQUFNLENBQUMsSUFBSUMsSUFBSixFQUFELENBQTFCO0FBQ0EsVUFBTXVDLGFBQWEsR0FBSSxPQUFPLEtBQUs5RCxRQUFMLENBQWNILGFBQXRCLEdBQXVDNEIsV0FBN0Q7QUFDQSxVQUFNUSxLQUFLLEdBQUc7QUFBRXVDO0FBQUYsS0FBZDtBQUNBLFVBQU1yQyxJQUFJLEdBQUc7QUFDWDBCLFVBQUksRUFBRTtBQUNKLG9EQUE0Q2QsY0FEeEM7QUFFSix1REFBK0N0QixXQUYzQztBQUdKLGdEQUF3Q3FDO0FBSHBDO0FBREssS0FBYjtBQU9BLFNBQUtRLHlCQUFMLENBQStCSSxNQUEvQixDQUFzQ3pDLEtBQXRDLEVBQTZDRSxJQUE3QztBQUNBaEMsVUFBTSxDQUFDMEIsVUFBUCxDQUNFLEtBQUtDLGFBQUwsQ0FBbUJDLElBQW5CLENBQXdCLElBQXhCLEVBQThCeUMsYUFBOUIsQ0FERixFQUVFLEtBQUt4RSxRQUFMLENBQWNILGFBQWQsR0FBOEIsSUFGaEM7QUFJRDs7QUFFRDBDLFNBQU8sQ0FBQ0MsU0FBRCxFQUFZO0FBQ2pCLFFBQUlBLFNBQVMsQ0FBQ0MsSUFBVixLQUFtQixVQUF2QixFQUFtQztBQUNqQztBQUNEOztBQUNELFVBQU0rQixhQUFhLEdBQUdoQyxTQUFTLENBQUMrQixVQUFWLENBQXFCQyxhQUEzQztBQUNBLFVBQU12QyxLQUFLLEdBQUc7QUFBRXVDO0FBQUYsS0FBZDtBQUNBLFVBQU1yQyxJQUFJLEdBQUc7QUFDWEMsWUFBTSxFQUFFO0FBQ04sZ0RBQXdDLENBRGxDO0FBRU4sb0RBQTRDO0FBRnRDO0FBREcsS0FBYjtBQU1BLFNBQUtrQyx5QkFBTCxDQUErQmpDLE1BQS9CLENBQXNDSixLQUF0QyxFQUE2Q0UsSUFBN0M7QUFDRDs7QUFFRCxTQUFPc0MsWUFBUCxDQUNFMUIsY0FERixFQUVFTSxrQkFGRixFQUdFQyxpQkFIRixFQUlFO0FBQ0EsVUFBTSxJQUFJbkQsTUFBTSxDQUFDYyxLQUFYLENBQ0osR0FESSxFQUVKLGdCQUZJLEVBR0o4QyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNiQyxhQUFPLEVBQUUsZ0JBREk7QUFFYmxCLG9CQUZhO0FBR2JNLHdCQUhhO0FBSWJDO0FBSmEsS0FBZixDQUhJLENBQU47QUFVRDs7QUFFRCxTQUFPSSxlQUFQLENBQXVCSCxRQUF2QixFQUFpQztBQUMvQixVQUFNLElBQUlwRCxNQUFNLENBQUNjLEtBQVgsQ0FDSixHQURJLEVBRUosbUJBRkksRUFHSjhDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2JDLGFBQU8sRUFBRSw0RUFESTtBQUViVjtBQUZhLEtBQWYsQ0FISSxDQUFOO0FBUUQ7O0FBRUQsU0FBT3hELFlBQVAsR0FBc0I7QUFDcEIsUUFBSUEsWUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLGtCQUFZLEdBQUdJLE1BQU0sQ0FBQ0gsUUFBUCxDQUFnQixrQkFBaEIsRUFBb0NELFlBQW5EO0FBQ0QsS0FGRCxDQUVFLE9BQU9tRSxDQUFQLEVBQVU7QUFDVm5FLGtCQUFZLEdBQUcsS0FBZjtBQUNEOztBQUNELFdBQU9BLFlBQVksSUFBSSxLQUF2QjtBQUNEOztBQUVENEUscUJBQW1CLENBQUNKLFVBQUQsRUFBYTtBQUM5QixXQUFPLEtBQUtELHlCQUFMLENBQStCTSxPQUEvQixDQUF1QztBQUM1Q0osbUJBQWEsRUFBRUQsVUFBVSxDQUFDQztBQURrQixLQUF2QyxDQUFQO0FBR0Q7O0FBRUQ1QyxZQUFVLENBQUMyQyxVQUFELEVBQWE7QUFDckJBLGNBQVUsR0FBRyxLQUFLSSxtQkFBTCxDQUF5QkosVUFBekIsQ0FBYjtBQUNBLFFBQUkzQyxVQUFKOztBQUNBLFFBQUk7QUFDRkEsZ0JBQVUsR0FBRzJDLFVBQVUsQ0FBQ0osUUFBWCxDQUFvQixrQkFBcEIsRUFBd0N2QyxVQUFyRDtBQUNELEtBRkQsQ0FFRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1Z0QyxnQkFBVSxHQUFHLENBQWI7QUFDRDs7QUFDRCxXQUFPQSxVQUFVLElBQUksQ0FBckI7QUFDRDs7QUFFRG1CLGdCQUFjLENBQUN3QixVQUFELEVBQWE7QUFDekJBLGNBQVUsR0FBRyxLQUFLSSxtQkFBTCxDQUF5QkosVUFBekIsQ0FBYjtBQUNBLFFBQUl4QixjQUFKOztBQUNBLFFBQUk7QUFDRkEsb0JBQWMsR0FBR3dCLFVBQVUsQ0FBQ0osUUFBWCxDQUFvQixrQkFBcEIsRUFBd0NwQixjQUF6RDtBQUNELEtBRkQsQ0FFRSxPQUFPbUIsQ0FBUCxFQUFVO0FBQ1ZuQixvQkFBYyxHQUFHLENBQWpCO0FBQ0Q7O0FBQ0QsV0FBT0EsY0FBYyxJQUFJLENBQXpCO0FBQ0Q7O0FBRURxQixtQkFBaUIsQ0FBQ0csVUFBRCxFQUFhO0FBQzVCQSxjQUFVLEdBQUcsS0FBS0ksbUJBQUwsQ0FBeUJKLFVBQXpCLENBQWI7QUFDQSxRQUFJSCxpQkFBSjs7QUFDQSxRQUFJO0FBQ0ZBLHVCQUFpQixHQUFHRyxVQUFVLENBQUNKLFFBQVgsQ0FBb0Isa0JBQXBCLEVBQXdDQyxpQkFBNUQ7QUFDRCxLQUZELENBRUUsT0FBT0YsQ0FBUCxFQUFVO0FBQ1ZFLHVCQUFpQixHQUFHLENBQXBCO0FBQ0Q7O0FBQ0QsV0FBT0EsaUJBQWlCLElBQUksQ0FBNUI7QUFDRDs7QUFFRHBCLG9CQUFrQixDQUFDdUIsVUFBRCxFQUFhO0FBQzdCQSxjQUFVLEdBQUcsS0FBS0ksbUJBQUwsQ0FBeUJKLFVBQXpCLENBQWI7QUFDQSxRQUFJdkIsa0JBQUo7O0FBQ0EsUUFBSTtBQUNGQSx3QkFBa0IsR0FBR3VCLFVBQVUsQ0FBQ0osUUFBWCxDQUFvQixrQkFBcEIsRUFBd0NuQixrQkFBN0Q7QUFDRCxLQUZELENBRUUsT0FBT2tCLENBQVAsRUFBVTtBQUNWbEIsd0JBQWtCLEdBQUcsQ0FBckI7QUFDRDs7QUFDRCxXQUFPQSxrQkFBa0IsSUFBSSxDQUE3QjtBQUNEOztBQUVEbEIsZUFBYSxDQUFDMEMsYUFBRCxFQUFnQjtBQUMzQixVQUFNdkMsS0FBSyxHQUFHO0FBQUV1QztBQUFGLEtBQWQ7QUFDQSxVQUFNckMsSUFBSSxHQUFHO0FBQ1hDLFlBQU0sRUFBRTtBQUNOLGdEQUF3QyxDQURsQztBQUVOLG9EQUE0QztBQUZ0QztBQURHLEtBQWI7QUFNQSxTQUFLa0MseUJBQUwsQ0FBK0JqQyxNQUEvQixDQUFzQ0osS0FBdEMsRUFBNkNFLElBQTdDO0FBQ0Q7O0FBalVlOztBQUpsQmxELE1BQU0sQ0FBQ2lCLGFBQVAsQ0F3VWVULFdBeFVmLEUiLCJmaWxlIjoiL3BhY2thZ2VzL2x1Y2FzYW50b25pYXNzaV9hY2NvdW50cy1sb2Nrb3V0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEFjY291bnRzTG9ja291dCBmcm9tICcuL3NyYy9hY2NvdW50c0xvY2tvdXQnO1xuXG5jb25zdCBOYW1lID0gJ2x1Y2FzYW50b25pYXNzaTphY2NvdW50cy1sb2Nrb3V0JztcblxuZXhwb3J0IHsgTmFtZSwgQWNjb3VudHNMb2Nrb3V0IH07XG4iLCJpbXBvcnQgS25vd25Vc2VyIGZyb20gJy4va25vd25Vc2VyJztcbmltcG9ydCBVbmtub3duVXNlciBmcm9tICcuL3Vua25vd25Vc2VyJztcblxuY2xhc3MgQWNjb3VudHNMb2Nrb3V0IHtcbiAgY29uc3RydWN0b3Ioe1xuICAgIGtub3duVXNlcnMgPSB7XG4gICAgICBmYWlsdXJlc0JlZm9yZUxvY2tvdXQ6IDMsXG4gICAgICBsb2Nrb3V0UGVyaW9kOiA2MCxcbiAgICAgIGZhaWx1cmVXaW5kb3c6IDE1LFxuICAgIH0sXG4gICAgdW5rbm93blVzZXJzID0ge1xuICAgICAgZmFpbHVyZXNCZWZvcmVMb2Nrb3V0OiAzLFxuICAgICAgbG9ja291dFBlcmlvZDogNjAsXG4gICAgICBmYWlsdXJlV2luZG93OiAxNSxcbiAgICB9LFxuICB9KSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IHtcbiAgICAgIGtub3duVXNlcnMsXG4gICAgICB1bmtub3duVXNlcnMsXG4gICAgfTtcbiAgfVxuXG4gIHN0YXJ0dXAoKSB7XG4gICAgKG5ldyBLbm93blVzZXIodGhpcy5zZXR0aW5ncy5rbm93blVzZXJzKSkuc3RhcnR1cCgpO1xuICAgIChuZXcgVW5rbm93blVzZXIodGhpcy5zZXR0aW5ncy51bmtub3duVXNlcnMpKS5zdGFydHVwKCk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQWNjb3VudHNMb2Nrb3V0O1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmV4cG9ydCBkZWZhdWx0IG5ldyBNZXRlb3IuQ29sbGVjdGlvbignQWNjb3VudHNMb2Nrb3V0LkNvbm5lY3Rpb25zJyk7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBuby11bmRlcnNjb3JlLWRhbmdsZSAqL1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuXG5jbGFzcyBLbm93blVzZXIge1xuICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgIHRoaXMudW5jaGFuZ2VkU2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICBzdGFydHVwKCkge1xuICAgIGlmICghKHRoaXMudW5jaGFuZ2VkU2V0dGluZ3MgaW5zdGFuY2VvZiBGdW5jdGlvbikpIHtcbiAgICAgIHRoaXMudXBkYXRlU2V0dGluZ3MoKTtcbiAgICB9XG4gICAgdGhpcy5zY2hlZHVsZVVubG9ja3NGb3JMb2NrZWRBY2NvdW50cygpO1xuICAgIEtub3duVXNlci51bmxvY2tBY2NvdW50c0lmTG9ja291dEFscmVhZHlFeHBpcmVkKCk7XG4gICAgdGhpcy5ob29rSW50b0FjY291bnRzKCk7XG4gIH1cblxuICB1cGRhdGVTZXR0aW5ncygpIHtcbiAgICBjb25zdCBzZXR0aW5ncyA9IEtub3duVXNlci5rbm93blVzZXJzKCk7XG4gICAgaWYgKHNldHRpbmdzKSB7XG4gICAgICBzZXR0aW5ncy5mb3JFYWNoKGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmcoeyBrZXksIHZhbHVlIH0pIHtcbiAgICAgICAgdGhpcy5zZXR0aW5nc1trZXldID0gdmFsdWU7XG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpcy52YWxpZGF0ZVNldHRpbmdzKCk7XG4gIH1cblxuICB2YWxpZGF0ZVNldHRpbmdzKCkge1xuICAgIGlmIChcbiAgICAgICF0aGlzLnNldHRpbmdzLmZhaWx1cmVzQmVmb3JlTG9ja291dCB8fFxuICAgICAgdGhpcy5zZXR0aW5ncy5mYWlsdXJlc0JlZm9yZUxvY2tvdXQgPCAwXG4gICAgKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiZmFpbHVyZXNCZWZvcmVMb2Nrb3V0XCIgaXMgbm90IHBvc2l0aXZlIGludGVnZXInKTtcbiAgICB9XG4gICAgaWYgKFxuICAgICAgIXRoaXMuc2V0dGluZ3MubG9ja291dFBlcmlvZCB8fFxuICAgICAgdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kIDwgMFxuICAgICkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdcImxvY2tvdXRQZXJpb2RcIiBpcyBub3QgcG9zaXRpdmUgaW50ZWdlcicpO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICAhdGhpcy5zZXR0aW5ncy5mYWlsdXJlV2luZG93IHx8XG4gICAgICB0aGlzLnNldHRpbmdzLmZhaWx1cmVXaW5kb3cgPCAwXG4gICAgKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiZmFpbHVyZVdpbmRvd1wiIGlzIG5vdCBwb3NpdGl2ZSBpbnRlZ2VyJyk7XG4gICAgfVxuICB9XG5cbiAgc2NoZWR1bGVVbmxvY2tzRm9yTG9ja2VkQWNjb3VudHMoKSB7XG4gICAgY29uc3QgbG9ja2VkQWNjb3VudHNDdXJzb3IgPSBNZXRlb3IudXNlcnMuZmluZChcbiAgICAgIHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IHtcbiAgICAgICAgICAkZ3Q6IE51bWJlcihuZXcgRGF0ZSgpKSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGZpZWxkczoge1xuICAgICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LnVubG9ja1RpbWUnOiAxLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICApO1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gTnVtYmVyKG5ldyBEYXRlKCkpO1xuICAgIGxvY2tlZEFjY291bnRzQ3Vyc29yLmZvckVhY2goKHVzZXIpID0+IHtcbiAgICAgIGxldCBsb2NrRHVyYXRpb24gPSBLbm93blVzZXIudW5sb2NrVGltZSh1c2VyKSAtIGN1cnJlbnRUaW1lO1xuICAgICAgaWYgKGxvY2tEdXJhdGlvbiA+PSB0aGlzLnNldHRpbmdzLmxvY2tvdXRQZXJpb2QpIHtcbiAgICAgICAgbG9ja0R1cmF0aW9uID0gdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kICogMTAwMDtcbiAgICAgIH1cbiAgICAgIGlmIChsb2NrRHVyYXRpb24gPD0gMSkge1xuICAgICAgICBsb2NrRHVyYXRpb24gPSAxO1xuICAgICAgfVxuICAgICAgTWV0ZW9yLnNldFRpbWVvdXQoXG4gICAgICAgIEtub3duVXNlci51bmxvY2tBY2NvdW50LmJpbmQobnVsbCwgdXNlci5faWQpLFxuICAgICAgICBsb2NrRHVyYXRpb24sXG4gICAgICApO1xuICAgIH0pO1xuICB9XG5cbiAgc3RhdGljIHVubG9ja0FjY291bnRzSWZMb2Nrb3V0QWxyZWFkeUV4cGlyZWQoKSB7XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBOdW1iZXIobmV3IERhdGUoKSk7XG4gICAgY29uc3QgcXVlcnkgPSB7XG4gICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC51bmxvY2tUaW1lJzoge1xuICAgICAgICAkbHQ6IGN1cnJlbnRUaW1lLFxuICAgICAgfSxcbiAgICB9O1xuICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICAkdW5zZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IDAsXG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LmZhaWxlZEF0dGVtcHRzJzogMCxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHF1ZXJ5LCBkYXRhKTtcbiAgfVxuXG4gIGhvb2tJbnRvQWNjb3VudHMoKSB7XG4gICAgQWNjb3VudHMudmFsaWRhdGVMb2dpbkF0dGVtcHQodGhpcy52YWxpZGF0ZUxvZ2luQXR0ZW1wdC5iaW5kKHRoaXMpKTtcbiAgICBBY2NvdW50cy5vbkxvZ2luKEtub3duVXNlci5vbkxvZ2luKTtcbiAgfVxuXG5cbiAgdmFsaWRhdGVMb2dpbkF0dGVtcHQobG9naW5JbmZvKSB7XG4gICAgaWYgKFxuICAgICAgLy8gZG9uJ3QgaW50ZXJydXB0IG5vbi1wYXNzd29yZCBsb2dpbnNcbiAgICAgIGxvZ2luSW5mby50eXBlICE9PSAncGFzc3dvcmQnIHx8XG4gICAgICBsb2dpbkluZm8udXNlciA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAvLyBEb24ndCBoYW5kbGUgZXJyb3JzIHVubGVzcyB0aGV5IGFyZSBkdWUgdG8gaW5jb3JyZWN0IHBhc3N3b3JkXG4gICAgICAobG9naW5JbmZvLmVycm9yICE9PSB1bmRlZmluZWQgJiYgbG9naW5JbmZvLmVycm9yLnJlYXNvbiAhPT0gJ0luY29ycmVjdCBwYXNzd29yZCcpXG4gICAgKSB7XG4gICAgICByZXR1cm4gbG9naW5JbmZvLmFsbG93ZWQ7XG4gICAgfVxuXG4gICAgLy8gSWYgdGhlcmUgd2FzIG5vIGxvZ2luIGVycm9yIGFuZCB0aGUgYWNjb3VudCBpcyBOT1QgbG9ja2VkLCBkb24ndCBpbnRlcnJ1cHRcbiAgICBjb25zdCB1bmxvY2tUaW1lID0gS25vd25Vc2VyLnVubG9ja1RpbWUobG9naW5JbmZvLnVzZXIpO1xuICAgIGlmIChsb2dpbkluZm8uZXJyb3IgPT09IHVuZGVmaW5lZCAmJiB1bmxvY2tUaW1lID09PSAwKSB7XG4gICAgICByZXR1cm4gbG9naW5JbmZvLmFsbG93ZWQ7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMudW5jaGFuZ2VkU2V0dGluZ3MgaW5zdGFuY2VvZiBGdW5jdGlvbikge1xuICAgICAgdGhpcy5zZXR0aW5ncyA9IHRoaXMudW5jaGFuZ2VkU2V0dGluZ3MobG9naW5JbmZvLnVzZXIpO1xuICAgICAgdGhpcy52YWxpZGF0ZVNldHRpbmdzKCk7XG4gICAgfVxuXG4gICAgY29uc3QgdXNlcklkID0gbG9naW5JbmZvLnVzZXIuX2lkO1xuICAgIGxldCBmYWlsZWRBdHRlbXB0cyA9IDEgKyBLbm93blVzZXIuZmFpbGVkQXR0ZW1wdHMobG9naW5JbmZvLnVzZXIpO1xuICAgIGNvbnN0IGZpcnN0RmFpbGVkQXR0ZW1wdCA9IEtub3duVXNlci5maXJzdEZhaWxlZEF0dGVtcHQobG9naW5JbmZvLnVzZXIpO1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gTnVtYmVyKG5ldyBEYXRlKCkpO1xuXG4gICAgY29uc3QgY2FuUmVzZXQgPSAoY3VycmVudFRpbWUgLSBmaXJzdEZhaWxlZEF0dGVtcHQpID4gKDEwMDAgKiB0aGlzLnNldHRpbmdzLmZhaWx1cmVXaW5kb3cpO1xuICAgIGlmIChjYW5SZXNldCkge1xuICAgICAgZmFpbGVkQXR0ZW1wdHMgPSAxO1xuICAgICAgS25vd25Vc2VyLnJlc2V0QXR0ZW1wdHMoZmFpbGVkQXR0ZW1wdHMsIHVzZXJJZCk7XG4gICAgfVxuXG4gICAgY29uc3QgY2FuSW5jcmVtZW50ID0gZmFpbGVkQXR0ZW1wdHMgPCB0aGlzLnNldHRpbmdzLmZhaWx1cmVzQmVmb3JlTG9ja291dDtcbiAgICBpZiAoY2FuSW5jcmVtZW50KSB7XG4gICAgICBLbm93blVzZXIuaW5jcmVtZW50QXR0ZW1wdHMoZmFpbGVkQXR0ZW1wdHMsIHVzZXJJZCk7XG4gICAgfVxuXG4gICAgY29uc3QgbWF4QXR0ZW1wdHNBbGxvd2VkID0gdGhpcy5zZXR0aW5ncy5mYWlsdXJlc0JlZm9yZUxvY2tvdXQ7XG4gICAgY29uc3QgYXR0ZW1wdHNSZW1haW5pbmcgPSBtYXhBdHRlbXB0c0FsbG93ZWQgLSBmYWlsZWRBdHRlbXB0cztcbiAgICBpZiAodW5sb2NrVGltZSA+IGN1cnJlbnRUaW1lKSB7XG4gICAgICBsZXQgZHVyYXRpb24gPSB1bmxvY2tUaW1lIC0gY3VycmVudFRpbWU7XG4gICAgICBkdXJhdGlvbiA9IE1hdGguY2VpbChkdXJhdGlvbiAvIDEwMDApO1xuICAgICAgZHVyYXRpb24gPSBkdXJhdGlvbiA+IDEgPyBkdXJhdGlvbiA6IDE7XG4gICAgICBLbm93blVzZXIudG9vTWFueUF0dGVtcHRzKGR1cmF0aW9uKTtcbiAgICB9XG4gICAgaWYgKGZhaWxlZEF0dGVtcHRzID09PSBtYXhBdHRlbXB0c0FsbG93ZWQpIHtcbiAgICAgIHRoaXMuc2V0TmV3VW5sb2NrVGltZShmYWlsZWRBdHRlbXB0cywgdXNlcklkKTtcblxuICAgICAgbGV0IGR1cmF0aW9uID0gdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kO1xuICAgICAgZHVyYXRpb24gPSBNYXRoLmNlaWwoZHVyYXRpb24pO1xuICAgICAgZHVyYXRpb24gPSBkdXJhdGlvbiA+IDEgPyBkdXJhdGlvbiA6IDE7XG4gICAgICByZXR1cm4gS25vd25Vc2VyLnRvb01hbnlBdHRlbXB0cyhkdXJhdGlvbik7XG4gICAgfVxuICAgIHJldHVybiBLbm93blVzZXIuaW5jb3JyZWN0UGFzc3dvcmQoXG4gICAgICBmYWlsZWRBdHRlbXB0cyxcbiAgICAgIG1heEF0dGVtcHRzQWxsb3dlZCxcbiAgICAgIGF0dGVtcHRzUmVtYWluaW5nLFxuICAgICk7XG4gIH1cblxuICBzdGF0aWMgcmVzZXRBdHRlbXB0cyhcbiAgICBmYWlsZWRBdHRlbXB0cyxcbiAgICB1c2VySWQsXG4gICkge1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gTnVtYmVyKG5ldyBEYXRlKCkpO1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBfaWQ6IHVzZXJJZCB9O1xuICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LmZhaWxlZEF0dGVtcHRzJzogZmFpbGVkQXR0ZW1wdHMsXG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0Lmxhc3RGYWlsZWRBdHRlbXB0JzogY3VycmVudFRpbWUsXG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LmZpcnN0RmFpbGVkQXR0ZW1wdCc6IGN1cnJlbnRUaW1lLFxuICAgICAgfSxcbiAgICB9O1xuICAgIE1ldGVvci51c2Vycy51cGRhdGUocXVlcnksIGRhdGEpO1xuICB9XG5cbiAgc3RhdGljIGluY3JlbWVudEF0dGVtcHRzKFxuICAgIGZhaWxlZEF0dGVtcHRzLFxuICAgIHVzZXJJZCxcbiAgKSB7XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBOdW1iZXIobmV3IERhdGUoKSk7XG4gICAgY29uc3QgcXVlcnkgPSB7IF9pZDogdXNlcklkIH07XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQuZmFpbGVkQXR0ZW1wdHMnOiBmYWlsZWRBdHRlbXB0cyxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQubGFzdEZhaWxlZEF0dGVtcHQnOiBjdXJyZW50VGltZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHF1ZXJ5LCBkYXRhKTtcbiAgfVxuXG4gIHNldE5ld1VubG9ja1RpbWUoXG4gICAgZmFpbGVkQXR0ZW1wdHMsXG4gICAgdXNlcklkLFxuICApIHtcbiAgICBjb25zdCBjdXJyZW50VGltZSA9IE51bWJlcihuZXcgRGF0ZSgpKTtcbiAgICBjb25zdCBuZXdVbmxvY2tUaW1lID0gKDEwMDAgKiB0aGlzLnNldHRpbmdzLmxvY2tvdXRQZXJpb2QpICsgY3VycmVudFRpbWU7XG4gICAgY29uc3QgcXVlcnkgPSB7IF9pZDogdXNlcklkIH07XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQuZmFpbGVkQXR0ZW1wdHMnOiBmYWlsZWRBdHRlbXB0cyxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQubGFzdEZhaWxlZEF0dGVtcHQnOiBjdXJyZW50VGltZSxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IG5ld1VubG9ja1RpbWUsXG4gICAgICB9LFxuICAgIH07XG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShxdWVyeSwgZGF0YSk7XG4gICAgTWV0ZW9yLnNldFRpbWVvdXQoXG4gICAgICBLbm93blVzZXIudW5sb2NrQWNjb3VudC5iaW5kKG51bGwsIHVzZXJJZCksXG4gICAgICB0aGlzLnNldHRpbmdzLmxvY2tvdXRQZXJpb2QgKiAxMDAwLFxuICAgICk7XG4gIH1cblxuICBzdGF0aWMgb25Mb2dpbihsb2dpbkluZm8pIHtcbiAgICBpZiAobG9naW5JbmZvLnR5cGUgIT09ICdwYXNzd29yZCcpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgdXNlcklkID0gbG9naW5JbmZvLnVzZXIuX2lkO1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBfaWQ6IHVzZXJJZCB9O1xuICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICAkdW5zZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IDAsXG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LmZhaWxlZEF0dGVtcHRzJzogMCxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHF1ZXJ5LCBkYXRhKTtcbiAgfVxuXG4gIHN0YXRpYyBpbmNvcnJlY3RQYXNzd29yZChcbiAgICBmYWlsZWRBdHRlbXB0cyxcbiAgICBtYXhBdHRlbXB0c0FsbG93ZWQsXG4gICAgYXR0ZW1wdHNSZW1haW5pbmcsXG4gICkge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICA0MDMsXG4gICAgICAnSW5jb3JyZWN0IHBhc3N3b3JkJyxcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbWVzc2FnZTogJ0luY29ycmVjdCBwYXNzd29yZCcsXG4gICAgICAgIGZhaWxlZEF0dGVtcHRzLFxuICAgICAgICBtYXhBdHRlbXB0c0FsbG93ZWQsXG4gICAgICAgIGF0dGVtcHRzUmVtYWluaW5nLFxuICAgICAgfSksXG4gICAgKTtcbiAgfVxuXG4gIHN0YXRpYyB0b29NYW55QXR0ZW1wdHMoZHVyYXRpb24pIHtcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgNDAzLFxuICAgICAgJ1RvbyBtYW55IGF0dGVtcHRzJyxcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbWVzc2FnZTogJ1dyb25nIHBhc3N3b3JkcyB3ZXJlIHN1Ym1pdHRlZCB0b28gbWFueSB0aW1lcy4gQWNjb3VudCBpcyBsb2NrZWQgZm9yIGEgd2hpbGUuJyxcbiAgICAgICAgZHVyYXRpb24sXG4gICAgICB9KSxcbiAgICApO1xuICB9XG5cbiAgc3RhdGljIGtub3duVXNlcnMoKSB7XG4gICAgbGV0IGtub3duVXNlcnM7XG4gICAgdHJ5IHtcbiAgICAgIGtub3duVXNlcnMgPSBNZXRlb3Iuc2V0dGluZ3NbJ2FjY291bnRzLWxvY2tvdXQnXS5rbm93blVzZXJzO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGtub3duVXNlcnMgPSBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIGtub3duVXNlcnMgfHwgZmFsc2U7XG4gIH1cblxuICBzdGF0aWMgdW5sb2NrVGltZSh1c2VyKSB7XG4gICAgbGV0IHVubG9ja1RpbWU7XG4gICAgdHJ5IHtcbiAgICAgIHVubG9ja1RpbWUgPSB1c2VyLnNlcnZpY2VzWydhY2NvdW50cy1sb2Nrb3V0J10udW5sb2NrVGltZTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB1bmxvY2tUaW1lID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIHVubG9ja1RpbWUgfHwgMDtcbiAgfVxuXG4gIHN0YXRpYyBmYWlsZWRBdHRlbXB0cyh1c2VyKSB7XG4gICAgbGV0IGZhaWxlZEF0dGVtcHRzO1xuICAgIHRyeSB7XG4gICAgICBmYWlsZWRBdHRlbXB0cyA9IHVzZXIuc2VydmljZXNbJ2FjY291bnRzLWxvY2tvdXQnXS5mYWlsZWRBdHRlbXB0cztcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBmYWlsZWRBdHRlbXB0cyA9IDA7XG4gICAgfVxuICAgIHJldHVybiBmYWlsZWRBdHRlbXB0cyB8fCAwO1xuICB9XG5cbiAgc3RhdGljIGxhc3RGYWlsZWRBdHRlbXB0KHVzZXIpIHtcbiAgICBsZXQgbGFzdEZhaWxlZEF0dGVtcHQ7XG4gICAgdHJ5IHtcbiAgICAgIGxhc3RGYWlsZWRBdHRlbXB0ID0gdXNlci5zZXJ2aWNlc1snYWNjb3VudHMtbG9ja291dCddLmxhc3RGYWlsZWRBdHRlbXB0O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGxhc3RGYWlsZWRBdHRlbXB0ID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIGxhc3RGYWlsZWRBdHRlbXB0IHx8IDA7XG4gIH1cblxuICBzdGF0aWMgZmlyc3RGYWlsZWRBdHRlbXB0KHVzZXIpIHtcbiAgICBsZXQgZmlyc3RGYWlsZWRBdHRlbXB0O1xuICAgIHRyeSB7XG4gICAgICBmaXJzdEZhaWxlZEF0dGVtcHQgPSB1c2VyLnNlcnZpY2VzWydhY2NvdW50cy1sb2Nrb3V0J10uZmlyc3RGYWlsZWRBdHRlbXB0O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGZpcnN0RmFpbGVkQXR0ZW1wdCA9IDA7XG4gICAgfVxuICAgIHJldHVybiBmaXJzdEZhaWxlZEF0dGVtcHQgfHwgMDtcbiAgfVxuXG4gIHN0YXRpYyB1bmxvY2tBY2NvdW50KHVzZXJJZCkge1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBfaWQ6IHVzZXJJZCB9O1xuICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICAkdW5zZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IDAsXG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LmZhaWxlZEF0dGVtcHRzJzogMCxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHF1ZXJ5LCBkYXRhKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBLbm93blVzZXI7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IF9BY2NvdW50c0xvY2tvdXRDb2xsZWN0aW9uIGZyb20gJy4vYWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbic7XG5cbmNsYXNzIFVua25vd25Vc2VyIHtcbiAgY29uc3RydWN0b3IoXG4gICAgc2V0dGluZ3MsXG4gICAge1xuICAgICAgQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbiA9IF9BY2NvdW50c0xvY2tvdXRDb2xsZWN0aW9uLFxuICAgIH0gPSB7fSxcbiAgKSB7XG4gICAgdGhpcy5BY2NvdW50c0xvY2tvdXRDb2xsZWN0aW9uID0gQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbjtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICBzdGFydHVwKCkge1xuICAgIGlmICghKHRoaXMuc2V0dGluZ3MgaW5zdGFuY2VvZiBGdW5jdGlvbikpIHtcbiAgICAgIHRoaXMudXBkYXRlU2V0dGluZ3MoKTtcbiAgICB9XG4gICAgdGhpcy5zY2hlZHVsZVVubG9ja3NGb3JMb2NrZWRBY2NvdW50cygpO1xuICAgIHRoaXMudW5sb2NrQWNjb3VudHNJZkxvY2tvdXRBbHJlYWR5RXhwaXJlZCgpO1xuICAgIHRoaXMuaG9va0ludG9BY2NvdW50cygpO1xuICB9XG5cbiAgdXBkYXRlU2V0dGluZ3MoKSB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSBVbmtub3duVXNlci51bmtub3duVXNlcnMoKTtcbiAgICBpZiAoc2V0dGluZ3MpIHtcbiAgICAgIHNldHRpbmdzLmZvckVhY2goZnVuY3Rpb24gdXBkYXRlU2V0dGluZyh7IGtleSwgdmFsdWUgfSkge1xuICAgICAgICB0aGlzLnNldHRpbmdzW2tleV0gPSB2YWx1ZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aGlzLnZhbGlkYXRlU2V0dGluZ3MoKTtcbiAgfVxuXG4gIHZhbGlkYXRlU2V0dGluZ3MoKSB7XG4gICAgaWYgKFxuICAgICAgIXRoaXMuc2V0dGluZ3MuZmFpbHVyZXNCZWZvcmVMb2Nrb3V0IHx8XG4gICAgICB0aGlzLnNldHRpbmdzLmZhaWx1cmVzQmVmb3JlTG9ja291dCA8IDBcbiAgICApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignXCJmYWlsdXJlc0JlZm9yZUxvY2tvdXRcIiBpcyBub3QgcG9zaXRpdmUgaW50ZWdlcicpO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICAhdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kIHx8XG4gICAgICB0aGlzLnNldHRpbmdzLmxvY2tvdXRQZXJpb2QgPCAwXG4gICAgKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wibG9ja291dFBlcmlvZFwiIGlzIG5vdCBwb3NpdGl2ZSBpbnRlZ2VyJyk7XG4gICAgfVxuICAgIGlmIChcbiAgICAgICF0aGlzLnNldHRpbmdzLmZhaWx1cmVXaW5kb3cgfHxcbiAgICAgIHRoaXMuc2V0dGluZ3MuZmFpbHVyZVdpbmRvdyA8IDBcbiAgICApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignXCJmYWlsdXJlV2luZG93XCIgaXMgbm90IHBvc2l0aXZlIGludGVnZXInKTtcbiAgICB9XG4gIH1cblxuICBzY2hlZHVsZVVubG9ja3NGb3JMb2NrZWRBY2NvdW50cygpIHtcbiAgICBjb25zdCBsb2NrZWRBY2NvdW50c0N1cnNvciA9IHRoaXMuQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbi5maW5kKFxuICAgICAge1xuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC51bmxvY2tUaW1lJzoge1xuICAgICAgICAgICRndDogTnVtYmVyKG5ldyBEYXRlKCkpLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IDEsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICk7XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBOdW1iZXIobmV3IERhdGUoKSk7XG4gICAgbG9ja2VkQWNjb3VudHNDdXJzb3IuZm9yRWFjaCgoY29ubmVjdGlvbikgPT4ge1xuICAgICAgbGV0IGxvY2tEdXJhdGlvbiA9IHRoaXMudW5sb2NrVGltZShjb25uZWN0aW9uKSAtIGN1cnJlbnRUaW1lO1xuICAgICAgaWYgKGxvY2tEdXJhdGlvbiA+PSB0aGlzLnNldHRpbmdzLmxvY2tvdXRQZXJpb2QpIHtcbiAgICAgICAgbG9ja0R1cmF0aW9uID0gdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kICogMTAwMDtcbiAgICAgIH1cbiAgICAgIGlmIChsb2NrRHVyYXRpb24gPD0gMSkge1xuICAgICAgICBsb2NrRHVyYXRpb24gPSAxO1xuICAgICAgfVxuICAgICAgTWV0ZW9yLnNldFRpbWVvdXQoXG4gICAgICAgIHRoaXMudW5sb2NrQWNjb3VudC5iaW5kKHRoaXMsIGNvbm5lY3Rpb24uY2xpZW50QWRkcmVzcyksXG4gICAgICAgIGxvY2tEdXJhdGlvbixcbiAgICAgICk7XG4gICAgfSk7XG4gIH1cblxuICB1bmxvY2tBY2NvdW50c0lmTG9ja291dEFscmVhZHlFeHBpcmVkKCkge1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gTnVtYmVyKG5ldyBEYXRlKCkpO1xuICAgIGNvbnN0IHF1ZXJ5ID0ge1xuICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IHtcbiAgICAgICAgJGx0OiBjdXJyZW50VGltZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgJHVuc2V0OiB7XG4gICAgICAgICdzZXJ2aWNlcy5hY2NvdW50cy1sb2Nrb3V0LnVubG9ja1RpbWUnOiAwLFxuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC5mYWlsZWRBdHRlbXB0cyc6IDAsXG4gICAgICB9LFxuICAgIH07XG4gICAgdGhpcy5BY2NvdW50c0xvY2tvdXRDb2xsZWN0aW9uLnVwZGF0ZShxdWVyeSwgZGF0YSk7XG4gIH1cblxuICBob29rSW50b0FjY291bnRzKCkge1xuICAgIEFjY291bnRzLnZhbGlkYXRlTG9naW5BdHRlbXB0KHRoaXMudmFsaWRhdGVMb2dpbkF0dGVtcHQuYmluZCh0aGlzKSk7XG4gICAgQWNjb3VudHMub25Mb2dpbih0aGlzLm9uTG9naW4uYmluZCh0aGlzKSk7XG4gIH1cblxuICB2YWxpZGF0ZUxvZ2luQXR0ZW1wdChsb2dpbkluZm8pIHtcbiAgICAvLyBkb24ndCBpbnRlcnJ1cHQgbm9uLXBhc3N3b3JkIGxvZ2luc1xuICAgIGlmIChcbiAgICAgIGxvZ2luSW5mby50eXBlICE9PSAncGFzc3dvcmQnIHx8XG4gICAgICBsb2dpbkluZm8udXNlciAhPT0gdW5kZWZpbmVkIHx8XG4gICAgICBsb2dpbkluZm8uZXJyb3IgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgbG9naW5JbmZvLmVycm9yLnJlYXNvbiAhPT0gJ1VzZXIgbm90IGZvdW5kJ1xuICAgICkge1xuICAgICAgcmV0dXJuIGxvZ2luSW5mby5hbGxvd2VkO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnNldHRpbmdzIGluc3RhbmNlb2YgRnVuY3Rpb24pIHtcbiAgICAgIHRoaXMuc2V0dGluZ3MgPSB0aGlzLnNldHRpbmdzKGxvZ2luSW5mby5jb25uZWN0aW9uKTtcbiAgICAgIHRoaXMudmFsaWRhdGVTZXR0aW5ncygpO1xuICAgIH1cblxuICAgIGNvbnN0IGNsaWVudEFkZHJlc3MgPSBsb2dpbkluZm8uY29ubmVjdGlvbi5jbGllbnRBZGRyZXNzO1xuICAgIGNvbnN0IHVubG9ja1RpbWUgPSB0aGlzLnVubG9ja1RpbWUobG9naW5JbmZvLmNvbm5lY3Rpb24pO1xuICAgIGxldCBmYWlsZWRBdHRlbXB0cyA9IDEgKyB0aGlzLmZhaWxlZEF0dGVtcHRzKGxvZ2luSW5mby5jb25uZWN0aW9uKTtcbiAgICBjb25zdCBmaXJzdEZhaWxlZEF0dGVtcHQgPSB0aGlzLmZpcnN0RmFpbGVkQXR0ZW1wdChsb2dpbkluZm8uY29ubmVjdGlvbik7XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBOdW1iZXIobmV3IERhdGUoKSk7XG5cbiAgICBjb25zdCBjYW5SZXNldCA9IChjdXJyZW50VGltZSAtIGZpcnN0RmFpbGVkQXR0ZW1wdCkgPiAoMTAwMCAqIHRoaXMuc2V0dGluZ3MuZmFpbHVyZVdpbmRvdyk7XG4gICAgaWYgKGNhblJlc2V0KSB7XG4gICAgICBmYWlsZWRBdHRlbXB0cyA9IDE7XG4gICAgICB0aGlzLnJlc2V0QXR0ZW1wdHMoZmFpbGVkQXR0ZW1wdHMsIGNsaWVudEFkZHJlc3MpO1xuICAgIH1cblxuICAgIGNvbnN0IGNhbkluY3JlbWVudCA9IGZhaWxlZEF0dGVtcHRzIDwgdGhpcy5zZXR0aW5ncy5mYWlsdXJlc0JlZm9yZUxvY2tvdXQ7XG4gICAgaWYgKGNhbkluY3JlbWVudCkge1xuICAgICAgdGhpcy5pbmNyZW1lbnRBdHRlbXB0cyhmYWlsZWRBdHRlbXB0cywgY2xpZW50QWRkcmVzcyk7XG4gICAgfVxuXG4gICAgY29uc3QgbWF4QXR0ZW1wdHNBbGxvd2VkID0gdGhpcy5zZXR0aW5ncy5mYWlsdXJlc0JlZm9yZUxvY2tvdXQ7XG4gICAgY29uc3QgYXR0ZW1wdHNSZW1haW5pbmcgPSBtYXhBdHRlbXB0c0FsbG93ZWQgLSBmYWlsZWRBdHRlbXB0cztcbiAgICBpZiAodW5sb2NrVGltZSA+IGN1cnJlbnRUaW1lKSB7XG4gICAgICBsZXQgZHVyYXRpb24gPSB1bmxvY2tUaW1lIC0gY3VycmVudFRpbWU7XG4gICAgICBkdXJhdGlvbiA9IE1hdGguY2VpbChkdXJhdGlvbiAvIDEwMDApO1xuICAgICAgZHVyYXRpb24gPSBkdXJhdGlvbiA+IDEgPyBkdXJhdGlvbiA6IDE7XG4gICAgICBVbmtub3duVXNlci50b29NYW55QXR0ZW1wdHMoZHVyYXRpb24pO1xuICAgIH1cbiAgICBpZiAoZmFpbGVkQXR0ZW1wdHMgPT09IG1heEF0dGVtcHRzQWxsb3dlZCkge1xuICAgICAgdGhpcy5zZXROZXdVbmxvY2tUaW1lKGZhaWxlZEF0dGVtcHRzLCBjbGllbnRBZGRyZXNzKTtcblxuICAgICAgbGV0IGR1cmF0aW9uID0gdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kO1xuICAgICAgZHVyYXRpb24gPSBNYXRoLmNlaWwoZHVyYXRpb24pO1xuICAgICAgZHVyYXRpb24gPSBkdXJhdGlvbiA+IDEgPyBkdXJhdGlvbiA6IDE7XG4gICAgICByZXR1cm4gVW5rbm93blVzZXIudG9vTWFueUF0dGVtcHRzKGR1cmF0aW9uKTtcbiAgICB9XG4gICAgcmV0dXJuIFVua25vd25Vc2VyLnVzZXJOb3RGb3VuZChcbiAgICAgIGZhaWxlZEF0dGVtcHRzLFxuICAgICAgbWF4QXR0ZW1wdHNBbGxvd2VkLFxuICAgICAgYXR0ZW1wdHNSZW1haW5pbmcsXG4gICAgKTtcbiAgfVxuXG4gIHJlc2V0QXR0ZW1wdHMoXG4gICAgZmFpbGVkQXR0ZW1wdHMsXG4gICAgY2xpZW50QWRkcmVzcyxcbiAgKSB7XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBOdW1iZXIobmV3IERhdGUoKSk7XG4gICAgY29uc3QgcXVlcnkgPSB7IGNsaWVudEFkZHJlc3MgfTtcbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgJHNldDoge1xuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC5mYWlsZWRBdHRlbXB0cyc6IGZhaWxlZEF0dGVtcHRzLFxuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC5sYXN0RmFpbGVkQXR0ZW1wdCc6IGN1cnJlbnRUaW1lLFxuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC5maXJzdEZhaWxlZEF0dGVtcHQnOiBjdXJyZW50VGltZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICB0aGlzLkFjY291bnRzTG9ja291dENvbGxlY3Rpb24udXBzZXJ0KHF1ZXJ5LCBkYXRhKTtcbiAgfVxuXG4gIGluY3JlbWVudEF0dGVtcHRzKFxuICAgIGZhaWxlZEF0dGVtcHRzLFxuICAgIGNsaWVudEFkZHJlc3MsXG4gICkge1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gTnVtYmVyKG5ldyBEYXRlKCkpO1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBjbGllbnRBZGRyZXNzIH07XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQuZmFpbGVkQXR0ZW1wdHMnOiBmYWlsZWRBdHRlbXB0cyxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQubGFzdEZhaWxlZEF0dGVtcHQnOiBjdXJyZW50VGltZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICB0aGlzLkFjY291bnRzTG9ja291dENvbGxlY3Rpb24udXBzZXJ0KHF1ZXJ5LCBkYXRhKTtcbiAgfVxuXG4gIHNldE5ld1VubG9ja1RpbWUoXG4gICAgZmFpbGVkQXR0ZW1wdHMsXG4gICAgY2xpZW50QWRkcmVzcyxcbiAgKSB7XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBOdW1iZXIobmV3IERhdGUoKSk7XG4gICAgY29uc3QgbmV3VW5sb2NrVGltZSA9ICgxMDAwICogdGhpcy5zZXR0aW5ncy5sb2Nrb3V0UGVyaW9kKSArIGN1cnJlbnRUaW1lO1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBjbGllbnRBZGRyZXNzIH07XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQuZmFpbGVkQXR0ZW1wdHMnOiBmYWlsZWRBdHRlbXB0cyxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQubGFzdEZhaWxlZEF0dGVtcHQnOiBjdXJyZW50VGltZSxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQudW5sb2NrVGltZSc6IG5ld1VubG9ja1RpbWUsXG4gICAgICB9LFxuICAgIH07XG4gICAgdGhpcy5BY2NvdW50c0xvY2tvdXRDb2xsZWN0aW9uLnVwc2VydChxdWVyeSwgZGF0YSk7XG4gICAgTWV0ZW9yLnNldFRpbWVvdXQoXG4gICAgICB0aGlzLnVubG9ja0FjY291bnQuYmluZCh0aGlzLCBjbGllbnRBZGRyZXNzKSxcbiAgICAgIHRoaXMuc2V0dGluZ3MubG9ja291dFBlcmlvZCAqIDEwMDAsXG4gICAgKTtcbiAgfVxuXG4gIG9uTG9naW4obG9naW5JbmZvKSB7XG4gICAgaWYgKGxvZ2luSW5mby50eXBlICE9PSAncGFzc3dvcmQnKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNsaWVudEFkZHJlc3MgPSBsb2dpbkluZm8uY29ubmVjdGlvbi5jbGllbnRBZGRyZXNzO1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBjbGllbnRBZGRyZXNzIH07XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICR1bnNldDoge1xuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC51bmxvY2tUaW1lJzogMCxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQuZmFpbGVkQXR0ZW1wdHMnOiAwLFxuICAgICAgfSxcbiAgICB9O1xuICAgIHRoaXMuQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbi51cGRhdGUocXVlcnksIGRhdGEpO1xuICB9XG5cbiAgc3RhdGljIHVzZXJOb3RGb3VuZChcbiAgICBmYWlsZWRBdHRlbXB0cyxcbiAgICBtYXhBdHRlbXB0c0FsbG93ZWQsXG4gICAgYXR0ZW1wdHNSZW1haW5pbmcsXG4gICkge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICA0MDMsXG4gICAgICAnVXNlciBub3QgZm91bmQnLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBtZXNzYWdlOiAnVXNlciBub3QgZm91bmQnLFxuICAgICAgICBmYWlsZWRBdHRlbXB0cyxcbiAgICAgICAgbWF4QXR0ZW1wdHNBbGxvd2VkLFxuICAgICAgICBhdHRlbXB0c1JlbWFpbmluZyxcbiAgICAgIH0pLFxuICAgICk7XG4gIH1cblxuICBzdGF0aWMgdG9vTWFueUF0dGVtcHRzKGR1cmF0aW9uKSB7XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcbiAgICAgIDQwMyxcbiAgICAgICdUb28gbWFueSBhdHRlbXB0cycsXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG1lc3NhZ2U6ICdXcm9uZyBlbWFpbHMgd2VyZSBzdWJtaXR0ZWQgdG9vIG1hbnkgdGltZXMuIEFjY291bnQgaXMgbG9ja2VkIGZvciBhIHdoaWxlLicsXG4gICAgICAgIGR1cmF0aW9uLFxuICAgICAgfSksXG4gICAgKTtcbiAgfVxuXG4gIHN0YXRpYyB1bmtub3duVXNlcnMoKSB7XG4gICAgbGV0IHVua25vd25Vc2VycztcbiAgICB0cnkge1xuICAgICAgdW5rbm93blVzZXJzID0gTWV0ZW9yLnNldHRpbmdzWydhY2NvdW50cy1sb2Nrb3V0J10udW5rbm93blVzZXJzO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHVua25vd25Vc2VycyA9IGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdW5rbm93blVzZXJzIHx8IGZhbHNlO1xuICB9XG5cbiAgZmluZE9uZUJ5Q29ubmVjdGlvbihjb25uZWN0aW9uKSB7XG4gICAgcmV0dXJuIHRoaXMuQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbi5maW5kT25lKHtcbiAgICAgIGNsaWVudEFkZHJlc3M6IGNvbm5lY3Rpb24uY2xpZW50QWRkcmVzcyxcbiAgICB9KTtcbiAgfVxuXG4gIHVubG9ja1RpbWUoY29ubmVjdGlvbikge1xuICAgIGNvbm5lY3Rpb24gPSB0aGlzLmZpbmRPbmVCeUNvbm5lY3Rpb24oY29ubmVjdGlvbik7XG4gICAgbGV0IHVubG9ja1RpbWU7XG4gICAgdHJ5IHtcbiAgICAgIHVubG9ja1RpbWUgPSBjb25uZWN0aW9uLnNlcnZpY2VzWydhY2NvdW50cy1sb2Nrb3V0J10udW5sb2NrVGltZTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB1bmxvY2tUaW1lID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIHVubG9ja1RpbWUgfHwgMDtcbiAgfVxuXG4gIGZhaWxlZEF0dGVtcHRzKGNvbm5lY3Rpb24pIHtcbiAgICBjb25uZWN0aW9uID0gdGhpcy5maW5kT25lQnlDb25uZWN0aW9uKGNvbm5lY3Rpb24pO1xuICAgIGxldCBmYWlsZWRBdHRlbXB0cztcbiAgICB0cnkge1xuICAgICAgZmFpbGVkQXR0ZW1wdHMgPSBjb25uZWN0aW9uLnNlcnZpY2VzWydhY2NvdW50cy1sb2Nrb3V0J10uZmFpbGVkQXR0ZW1wdHM7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgZmFpbGVkQXR0ZW1wdHMgPSAwO1xuICAgIH1cbiAgICByZXR1cm4gZmFpbGVkQXR0ZW1wdHMgfHwgMDtcbiAgfVxuXG4gIGxhc3RGYWlsZWRBdHRlbXB0KGNvbm5lY3Rpb24pIHtcbiAgICBjb25uZWN0aW9uID0gdGhpcy5maW5kT25lQnlDb25uZWN0aW9uKGNvbm5lY3Rpb24pO1xuICAgIGxldCBsYXN0RmFpbGVkQXR0ZW1wdDtcbiAgICB0cnkge1xuICAgICAgbGFzdEZhaWxlZEF0dGVtcHQgPSBjb25uZWN0aW9uLnNlcnZpY2VzWydhY2NvdW50cy1sb2Nrb3V0J10ubGFzdEZhaWxlZEF0dGVtcHQ7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbGFzdEZhaWxlZEF0dGVtcHQgPSAwO1xuICAgIH1cbiAgICByZXR1cm4gbGFzdEZhaWxlZEF0dGVtcHQgfHwgMDtcbiAgfVxuXG4gIGZpcnN0RmFpbGVkQXR0ZW1wdChjb25uZWN0aW9uKSB7XG4gICAgY29ubmVjdGlvbiA9IHRoaXMuZmluZE9uZUJ5Q29ubmVjdGlvbihjb25uZWN0aW9uKTtcbiAgICBsZXQgZmlyc3RGYWlsZWRBdHRlbXB0O1xuICAgIHRyeSB7XG4gICAgICBmaXJzdEZhaWxlZEF0dGVtcHQgPSBjb25uZWN0aW9uLnNlcnZpY2VzWydhY2NvdW50cy1sb2Nrb3V0J10uZmlyc3RGYWlsZWRBdHRlbXB0O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGZpcnN0RmFpbGVkQXR0ZW1wdCA9IDA7XG4gICAgfVxuICAgIHJldHVybiBmaXJzdEZhaWxlZEF0dGVtcHQgfHwgMDtcbiAgfVxuXG4gIHVubG9ja0FjY291bnQoY2xpZW50QWRkcmVzcykge1xuICAgIGNvbnN0IHF1ZXJ5ID0geyBjbGllbnRBZGRyZXNzIH07XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICR1bnNldDoge1xuICAgICAgICAnc2VydmljZXMuYWNjb3VudHMtbG9ja291dC51bmxvY2tUaW1lJzogMCxcbiAgICAgICAgJ3NlcnZpY2VzLmFjY291bnRzLWxvY2tvdXQuZmFpbGVkQXR0ZW1wdHMnOiAwLFxuICAgICAgfSxcbiAgICB9O1xuICAgIHRoaXMuQWNjb3VudHNMb2Nrb3V0Q29sbGVjdGlvbi51cGRhdGUocXVlcnksIGRhdGEpO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFVua25vd25Vc2VyO1xuIl19
