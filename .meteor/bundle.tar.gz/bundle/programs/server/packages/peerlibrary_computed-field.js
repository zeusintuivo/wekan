(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var dontStop, equalsFunc, ComputedField;

var require = meteorInstall({"node_modules":{"meteor":{"peerlibrary:computed-field":{"lib.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_computed-field/lib.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ComputedField: () => ComputedField
});

class ComputedField {
  constructor(func, equalsFunc, dontStop) {
    // To support passing boolean as the second argument.
    if (_.isBoolean(equalsFunc)) {
      dontStop = equalsFunc;
      equalsFunc = null;
    }

    let handle = null;
    let lastValue = null; // TODO: Provide an option to prevent using view's autorun.
    //       One can wrap code with Blaze._withCurrentView(null, code) to prevent using view's autorun for now.

    let autorun;
    const currentView = Package.blaze && Package.blaze.Blaze && Package.blaze.Blaze.currentView;

    if (currentView) {
      if (currentView._isInRender) {
        // Inside render we cannot use currentView.autorun directly, so we use our own version of it.
        // This allows computed fields to be created inside Blaze template helpers, which are called
        // the first time inside render. While currentView.autorun is disallowed inside render because
        // autorun would be recreated for reach re-render, this is exactly what computed field does
        // anyway so it is OK for use to use autorun in this way.
        autorun = function (f) {
          const templateInstanceFunc = Package.blaze.Blaze.Template._currentTemplateInstanceFunc;
          const comp = Tracker.autorun(c => {
            Package.blaze.Blaze._withCurrentView(currentView, () => {
              Package.blaze.Blaze.Template._withTemplateInstanceFunc(templateInstanceFunc, () => {
                f.call(currentView, c);
              });
            });
          });

          const stopComputation = () => {
            comp.stop();
          };

          currentView.onViewDestroyed(stopComputation);
          comp.onStop(() => {
            currentView.removeViewDestroyedListener(stopComputation);
          });
          return comp;
        };
      } else {
        autorun = f => {
          return currentView.autorun(f);
        };
      }
    } else {
      autorun = Tracker.autorun;
    }

    const startAutorun = function () {
      handle = autorun(function (computation) {
        const value = func();

        if (!lastValue) {
          lastValue = new ReactiveVar(value, equalsFunc);
        } else {
          lastValue.set(value);
        }

        if (!dontStop) {
          Tracker.afterFlush(function () {
            // If there are no dependents anymore, stop the autorun. We will run
            // it again in the getter's flush call if needed.
            if (!lastValue.dep.hasDependents()) {
              getter.stop();
            }
          });
        }
      }); // If something stops our autorun from the outside, we want to know that and update internal state accordingly.
      // This means that if computed field was created inside an autorun, and that autorun is invalided our autorun is
      // stopped. But then computed field might be still around and it might be asked again for the value. We want to
      // restart our autorun in that case. Instead of trying to recompute the stopped autorun.

      if (handle.onStop) {
        handle.onStop(() => {
          handle = null;
        });
      } else {
        // XXX COMPAT WITH METEOR 1.1.0
        const originalStop = handle.stop;

        handle.stop = function () {
          if (handle) {
            originalStop.call(handle);
          }

          handle = null;
        };
      }
    };

    startAutorun();

    const getter = function () {
      // We always flush so that you get the most recent value. This is a noop if autorun was not invalidated.
      getter.flush();
      return lastValue.get();
    }; // We mingle the prototype so that getter instanceof ComputedField is true.


    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(getter, this.constructor.prototype);
    } else {
      getter.__proto__ = this.constructor.prototype;
    }

    getter.toString = function () {
      return "ComputedField{".concat(this(), "}");
    };

    getter.apply = () => {
      return getter();
    };

    getter.call = () => {
      return getter();
    }; // If this autorun is nested in the outside autorun it gets stopped automatically when the outside autorun gets
    // invalidated, so no need to call destroy. But otherwise you should call destroy when the field is not needed anymore.


    getter.stop = function () {
      if (handle != null) {
        handle.stop();
      }

      return handle = null;
    }; // For tests.


    getter._isRunning = () => {
      return !!handle;
    }; // Sometimes you want to force recomputation of the new value before the global Tracker flush is done.
    // This is a noop if autorun was not invalidated.


    getter.flush = () => {
      Tracker.nonreactive(function () {
        if (handle) {
          handle.flush();
        } else {
          // If there is no autorun, create it now. This will do initial recomputation as well. If there
          // will be no dependents after the global flush, autorun will stop (again).
          startAutorun();
        }
      });
    };

    return getter;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/peerlibrary:computed-field/lib.js");

/* Exports */
Package._define("peerlibrary:computed-field", exports, {
  ComputedField: ComputedField
});

})();

//# sourceURL=meteor://💻app/packages/peerlibrary_computed-field.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnk6Y29tcHV0ZWQtZmllbGQvbGliLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkNvbXB1dGVkRmllbGQiLCJjb25zdHJ1Y3RvciIsImZ1bmMiLCJlcXVhbHNGdW5jIiwiZG9udFN0b3AiLCJfIiwiaXNCb29sZWFuIiwiaGFuZGxlIiwibGFzdFZhbHVlIiwiYXV0b3J1biIsImN1cnJlbnRWaWV3IiwiUGFja2FnZSIsImJsYXplIiwiQmxhemUiLCJfaXNJblJlbmRlciIsImYiLCJ0ZW1wbGF0ZUluc3RhbmNlRnVuYyIsIlRlbXBsYXRlIiwiX2N1cnJlbnRUZW1wbGF0ZUluc3RhbmNlRnVuYyIsImNvbXAiLCJUcmFja2VyIiwiYyIsIl93aXRoQ3VycmVudFZpZXciLCJfd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jIiwiY2FsbCIsInN0b3BDb21wdXRhdGlvbiIsInN0b3AiLCJvblZpZXdEZXN0cm95ZWQiLCJvblN0b3AiLCJyZW1vdmVWaWV3RGVzdHJveWVkTGlzdGVuZXIiLCJzdGFydEF1dG9ydW4iLCJjb21wdXRhdGlvbiIsInZhbHVlIiwiUmVhY3RpdmVWYXIiLCJzZXQiLCJhZnRlckZsdXNoIiwiZGVwIiwiaGFzRGVwZW5kZW50cyIsImdldHRlciIsIm9yaWdpbmFsU3RvcCIsImZsdXNoIiwiZ2V0IiwiT2JqZWN0Iiwic2V0UHJvdG90eXBlT2YiLCJwcm90b3R5cGUiLCJfX3Byb3RvX18iLCJ0b1N0cmluZyIsImFwcGx5IiwiX2lzUnVubmluZyIsIm5vbnJlYWN0aXZlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLGVBQWEsRUFBQyxNQUFJQTtBQUFuQixDQUFkOztBQUFPLE1BQU1BLGFBQU4sQ0FBb0I7QUFDekJDLGFBQVcsQ0FBQ0MsSUFBRCxFQUFPQyxVQUFQLEVBQW1CQyxRQUFuQixFQUE2QjtBQUN0QztBQUNBLFFBQUlDLENBQUMsQ0FBQ0MsU0FBRixDQUFZSCxVQUFaLENBQUosRUFBNkI7QUFDM0JDLGNBQVEsR0FBR0QsVUFBWDtBQUNBQSxnQkFBVSxHQUFHLElBQWI7QUFDRDs7QUFFRCxRQUFJSSxNQUFNLEdBQUcsSUFBYjtBQUNBLFFBQUlDLFNBQVMsR0FBRyxJQUFoQixDQVJzQyxDQVV0QztBQUNBOztBQUNBLFFBQUlDLE9BQUo7QUFDQSxVQUFNQyxXQUFXLEdBQUdDLE9BQU8sQ0FBQ0MsS0FBUixJQUFpQkQsT0FBTyxDQUFDQyxLQUFSLENBQWNDLEtBQS9CLElBQXdDRixPQUFPLENBQUNDLEtBQVIsQ0FBY0MsS0FBZCxDQUFvQkgsV0FBaEY7O0FBQ0EsUUFBSUEsV0FBSixFQUFpQjtBQUNmLFVBQUlBLFdBQVcsQ0FBQ0ksV0FBaEIsRUFBNkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBTCxlQUFPLEdBQUcsVUFBVU0sQ0FBVixFQUFhO0FBQ3JCLGdCQUFNQyxvQkFBb0IsR0FBR0wsT0FBTyxDQUFDQyxLQUFSLENBQWNDLEtBQWQsQ0FBb0JJLFFBQXBCLENBQTZCQyw0QkFBMUQ7QUFFQSxnQkFBTUMsSUFBSSxHQUFHQyxPQUFPLENBQUNYLE9BQVIsQ0FBaUJZLENBQUQsSUFBTztBQUNsQ1YsbUJBQU8sQ0FBQ0MsS0FBUixDQUFjQyxLQUFkLENBQW9CUyxnQkFBcEIsQ0FBcUNaLFdBQXJDLEVBQWtELE1BQU07QUFDdERDLHFCQUFPLENBQUNDLEtBQVIsQ0FBY0MsS0FBZCxDQUFvQkksUUFBcEIsQ0FBNkJNLHlCQUE3QixDQUF1RFAsb0JBQXZELEVBQTZFLE1BQU07QUFDakZELGlCQUFDLENBQUNTLElBQUYsQ0FBT2QsV0FBUCxFQUFvQlcsQ0FBcEI7QUFDRCxlQUZEO0FBR0QsYUFKRDtBQUtELFdBTlksQ0FBYjs7QUFRQSxnQkFBTUksZUFBZSxHQUFHLE1BQU07QUFDNUJOLGdCQUFJLENBQUNPLElBQUw7QUFDRCxXQUZEOztBQUdBaEIscUJBQVcsQ0FBQ2lCLGVBQVosQ0FBNEJGLGVBQTVCO0FBQ0FOLGNBQUksQ0FBQ1MsTUFBTCxDQUFZLE1BQU07QUFDaEJsQix1QkFBVyxDQUFDbUIsMkJBQVosQ0FBd0NKLGVBQXhDO0FBQ0QsV0FGRDtBQUlBLGlCQUFPTixJQUFQO0FBQ0QsU0FwQkQ7QUFzQkQsT0E1QkQsTUE2Qks7QUFDSFYsZUFBTyxHQUFJTSxDQUFELElBQU87QUFDZixpQkFBT0wsV0FBVyxDQUFDRCxPQUFaLENBQW9CTSxDQUFwQixDQUFQO0FBQ0QsU0FGRDtBQUdEO0FBQ0YsS0FuQ0QsTUFvQ0s7QUFDSE4sYUFBTyxHQUFHVyxPQUFPLENBQUNYLE9BQWxCO0FBQ0Q7O0FBRUQsVUFBTXFCLFlBQVksR0FBRyxZQUFZO0FBQy9CdkIsWUFBTSxHQUFHRSxPQUFPLENBQUMsVUFBVXNCLFdBQVYsRUFBdUI7QUFDdEMsY0FBTUMsS0FBSyxHQUFHOUIsSUFBSSxFQUFsQjs7QUFFQSxZQUFJLENBQUNNLFNBQUwsRUFBZ0I7QUFDZEEsbUJBQVMsR0FBRyxJQUFJeUIsV0FBSixDQUFnQkQsS0FBaEIsRUFBdUI3QixVQUF2QixDQUFaO0FBQ0QsU0FGRCxNQUdLO0FBQ0hLLG1CQUFTLENBQUMwQixHQUFWLENBQWNGLEtBQWQ7QUFDRDs7QUFFRCxZQUFJLENBQUM1QixRQUFMLEVBQWU7QUFDYmdCLGlCQUFPLENBQUNlLFVBQVIsQ0FBbUIsWUFBWTtBQUM3QjtBQUNBO0FBQ0EsZ0JBQUksQ0FBQzNCLFNBQVMsQ0FBQzRCLEdBQVYsQ0FBY0MsYUFBZCxFQUFMLEVBQW9DO0FBQ2xDQyxvQkFBTSxDQUFDWixJQUFQO0FBQ0Q7QUFDRixXQU5EO0FBT0Q7QUFDRixPQW5CZSxDQUFoQixDQUQrQixDQXNCL0I7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsVUFBSW5CLE1BQU0sQ0FBQ3FCLE1BQVgsRUFBbUI7QUFDakJyQixjQUFNLENBQUNxQixNQUFQLENBQWMsTUFBTTtBQUNsQnJCLGdCQUFNLEdBQUcsSUFBVDtBQUNELFNBRkQ7QUFHRCxPQUpELE1BS0s7QUFDSDtBQUNBLGNBQU1nQyxZQUFZLEdBQUdoQyxNQUFNLENBQUNtQixJQUE1Qjs7QUFDQW5CLGNBQU0sQ0FBQ21CLElBQVAsR0FBYyxZQUFZO0FBQ3hCLGNBQUluQixNQUFKLEVBQVk7QUFDVmdDLHdCQUFZLENBQUNmLElBQWIsQ0FBa0JqQixNQUFsQjtBQUNEOztBQUNEQSxnQkFBTSxHQUFHLElBQVQ7QUFDRCxTQUxEO0FBTUQ7QUFDRixLQXpDRDs7QUEyQ0F1QixnQkFBWTs7QUFFWixVQUFNUSxNQUFNLEdBQUcsWUFBWTtBQUN6QjtBQUNBQSxZQUFNLENBQUNFLEtBQVA7QUFDQSxhQUFPaEMsU0FBUyxDQUFDaUMsR0FBVixFQUFQO0FBQ0QsS0FKRCxDQW5Hc0MsQ0F5R3RDOzs7QUFDQSxRQUFJQyxNQUFNLENBQUNDLGNBQVgsRUFBMkI7QUFDekJELFlBQU0sQ0FBQ0MsY0FBUCxDQUFzQkwsTUFBdEIsRUFBOEIsS0FBS3JDLFdBQUwsQ0FBaUIyQyxTQUEvQztBQUNELEtBRkQsTUFHSztBQUNITixZQUFNLENBQUNPLFNBQVAsR0FBbUIsS0FBSzVDLFdBQUwsQ0FBaUIyQyxTQUFwQztBQUNEOztBQUVETixVQUFNLENBQUNRLFFBQVAsR0FBa0IsWUFBVztBQUMzQixxQ0FBd0IsTUFBeEI7QUFDRCxLQUZEOztBQUlBUixVQUFNLENBQUNTLEtBQVAsR0FBZSxNQUFNO0FBQ25CLGFBQU9ULE1BQU0sRUFBYjtBQUNELEtBRkQ7O0FBSUFBLFVBQU0sQ0FBQ2QsSUFBUCxHQUFjLE1BQU07QUFDbEIsYUFBT2MsTUFBTSxFQUFiO0FBQ0QsS0FGRCxDQXpIc0MsQ0E2SHRDO0FBQ0E7OztBQUNBQSxVQUFNLENBQUNaLElBQVAsR0FBYyxZQUFZO0FBQ3hCLFVBQUluQixNQUFNLElBQUksSUFBZCxFQUFvQjtBQUNsQkEsY0FBTSxDQUFDbUIsSUFBUDtBQUNEOztBQUNELGFBQU9uQixNQUFNLEdBQUcsSUFBaEI7QUFDRCxLQUxELENBL0hzQyxDQXNJdEM7OztBQUNBK0IsVUFBTSxDQUFDVSxVQUFQLEdBQW9CLE1BQU07QUFDeEIsYUFBTyxDQUFDLENBQUN6QyxNQUFUO0FBQ0QsS0FGRCxDQXZJc0MsQ0EySXRDO0FBQ0E7OztBQUNBK0IsVUFBTSxDQUFDRSxLQUFQLEdBQWUsTUFBTTtBQUNuQnBCLGFBQU8sQ0FBQzZCLFdBQVIsQ0FBb0IsWUFBWTtBQUM5QixZQUFJMUMsTUFBSixFQUFZO0FBQ1ZBLGdCQUFNLENBQUNpQyxLQUFQO0FBQ0QsU0FGRCxNQUdLO0FBQ0g7QUFDQTtBQUNBVixzQkFBWTtBQUNiO0FBQ0YsT0FURDtBQVVELEtBWEQ7O0FBYUEsV0FBT1EsTUFBUDtBQUNEOztBQTVKd0IsQyIsImZpbGUiOiIvcGFja2FnZXMvcGVlcmxpYnJhcnlfY29tcHV0ZWQtZmllbGQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgQ29tcHV0ZWRGaWVsZCB7XG4gIGNvbnN0cnVjdG9yKGZ1bmMsIGVxdWFsc0Z1bmMsIGRvbnRTdG9wKSB7XG4gICAgLy8gVG8gc3VwcG9ydCBwYXNzaW5nIGJvb2xlYW4gYXMgdGhlIHNlY29uZCBhcmd1bWVudC5cbiAgICBpZiAoXy5pc0Jvb2xlYW4oZXF1YWxzRnVuYykpIHtcbiAgICAgIGRvbnRTdG9wID0gZXF1YWxzRnVuYztcbiAgICAgIGVxdWFsc0Z1bmMgPSBudWxsO1xuICAgIH1cblxuICAgIGxldCBoYW5kbGUgPSBudWxsO1xuICAgIGxldCBsYXN0VmFsdWUgPSBudWxsO1xuXG4gICAgLy8gVE9ETzogUHJvdmlkZSBhbiBvcHRpb24gdG8gcHJldmVudCB1c2luZyB2aWV3J3MgYXV0b3J1bi5cbiAgICAvLyAgICAgICBPbmUgY2FuIHdyYXAgY29kZSB3aXRoIEJsYXplLl93aXRoQ3VycmVudFZpZXcobnVsbCwgY29kZSkgdG8gcHJldmVudCB1c2luZyB2aWV3J3MgYXV0b3J1biBmb3Igbm93LlxuICAgIGxldCBhdXRvcnVuO1xuICAgIGNvbnN0IGN1cnJlbnRWaWV3ID0gUGFja2FnZS5ibGF6ZSAmJiBQYWNrYWdlLmJsYXplLkJsYXplICYmIFBhY2thZ2UuYmxhemUuQmxhemUuY3VycmVudFZpZXdcbiAgICBpZiAoY3VycmVudFZpZXcpIHtcbiAgICAgIGlmIChjdXJyZW50Vmlldy5faXNJblJlbmRlcikge1xuICAgICAgICAvLyBJbnNpZGUgcmVuZGVyIHdlIGNhbm5vdCB1c2UgY3VycmVudFZpZXcuYXV0b3J1biBkaXJlY3RseSwgc28gd2UgdXNlIG91ciBvd24gdmVyc2lvbiBvZiBpdC5cbiAgICAgICAgLy8gVGhpcyBhbGxvd3MgY29tcHV0ZWQgZmllbGRzIHRvIGJlIGNyZWF0ZWQgaW5zaWRlIEJsYXplIHRlbXBsYXRlIGhlbHBlcnMsIHdoaWNoIGFyZSBjYWxsZWRcbiAgICAgICAgLy8gdGhlIGZpcnN0IHRpbWUgaW5zaWRlIHJlbmRlci4gV2hpbGUgY3VycmVudFZpZXcuYXV0b3J1biBpcyBkaXNhbGxvd2VkIGluc2lkZSByZW5kZXIgYmVjYXVzZVxuICAgICAgICAvLyBhdXRvcnVuIHdvdWxkIGJlIHJlY3JlYXRlZCBmb3IgcmVhY2ggcmUtcmVuZGVyLCB0aGlzIGlzIGV4YWN0bHkgd2hhdCBjb21wdXRlZCBmaWVsZCBkb2VzXG4gICAgICAgIC8vIGFueXdheSBzbyBpdCBpcyBPSyBmb3IgdXNlIHRvIHVzZSBhdXRvcnVuIGluIHRoaXMgd2F5LlxuICAgICAgICBhdXRvcnVuID0gZnVuY3Rpb24gKGYpIHtcbiAgICAgICAgICBjb25zdCB0ZW1wbGF0ZUluc3RhbmNlRnVuYyA9IFBhY2thZ2UuYmxhemUuQmxhemUuVGVtcGxhdGUuX2N1cnJlbnRUZW1wbGF0ZUluc3RhbmNlRnVuYztcblxuICAgICAgICAgIGNvbnN0IGNvbXAgPSBUcmFja2VyLmF1dG9ydW4oKGMpID0+IHtcbiAgICAgICAgICAgIFBhY2thZ2UuYmxhemUuQmxhemUuX3dpdGhDdXJyZW50VmlldyhjdXJyZW50VmlldywgKCkgPT4ge1xuICAgICAgICAgICAgICBQYWNrYWdlLmJsYXplLkJsYXplLlRlbXBsYXRlLl93aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmModGVtcGxhdGVJbnN0YW5jZUZ1bmMsICgpID0+IHtcbiAgICAgICAgICAgICAgICBmLmNhbGwoY3VycmVudFZpZXcsIGMpO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjb25zdCBzdG9wQ29tcHV0YXRpb24gPSAoKSA9PiB7XG4gICAgICAgICAgICBjb21wLnN0b3AoKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIGN1cnJlbnRWaWV3Lm9uVmlld0Rlc3Ryb3llZChzdG9wQ29tcHV0YXRpb24pO1xuICAgICAgICAgIGNvbXAub25TdG9wKCgpID0+IHtcbiAgICAgICAgICAgIGN1cnJlbnRWaWV3LnJlbW92ZVZpZXdEZXN0cm95ZWRMaXN0ZW5lcihzdG9wQ29tcHV0YXRpb24pO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgcmV0dXJuIGNvbXA7XG4gICAgICAgIH07XG5cbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICBhdXRvcnVuID0gKGYpID0+IHtcbiAgICAgICAgICByZXR1cm4gY3VycmVudFZpZXcuYXV0b3J1bihmKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGF1dG9ydW4gPSBUcmFja2VyLmF1dG9ydW47XG4gICAgfVxuXG4gICAgY29uc3Qgc3RhcnRBdXRvcnVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgaGFuZGxlID0gYXV0b3J1bihmdW5jdGlvbiAoY29tcHV0YXRpb24pIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBmdW5jKCk7XG5cbiAgICAgICAgaWYgKCFsYXN0VmFsdWUpIHtcbiAgICAgICAgICBsYXN0VmFsdWUgPSBuZXcgUmVhY3RpdmVWYXIodmFsdWUsIGVxdWFsc0Z1bmMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgIGxhc3RWYWx1ZS5zZXQodmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFkb250U3RvcCkge1xuICAgICAgICAgIFRyYWNrZXIuYWZ0ZXJGbHVzaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAvLyBJZiB0aGVyZSBhcmUgbm8gZGVwZW5kZW50cyBhbnltb3JlLCBzdG9wIHRoZSBhdXRvcnVuLiBXZSB3aWxsIHJ1blxuICAgICAgICAgICAgLy8gaXQgYWdhaW4gaW4gdGhlIGdldHRlcidzIGZsdXNoIGNhbGwgaWYgbmVlZGVkLlxuICAgICAgICAgICAgaWYgKCFsYXN0VmFsdWUuZGVwLmhhc0RlcGVuZGVudHMoKSkge1xuICAgICAgICAgICAgICBnZXR0ZXIuc3RvcCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gSWYgc29tZXRoaW5nIHN0b3BzIG91ciBhdXRvcnVuIGZyb20gdGhlIG91dHNpZGUsIHdlIHdhbnQgdG8ga25vdyB0aGF0IGFuZCB1cGRhdGUgaW50ZXJuYWwgc3RhdGUgYWNjb3JkaW5nbHkuXG4gICAgICAvLyBUaGlzIG1lYW5zIHRoYXQgaWYgY29tcHV0ZWQgZmllbGQgd2FzIGNyZWF0ZWQgaW5zaWRlIGFuIGF1dG9ydW4sIGFuZCB0aGF0IGF1dG9ydW4gaXMgaW52YWxpZGVkIG91ciBhdXRvcnVuIGlzXG4gICAgICAvLyBzdG9wcGVkLiBCdXQgdGhlbiBjb21wdXRlZCBmaWVsZCBtaWdodCBiZSBzdGlsbCBhcm91bmQgYW5kIGl0IG1pZ2h0IGJlIGFza2VkIGFnYWluIGZvciB0aGUgdmFsdWUuIFdlIHdhbnQgdG9cbiAgICAgIC8vIHJlc3RhcnQgb3VyIGF1dG9ydW4gaW4gdGhhdCBjYXNlLiBJbnN0ZWFkIG9mIHRyeWluZyB0byByZWNvbXB1dGUgdGhlIHN0b3BwZWQgYXV0b3J1bi5cbiAgICAgIGlmIChoYW5kbGUub25TdG9wKSB7XG4gICAgICAgIGhhbmRsZS5vblN0b3AoKCkgPT4ge1xuICAgICAgICAgIGhhbmRsZSA9IG51bGw7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIFhYWCBDT01QQVQgV0lUSCBNRVRFT1IgMS4xLjBcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxTdG9wID0gaGFuZGxlLnN0b3A7XG4gICAgICAgIGhhbmRsZS5zdG9wID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmIChoYW5kbGUpIHtcbiAgICAgICAgICAgIG9yaWdpbmFsU3RvcC5jYWxsKGhhbmRsZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGhhbmRsZSA9IG51bGw7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfTtcblxuICAgIHN0YXJ0QXV0b3J1bigpO1xuXG4gICAgY29uc3QgZ2V0dGVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgLy8gV2UgYWx3YXlzIGZsdXNoIHNvIHRoYXQgeW91IGdldCB0aGUgbW9zdCByZWNlbnQgdmFsdWUuIFRoaXMgaXMgYSBub29wIGlmIGF1dG9ydW4gd2FzIG5vdCBpbnZhbGlkYXRlZC5cbiAgICAgIGdldHRlci5mbHVzaCgpO1xuICAgICAgcmV0dXJuIGxhc3RWYWx1ZS5nZXQoKTtcbiAgICB9O1xuXG4gICAgLy8gV2UgbWluZ2xlIHRoZSBwcm90b3R5cGUgc28gdGhhdCBnZXR0ZXIgaW5zdGFuY2VvZiBDb21wdXRlZEZpZWxkIGlzIHRydWUuXG4gICAgaWYgKE9iamVjdC5zZXRQcm90b3R5cGVPZikge1xuICAgICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKGdldHRlciwgdGhpcy5jb25zdHJ1Y3Rvci5wcm90b3R5cGUpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGdldHRlci5fX3Byb3RvX18gPSB0aGlzLmNvbnN0cnVjdG9yLnByb3RvdHlwZTtcbiAgICB9XG5cbiAgICBnZXR0ZXIudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBgQ29tcHV0ZWRGaWVsZHske3RoaXMoKX19YDtcbiAgICB9O1xuXG4gICAgZ2V0dGVyLmFwcGx5ID0gKCkgPT4ge1xuICAgICAgcmV0dXJuIGdldHRlcigpO1xuICAgIH07XG5cbiAgICBnZXR0ZXIuY2FsbCA9ICgpID0+IHtcbiAgICAgIHJldHVybiBnZXR0ZXIoKTtcbiAgICB9O1xuXG4gICAgLy8gSWYgdGhpcyBhdXRvcnVuIGlzIG5lc3RlZCBpbiB0aGUgb3V0c2lkZSBhdXRvcnVuIGl0IGdldHMgc3RvcHBlZCBhdXRvbWF0aWNhbGx5IHdoZW4gdGhlIG91dHNpZGUgYXV0b3J1biBnZXRzXG4gICAgLy8gaW52YWxpZGF0ZWQsIHNvIG5vIG5lZWQgdG8gY2FsbCBkZXN0cm95LiBCdXQgb3RoZXJ3aXNlIHlvdSBzaG91bGQgY2FsbCBkZXN0cm95IHdoZW4gdGhlIGZpZWxkIGlzIG5vdCBuZWVkZWQgYW55bW9yZS5cbiAgICBnZXR0ZXIuc3RvcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChoYW5kbGUgIT0gbnVsbCkge1xuICAgICAgICBoYW5kbGUuc3RvcCgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGhhbmRsZSA9IG51bGw7XG4gICAgfTtcblxuICAgIC8vIEZvciB0ZXN0cy5cbiAgICBnZXR0ZXIuX2lzUnVubmluZyA9ICgpID0+IHtcbiAgICAgIHJldHVybiAhIWhhbmRsZTtcbiAgICB9O1xuXG4gICAgLy8gU29tZXRpbWVzIHlvdSB3YW50IHRvIGZvcmNlIHJlY29tcHV0YXRpb24gb2YgdGhlIG5ldyB2YWx1ZSBiZWZvcmUgdGhlIGdsb2JhbCBUcmFja2VyIGZsdXNoIGlzIGRvbmUuXG4gICAgLy8gVGhpcyBpcyBhIG5vb3AgaWYgYXV0b3J1biB3YXMgbm90IGludmFsaWRhdGVkLlxuICAgIGdldHRlci5mbHVzaCA9ICgpID0+IHtcbiAgICAgIFRyYWNrZXIubm9ucmVhY3RpdmUoZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoaGFuZGxlKSB7XG4gICAgICAgICAgaGFuZGxlLmZsdXNoKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgLy8gSWYgdGhlcmUgaXMgbm8gYXV0b3J1biwgY3JlYXRlIGl0IG5vdy4gVGhpcyB3aWxsIGRvIGluaXRpYWwgcmVjb21wdXRhdGlvbiBhcyB3ZWxsLiBJZiB0aGVyZVxuICAgICAgICAgIC8vIHdpbGwgYmUgbm8gZGVwZW5kZW50cyBhZnRlciB0aGUgZ2xvYmFsIGZsdXNoLCBhdXRvcnVuIHdpbGwgc3RvcCAoYWdhaW4pLlxuICAgICAgICAgIHN0YXJ0QXV0b3J1bigpO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgIH07XG5cbiAgICByZXR1cm4gZ2V0dGVyO1xuICB9XG59XG4iXX0=
