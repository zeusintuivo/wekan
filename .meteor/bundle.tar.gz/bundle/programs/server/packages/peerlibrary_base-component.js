(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var assert = Package['peerlibrary:assert'].assert;
var ReactiveField = Package['peerlibrary:reactive-field'].ReactiveField;
var ComputedField = Package['peerlibrary:computed-field'].ComputedField;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, BaseComponent, componentClass, componentName, componentsNamespace, propertyOrMatcherOrFunction, methods, constructor, BaseComponentDebug, component;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/peerlibrary_base-component/lib.coffee                                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
// Comparing arrays of components by reference. This might not be really necessary
// to do, because all operations we officially support modify length of the array
// (add a new component or remove an old one). But if somebody is modifying the
// reactive variable directly we want a sane behavior. The default ReactiveVar
// equality always returns false when comparing any non-primitive values. Because
// the order of components in the children array is arbitrary we could further
// improve this comparison to compare arrays as sets, ignoring the order. Or we
// could have some canonical order of components in the array.
var ComponentsNamespace,
    addComponentChildDeprecationWarning,
    arrayReferenceEquals,
    childrenComponentsDeprecationWarning,
    childrenComponentsWithDeprecationWarning,
    componentChildrenDeprecationWarning,
    componentChildrenWithDeprecationWarning,
    componentParentDeprecationWarning,
    createMatcher,
    createNamespace,
    getComponent,
    getNamespace,
    getPathAndName,
    removeComponentChildDeprecationWarning,
    setComponent,
    hasProp = {}.hasOwnProperty;

arrayReferenceEquals = function (a, b) {
  var i, j, ref;

  if (a.length !== b.length) {
    return false;
  }

  for (i = j = 0, ref = a.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
    if (a[i] !== b[i]) {
      return false;
    }
  }

  return true;
};

createMatcher = function (propertyOrMatcherOrFunction) {
  var matcher, property;

  if (_.isString(propertyOrMatcherOrFunction)) {
    property = propertyOrMatcherOrFunction;

    propertyOrMatcherOrFunction = (child, parent) => {
      return property in child;
    };
  } else if (!_.isFunction(propertyOrMatcherOrFunction)) {
    assert(_.isObject(propertyOrMatcherOrFunction));
    matcher = propertyOrMatcherOrFunction;

    propertyOrMatcherOrFunction = (child, parent) => {
      var value;

      for (property in matcher) {
        value = matcher[property];

        if (!(property in child)) {
          return false;
        }

        if (_.isFunction(child[property])) {
          if (child[property]() !== value) {
            return false;
          }
        } else {
          if (child[property] !== value) {
            return false;
          }
        }
      }

      return true;
    };
  }

  return propertyOrMatcherOrFunction;
};

ComponentsNamespace = function () {
  class ComponentsNamespace {}

  ; // We have a special field for components. This allows us to have the namespace with the same name
  // as a component, without overriding anything in the component (we do not want to use component
  // object as a namespace object).

  ComponentsNamespace.COMPONENTS_FIELD = '';
  return ComponentsNamespace;
}.call(this);

getPathAndName = function (name) {
  var path;
  assert(name);
  path = name.split('.');
  name = path.pop();
  assert(name);
  return {
    path,
    name
  };
};

getNamespace = function (components, path) {
  var match, segment;
  assert(_.isObject(components));
  assert(_.isArray(path));
  match = components;

  while ((segment = path.shift()) != null) {
    match = match[segment];

    if (!_.isObject(match)) {
      return null;
    }
  }

  if (!_.isObject(match)) {
    return null;
  }

  return match || null;
};

createNamespace = function (components, path) {
  var match, segment;
  assert(_.isObject(components));
  assert(_.isArray(path));
  match = components;

  while ((segment = path.shift()) != null) {
    if (!(segment in match)) {
      match[segment] = new components.constructor();
    }

    match = match[segment];
    assert(_.isObject(match));
  }

  assert(_.isObject(match));
  return match;
};

getComponent = function (components, name) {
  var namespace, path, ref;
  assert(_.isObject(components));

  if (!name) {
    return null;
  }

  ({
    path,
    name
  } = getPathAndName(name));
  namespace = getNamespace(components, path);

  if (!namespace) {
    return null;
  }

  return ((ref = namespace[components.constructor.COMPONENTS_FIELD]) != null ? ref[name] : void 0) || null;
};

setComponent = function (components, name, component) {
  var name1, namespace, path;
  assert(_.isObject(components));
  assert(name);
  assert(component);
  ({
    path,
    name
  } = getPathAndName(name));
  namespace = createNamespace(components, path);

  if (namespace[name1 = components.constructor.COMPONENTS_FIELD] == null) {
    namespace[name1] = new components.constructor();
  }

  assert(!(name in namespace[components.constructor.COMPONENTS_FIELD]));
  return namespace[components.constructor.COMPONENTS_FIELD][name] = component;
};

componentChildrenDeprecationWarning = false;
componentChildrenWithDeprecationWarning = false;
addComponentChildDeprecationWarning = false;
removeComponentChildDeprecationWarning = false;
componentParentDeprecationWarning = false;
childrenComponentsDeprecationWarning = false;
childrenComponentsWithDeprecationWarning = false;

BaseComponent = function () {
  class BaseComponent {
    static register(componentName, componentClass) {
      if (!componentName) {
        throw new Error("Component name is required for registration.");
      } // To allow calling @register 'name' from inside a class body.


      if (componentClass == null) {
        componentClass = this;
      }

      if (getComponent(this.components, componentName)) {
        throw new Error(`Component '${componentName}' already registered.`);
      } // The last condition is to make sure we do not throw the exception when registering a subclass.
      // Subclassed components have at this stage the same component as the parent component, so we have
      // to check if they are the same class. If not, this is not an error, it is a subclass.


      if (componentClass.componentName() && componentClass.componentName() !== componentName && getComponent(this.components, componentClass.componentName()) === componentClass) {
        throw new Error(`Component '${componentName}' already registered under the name '${componentClass.componentName()}'.`);
      }

      componentClass.componentName(componentName);
      assert.equal(componentClass.componentName(), componentName);
      setComponent(this.components, componentName, componentClass);
      return this;
    }

    static getComponent(componentsNamespace, componentName) {
      if (!componentName) {
        componentName = componentsNamespace;
        componentsNamespace = this.components;
      }

      if (!componentName) {
        // If component is missing, just return a null.
        return null;
      }

      if (!_.isString(componentName)) {
        // But otherwise throw an exception.
        throw new Error(`Component name '${componentName}' is not a string.`);
      }

      return getComponent(componentsNamespace, componentName);
    } // Component name is set in the register class method. If not using a registered component and a component name is
    // wanted, component name has to be set manually or this class method should be overridden with a custom implementation.
    // Care should be taken that unregistered components have their own name and not the name of their parent class, which
    // they would have by default. Probably component name should be set in the constructor for such classes, or by calling
    // componentName class method manually on the new class of this new component.


    static componentName(componentName) {
      // Setter.
      if (componentName) {
        this._componentName = componentName; // To allow chaining.

        return this;
      } // Getter.


      return this._componentName || null;
    } // We allow access to the component name through a method so that it can be accessed in templates in an easy way.
    // It should never be overridden. The implementation should always be exactly the same as class method implementation.


    componentName() {
      // Instance method is just a getter, not a setter as well.
      return this.constructor.componentName();
    } // The order of components is arbitrary and does not necessary match siblings relations in DOM.
    // nameOrComponent is optional and it limits the returned children only to those.


    childComponents(nameOrComponent) {
      var base, child;

      if (this._componentInternals == null) {
        this._componentInternals = {};
      }

      if ((base = this._componentInternals).childComponents == null) {
        base.childComponents = new ReactiveField([], arrayReferenceEquals);
      }

      if (!nameOrComponent) {
        return function () {
          var j, len, ref, results1;
          ref = this._componentInternals.childComponents();
          results1 = [];

          for (j = 0, len = ref.length; j < len; j++) {
            child = ref[j]; // Quick path. Returns a shallow copy.

            results1.push(child);
          }

          return results1;
        }.call(this);
      }

      if (_.isString(nameOrComponent)) {
        return this.childComponentsWith((child, parent) => {
          return child.componentName() === nameOrComponent;
        });
      } else {
        return this.childComponentsWith((child, parent) => {
          if (child.constructor === nameOrComponent) {
            // nameOrComponent is a class.
            return true;
          }

          if (child === nameOrComponent) {
            // nameOrComponent is an instance, or something else.
            return true;
          }

          return false;
        });
      }
    } // The order of components is arbitrary and does not necessary match siblings relations in DOM.
    // Returns children which pass a predicate function.


    childComponentsWith(propertyOrMatcherOrFunction) {
      var results;
      assert(propertyOrMatcherOrFunction);
      propertyOrMatcherOrFunction = createMatcher(propertyOrMatcherOrFunction);
      results = new ComputedField(() => {
        var child, j, len, ref, results1;
        ref = this.childComponents();
        results1 = [];

        for (j = 0, len = ref.length; j < len; j++) {
          child = ref[j];

          if (propertyOrMatcherOrFunction.call(this, child, this)) {
            results1.push(child);
          }
        }

        return results1;
      }, arrayReferenceEquals);
      return results();
    }

    addChildComponent(childComponent) {
      var base;

      if (this._componentInternals == null) {
        this._componentInternals = {};
      }

      if ((base = this._componentInternals).childComponents == null) {
        base.childComponents = new ReactiveField([], arrayReferenceEquals);
      }

      this._componentInternals.childComponents(Tracker.nonreactive(() => {
        return this._componentInternals.childComponents().concat([childComponent]);
      }));

      return this;
    }

    removeChildComponent(childComponent) {
      var base;

      if (this._componentInternals == null) {
        this._componentInternals = {};
      }

      if ((base = this._componentInternals).childComponents == null) {
        base.childComponents = new ReactiveField([], arrayReferenceEquals);
      }

      this._componentInternals.childComponents(Tracker.nonreactive(() => {
        return _.without(this._componentInternals.childComponents(), childComponent);
      }));

      return this;
    }

    parentComponent(parentComponent) {
      var base;

      if (this._componentInternals == null) {
        this._componentInternals = {};
      } // We use reference equality here. This makes reactivity not invalidate the
      // computation if the same component instance (by reference) is set as a parent.


      if ((base = this._componentInternals).parentComponent == null) {
        base.parentComponent = new ReactiveField(null, function (a, b) {
          return a === b;
        });
      } // Setter.


      if (!_.isUndefined(parentComponent)) {
        this._componentInternals.parentComponent(parentComponent); // To allow chaining.


        return this;
      } // Getter.


      return this._componentInternals.parentComponent();
    }

    static renderComponent(parentComponent) {
      throw new Error("Not implemented");
    }

    renderComponent(parentComponent) {
      throw new Error("Not implemented");
    }

    static extendComponent(constructor, methods) {
      var currentClass, property, ref, value;
      currentClass = this;

      if (_.isFunction(constructor)) {
        constructor.prototype = Object.create(currentClass.prototype, {
          constructor: {
            value: constructor,
            writable: true,
            configurable: true
          }
        });
        Object.setPrototypeOf(constructor, currentClass);
      } else {
        methods = constructor;
        constructor = class extends currentClass {};
      }

      ref = methods || {};

      for (property in ref) {
        if (!hasProp.call(ref, property)) continue;
        value = ref[property];
        constructor.prototype[property] = value;
      }

      return constructor;
    } // Deprecated method names.
    // TODO: Remove them in the future.
    // @deprecated Use childComponents instead.


    componentChildren(...args) {
      if (!componentChildrenDeprecationWarning) {
        componentChildrenDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("componentChildren has been deprecated. Use childComponents instead.");
        }
      }

      return this.childComponents(...args);
    } // @deprecated Use childComponentsWith instead.


    componentChildrenWith(...args) {
      if (!componentChildrenWithDeprecationWarning) {
        componentChildrenWithDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("componentChildrenWith has been deprecated. Use childComponentsWith instead.");
        }
      }

      return this.childComponentsWith(...args);
    } // @deprecated Use addChildComponent instead.


    addComponentChild(...args) {
      if (!addComponentChildDeprecationWarning) {
        addComponentChildDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("addComponentChild has been deprecated. Use addChildComponent instead.");
        }
      }

      return this.addChildComponent(...args);
    } // @deprecated Use removeChildComponent instead.


    removeComponentChild(...args) {
      if (!removeComponentChildDeprecationWarning) {
        removeComponentChildDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("removeComponentChild has been deprecated. Use removeChildComponent instead.");
        }
      }

      return this.removeChildComponent(...args);
    } // @deprecated Use parentComponent instead.


    componentParent(...args) {
      if (!componentParentDeprecationWarning) {
        componentParentDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("componentParent has been deprecated. Use parentComponent instead.");
        }
      }

      return this.parentComponent(...args);
    } // @deprecated Use childComponents instead.


    childrenComponents(...args) {
      if (!componentChildrenDeprecationWarning) {
        componentChildrenDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("childrenComponents has been deprecated. Use childComponents instead.");
        }
      }

      return this.childComponents(...args);
    } // @deprecated Use childComponentsWith instead.


    childrenComponentsWith(...args) {
      if (!componentChildrenWithDeprecationWarning) {
        componentChildrenWithDeprecationWarning = true;

        if (typeof console !== "undefined" && console !== null) {
          console.warn("childrenComponentsWith has been deprecated. Use childComponentsWith instead.");
        }
      }

      return this.childComponentsWith(...args);
    }

  }

  ;
  BaseComponent.components = new ComponentsNamespace();
  return BaseComponent;
}.call(this);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/peerlibrary_base-component/debug.coffee                                                         //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
BaseComponentDebug = class BaseComponentDebug {
  static startComponent(component) {
    var name;
    name = component.componentName() || 'unnamed';
    console.group(name);
    return console.log('%o', component);
  }

  static endComponent(component) {
    return console.groupEnd();
  }

  static startMarkedComponent(component) {
    var name;
    name = component.componentName() || 'unnamed';
    console.group('%c%s', 'text-decoration: underline', name);
    return console.log('%o', component);
  }

  static endMarkedComponent(component) {
    return this.endComponent(component);
  }

  static dumpComponentSubtree(rootComponent, _markComponent = function () {}) {
    var child, i, len, marked, ref;

    if (!rootComponent) {
      return;
    }

    marked = _markComponent(rootComponent);

    if (marked) {
      this.startMarkedComponent(rootComponent);
    } else {
      this.startComponent(rootComponent);
    }

    ref = rootComponent.childComponents();

    for (i = 0, len = ref.length; i < len; i++) {
      child = ref[i];
      this.dumpComponentSubtree(child, _markComponent);
    }

    if (marked) {
      this.endMarkedComponent(rootComponent);
    } else {
      this.endComponent(rootComponent);
    }
  }

  static componentRoot(component) {
    var parentComponent;

    while (parentComponent = component.parentComponent()) {
      component = parentComponent;
    }

    return component;
  }

  static dumpComponentTree(component) {
    if (!component) {
      return;
    }

    return this.dumpComponentSubtree(this.componentRoot(component), function (c) {
      return c === component;
    });
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("peerlibrary:base-component", {
  BaseComponent: BaseComponent,
  BaseComponentDebug: BaseComponentDebug
});

})();

//# sourceURL=meteor://💻app/packages/peerlibrary_base-component.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnlfYmFzZS1jb21wb25lbnQvbGliLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvbGliLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnlfYmFzZS1jb21wb25lbnQvZGVidWcuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9kZWJ1Zy5jb2ZmZWUiXSwibmFtZXMiOlsiQ29tcG9uZW50c05hbWVzcGFjZSIsImFkZENvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nIiwiYXJyYXlSZWZlcmVuY2VFcXVhbHMiLCJjaGlsZHJlbkNvbXBvbmVudHNEZXByZWNhdGlvbldhcm5pbmciLCJjaGlsZHJlbkNvbXBvbmVudHNXaXRoRGVwcmVjYXRpb25XYXJuaW5nIiwiY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmciLCJjb21wb25lbnRDaGlsZHJlbldpdGhEZXByZWNhdGlvbldhcm5pbmciLCJjb21wb25lbnRQYXJlbnREZXByZWNhdGlvbldhcm5pbmciLCJjcmVhdGVNYXRjaGVyIiwiY3JlYXRlTmFtZXNwYWNlIiwiZ2V0Q29tcG9uZW50IiwiZ2V0TmFtZXNwYWNlIiwiZ2V0UGF0aEFuZE5hbWUiLCJyZW1vdmVDb21wb25lbnRDaGlsZERlcHJlY2F0aW9uV2FybmluZyIsInNldENvbXBvbmVudCIsImhhc1Byb3AiLCJoYXNPd25Qcm9wZXJ0eSIsImEiLCJiIiwiaSIsImoiLCJyZWYiLCJsZW5ndGgiLCJwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24iLCJtYXRjaGVyIiwicHJvcGVydHkiLCJfIiwiaXNTdHJpbmciLCJjaGlsZCIsInBhcmVudCIsImlzRnVuY3Rpb24iLCJhc3NlcnQiLCJpc09iamVjdCIsInZhbHVlIiwiQ09NUE9ORU5UU19GSUVMRCIsImNhbGwiLCJuYW1lIiwicGF0aCIsInNwbGl0IiwicG9wIiwiY29tcG9uZW50cyIsIm1hdGNoIiwic2VnbWVudCIsImlzQXJyYXkiLCJzaGlmdCIsImNvbnN0cnVjdG9yIiwibmFtZXNwYWNlIiwiY29tcG9uZW50IiwibmFtZTEiLCJCYXNlQ29tcG9uZW50IiwicmVnaXN0ZXIiLCJjb21wb25lbnROYW1lIiwiY29tcG9uZW50Q2xhc3MiLCJFcnJvciIsImVxdWFsIiwiY29tcG9uZW50c05hbWVzcGFjZSIsIl9jb21wb25lbnROYW1lIiwiY2hpbGRDb21wb25lbnRzIiwibmFtZU9yQ29tcG9uZW50IiwiYmFzZSIsIl9jb21wb25lbnRJbnRlcm5hbHMiLCJSZWFjdGl2ZUZpZWxkIiwibGVuIiwicmVzdWx0czEiLCJwdXNoIiwiY2hpbGRDb21wb25lbnRzV2l0aCIsInJlc3VsdHMiLCJDb21wdXRlZEZpZWxkIiwiYWRkQ2hpbGRDb21wb25lbnQiLCJjaGlsZENvbXBvbmVudCIsIlRyYWNrZXIiLCJub25yZWFjdGl2ZSIsImNvbmNhdCIsInJlbW92ZUNoaWxkQ29tcG9uZW50Iiwid2l0aG91dCIsInBhcmVudENvbXBvbmVudCIsImlzVW5kZWZpbmVkIiwicmVuZGVyQ29tcG9uZW50IiwiZXh0ZW5kQ29tcG9uZW50IiwibWV0aG9kcyIsImN1cnJlbnRDbGFzcyIsInByb3RvdHlwZSIsIk9iamVjdCIsImNyZWF0ZSIsIndyaXRhYmxlIiwiY29uZmlndXJhYmxlIiwic2V0UHJvdG90eXBlT2YiLCJjb21wb25lbnRDaGlsZHJlbiIsImFyZ3MiLCJjb25zb2xlIiwid2FybiIsImNvbXBvbmVudENoaWxkcmVuV2l0aCIsImFkZENvbXBvbmVudENoaWxkIiwicmVtb3ZlQ29tcG9uZW50Q2hpbGQiLCJjb21wb25lbnRQYXJlbnQiLCJjaGlsZHJlbkNvbXBvbmVudHMiLCJjaGlsZHJlbkNvbXBvbmVudHNXaXRoIiwiQmFzZUNvbXBvbmVudERlYnVnIiwic3RhcnRDb21wb25lbnQiLCJncm91cCIsImxvZyIsImVuZENvbXBvbmVudCIsImdyb3VwRW5kIiwic3RhcnRNYXJrZWRDb21wb25lbnQiLCJlbmRNYXJrZWRDb21wb25lbnQiLCJkdW1wQ29tcG9uZW50U3VidHJlZSIsInJvb3RDb21wb25lbnQiLCJfbWFya0NvbXBvbmVudCIsIm1hcmtlZCIsImNvbXBvbmVudFJvb3QiLCJkdW1wQ29tcG9uZW50VHJlZSIsImMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FDQ0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QURQRixJQUFBQSxtQkFBQTtBQUFBLElBQUFDLG1DQUFBO0FBQUEsSUFBQUMsb0JBQUE7QUFBQSxJQUFBQyxvQ0FBQTtBQUFBLElBQUFDLHdDQUFBO0FBQUEsSUFBQUMsbUNBQUE7QUFBQSxJQUFBQyx1Q0FBQTtBQUFBLElBQUFDLGlDQUFBO0FBQUEsSUFBQUMsYUFBQTtBQUFBLElBQUFDLGVBQUE7QUFBQSxJQUFBQyxZQUFBO0FBQUEsSUFBQUMsWUFBQTtBQUFBLElBQUFDLGNBQUE7QUFBQSxJQUFBQyxzQ0FBQTtBQUFBLElBQUFDLFlBQUE7QUFBQSxJQUFBQyxPQUFBLE1BQUFDLGNBQUE7O0FBUUFkLG9CQUFBLEdBQXVCLFVBQUNlLENBQUQsRUFBSUMsQ0FBSjtBQUNyQixNQUFBQyxDQUFBLEVBQUFDLENBQUEsRUFBQUMsR0FBQTs7QUFBQSxNQUFnQkosQ0FBQyxDQUFDSyxNQUFGLEtBQWNKLENBQUMsQ0FBQ0ksTUFBaEM7QUFBQSxXQUFPLEtBQVA7QUNNQzs7QURKRCxPQUFTSCxDQUFBLEdBQUFDLENBQUEsTUFBQUMsR0FBQSxHQUFBSixDQUFBLENBQUFLLE1BQVQsRUFBUyxLQUFBRCxHQUFBLEdBQUFELENBQUEsR0FBQUMsR0FBQSxHQUFBRCxDQUFBLEdBQUFDLEdBQVQsRUFBU0YsQ0FBQSxRQUFBRSxHQUFBLEtBQUFELENBQUEsS0FBQUEsQ0FBVDtBQUNFLFFBQWdCSCxDQUFFLENBQUFFLENBQUEsQ0FBRixLQUFVRCxDQUFFLENBQUFDLENBQUEsQ0FBNUI7QUFBQSxhQUFPLEtBQVA7QUNPQztBRFJIOztBQ1VBLFNEUEEsSUNPQTtBRGJxQixDQUF2Qjs7QUFRQVgsYUFBQSxHQUFnQixVQUFDZSwyQkFBRDtBQUNkLE1BQUFDLE9BQUEsRUFBQUMsUUFBQTs7QUFBQSxNQUFHQyxDQUFDLENBQUNDLFFBQUYsQ0FBV0osMkJBQVgsQ0FBSDtBQUNFRSxZQUFBLEdBQVdGLDJCQUFYOztBQUNBQSwrQkFBQSxHQUE4QixDQUFDSyxLQUFELEVBQVFDLE1BQVI7QUNVNUIsYURUQUosUUFBQSxJQUFZRyxLQ1NaO0FEVjRCLEtBQTlCO0FBRkYsU0FLSyxJQUFHLENBQUlGLENBQUMsQ0FBQ0ksVUFBRixDQUFhUCwyQkFBYixDQUFQO0FBQ0hRLFVBQUEsQ0FBT0wsQ0FBQyxDQUFDTSxRQUFGLENBQVdULDJCQUFYLENBQVA7QUFDQUMsV0FBQSxHQUFVRCwyQkFBVjs7QUFDQUEsK0JBQUEsR0FBOEIsQ0FBQ0ssS0FBRCxFQUFRQyxNQUFSO0FBQzVCLFVBQUFJLEtBQUE7O0FBQUEsV0FBQVIsUUFBQSxJQUFBRCxPQUFBO0FDV0VTLGFBQUssR0FBR1QsT0FBTyxDQUFDQyxRQUFELENBQWY7O0FEVkEsY0FBb0JBLFFBQUEsSUFBWUcsS0FBaEM7QUFBQSxpQkFBTyxLQUFQO0FDYUM7O0FEWEQsWUFBR0YsQ0FBQyxDQUFDSSxVQUFGLENBQWFGLEtBQU0sQ0FBQUgsUUFBQSxDQUFuQixDQUFIO0FBQ0UsY0FBb0JHLEtBQU0sQ0FBQUgsUUFBQSxDQUFOLE9BQXFCUSxLQUF6QztBQUFBLG1CQUFPLEtBQVA7QUFERjtBQUFBO0FBR0UsY0FBb0JMLEtBQU0sQ0FBQUgsUUFBQSxDQUFOLEtBQW1CUSxLQUF2QztBQUFBLG1CQUFPLEtBQVA7QUFIRjtBQ29CQztBRHZCSDs7QUN5QkEsYURqQkEsSUNpQkE7QUQxQjRCLEtBQTlCO0FDNEJEOztBQUNELFNEbEJBViwyQkNrQkE7QUR0Q2MsQ0FBaEI7O0FBc0JNdkIsbUJBQUE7QUFBTixRQUFBQSxtQkFBQTs7QUFBQSxHQUFNLENDc0JKO0FBQ0E7QUFDQTs7QURwQkFBLHFCQUFDLENBQUFrQyxnQkFBRCxHQUFtQixFQUFuQjtBQ3VCQSxTQUFPbEMsbUJBQVA7QUFFRCxDRDdCSyxDQzZCSG1DLElEN0JHLENDNkJFLElEN0JGOztBQU1OdkIsY0FBQSxHQUFpQixVQUFDd0IsSUFBRDtBQUNmLE1BQUFDLElBQUE7QUFBQU4sUUFBQSxDQUFPSyxJQUFQO0FBRUFDLE1BQUEsR0FBT0QsSUFBSSxDQUFDRSxLQUFMLENBQVcsR0FBWCxDQUFQO0FBRUFGLE1BQUEsR0FBT0MsSUFBSSxDQUFDRSxHQUFMLEVBQVA7QUFFQVIsUUFBQSxDQUFPSyxJQUFQO0FDd0JBLFNEdEJBO0FBQUNDLFFBQUQ7QUFBT0Q7QUFBUCxHQ3NCQTtBRC9CZSxDQUFqQjs7QUFXQXpCLFlBQUEsR0FBZSxVQUFDNkIsVUFBRCxFQUFhSCxJQUFiO0FBQ2IsTUFBQUksS0FBQSxFQUFBQyxPQUFBO0FBQUFYLFFBQUEsQ0FBT0wsQ0FBQyxDQUFDTSxRQUFGLENBQVdRLFVBQVgsQ0FBUDtBQUNBVCxRQUFBLENBQU9MLENBQUMsQ0FBQ2lCLE9BQUYsQ0FBVU4sSUFBVixDQUFQO0FBRUFJLE9BQUEsR0FBUUQsVUFBUjs7QUFFQSxTQUFNLENBQUFFLE9BQUEsR0FBQUwsSUFBQSxDQUFBTyxLQUFBLFdBQU47QUFDRUgsU0FBQSxHQUFRQSxLQUFNLENBQUFDLE9BQUEsQ0FBZDs7QUFDQSxTQUFtQmhCLENBQUMsQ0FBQ00sUUFBRixDQUFXUyxLQUFYLENBQW5CO0FBQUEsYUFBTyxJQUFQO0FDd0JDO0FEMUJIOztBQUlBLE9BQW1CZixDQUFDLENBQUNNLFFBQUYsQ0FBV1MsS0FBWCxDQUFuQjtBQUFBLFdBQU8sSUFBUDtBQzBCQzs7QUFDRCxTRHpCQUEsS0FBQSxJQUFTLElDeUJUO0FEckNhLENBQWY7O0FBY0FoQyxlQUFBLEdBQWtCLFVBQUMrQixVQUFELEVBQWFILElBQWI7QUFDaEIsTUFBQUksS0FBQSxFQUFBQyxPQUFBO0FBQUFYLFFBQUEsQ0FBT0wsQ0FBQyxDQUFDTSxRQUFGLENBQVdRLFVBQVgsQ0FBUDtBQUNBVCxRQUFBLENBQU9MLENBQUMsQ0FBQ2lCLE9BQUYsQ0FBVU4sSUFBVixDQUFQO0FBRUFJLE9BQUEsR0FBUUQsVUFBUjs7QUFFQSxTQUFNLENBQUFFLE9BQUEsR0FBQUwsSUFBQSxDQUFBTyxLQUFBLFdBQU47QUFDRSxVQUFxREYsT0FBQSxJQUFXRCxLQUFoRTtBQUFBQSxXQUFNLENBQUFDLE9BQUEsQ0FBTixHQUFpQixJQUFJRixVQUFVLENBQUNLLFdBQWYsRUFBakI7QUMyQkM7O0FEMUJESixTQUFBLEdBQVFBLEtBQU0sQ0FBQUMsT0FBQSxDQUFkO0FBQ0FYLFVBQUEsQ0FBT0wsQ0FBQyxDQUFDTSxRQUFGLENBQVdTLEtBQVgsQ0FBUDtBQUhGOztBQUtBVixRQUFBLENBQU9MLENBQUMsQ0FBQ00sUUFBRixDQUFXUyxLQUFYLENBQVA7QUM0QkEsU0QxQkFBLEtDMEJBO0FEdkNnQixDQUFsQjs7QUFlQS9CLFlBQUEsR0FBZSxVQUFDOEIsVUFBRCxFQUFhSixJQUFiO0FBQ2IsTUFBQVUsU0FBQSxFQUFBVCxJQUFBLEVBQUFoQixHQUFBO0FBQUFVLFFBQUEsQ0FBT0wsQ0FBQyxDQUFDTSxRQUFGLENBQVdRLFVBQVgsQ0FBUDs7QUFFQSxPQUFtQkosSUFBbkI7QUFBQSxXQUFPLElBQVA7QUM2QkM7O0FEM0JEO0FBQUNDLFFBQUQ7QUFBT0Q7QUFBUCxNQUFleEIsY0FBQSxDQUFld0IsSUFBZixDQUFmO0FBRUFVLFdBQUEsR0FBWW5DLFlBQUEsQ0FBYTZCLFVBQWIsRUFBeUJILElBQXpCLENBQVo7O0FBQ0EsT0FBbUJTLFNBQW5CO0FBQUEsV0FBTyxJQUFQO0FDNkJDOztBQUNELFNBQU8sQ0FBQyxDQUFDekIsR0FBRyxHQUFHeUIsU0FBUyxDQUFDTixVQUFVLENBQUNLLFdBQVgsQ0FBdUJYLGdCQUF4QixDQUFoQixLQUE4RCxJQUE5RCxHQUFxRWIsR0Q1QnpCLENBQUFlLElBQUEsQ0M0QjVDLEdENUI0QyxNQzRCN0MsS0Q1QnNELElDNEI3RDtBRHRDYSxDQUFmOztBQVlBdEIsWUFBQSxHQUFlLFVBQUMwQixVQUFELEVBQWFKLElBQWIsRUFBbUJXLFNBQW5CO0FBQ2IsTUFBQUMsS0FBQSxFQUFBRixTQUFBLEVBQUFULElBQUE7QUFBQU4sUUFBQSxDQUFPTCxDQUFDLENBQUNNLFFBQUYsQ0FBV1EsVUFBWCxDQUFQO0FBQ0FULFFBQUEsQ0FBT0ssSUFBUDtBQUNBTCxRQUFBLENBQU9nQixTQUFQO0FBRUE7QUFBQ1YsUUFBRDtBQUFPRDtBQUFQLE1BQWV4QixjQUFBLENBQWV3QixJQUFmLENBQWY7QUFFQVUsV0FBQSxHQUFZckMsZUFBQSxDQUFnQitCLFVBQWhCLEVBQTRCSCxJQUE1QixDQUFaOztBQzZCQSxNQUFJUyxTQUFTLENBQUNFLEtBQUssR0FBR1IsVUFBVSxDQUFDSyxXQUFYLENBQXVCWCxnQkFBaEMsQ0FBVCxJQUE4RCxJQUFsRSxFQUF3RTtBRDNCeEVZLGFBQUEsQ0FBQUUsS0FBQSxJQUFzRCxJQUFJUixVQUFVLENBQUNLLFdBQWYsRUFBdEQ7QUM2QkM7O0FENUJEZCxRQUFBLENBQU8sRUFBQUssSUFBQSxJQUFZVSxTQUFVLENBQUFOLFVBQVUsQ0FBQ0ssV0FBWCxDQUF1QlgsZ0JBQXZCLENBQXRCLENBQVA7QUM4QkEsU0Q3QkFZLFNBQVUsQ0FBQU4sVUFBVSxDQUFDSyxXQUFYLENBQXVCWCxnQkFBdkIsQ0FBVixDQUFtREUsSUFBbkQsSUFBMkRXLFNDNkIzRDtBRHhDYSxDQUFmOztBQWFBMUMsbUNBQUEsR0FBc0MsS0FBdEM7QUFDQUMsdUNBQUEsR0FBMEMsS0FBMUM7QUFDQUwsbUNBQUEsR0FBc0MsS0FBdEM7QUFDQVksc0NBQUEsR0FBeUMsS0FBekM7QUFFQU4saUNBQUEsR0FBb0MsS0FBcEM7QUFFQUosb0NBQUEsR0FBdUMsS0FBdkM7QUFDQUMsd0NBQUEsR0FBMkMsS0FBM0M7O0FBRU02QyxhQUFBO0FBQU4sUUFBQUEsYUFBQTtBQUdhLFdBQVZDLFFBQVUsQ0FBQ0MsYUFBRCxFQUFnQkMsY0FBaEI7QUFDVCxXQUFzRUQsYUFBdEU7QUFBQSxjQUFNLElBQUlFLEtBQUosQ0FBVSw4Q0FBVixDQUFOO0FBQUEsT0FEUyxDQ3FDUDs7O0FBQ0EsVUFBSUQsY0FBYyxJQUFJLElBQXRCLEVBQTRCO0FEbEM5QkEsc0JBQUEsR0FBa0IsSUFBbEI7QUNvQ0c7O0FEbENILFVBQXdFMUMsWUFBQSxDQUFhLEtBQUM4QixVQUFkLEVBQTBCVyxhQUExQixDQUF4RTtBQUFBLGNBQU0sSUFBSUUsS0FBSixDQUFVLGNBQWVGLGFBQWUsdUJBQXhDLENBQU47QUFMQSxPQURTLENDNENQO0FBQ0E7QUFDQTs7O0FEbkNGLFVBQUdDLGNBQWMsQ0FBQ0QsYUFBZixNQUFtQ0MsY0FBYyxDQUFDRCxhQUFmLE9BQW9DQSxhQUF2RSxJQUF5RnpDLFlBQUEsQ0FBYSxLQUFDOEIsVUFBZCxFQUEwQlksY0FBYyxDQUFDRCxhQUFmLEVBQTFCLE1BQTZEQyxjQUF6SjtBQUNFLGNBQU0sSUFBSUMsS0FBSixDQUFVLGNBQWVGLGFBQWUsd0NBQXdDQyxjQUFjLENBQUNELGFBQWYsRUFBZ0MsSUFBaEgsQ0FBTjtBQ3FDQzs7QURuQ0hDLG9CQUFjLENBQUNELGFBQWYsQ0FBNkJBLGFBQTdCO0FBQ0FwQixZQUFNLENBQUN1QixLQUFQLENBQWFGLGNBQWMsQ0FBQ0QsYUFBZixFQUFiLEVBQTZDQSxhQUE3QztBQUVBckMsa0JBQUEsQ0FBYSxLQUFDMEIsVUFBZCxFQUEwQlcsYUFBMUIsRUFBeUNDLGNBQXpDO0FDb0NFLGFEakNGLElDaUNFO0FEckRPOztBQXNCSSxXQUFkMUMsWUFBYyxDQUFDNkMsbUJBQUQsRUFBc0JKLGFBQXRCO0FBQ2IsV0FBT0EsYUFBUDtBQUNFQSxxQkFBQSxHQUFnQkksbUJBQWhCO0FBQ0FBLDJCQUFBLEdBQXNCLEtBQUNmLFVBQXZCO0FDbUNDOztBRGhDSCxXQUFtQlcsYUFBbkI7QUNrQ0k7QURsQ0osZUFBTyxJQUFQO0FDb0NHOztBRGpDSCxXQUE4RXpCLENBQUMsQ0FBQ0MsUUFBRixDQUFXd0IsYUFBWCxDQUE5RTtBQ21DSTtBRG5DSixjQUFNLElBQUlFLEtBQUosQ0FBVSxtQkFBb0JGLGFBQWUsb0JBQTdDLENBQU47QUNxQ0c7O0FBQ0QsYURwQ0Z6QyxZQUFBLENBQWE2QyxtQkFBYixFQUFrQ0osYUFBbEMsQ0NvQ0U7QUR2RUosS0FERixDQzJFSTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QURwQ2MsV0FBZkEsYUFBZSxDQUFDQSxhQUFEO0FDc0NaO0FEcENGLFVBQUdBLGFBQUg7QUFDRSxhQUFDSyxjQUFELEdBQWtCTCxhQUFsQixDQURGLENDdUNJOztBRHBDRixlQUFPLElBQVA7QUFIRixPQUZjLENDNENaOzs7QUFDQSxhRHJDRixLQUFDSyxjQUFELElBQW1CLElDcUNqQjtBRHZGSixLQURGLENDMkZJO0FBQ0E7OztBRHJDRkwsaUJBQWU7QUN1Q1g7QUFDQSxhRHRDRixLQUFDTixXQUFELENBQWFNLGFBQWIsRUNzQ0U7QUQ5RkosS0FERixDQ2tHSTtBQUNBOzs7QUR0Q0ZNLG1CQUFpQixDQUFDQyxlQUFEO0FBQ2YsVUFBQUMsSUFBQSxFQUFBL0IsS0FBQTs7QUN3Q0UsVUFBSSxLQUFLZ0MsbUJBQUwsSUFBNEIsSUFBaEMsRUFBc0M7QUR4Q3hDLGFBQUNBLG1CQUFELEdBQXdCLEVBQXhCO0FDMENHOztBQUNELFVBQUksQ0FBQ0QsSUFBSSxHQUFHLEtBQUtDLG1CQUFiLEVBQWtDSCxlQUFsQyxJQUFxRCxJQUF6RCxFQUErRDtBQUM3REUsWUQzQ2dCLENBQUNGLGVDMkNqQixHRDNDb0MsSUFBSUksYUFBSixDQUFrQixFQUFsQixFQUFzQjNELG9CQUF0QixDQzJDcEM7QUFDRDs7QUR6Q0gsV0FBMEV3RCxlQUExRTtBQUFBO0FDNENNLGNBQUl0QyxDQUFKLEVBQU8wQyxHQUFQLEVBQVl6QyxHQUFaLEVBQWlCMEMsUUFBakI7QUQ1Q1ExQyxhQUFBLFFBQUF1QyxtQkFBQSxDQUFBSCxlQUFBO0FBQUFNLGtCQUFBOztBQUFBLGVBQUEzQyxDQUFBLE1BQUEwQyxHQUFBLEdBQUF6QyxHQUFBLENBQUFDLE1BQUEsRUFBQUYsQ0FBQSxHQUFBMEMsR0FBQSxFQUFBMUMsQ0FBQTtBQ2dETlEsaUJBQUssR0FBR1AsR0FBRyxDQUFDRCxDQUFELENBQVgsQ0RoRE0sQ0NpRE47O0FBQ0EyQyxvQkFBUSxDQUFDQyxJQUFULENEbERBcEMsS0NrREE7QURsRE07O0FDb0RSLGlCQUFPbUMsUUFBUDtBQUNELFNEckRMLENDcURPNUIsSURyRFAsQ0NxRFksSURyRFo7QUNzREc7O0FEcERILFVBQUdULENBQUMsQ0FBQ0MsUUFBRixDQUFXK0IsZUFBWCxDQUFIO0FDc0RJLGVEckRGLEtBQUNPLG1CQUFELENBQXFCLENBQUNyQyxLQUFELEVBQVFDLE1BQVI7QUNzRGpCLGlCRHJERkQsS0FBSyxDQUFDdUIsYUFBTixPQUF5Qk8sZUNxRHZCO0FEdERKLFVDcURFO0FEdERKO0FDMERJLGVEdERGLEtBQUNPLG1CQUFELENBQXFCLENBQUNyQyxLQUFELEVBQVFDLE1BQVI7QUFFbkIsY0FBZUQsS0FBSyxDQUFDaUIsV0FBTixLQUFxQmEsZUFBcEM7QUNzREk7QUR0REosbUJBQU8sSUFBUDtBQ3dERzs7QURyREgsY0FBZTlCLEtBQUEsS0FBUzhCLGVBQXhCO0FDdURJO0FEdkRKLG1CQUFPLElBQVA7QUN5REc7O0FBQ0QsaUJEeERGLEtDd0RFO0FEL0RKLFVDc0RFO0FBV0Q7QUR4SUwsS0FERixDQzRJSTtBQUNBOzs7QUQxREZPLHVCQUFxQixDQUFDMUMsMkJBQUQ7QUFDbkIsVUFBQTJDLE9BQUE7QUFBQW5DLFlBQUEsQ0FBT1IsMkJBQVA7QUFFQUEsaUNBQUEsR0FBOEJmLGFBQUEsQ0FBY2UsMkJBQWQsQ0FBOUI7QUFFQTJDLGFBQUEsR0FBVSxJQUFJQyxhQUFKLENBQWtCO0FBQzFCLFlBQUF2QyxLQUFBLEVBQUFSLENBQUEsRUFBQTBDLEdBQUEsRUFBQXpDLEdBQUEsRUFBQTBDLFFBQUE7QUFBTTFDLFdBQUEsUUFBQW9DLGVBQUE7QUFBQU0sZ0JBQUE7O0FBQUEsYUFBQTNDLENBQUEsTUFBQTBDLEdBQUEsR0FBQXpDLEdBQUEsQ0FBQUMsTUFBQSxFQUFBRixDQUFBLEdBQUEwQyxHQUFBLEVBQUExQyxDQUFBO0FDOERGUSxlQUFLLEdBQUdQLEdBQUcsQ0FBQ0QsQ0FBRCxDQUFYOztBQUNBLGNEL0R1Q0csMkJBQTJCLENBQUNZLElBQTVCLENBQWlDLElBQWpDLEVBQW9DUCxLQUFwQyxFQUEyQyxJQUEzQyxDQytEdkMsRUQvRHVDO0FDZ0VyQ21DLG9CQUFRLENBQUNDLElBQVQsQ0RoRU5wQyxLQ2dFTTtBQUNEO0FEakVDOztBQ21FSixlQUFPbUMsUUFBUDtBRHBFTSxTQUdSN0Qsb0JBSFEsQ0FBVjtBQ3NFRSxhRGpFRmdFLE9BQUEsRUNpRUU7QUQzRWlCOztBQVlyQkUscUJBQW1CLENBQUNDLGNBQUQ7QUFDakIsVUFBQVYsSUFBQTs7QUNtRUUsVUFBSSxLQUFLQyxtQkFBTCxJQUE0QixJQUFoQyxFQUFzQztBRG5FeEMsYUFBQ0EsbUJBQUQsR0FBd0IsRUFBeEI7QUNxRUc7O0FBQ0QsVUFBSSxDQUFDRCxJQUFJLEdBQUcsS0FBS0MsbUJBQWIsRUFBa0NILGVBQWxDLElBQXFELElBQXpELEVBQStEO0FBQzdERSxZRHRFZ0IsQ0FBQ0YsZUNzRWpCLEdEdEVvQyxJQUFJSSxhQUFKLENBQWtCLEVBQWxCLEVBQXNCM0Qsb0JBQXRCLENDc0VwQztBQUNEOztBRHRFSCxXQUFDMEQsbUJBQUQsQ0FBcUJILGVBQXJCLENBQXFDYSxPQUFPLENBQUNDLFdBQVIsQ0FBb0I7QUN3RXJELGVEdkVGLEtBQUNYLG1CQUFELENBQXFCSCxlQUFyQixHQUF1Q2UsTUFBdkMsQ0FBOEMsQ0FBQ0gsY0FBRCxDQUE5QyxDQ3VFRTtBRHhFaUMsUUFBckM7O0FDMEVFLGFEdEVGLElDc0VFO0FEN0VlOztBQVNuQkksd0JBQXNCLENBQUNKLGNBQUQ7QUFDcEIsVUFBQVYsSUFBQTs7QUN3RUUsVUFBSSxLQUFLQyxtQkFBTCxJQUE0QixJQUFoQyxFQUFzQztBRHhFeEMsYUFBQ0EsbUJBQUQsR0FBd0IsRUFBeEI7QUMwRUc7O0FBQ0QsVUFBSSxDQUFDRCxJQUFJLEdBQUcsS0FBS0MsbUJBQWIsRUFBa0NILGVBQWxDLElBQXFELElBQXpELEVBQStEO0FBQzdERSxZRDNFZ0IsQ0FBQ0YsZUMyRWpCLEdEM0VvQyxJQUFJSSxhQUFKLENBQWtCLEVBQWxCLEVBQXNCM0Qsb0JBQXRCLENDMkVwQztBQUNEOztBRDNFSCxXQUFDMEQsbUJBQUQsQ0FBcUJILGVBQXJCLENBQXFDYSxPQUFPLENBQUNDLFdBQVIsQ0FBb0I7QUM2RXJELGVENUVGN0MsQ0FBQyxDQUFDZ0QsT0FBRixDQUFVLEtBQUNkLG1CQUFELENBQXFCSCxlQUFyQixFQUFWLEVBQWtEWSxjQUFsRCxDQzRFRTtBRDdFaUMsUUFBckM7O0FDK0VFLGFEM0VGLElDMkVFO0FEbEZrQjs7QUFTdEJNLG1CQUFpQixDQUFDQSxlQUFEO0FBQ2YsVUFBQWhCLElBQUE7O0FDNkVFLFVBQUksS0FBS0MsbUJBQUwsSUFBNEIsSUFBaEMsRUFBc0M7QUQ3RXhDLGFBQUNBLG1CQUFELEdBQXdCLEVBQXhCO0FBQUEsT0FEZSxDQ2lGYjtBQUNBOzs7QUFDQSxVQUFJLENBQUNELElBQUksR0FBRyxLQUFLQyxtQkFBYixFQUFrQ2UsZUFBbEMsSUFBcUQsSUFBekQsRUFBK0Q7QUFDN0RoQixZRGhGZ0IsQ0FBQ2dCLGVDZ0ZqQixHRGhGb0MsSUFBSWQsYUFBSixDQUFrQixJQUFsQixFQUF3QixVQUFDNUMsQ0FBRCxFQUFJQyxDQUFKO0FDaUYxRCxpQkRqRm9FRCxDQUFBLEtBQUtDLENDaUZ6RTtBRGpGa0MsVUNnRnBDO0FEbkZKLE9BRGUsQ0N3RmI7OztBRGpGRixXQUFPUSxDQUFDLENBQUNrRCxXQUFGLENBQWNELGVBQWQsQ0FBUDtBQUNFLGFBQUNmLG1CQUFELENBQXFCZSxlQUFyQixDQUFxQ0EsZUFBckMsRUFERixDQ29GSTs7O0FEakZGLGVBQU8sSUFBUDtBQVRGLE9BRGUsQ0M4RmI7OztBQUNBLGFEbEZGLEtBQUNmLG1CQUFELENBQXFCZSxlQUFyQixFQ2tGRTtBRC9GYTs7QUFlQyxXQUFqQkUsZUFBaUIsQ0FBQ0YsZUFBRDtBQUNoQixZQUFNLElBQUl0QixLQUFKLENBQVUsaUJBQVYsQ0FBTjtBQURnQjs7QUFHbEJ3QixtQkFBaUIsQ0FBQ0YsZUFBRDtBQUNmLFlBQU0sSUFBSXRCLEtBQUosQ0FBVSxpQkFBVixDQUFOO0FBRGU7O0FBR0MsV0FBakJ5QixlQUFpQixDQUFDakMsV0FBRCxFQUFja0MsT0FBZDtBQUNoQixVQUFBQyxZQUFBLEVBQUF2RCxRQUFBLEVBQUFKLEdBQUEsRUFBQVksS0FBQTtBQUFBK0Msa0JBQUEsR0FBZSxJQUFmOztBQUVBLFVBQUd0RCxDQUFDLENBQUNJLFVBQUYsQ0FBYWUsV0FBYixDQUFIO0FBQ0VBLG1CQUFXLENBQUFvQyxTQUFYLEdBQWdCQyxNQUFNLENBQUNDLE1BQVAsQ0FBY0gsWUFBWSxDQUFBQyxTQUExQixFQUNkO0FBQUFwQyxxQkFBQSxFQUNFO0FBQUFaLGlCQUFBLEVBQU9ZLFdBQVA7QUFDQXVDLG9CQUFBLEVBQVUsSUFEVjtBQUVBQyx3QkFBQSxFQUFjO0FBRmQ7QUFERixTQURjLENBQWhCO0FBTUFILGNBQU0sQ0FBQ0ksY0FBUCxDQUFzQnpDLFdBQXRCLEVBQW1DbUMsWUFBbkM7QUFQRjtBQVVFRCxlQUFBLEdBQVVsQyxXQUFWO0FBQ0FBLG1CQUFBLEdBQWMsY0FBY21DLFlBQWQsR0FBZDtBQ3NGQzs7QURsRkgzRCxTQUFBLEdBQUEwRCxPQUFBOztBQUFBLFdBQUF0RCxRQUFBLElBQUFKLEdBQUE7QUNxRkksWUFBSSxDQUFDTixPQUFPLENBQUNvQixJQUFSLENBQWFkLEdBQWIsRUFBa0JJLFFBQWxCLENBQUwsRUFBa0M7QUFDbENRLGFBQUssR0FBR1osR0FBRyxDQUFDSSxRQUFELENBQVg7QURyRkZvQixtQkFBVyxDQUFBb0MsU0FBWCxDQUFjeEQsUUFBZCxJQUEwQlEsS0FBMUI7QUFERjs7QUN5RkUsYUR0RkZZLFdDc0ZFO0FEaFBKLEtBREYsQ0NvUEk7QUFDQTtBQUVBOzs7QUR0RkYwQyxxQkFBbUIsSUFBQ0MsSUFBRDtBQUNqQixXQUFPbkYsbUNBQVA7QUFDRUEsMkNBQUEsR0FBc0MsSUFBdEM7O0FDd0ZFLFlBQUksT0FBT29GLE9BQVAsS0FBbUIsV0FBbkIsSUFBa0NBLE9BQU8sS0FBSyxJQUFsRCxFQUF3RDtBRHZGMURBLGlCQUFPLENBQUVDLElBQVQsQ0FBYyxxRUFBZDtBQUZGO0FDNEZHOztBQUNELGFEekZGLEtBQUNqQyxlQUFELENBQWlCLEdBQUErQixJQUFqQixDQ3lGRTtBRDlQSixLQURGLENDa1FJOzs7QUR6RkZHLHlCQUF1QixJQUFDSCxJQUFEO0FBQ3JCLFdBQU9sRix1Q0FBUDtBQUNFQSwrQ0FBQSxHQUEwQyxJQUExQzs7QUMyRkUsWUFBSSxPQUFPbUYsT0FBUCxLQUFtQixXQUFuQixJQUFrQ0EsT0FBTyxLQUFLLElBQWxELEVBQXdEO0FEMUYxREEsaUJBQU8sQ0FBRUMsSUFBVCxDQUFjLDZFQUFkO0FBRkY7QUMrRkc7O0FBQ0QsYUQ1RkYsS0FBQ3pCLG1CQUFELENBQXFCLEdBQUF1QixJQUFyQixDQzRGRTtBRHpRSixLQURGLENDNlFJOzs7QUQ1RkZJLHFCQUFtQixJQUFDSixJQUFEO0FBQ2pCLFdBQU92RixtQ0FBUDtBQUNFQSwyQ0FBQSxHQUFzQyxJQUF0Qzs7QUM4RkUsWUFBSSxPQUFPd0YsT0FBUCxLQUFtQixXQUFuQixJQUFrQ0EsT0FBTyxLQUFLLElBQWxELEVBQXdEO0FEN0YxREEsaUJBQU8sQ0FBRUMsSUFBVCxDQUFjLHVFQUFkO0FBRkY7QUNrR0c7O0FBQ0QsYUQvRkYsS0FBQ3RCLGlCQUFELENBQW1CLEdBQUFvQixJQUFuQixDQytGRTtBRHBSSixLQURGLENDd1JJOzs7QUQvRkZLLHdCQUFzQixJQUFDTCxJQUFEO0FBQ3BCLFdBQU8zRSxzQ0FBUDtBQUNFQSw4Q0FBQSxHQUF5QyxJQUF6Qzs7QUNpR0UsWUFBSSxPQUFPNEUsT0FBUCxLQUFtQixXQUFuQixJQUFrQ0EsT0FBTyxLQUFLLElBQWxELEVBQXdEO0FEaEcxREEsaUJBQU8sQ0FBRUMsSUFBVCxDQUFjLDZFQUFkO0FBRkY7QUNxR0c7O0FBQ0QsYURsR0YsS0FBQ2pCLG9CQUFELENBQXNCLEdBQUFlLElBQXRCLENDa0dFO0FEL1JKLEtBREYsQ0NtU0k7OztBRGxHRk0sbUJBQWlCLElBQUNOLElBQUQ7QUFDZixXQUFPakYsaUNBQVA7QUFDRUEseUNBQUEsR0FBb0MsSUFBcEM7O0FDb0dFLFlBQUksT0FBT2tGLE9BQVAsS0FBbUIsV0FBbkIsSUFBa0NBLE9BQU8sS0FBSyxJQUFsRCxFQUF3RDtBRG5HMURBLGlCQUFPLENBQUVDLElBQVQsQ0FBYyxtRUFBZDtBQUZGO0FDd0dHOztBQUNELGFEckdGLEtBQUNmLGVBQUQsQ0FBaUIsR0FBQWEsSUFBakIsQ0NxR0U7QUQxU0osS0FERixDQzhTSTs7O0FEckdGTyxzQkFBb0IsSUFBQ1AsSUFBRDtBQUNsQixXQUFPbkYsbUNBQVA7QUFDRUEsMkNBQUEsR0FBc0MsSUFBdEM7O0FDdUdFLFlBQUksT0FBT29GLE9BQVAsS0FBbUIsV0FBbkIsSUFBa0NBLE9BQU8sS0FBSyxJQUFsRCxFQUF3RDtBRHRHMURBLGlCQUFPLENBQUVDLElBQVQsQ0FBYyxzRUFBZDtBQUZGO0FDMkdHOztBQUNELGFEeEdGLEtBQUNqQyxlQUFELENBQWlCLEdBQUErQixJQUFqQixDQ3dHRTtBRHJUSixLQURGLENDeVRJOzs7QUR4R0ZRLDBCQUF3QixJQUFDUixJQUFEO0FBQ3RCLFdBQU9sRix1Q0FBUDtBQUNFQSwrQ0FBQSxHQUEwQyxJQUExQzs7QUMwR0UsWUFBSSxPQUFPbUYsT0FBUCxLQUFtQixXQUFuQixJQUFrQ0EsT0FBTyxLQUFLLElBQWxELEVBQXdEO0FEekcxREEsaUJBQU8sQ0FBRUMsSUFBVCxDQUFjLDhFQUFkO0FBRkY7QUM4R0c7O0FBQ0QsYUQzR0YsS0FBQ3pCLG1CQUFELENBQXFCLEdBQUF1QixJQUFyQixDQzJHRTtBRGhIb0I7O0FBak4xQjs7QUFBQTtBQUNFdkMsZUFBQyxDQUFBVCxVQUFELEdBQWEsSUFBSXhDLG1CQUFKLEVBQWI7QUN1VUEsU0FBT2lELGFBQVA7QUFFRCxDRDFVSyxDQzBVSGQsSUQxVUcsQ0MwVUUsSUQxVUYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBRXZIQThELGtCQUFBLEdBQU4sTUFBQUEsa0JBQUE7QUFDbUIsU0FBaEJDLGNBQWdCLENBQUNuRCxTQUFEO0FBQ2YsUUFBQVgsSUFBQTtBQUFBQSxRQUFBLEdBQU9XLFNBQVMsQ0FBQ0ksYUFBVixNQUE2QixTQUFwQztBQUNBc0MsV0FBTyxDQUFDVSxLQUFSLENBQWMvRCxJQUFkO0FDSUEsV0RIQXFELE9BQU8sQ0FBQ1csR0FBUixDQUFZLElBQVosRUFBa0JyRCxTQUFsQixDQ0dBO0FETmU7O0FBS0YsU0FBZHNELFlBQWMsQ0FBQ3RELFNBQUQ7QUNLYixXREpBMEMsT0FBTyxDQUFDYSxRQUFSLEVDSUE7QURMYTs7QUFHUSxTQUF0QkMsb0JBQXNCLENBQUN4RCxTQUFEO0FBQ3JCLFFBQUFYLElBQUE7QUFBQUEsUUFBQSxHQUFPVyxTQUFTLENBQUNJLGFBQVYsTUFBNkIsU0FBcEM7QUFDQXNDLFdBQU8sQ0FBQ1UsS0FBUixDQUFjLE1BQWQsRUFBc0IsNEJBQXRCLEVBQW9EL0QsSUFBcEQ7QUNPQSxXRE5BcUQsT0FBTyxDQUFDVyxHQUFSLENBQVksSUFBWixFQUFrQnJELFNBQWxCLENDTUE7QURUcUI7O0FBS0YsU0FBcEJ5RCxrQkFBb0IsQ0FBQ3pELFNBQUQ7QUNRbkIsV0RQQSxLQUFDc0QsWUFBRCxDQUFjdEQsU0FBZCxDQ09BO0FEUm1COztBQUdFLFNBQXRCMEQsb0JBQXNCLENBQUNDLGFBQUQsRUFBZ0JDLGNBQUEsR0FBZ0IsYUFBRCxDQUEvQjtBQUNyQixRQUFBL0UsS0FBQSxFQUFBVCxDQUFBLEVBQUEyQyxHQUFBLEVBQUE4QyxNQUFBLEVBQUF2RixHQUFBOztBQUFBLFNBQWNxRixhQUFkO0FBQUE7QUNXQzs7QURUREUsVUFBQSxHQUFTRCxjQUFBLENBQWVELGFBQWYsQ0FBVDs7QUFFQSxRQUFHRSxNQUFIO0FBQ0UsV0FBQ0wsb0JBQUQsQ0FBc0JHLGFBQXRCO0FBREY7QUFHRSxXQUFDUixjQUFELENBQWdCUSxhQUFoQjtBQ1VEOztBRFJEckYsT0FBQSxHQUFBcUYsYUFBQSxDQUFBakQsZUFBQTs7QUFBQSxTQUFBdEMsQ0FBQSxNQUFBMkMsR0FBQSxHQUFBekMsR0FBQSxDQUFBQyxNQUFBLEVBQUFILENBQUEsR0FBQTJDLEdBQUEsRUFBQTNDLENBQUE7QUNXRVMsV0FBSyxHQUFHUCxHQUFHLENBQUNGLENBQUQsQ0FBWDtBRFZBLFdBQUNzRixvQkFBRCxDQUFzQjdFLEtBQXRCLEVBQTZCK0UsY0FBN0I7QUFERjs7QUFHQSxRQUFHQyxNQUFIO0FBQ0UsV0FBQ0osa0JBQUQsQ0FBb0JFLGFBQXBCO0FBREY7QUFHRSxXQUFDTCxZQUFELENBQWNLLGFBQWQ7QUNZRDtBRDVCb0I7O0FBb0JQLFNBQWZHLGFBQWUsQ0FBQzlELFNBQUQ7QUFDZCxRQUFBNEIsZUFBQTs7QUFBQSxXQUFNQSxlQUFBLEdBQWtCNUIsU0FBUyxDQUFDNEIsZUFBVixFQUF4QjtBQUNFNUIsZUFBQSxHQUFZNEIsZUFBWjtBQURGOztBQ2VBLFdEWkE1QixTQ1lBO0FEaEJjOztBQU1JLFNBQW5CK0QsaUJBQW1CLENBQUMvRCxTQUFEO0FBQ2xCLFNBQWNBLFNBQWQ7QUFBQTtBQ2VDOztBQUNELFdEZEEsS0FBQzBELG9CQUFELENBQXNCLEtBQUNJLGFBQUQsQ0FBZTlELFNBQWYsQ0FBdEIsRUFBaUQsVUFBQ2dFLENBQUQ7QUNlL0MsYURmc0RBLENBQUEsS0FBS2hFLFNDZTNEO0FEZkYsTUNjQTtBRGpCa0I7O0FBM0N0QixDQUFNLEMiLCJmaWxlIjoiL3BhY2thZ2VzL3BlZXJsaWJyYXJ5X2Jhc2UtY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIyBDb21wYXJpbmcgYXJyYXlzIG9mIGNvbXBvbmVudHMgYnkgcmVmZXJlbmNlLiBUaGlzIG1pZ2h0IG5vdCBiZSByZWFsbHkgbmVjZXNzYXJ5XG4jIHRvIGRvLCBiZWNhdXNlIGFsbCBvcGVyYXRpb25zIHdlIG9mZmljaWFsbHkgc3VwcG9ydCBtb2RpZnkgbGVuZ3RoIG9mIHRoZSBhcnJheVxuIyAoYWRkIGEgbmV3IGNvbXBvbmVudCBvciByZW1vdmUgYW4gb2xkIG9uZSkuIEJ1dCBpZiBzb21lYm9keSBpcyBtb2RpZnlpbmcgdGhlXG4jIHJlYWN0aXZlIHZhcmlhYmxlIGRpcmVjdGx5IHdlIHdhbnQgYSBzYW5lIGJlaGF2aW9yLiBUaGUgZGVmYXVsdCBSZWFjdGl2ZVZhclxuIyBlcXVhbGl0eSBhbHdheXMgcmV0dXJucyBmYWxzZSB3aGVuIGNvbXBhcmluZyBhbnkgbm9uLXByaW1pdGl2ZSB2YWx1ZXMuIEJlY2F1c2VcbiMgdGhlIG9yZGVyIG9mIGNvbXBvbmVudHMgaW4gdGhlIGNoaWxkcmVuIGFycmF5IGlzIGFyYml0cmFyeSB3ZSBjb3VsZCBmdXJ0aGVyXG4jIGltcHJvdmUgdGhpcyBjb21wYXJpc29uIHRvIGNvbXBhcmUgYXJyYXlzIGFzIHNldHMsIGlnbm9yaW5nIHRoZSBvcmRlci4gT3Igd2VcbiMgY291bGQgaGF2ZSBzb21lIGNhbm9uaWNhbCBvcmRlciBvZiBjb21wb25lbnRzIGluIHRoZSBhcnJheS5cbmFycmF5UmVmZXJlbmNlRXF1YWxzID0gKGEsIGIpIC0+XG4gIHJldHVybiBmYWxzZSBpZiBhLmxlbmd0aCBpc250IGIubGVuZ3RoXG5cbiAgZm9yIGkgaW4gWzAuLi5hLmxlbmd0aF1cbiAgICByZXR1cm4gZmFsc2UgaWYgYVtpXSBpc250IGJbaV1cblxuICB0cnVlXG5cbmNyZWF0ZU1hdGNoZXIgPSAocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKSAtPlxuICBpZiBfLmlzU3RyaW5nIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvblxuICAgIHByb3BlcnR5ID0gcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uXG4gICAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uID0gKGNoaWxkLCBwYXJlbnQpID0+XG4gICAgICBwcm9wZXJ0eSBvZiBjaGlsZFxuXG4gIGVsc2UgaWYgbm90IF8uaXNGdW5jdGlvbiBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb25cbiAgICBhc3NlcnQgXy5pc09iamVjdCBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb25cbiAgICBtYXRjaGVyID0gcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uXG4gICAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uID0gKGNoaWxkLCBwYXJlbnQpID0+XG4gICAgICBmb3IgcHJvcGVydHksIHZhbHVlIG9mIG1hdGNoZXJcbiAgICAgICAgcmV0dXJuIGZhbHNlIHVubGVzcyBwcm9wZXJ0eSBvZiBjaGlsZFxuXG4gICAgICAgIGlmIF8uaXNGdW5jdGlvbiBjaGlsZFtwcm9wZXJ0eV1cbiAgICAgICAgICByZXR1cm4gZmFsc2UgdW5sZXNzIGNoaWxkW3Byb3BlcnR5XSgpIGlzIHZhbHVlXG4gICAgICAgIGVsc2VcbiAgICAgICAgICByZXR1cm4gZmFsc2UgdW5sZXNzIGNoaWxkW3Byb3BlcnR5XSBpcyB2YWx1ZVxuXG4gICAgICB0cnVlXG5cbiAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uXG5cbmNsYXNzIENvbXBvbmVudHNOYW1lc3BhY2VcbiAgIyBXZSBoYXZlIGEgc3BlY2lhbCBmaWVsZCBmb3IgY29tcG9uZW50cy4gVGhpcyBhbGxvd3MgdXMgdG8gaGF2ZSB0aGUgbmFtZXNwYWNlIHdpdGggdGhlIHNhbWUgbmFtZVxuICAjIGFzIGEgY29tcG9uZW50LCB3aXRob3V0IG92ZXJyaWRpbmcgYW55dGhpbmcgaW4gdGhlIGNvbXBvbmVudCAod2UgZG8gbm90IHdhbnQgdG8gdXNlIGNvbXBvbmVudFxuICAjIG9iamVjdCBhcyBhIG5hbWVzcGFjZSBvYmplY3QpLlxuICBAQ09NUE9ORU5UU19GSUVMRDogJydcblxuZ2V0UGF0aEFuZE5hbWUgPSAobmFtZSkgLT5cbiAgYXNzZXJ0IG5hbWVcblxuICBwYXRoID0gbmFtZS5zcGxpdCAnLidcblxuICBuYW1lID0gcGF0aC5wb3AoKVxuXG4gIGFzc2VydCBuYW1lXG5cbiAge3BhdGgsIG5hbWV9XG5cbmdldE5hbWVzcGFjZSA9IChjb21wb25lbnRzLCBwYXRoKSAtPlxuICBhc3NlcnQgXy5pc09iamVjdCBjb21wb25lbnRzXG4gIGFzc2VydCBfLmlzQXJyYXkgcGF0aFxuXG4gIG1hdGNoID0gY29tcG9uZW50c1xuXG4gIHdoaWxlIChzZWdtZW50ID0gcGF0aC5zaGlmdCgpKT9cbiAgICBtYXRjaCA9IG1hdGNoW3NlZ21lbnRdXG4gICAgcmV0dXJuIG51bGwgdW5sZXNzIF8uaXNPYmplY3QgbWF0Y2hcblxuICByZXR1cm4gbnVsbCB1bmxlc3MgXy5pc09iamVjdCBtYXRjaFxuXG4gIG1hdGNoIG9yIG51bGxcblxuY3JlYXRlTmFtZXNwYWNlID0gKGNvbXBvbmVudHMsIHBhdGgpIC0+XG4gIGFzc2VydCBfLmlzT2JqZWN0IGNvbXBvbmVudHNcbiAgYXNzZXJ0IF8uaXNBcnJheSBwYXRoXG5cbiAgbWF0Y2ggPSBjb21wb25lbnRzXG5cbiAgd2hpbGUgKHNlZ21lbnQgPSBwYXRoLnNoaWZ0KCkpP1xuICAgIG1hdGNoW3NlZ21lbnRdID0gbmV3IGNvbXBvbmVudHMuY29uc3RydWN0b3IoKSB1bmxlc3Mgc2VnbWVudCBvZiBtYXRjaFxuICAgIG1hdGNoID0gbWF0Y2hbc2VnbWVudF1cbiAgICBhc3NlcnQgXy5pc09iamVjdCBtYXRjaFxuXG4gIGFzc2VydCBfLmlzT2JqZWN0IG1hdGNoXG5cbiAgbWF0Y2hcblxuZ2V0Q29tcG9uZW50ID0gKGNvbXBvbmVudHMsIG5hbWUpIC0+XG4gIGFzc2VydCBfLmlzT2JqZWN0IGNvbXBvbmVudHNcblxuICByZXR1cm4gbnVsbCB1bmxlc3MgbmFtZVxuXG4gIHtwYXRoLCBuYW1lfSA9IGdldFBhdGhBbmROYW1lIG5hbWVcblxuICBuYW1lc3BhY2UgPSBnZXROYW1lc3BhY2UgY29tcG9uZW50cywgcGF0aFxuICByZXR1cm4gbnVsbCB1bmxlc3MgbmFtZXNwYWNlXG5cbiAgbmFtZXNwYWNlW2NvbXBvbmVudHMuY29uc3RydWN0b3IuQ09NUE9ORU5UU19GSUVMRF0/W25hbWVdIG9yIG51bGxcblxuc2V0Q29tcG9uZW50ID0gKGNvbXBvbmVudHMsIG5hbWUsIGNvbXBvbmVudCkgLT5cbiAgYXNzZXJ0IF8uaXNPYmplY3QgY29tcG9uZW50c1xuICBhc3NlcnQgbmFtZVxuICBhc3NlcnQgY29tcG9uZW50XG5cbiAge3BhdGgsIG5hbWV9ID0gZ2V0UGF0aEFuZE5hbWUgbmFtZVxuXG4gIG5hbWVzcGFjZSA9IGNyZWF0ZU5hbWVzcGFjZSBjb21wb25lbnRzLCBwYXRoXG5cbiAgbmFtZXNwYWNlW2NvbXBvbmVudHMuY29uc3RydWN0b3IuQ09NUE9ORU5UU19GSUVMRF0gPz0gbmV3IGNvbXBvbmVudHMuY29uc3RydWN0b3IoKVxuICBhc3NlcnQgbmFtZSBub3Qgb2YgbmFtZXNwYWNlW2NvbXBvbmVudHMuY29uc3RydWN0b3IuQ09NUE9ORU5UU19GSUVMRF1cbiAgbmFtZXNwYWNlW2NvbXBvbmVudHMuY29uc3RydWN0b3IuQ09NUE9ORU5UU19GSUVMRF1bbmFtZV0gPSBjb21wb25lbnRcblxuY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmcgPSBmYWxzZVxuY29tcG9uZW50Q2hpbGRyZW5XaXRoRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2VcbmFkZENvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2VcbnJlbW92ZUNvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2VcblxuY29tcG9uZW50UGFyZW50RGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2VcblxuY2hpbGRyZW5Db21wb25lbnRzRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2VcbmNoaWxkcmVuQ29tcG9uZW50c1dpdGhEZXByZWNhdGlvbldhcm5pbmcgPSBmYWxzZVxuXG5jbGFzcyBCYXNlQ29tcG9uZW50XG4gIEBjb21wb25lbnRzOiBuZXcgQ29tcG9uZW50c05hbWVzcGFjZSgpXG5cbiAgQHJlZ2lzdGVyOiAoY29tcG9uZW50TmFtZSwgY29tcG9uZW50Q2xhc3MpIC0+XG4gICAgdGhyb3cgbmV3IEVycm9yIFwiQ29tcG9uZW50IG5hbWUgaXMgcmVxdWlyZWQgZm9yIHJlZ2lzdHJhdGlvbi5cIiB1bmxlc3MgY29tcG9uZW50TmFtZVxuXG4gICAgIyBUbyBhbGxvdyBjYWxsaW5nIEByZWdpc3RlciAnbmFtZScgZnJvbSBpbnNpZGUgYSBjbGFzcyBib2R5LlxuICAgIGNvbXBvbmVudENsYXNzID89IEBcblxuICAgIHRocm93IG5ldyBFcnJvciBcIkNvbXBvbmVudCAnI3sgY29tcG9uZW50TmFtZSB9JyBhbHJlYWR5IHJlZ2lzdGVyZWQuXCIgaWYgZ2V0Q29tcG9uZW50IEBjb21wb25lbnRzLCBjb21wb25lbnROYW1lXG5cbiAgICAjIFRoZSBsYXN0IGNvbmRpdGlvbiBpcyB0byBtYWtlIHN1cmUgd2UgZG8gbm90IHRocm93IHRoZSBleGNlcHRpb24gd2hlbiByZWdpc3RlcmluZyBhIHN1YmNsYXNzLlxuICAgICMgU3ViY2xhc3NlZCBjb21wb25lbnRzIGhhdmUgYXQgdGhpcyBzdGFnZSB0aGUgc2FtZSBjb21wb25lbnQgYXMgdGhlIHBhcmVudCBjb21wb25lbnQsIHNvIHdlIGhhdmVcbiAgICAjIHRvIGNoZWNrIGlmIHRoZXkgYXJlIHRoZSBzYW1lIGNsYXNzLiBJZiBub3QsIHRoaXMgaXMgbm90IGFuIGVycm9yLCBpdCBpcyBhIHN1YmNsYXNzLlxuICAgIGlmIGNvbXBvbmVudENsYXNzLmNvbXBvbmVudE5hbWUoKSBhbmQgY29tcG9uZW50Q2xhc3MuY29tcG9uZW50TmFtZSgpIGlzbnQgY29tcG9uZW50TmFtZSBhbmQgZ2V0Q29tcG9uZW50KEBjb21wb25lbnRzLCBjb21wb25lbnRDbGFzcy5jb21wb25lbnROYW1lKCkpIGlzIGNvbXBvbmVudENsYXNzXG4gICAgICB0aHJvdyBuZXcgRXJyb3IgXCJDb21wb25lbnQgJyN7IGNvbXBvbmVudE5hbWUgfScgYWxyZWFkeSByZWdpc3RlcmVkIHVuZGVyIHRoZSBuYW1lICcjeyBjb21wb25lbnRDbGFzcy5jb21wb25lbnROYW1lKCkgfScuXCJcblxuICAgIGNvbXBvbmVudENsYXNzLmNvbXBvbmVudE5hbWUgY29tcG9uZW50TmFtZVxuICAgIGFzc2VydC5lcXVhbCBjb21wb25lbnRDbGFzcy5jb21wb25lbnROYW1lKCksIGNvbXBvbmVudE5hbWVcblxuICAgIHNldENvbXBvbmVudCBAY29tcG9uZW50cywgY29tcG9uZW50TmFtZSwgY29tcG9uZW50Q2xhc3NcblxuICAgICMgVG8gYWxsb3cgY2hhaW5pbmcuXG4gICAgQFxuXG4gIEBnZXRDb21wb25lbnQ6IChjb21wb25lbnRzTmFtZXNwYWNlLCBjb21wb25lbnROYW1lKSAtPlxuICAgIHVubGVzcyBjb21wb25lbnROYW1lXG4gICAgICBjb21wb25lbnROYW1lID0gY29tcG9uZW50c05hbWVzcGFjZVxuICAgICAgY29tcG9uZW50c05hbWVzcGFjZSA9IEBjb21wb25lbnRzXG5cbiAgICAjIElmIGNvbXBvbmVudCBpcyBtaXNzaW5nLCBqdXN0IHJldHVybiBhIG51bGwuXG4gICAgcmV0dXJuIG51bGwgdW5sZXNzIGNvbXBvbmVudE5hbWVcblxuICAgICMgQnV0IG90aGVyd2lzZSB0aHJvdyBhbiBleGNlcHRpb24uXG4gICAgdGhyb3cgbmV3IEVycm9yIFwiQ29tcG9uZW50IG5hbWUgJyN7IGNvbXBvbmVudE5hbWUgfScgaXMgbm90IGEgc3RyaW5nLlwiIHVubGVzcyBfLmlzU3RyaW5nIGNvbXBvbmVudE5hbWVcblxuICAgIGdldENvbXBvbmVudCBjb21wb25lbnRzTmFtZXNwYWNlLCBjb21wb25lbnROYW1lXG5cbiAgIyBDb21wb25lbnQgbmFtZSBpcyBzZXQgaW4gdGhlIHJlZ2lzdGVyIGNsYXNzIG1ldGhvZC4gSWYgbm90IHVzaW5nIGEgcmVnaXN0ZXJlZCBjb21wb25lbnQgYW5kIGEgY29tcG9uZW50IG5hbWUgaXNcbiAgIyB3YW50ZWQsIGNvbXBvbmVudCBuYW1lIGhhcyB0byBiZSBzZXQgbWFudWFsbHkgb3IgdGhpcyBjbGFzcyBtZXRob2Qgc2hvdWxkIGJlIG92ZXJyaWRkZW4gd2l0aCBhIGN1c3RvbSBpbXBsZW1lbnRhdGlvbi5cbiAgIyBDYXJlIHNob3VsZCBiZSB0YWtlbiB0aGF0IHVucmVnaXN0ZXJlZCBjb21wb25lbnRzIGhhdmUgdGhlaXIgb3duIG5hbWUgYW5kIG5vdCB0aGUgbmFtZSBvZiB0aGVpciBwYXJlbnQgY2xhc3MsIHdoaWNoXG4gICMgdGhleSB3b3VsZCBoYXZlIGJ5IGRlZmF1bHQuIFByb2JhYmx5IGNvbXBvbmVudCBuYW1lIHNob3VsZCBiZSBzZXQgaW4gdGhlIGNvbnN0cnVjdG9yIGZvciBzdWNoIGNsYXNzZXMsIG9yIGJ5IGNhbGxpbmdcbiAgIyBjb21wb25lbnROYW1lIGNsYXNzIG1ldGhvZCBtYW51YWxseSBvbiB0aGUgbmV3IGNsYXNzIG9mIHRoaXMgbmV3IGNvbXBvbmVudC5cbiAgQGNvbXBvbmVudE5hbWU6IChjb21wb25lbnROYW1lKSAtPlxuICAgICMgU2V0dGVyLlxuICAgIGlmIGNvbXBvbmVudE5hbWVcbiAgICAgIEBfY29tcG9uZW50TmFtZSA9IGNvbXBvbmVudE5hbWVcbiAgICAgICMgVG8gYWxsb3cgY2hhaW5pbmcuXG4gICAgICByZXR1cm4gQFxuXG4gICAgIyBHZXR0ZXIuXG4gICAgQF9jb21wb25lbnROYW1lIG9yIG51bGxcblxuICAjIFdlIGFsbG93IGFjY2VzcyB0byB0aGUgY29tcG9uZW50IG5hbWUgdGhyb3VnaCBhIG1ldGhvZCBzbyB0aGF0IGl0IGNhbiBiZSBhY2Nlc3NlZCBpbiB0ZW1wbGF0ZXMgaW4gYW4gZWFzeSB3YXkuXG4gICMgSXQgc2hvdWxkIG5ldmVyIGJlIG92ZXJyaWRkZW4uIFRoZSBpbXBsZW1lbnRhdGlvbiBzaG91bGQgYWx3YXlzIGJlIGV4YWN0bHkgdGhlIHNhbWUgYXMgY2xhc3MgbWV0aG9kIGltcGxlbWVudGF0aW9uLlxuICBjb21wb25lbnROYW1lOiAtPlxuICAgICMgSW5zdGFuY2UgbWV0aG9kIGlzIGp1c3QgYSBnZXR0ZXIsIG5vdCBhIHNldHRlciBhcyB3ZWxsLlxuICAgIEBjb25zdHJ1Y3Rvci5jb21wb25lbnROYW1lKClcblxuICAjIFRoZSBvcmRlciBvZiBjb21wb25lbnRzIGlzIGFyYml0cmFyeSBhbmQgZG9lcyBub3QgbmVjZXNzYXJ5IG1hdGNoIHNpYmxpbmdzIHJlbGF0aW9ucyBpbiBET00uXG4gICMgbmFtZU9yQ29tcG9uZW50IGlzIG9wdGlvbmFsIGFuZCBpdCBsaW1pdHMgdGhlIHJldHVybmVkIGNoaWxkcmVuIG9ubHkgdG8gdGhvc2UuXG4gIGNoaWxkQ29tcG9uZW50czogKG5hbWVPckNvbXBvbmVudCkgLT5cbiAgICBAX2NvbXBvbmVudEludGVybmFscyA/PSB7fVxuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzLmNoaWxkQ29tcG9uZW50cyA/PSBuZXcgUmVhY3RpdmVGaWVsZCBbXSwgYXJyYXlSZWZlcmVuY2VFcXVhbHNcblxuICAgICMgUXVpY2sgcGF0aC4gUmV0dXJucyBhIHNoYWxsb3cgY29weS5cbiAgICByZXR1cm4gKGNoaWxkIGZvciBjaGlsZCBpbiBAX2NvbXBvbmVudEludGVybmFscy5jaGlsZENvbXBvbmVudHMoKSkgdW5sZXNzIG5hbWVPckNvbXBvbmVudFxuXG4gICAgaWYgXy5pc1N0cmluZyBuYW1lT3JDb21wb25lbnRcbiAgICAgIEBjaGlsZENvbXBvbmVudHNXaXRoIChjaGlsZCwgcGFyZW50KSA9PlxuICAgICAgICBjaGlsZC5jb21wb25lbnROYW1lKCkgaXMgbmFtZU9yQ29tcG9uZW50XG4gICAgZWxzZVxuICAgICAgQGNoaWxkQ29tcG9uZW50c1dpdGggKGNoaWxkLCBwYXJlbnQpID0+XG4gICAgICAgICMgbmFtZU9yQ29tcG9uZW50IGlzIGEgY2xhc3MuXG4gICAgICAgIHJldHVybiB0cnVlIGlmIGNoaWxkLmNvbnN0cnVjdG9yIGlzIG5hbWVPckNvbXBvbmVudFxuXG4gICAgICAgICMgbmFtZU9yQ29tcG9uZW50IGlzIGFuIGluc3RhbmNlLCBvciBzb21ldGhpbmcgZWxzZS5cbiAgICAgICAgcmV0dXJuIHRydWUgaWYgY2hpbGQgaXMgbmFtZU9yQ29tcG9uZW50XG5cbiAgICAgICAgZmFsc2VcblxuICAjIFRoZSBvcmRlciBvZiBjb21wb25lbnRzIGlzIGFyYml0cmFyeSBhbmQgZG9lcyBub3QgbmVjZXNzYXJ5IG1hdGNoIHNpYmxpbmdzIHJlbGF0aW9ucyBpbiBET00uXG4gICMgUmV0dXJucyBjaGlsZHJlbiB3aGljaCBwYXNzIGEgcHJlZGljYXRlIGZ1bmN0aW9uLlxuICBjaGlsZENvbXBvbmVudHNXaXRoOiAocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKSAtPlxuICAgIGFzc2VydCBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb25cblxuICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IGNyZWF0ZU1hdGNoZXIgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uXG5cbiAgICByZXN1bHRzID0gbmV3IENvbXB1dGVkRmllbGQgPT5cbiAgICAgIGNoaWxkIGZvciBjaGlsZCBpbiBAY2hpbGRDb21wb25lbnRzKCkgd2hlbiBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24uY2FsbCBALCBjaGlsZCwgQFxuICAgICxcbiAgICAgIGFycmF5UmVmZXJlbmNlRXF1YWxzXG5cbiAgICByZXN1bHRzKClcblxuICBhZGRDaGlsZENvbXBvbmVudDogKGNoaWxkQ29tcG9uZW50KSAtPlxuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzID89IHt9XG4gICAgQF9jb21wb25lbnRJbnRlcm5hbHMuY2hpbGRDb21wb25lbnRzID89IG5ldyBSZWFjdGl2ZUZpZWxkIFtdLCBhcnJheVJlZmVyZW5jZUVxdWFsc1xuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzLmNoaWxkQ29tcG9uZW50cyBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICBAX2NvbXBvbmVudEludGVybmFscy5jaGlsZENvbXBvbmVudHMoKS5jb25jYXQgW2NoaWxkQ29tcG9uZW50XVxuXG4gICAgIyBUbyBhbGxvdyBjaGFpbmluZy5cbiAgICBAXG5cbiAgcmVtb3ZlQ2hpbGRDb21wb25lbnQ6IChjaGlsZENvbXBvbmVudCkgLT5cbiAgICBAX2NvbXBvbmVudEludGVybmFscyA/PSB7fVxuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzLmNoaWxkQ29tcG9uZW50cyA/PSBuZXcgUmVhY3RpdmVGaWVsZCBbXSwgYXJyYXlSZWZlcmVuY2VFcXVhbHNcbiAgICBAX2NvbXBvbmVudEludGVybmFscy5jaGlsZENvbXBvbmVudHMgVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgXy53aXRob3V0IEBfY29tcG9uZW50SW50ZXJuYWxzLmNoaWxkQ29tcG9uZW50cygpLCBjaGlsZENvbXBvbmVudFxuXG4gICAgIyBUbyBhbGxvdyBjaGFpbmluZy5cbiAgICBAXG5cbiAgcGFyZW50Q29tcG9uZW50OiAocGFyZW50Q29tcG9uZW50KSAtPlxuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzID89IHt9XG4gICAgIyBXZSB1c2UgcmVmZXJlbmNlIGVxdWFsaXR5IGhlcmUuIFRoaXMgbWFrZXMgcmVhY3Rpdml0eSBub3QgaW52YWxpZGF0ZSB0aGVcbiAgICAjIGNvbXB1dGF0aW9uIGlmIHRoZSBzYW1lIGNvbXBvbmVudCBpbnN0YW5jZSAoYnkgcmVmZXJlbmNlKSBpcyBzZXQgYXMgYSBwYXJlbnQuXG4gICAgQF9jb21wb25lbnRJbnRlcm5hbHMucGFyZW50Q29tcG9uZW50ID89IG5ldyBSZWFjdGl2ZUZpZWxkIG51bGwsIChhLCBiKSAtPiBhIGlzIGJcblxuICAgICMgU2V0dGVyLlxuICAgIHVubGVzcyBfLmlzVW5kZWZpbmVkIHBhcmVudENvbXBvbmVudFxuICAgICAgQF9jb21wb25lbnRJbnRlcm5hbHMucGFyZW50Q29tcG9uZW50IHBhcmVudENvbXBvbmVudFxuICAgICAgIyBUbyBhbGxvdyBjaGFpbmluZy5cbiAgICAgIHJldHVybiBAXG5cbiAgICAjIEdldHRlci5cbiAgICBAX2NvbXBvbmVudEludGVybmFscy5wYXJlbnRDb21wb25lbnQoKVxuXG4gIEByZW5kZXJDb21wb25lbnQ6IChwYXJlbnRDb21wb25lbnQpIC0+XG4gICAgdGhyb3cgbmV3IEVycm9yIFwiTm90IGltcGxlbWVudGVkXCJcblxuICByZW5kZXJDb21wb25lbnQ6IChwYXJlbnRDb21wb25lbnQpIC0+XG4gICAgdGhyb3cgbmV3IEVycm9yIFwiTm90IGltcGxlbWVudGVkXCJcblxuICBAZXh0ZW5kQ29tcG9uZW50OiAoY29uc3RydWN0b3IsIG1ldGhvZHMpIC0+XG4gICAgY3VycmVudENsYXNzID0gQFxuXG4gICAgaWYgXy5pc0Z1bmN0aW9uIGNvbnN0cnVjdG9yXG4gICAgICBjb25zdHJ1Y3Rvcjo6ID0gT2JqZWN0LmNyZWF0ZSBjdXJyZW50Q2xhc3M6OixcbiAgICAgICAgY29uc3RydWN0b3I6XG4gICAgICAgICAgdmFsdWU6IGNvbnN0cnVjdG9yXG4gICAgICAgICAgd3JpdGFibGU6IHRydWVcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWVcblxuICAgICAgT2JqZWN0LnNldFByb3RvdHlwZU9mIGNvbnN0cnVjdG9yLCBjdXJyZW50Q2xhc3NcblxuICAgIGVsc2VcbiAgICAgIG1ldGhvZHMgPSBjb25zdHJ1Y3RvclxuICAgICAgY29uc3RydWN0b3IgPSBjbGFzcyBleHRlbmRzIGN1cnJlbnRDbGFzc1xuXG4gICAgIyBXZSBleHBlY3QgdGhlIHBsYWluIG9iamVjdCBvZiBtZXRob2RzIGhlcmUsIGJ1dCBpZiBzb21ldGhpbmdcbiAgICAjIGVsc2UgaXMgcGFzc2VkLCB3ZSB1c2Ugb25seSBcIm93blwiIHByb3BlcnRpZXMuXG4gICAgZm9yIG93biBwcm9wZXJ0eSwgdmFsdWUgb2YgbWV0aG9kcyBvciB7fVxuICAgICAgY29uc3RydWN0b3I6Oltwcm9wZXJ0eV0gPSB2YWx1ZVxuXG4gICAgY29uc3RydWN0b3JcblxuICAjIERlcHJlY2F0ZWQgbWV0aG9kIG5hbWVzLlxuICAjIFRPRE86IFJlbW92ZSB0aGVtIGluIHRoZSBmdXR1cmUuXG5cbiAgIyBAZGVwcmVjYXRlZCBVc2UgY2hpbGRDb21wb25lbnRzIGluc3RlYWQuXG4gIGNvbXBvbmVudENoaWxkcmVuOiAoYXJncy4uLikgLT5cbiAgICB1bmxlc3MgY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmdcbiAgICAgIGNvbXBvbmVudENoaWxkcmVuRGVwcmVjYXRpb25XYXJuaW5nID0gdHJ1ZVxuICAgICAgY29uc29sZT8ud2FybiBcImNvbXBvbmVudENoaWxkcmVuIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBjaGlsZENvbXBvbmVudHMgaW5zdGVhZC5cIlxuXG4gICAgQGNoaWxkQ29tcG9uZW50cyBhcmdzLi4uXG5cbiAgIyBAZGVwcmVjYXRlZCBVc2UgY2hpbGRDb21wb25lbnRzV2l0aCBpbnN0ZWFkLlxuICBjb21wb25lbnRDaGlsZHJlbldpdGg6IChhcmdzLi4uKSAtPlxuICAgIHVubGVzcyBjb21wb25lbnRDaGlsZHJlbldpdGhEZXByZWNhdGlvbldhcm5pbmdcbiAgICAgIGNvbXBvbmVudENoaWxkcmVuV2l0aERlcHJlY2F0aW9uV2FybmluZyA9IHRydWVcbiAgICAgIGNvbnNvbGU/Lndhcm4gXCJjb21wb25lbnRDaGlsZHJlbldpdGggaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIGNoaWxkQ29tcG9uZW50c1dpdGggaW5zdGVhZC5cIlxuXG4gICAgQGNoaWxkQ29tcG9uZW50c1dpdGggYXJncy4uLlxuXG4gICMgQGRlcHJlY2F0ZWQgVXNlIGFkZENoaWxkQ29tcG9uZW50IGluc3RlYWQuXG4gIGFkZENvbXBvbmVudENoaWxkOiAoYXJncy4uLikgLT5cbiAgICB1bmxlc3MgYWRkQ29tcG9uZW50Q2hpbGREZXByZWNhdGlvbldhcm5pbmdcbiAgICAgIGFkZENvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nID0gdHJ1ZVxuICAgICAgY29uc29sZT8ud2FybiBcImFkZENvbXBvbmVudENoaWxkIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBhZGRDaGlsZENvbXBvbmVudCBpbnN0ZWFkLlwiXG5cbiAgICBAYWRkQ2hpbGRDb21wb25lbnQgYXJncy4uLlxuXG4gICMgQGRlcHJlY2F0ZWQgVXNlIHJlbW92ZUNoaWxkQ29tcG9uZW50IGluc3RlYWQuXG4gIHJlbW92ZUNvbXBvbmVudENoaWxkOiAoYXJncy4uLikgLT5cbiAgICB1bmxlc3MgcmVtb3ZlQ29tcG9uZW50Q2hpbGREZXByZWNhdGlvbldhcm5pbmdcbiAgICAgIHJlbW92ZUNvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nID0gdHJ1ZVxuICAgICAgY29uc29sZT8ud2FybiBcInJlbW92ZUNvbXBvbmVudENoaWxkIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSByZW1vdmVDaGlsZENvbXBvbmVudCBpbnN0ZWFkLlwiXG5cbiAgICBAcmVtb3ZlQ2hpbGRDb21wb25lbnQgYXJncy4uLlxuXG4gICMgQGRlcHJlY2F0ZWQgVXNlIHBhcmVudENvbXBvbmVudCBpbnN0ZWFkLlxuICBjb21wb25lbnRQYXJlbnQ6IChhcmdzLi4uKSAtPlxuICAgIHVubGVzcyBjb21wb25lbnRQYXJlbnREZXByZWNhdGlvbldhcm5pbmdcbiAgICAgIGNvbXBvbmVudFBhcmVudERlcHJlY2F0aW9uV2FybmluZyA9IHRydWVcbiAgICAgIGNvbnNvbGU/Lndhcm4gXCJjb21wb25lbnRQYXJlbnQgaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIHBhcmVudENvbXBvbmVudCBpbnN0ZWFkLlwiXG5cbiAgICBAcGFyZW50Q29tcG9uZW50IGFyZ3MuLi5cblxuICAjIEBkZXByZWNhdGVkIFVzZSBjaGlsZENvbXBvbmVudHMgaW5zdGVhZC5cbiAgY2hpbGRyZW5Db21wb25lbnRzOiAoYXJncy4uLikgLT5cbiAgICB1bmxlc3MgY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmdcbiAgICAgIGNvbXBvbmVudENoaWxkcmVuRGVwcmVjYXRpb25XYXJuaW5nID0gdHJ1ZVxuICAgICAgY29uc29sZT8ud2FybiBcImNoaWxkcmVuQ29tcG9uZW50cyBoYXMgYmVlbiBkZXByZWNhdGVkLiBVc2UgY2hpbGRDb21wb25lbnRzIGluc3RlYWQuXCJcblxuICAgIEBjaGlsZENvbXBvbmVudHMgYXJncy4uLlxuXG4gICMgQGRlcHJlY2F0ZWQgVXNlIGNoaWxkQ29tcG9uZW50c1dpdGggaW5zdGVhZC5cbiAgY2hpbGRyZW5Db21wb25lbnRzV2l0aDogKGFyZ3MuLi4pIC0+XG4gICAgdW5sZXNzIGNvbXBvbmVudENoaWxkcmVuV2l0aERlcHJlY2F0aW9uV2FybmluZ1xuICAgICAgY29tcG9uZW50Q2hpbGRyZW5XaXRoRGVwcmVjYXRpb25XYXJuaW5nID0gdHJ1ZVxuICAgICAgY29uc29sZT8ud2FybiBcImNoaWxkcmVuQ29tcG9uZW50c1dpdGggaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIGNoaWxkQ29tcG9uZW50c1dpdGggaW5zdGVhZC5cIlxuXG4gICAgQGNoaWxkQ29tcG9uZW50c1dpdGggYXJncy4uLlxuIiwiICAvLyBDb21wYXJpbmcgYXJyYXlzIG9mIGNvbXBvbmVudHMgYnkgcmVmZXJlbmNlLiBUaGlzIG1pZ2h0IG5vdCBiZSByZWFsbHkgbmVjZXNzYXJ5XG4gIC8vIHRvIGRvLCBiZWNhdXNlIGFsbCBvcGVyYXRpb25zIHdlIG9mZmljaWFsbHkgc3VwcG9ydCBtb2RpZnkgbGVuZ3RoIG9mIHRoZSBhcnJheVxuICAvLyAoYWRkIGEgbmV3IGNvbXBvbmVudCBvciByZW1vdmUgYW4gb2xkIG9uZSkuIEJ1dCBpZiBzb21lYm9keSBpcyBtb2RpZnlpbmcgdGhlXG4gIC8vIHJlYWN0aXZlIHZhcmlhYmxlIGRpcmVjdGx5IHdlIHdhbnQgYSBzYW5lIGJlaGF2aW9yLiBUaGUgZGVmYXVsdCBSZWFjdGl2ZVZhclxuICAvLyBlcXVhbGl0eSBhbHdheXMgcmV0dXJucyBmYWxzZSB3aGVuIGNvbXBhcmluZyBhbnkgbm9uLXByaW1pdGl2ZSB2YWx1ZXMuIEJlY2F1c2VcbiAgLy8gdGhlIG9yZGVyIG9mIGNvbXBvbmVudHMgaW4gdGhlIGNoaWxkcmVuIGFycmF5IGlzIGFyYml0cmFyeSB3ZSBjb3VsZCBmdXJ0aGVyXG4gIC8vIGltcHJvdmUgdGhpcyBjb21wYXJpc29uIHRvIGNvbXBhcmUgYXJyYXlzIGFzIHNldHMsIGlnbm9yaW5nIHRoZSBvcmRlci4gT3Igd2VcbiAgLy8gY291bGQgaGF2ZSBzb21lIGNhbm9uaWNhbCBvcmRlciBvZiBjb21wb25lbnRzIGluIHRoZSBhcnJheS5cbnZhciBDb21wb25lbnRzTmFtZXNwYWNlLCBhZGRDb21wb25lbnRDaGlsZERlcHJlY2F0aW9uV2FybmluZywgYXJyYXlSZWZlcmVuY2VFcXVhbHMsIGNoaWxkcmVuQ29tcG9uZW50c0RlcHJlY2F0aW9uV2FybmluZywgY2hpbGRyZW5Db21wb25lbnRzV2l0aERlcHJlY2F0aW9uV2FybmluZywgY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmcsIGNvbXBvbmVudENoaWxkcmVuV2l0aERlcHJlY2F0aW9uV2FybmluZywgY29tcG9uZW50UGFyZW50RGVwcmVjYXRpb25XYXJuaW5nLCBjcmVhdGVNYXRjaGVyLCBjcmVhdGVOYW1lc3BhY2UsIGdldENvbXBvbmVudCwgZ2V0TmFtZXNwYWNlLCBnZXRQYXRoQW5kTmFtZSwgcmVtb3ZlQ29tcG9uZW50Q2hpbGREZXByZWNhdGlvbldhcm5pbmcsIHNldENvbXBvbmVudCwgICAgICAgICAgICAgICBcbiAgaGFzUHJvcCA9IHt9Lmhhc093blByb3BlcnR5O1xuXG5hcnJheVJlZmVyZW5jZUVxdWFscyA9IGZ1bmN0aW9uKGEsIGIpIHtcbiAgdmFyIGksIGosIHJlZjtcbiAgaWYgKGEubGVuZ3RoICE9PSBiLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBmb3IgKGkgPSBqID0gMCwgcmVmID0gYS5sZW5ndGg7ICgwIDw9IHJlZiA/IGogPCByZWYgOiBqID4gcmVmKTsgaSA9IDAgPD0gcmVmID8gKytqIDogLS1qKSB7XG4gICAgaWYgKGFbaV0gIT09IGJbaV0pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59O1xuXG5jcmVhdGVNYXRjaGVyID0gZnVuY3Rpb24ocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKSB7XG4gIHZhciBtYXRjaGVyLCBwcm9wZXJ0eTtcbiAgaWYgKF8uaXNTdHJpbmcocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKSkge1xuICAgIHByb3BlcnR5ID0gcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uO1xuICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IChjaGlsZCwgcGFyZW50KSA9PiB7XG4gICAgICByZXR1cm4gcHJvcGVydHkgaW4gY2hpbGQ7XG4gICAgfTtcbiAgfSBlbHNlIGlmICghXy5pc0Z1bmN0aW9uKHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbikpIHtcbiAgICBhc3NlcnQoXy5pc09iamVjdChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pKTtcbiAgICBtYXRjaGVyID0gcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uO1xuICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IChjaGlsZCwgcGFyZW50KSA9PiB7XG4gICAgICB2YXIgdmFsdWU7XG4gICAgICBmb3IgKHByb3BlcnR5IGluIG1hdGNoZXIpIHtcbiAgICAgICAgdmFsdWUgPSBtYXRjaGVyW3Byb3BlcnR5XTtcbiAgICAgICAgaWYgKCEocHJvcGVydHkgaW4gY2hpbGQpKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChfLmlzRnVuY3Rpb24oY2hpbGRbcHJvcGVydHldKSkge1xuICAgICAgICAgIGlmIChjaGlsZFtwcm9wZXJ0eV0oKSAhPT0gdmFsdWUpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKGNoaWxkW3Byb3BlcnR5XSAhPT0gdmFsdWUpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG4gIH1cbiAgcmV0dXJuIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbjtcbn07XG5cbkNvbXBvbmVudHNOYW1lc3BhY2UgPSAoZnVuY3Rpb24oKSB7XG4gIGNsYXNzIENvbXBvbmVudHNOYW1lc3BhY2Uge307XG5cbiAgLy8gV2UgaGF2ZSBhIHNwZWNpYWwgZmllbGQgZm9yIGNvbXBvbmVudHMuIFRoaXMgYWxsb3dzIHVzIHRvIGhhdmUgdGhlIG5hbWVzcGFjZSB3aXRoIHRoZSBzYW1lIG5hbWVcbiAgLy8gYXMgYSBjb21wb25lbnQsIHdpdGhvdXQgb3ZlcnJpZGluZyBhbnl0aGluZyBpbiB0aGUgY29tcG9uZW50ICh3ZSBkbyBub3Qgd2FudCB0byB1c2UgY29tcG9uZW50XG4gIC8vIG9iamVjdCBhcyBhIG5hbWVzcGFjZSBvYmplY3QpLlxuICBDb21wb25lbnRzTmFtZXNwYWNlLkNPTVBPTkVOVFNfRklFTEQgPSAnJztcblxuICByZXR1cm4gQ29tcG9uZW50c05hbWVzcGFjZTtcblxufSkuY2FsbCh0aGlzKTtcblxuZ2V0UGF0aEFuZE5hbWUgPSBmdW5jdGlvbihuYW1lKSB7XG4gIHZhciBwYXRoO1xuICBhc3NlcnQobmFtZSk7XG4gIHBhdGggPSBuYW1lLnNwbGl0KCcuJyk7XG4gIG5hbWUgPSBwYXRoLnBvcCgpO1xuICBhc3NlcnQobmFtZSk7XG4gIHJldHVybiB7cGF0aCwgbmFtZX07XG59O1xuXG5nZXROYW1lc3BhY2UgPSBmdW5jdGlvbihjb21wb25lbnRzLCBwYXRoKSB7XG4gIHZhciBtYXRjaCwgc2VnbWVudDtcbiAgYXNzZXJ0KF8uaXNPYmplY3QoY29tcG9uZW50cykpO1xuICBhc3NlcnQoXy5pc0FycmF5KHBhdGgpKTtcbiAgbWF0Y2ggPSBjb21wb25lbnRzO1xuICB3aGlsZSAoKHNlZ21lbnQgPSBwYXRoLnNoaWZ0KCkpICE9IG51bGwpIHtcbiAgICBtYXRjaCA9IG1hdGNoW3NlZ21lbnRdO1xuICAgIGlmICghXy5pc09iamVjdChtYXRjaCkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfVxuICBpZiAoIV8uaXNPYmplY3QobWF0Y2gpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgcmV0dXJuIG1hdGNoIHx8IG51bGw7XG59O1xuXG5jcmVhdGVOYW1lc3BhY2UgPSBmdW5jdGlvbihjb21wb25lbnRzLCBwYXRoKSB7XG4gIHZhciBtYXRjaCwgc2VnbWVudDtcbiAgYXNzZXJ0KF8uaXNPYmplY3QoY29tcG9uZW50cykpO1xuICBhc3NlcnQoXy5pc0FycmF5KHBhdGgpKTtcbiAgbWF0Y2ggPSBjb21wb25lbnRzO1xuICB3aGlsZSAoKHNlZ21lbnQgPSBwYXRoLnNoaWZ0KCkpICE9IG51bGwpIHtcbiAgICBpZiAoIShzZWdtZW50IGluIG1hdGNoKSkge1xuICAgICAgbWF0Y2hbc2VnbWVudF0gPSBuZXcgY29tcG9uZW50cy5jb25zdHJ1Y3RvcigpO1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoW3NlZ21lbnRdO1xuICAgIGFzc2VydChfLmlzT2JqZWN0KG1hdGNoKSk7XG4gIH1cbiAgYXNzZXJ0KF8uaXNPYmplY3QobWF0Y2gpKTtcbiAgcmV0dXJuIG1hdGNoO1xufTtcblxuZ2V0Q29tcG9uZW50ID0gZnVuY3Rpb24oY29tcG9uZW50cywgbmFtZSkge1xuICB2YXIgbmFtZXNwYWNlLCBwYXRoLCByZWY7XG4gIGFzc2VydChfLmlzT2JqZWN0KGNvbXBvbmVudHMpKTtcbiAgaWYgKCFuYW1lKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgKHtwYXRoLCBuYW1lfSA9IGdldFBhdGhBbmROYW1lKG5hbWUpKTtcbiAgbmFtZXNwYWNlID0gZ2V0TmFtZXNwYWNlKGNvbXBvbmVudHMsIHBhdGgpO1xuICBpZiAoIW5hbWVzcGFjZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAoKHJlZiA9IG5hbWVzcGFjZVtjb21wb25lbnRzLmNvbnN0cnVjdG9yLkNPTVBPTkVOVFNfRklFTERdKSAhPSBudWxsID8gcmVmW25hbWVdIDogdm9pZCAwKSB8fCBudWxsO1xufTtcblxuc2V0Q29tcG9uZW50ID0gZnVuY3Rpb24oY29tcG9uZW50cywgbmFtZSwgY29tcG9uZW50KSB7XG4gIHZhciBuYW1lMSwgbmFtZXNwYWNlLCBwYXRoO1xuICBhc3NlcnQoXy5pc09iamVjdChjb21wb25lbnRzKSk7XG4gIGFzc2VydChuYW1lKTtcbiAgYXNzZXJ0KGNvbXBvbmVudCk7XG4gICh7cGF0aCwgbmFtZX0gPSBnZXRQYXRoQW5kTmFtZShuYW1lKSk7XG4gIG5hbWVzcGFjZSA9IGNyZWF0ZU5hbWVzcGFjZShjb21wb25lbnRzLCBwYXRoKTtcbiAgaWYgKG5hbWVzcGFjZVtuYW1lMSA9IGNvbXBvbmVudHMuY29uc3RydWN0b3IuQ09NUE9ORU5UU19GSUVMRF0gPT0gbnVsbCkge1xuICAgIG5hbWVzcGFjZVtuYW1lMV0gPSBuZXcgY29tcG9uZW50cy5jb25zdHJ1Y3RvcigpO1xuICB9XG4gIGFzc2VydCghKG5hbWUgaW4gbmFtZXNwYWNlW2NvbXBvbmVudHMuY29uc3RydWN0b3IuQ09NUE9ORU5UU19GSUVMRF0pKTtcbiAgcmV0dXJuIG5hbWVzcGFjZVtjb21wb25lbnRzLmNvbnN0cnVjdG9yLkNPTVBPTkVOVFNfRklFTERdW25hbWVdID0gY29tcG9uZW50O1xufTtcblxuY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmcgPSBmYWxzZTtcblxuY29tcG9uZW50Q2hpbGRyZW5XaXRoRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2U7XG5cbmFkZENvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2U7XG5cbnJlbW92ZUNvbXBvbmVudENoaWxkRGVwcmVjYXRpb25XYXJuaW5nID0gZmFsc2U7XG5cbmNvbXBvbmVudFBhcmVudERlcHJlY2F0aW9uV2FybmluZyA9IGZhbHNlO1xuXG5jaGlsZHJlbkNvbXBvbmVudHNEZXByZWNhdGlvbldhcm5pbmcgPSBmYWxzZTtcblxuY2hpbGRyZW5Db21wb25lbnRzV2l0aERlcHJlY2F0aW9uV2FybmluZyA9IGZhbHNlO1xuXG5CYXNlQ29tcG9uZW50ID0gKGZ1bmN0aW9uKCkge1xuICBjbGFzcyBCYXNlQ29tcG9uZW50IHtcbiAgICBzdGF0aWMgcmVnaXN0ZXIoY29tcG9uZW50TmFtZSwgY29tcG9uZW50Q2xhc3MpIHtcbiAgICAgIGlmICghY29tcG9uZW50TmFtZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDb21wb25lbnQgbmFtZSBpcyByZXF1aXJlZCBmb3IgcmVnaXN0cmF0aW9uLlwiKTtcbiAgICAgIH1cbiAgICAgIC8vIFRvIGFsbG93IGNhbGxpbmcgQHJlZ2lzdGVyICduYW1lJyBmcm9tIGluc2lkZSBhIGNsYXNzIGJvZHkuXG4gICAgICBpZiAoY29tcG9uZW50Q2xhc3MgPT0gbnVsbCkge1xuICAgICAgICBjb21wb25lbnRDbGFzcyA9IHRoaXM7XG4gICAgICB9XG4gICAgICBpZiAoZ2V0Q29tcG9uZW50KHRoaXMuY29tcG9uZW50cywgY29tcG9uZW50TmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDb21wb25lbnQgJyR7Y29tcG9uZW50TmFtZX0nIGFscmVhZHkgcmVnaXN0ZXJlZC5gKTtcbiAgICAgIH1cbiAgICAgIC8vIFRoZSBsYXN0IGNvbmRpdGlvbiBpcyB0byBtYWtlIHN1cmUgd2UgZG8gbm90IHRocm93IHRoZSBleGNlcHRpb24gd2hlbiByZWdpc3RlcmluZyBhIHN1YmNsYXNzLlxuICAgICAgLy8gU3ViY2xhc3NlZCBjb21wb25lbnRzIGhhdmUgYXQgdGhpcyBzdGFnZSB0aGUgc2FtZSBjb21wb25lbnQgYXMgdGhlIHBhcmVudCBjb21wb25lbnQsIHNvIHdlIGhhdmVcbiAgICAgIC8vIHRvIGNoZWNrIGlmIHRoZXkgYXJlIHRoZSBzYW1lIGNsYXNzLiBJZiBub3QsIHRoaXMgaXMgbm90IGFuIGVycm9yLCBpdCBpcyBhIHN1YmNsYXNzLlxuICAgICAgaWYgKGNvbXBvbmVudENsYXNzLmNvbXBvbmVudE5hbWUoKSAmJiBjb21wb25lbnRDbGFzcy5jb21wb25lbnROYW1lKCkgIT09IGNvbXBvbmVudE5hbWUgJiYgZ2V0Q29tcG9uZW50KHRoaXMuY29tcG9uZW50cywgY29tcG9uZW50Q2xhc3MuY29tcG9uZW50TmFtZSgpKSA9PT0gY29tcG9uZW50Q2xhc3MpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDb21wb25lbnQgJyR7Y29tcG9uZW50TmFtZX0nIGFscmVhZHkgcmVnaXN0ZXJlZCB1bmRlciB0aGUgbmFtZSAnJHtjb21wb25lbnRDbGFzcy5jb21wb25lbnROYW1lKCl9Jy5gKTtcbiAgICAgIH1cbiAgICAgIGNvbXBvbmVudENsYXNzLmNvbXBvbmVudE5hbWUoY29tcG9uZW50TmFtZSk7XG4gICAgICBhc3NlcnQuZXF1YWwoY29tcG9uZW50Q2xhc3MuY29tcG9uZW50TmFtZSgpLCBjb21wb25lbnROYW1lKTtcbiAgICAgIHNldENvbXBvbmVudCh0aGlzLmNvbXBvbmVudHMsIGNvbXBvbmVudE5hbWUsIGNvbXBvbmVudENsYXNzKTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHN0YXRpYyBnZXRDb21wb25lbnQoY29tcG9uZW50c05hbWVzcGFjZSwgY29tcG9uZW50TmFtZSkge1xuICAgICAgaWYgKCFjb21wb25lbnROYW1lKSB7XG4gICAgICAgIGNvbXBvbmVudE5hbWUgPSBjb21wb25lbnRzTmFtZXNwYWNlO1xuICAgICAgICBjb21wb25lbnRzTmFtZXNwYWNlID0gdGhpcy5jb21wb25lbnRzO1xuICAgICAgfVxuICAgICAgaWYgKCFjb21wb25lbnROYW1lKSB7XG4gICAgICAgIC8vIElmIGNvbXBvbmVudCBpcyBtaXNzaW5nLCBqdXN0IHJldHVybiBhIG51bGwuXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKCFfLmlzU3RyaW5nKGNvbXBvbmVudE5hbWUpKSB7XG4gICAgICAgIC8vIEJ1dCBvdGhlcndpc2UgdGhyb3cgYW4gZXhjZXB0aW9uLlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENvbXBvbmVudCBuYW1lICcke2NvbXBvbmVudE5hbWV9JyBpcyBub3QgYSBzdHJpbmcuYCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZ2V0Q29tcG9uZW50KGNvbXBvbmVudHNOYW1lc3BhY2UsIGNvbXBvbmVudE5hbWUpO1xuICAgIH1cblxuICAgIC8vIENvbXBvbmVudCBuYW1lIGlzIHNldCBpbiB0aGUgcmVnaXN0ZXIgY2xhc3MgbWV0aG9kLiBJZiBub3QgdXNpbmcgYSByZWdpc3RlcmVkIGNvbXBvbmVudCBhbmQgYSBjb21wb25lbnQgbmFtZSBpc1xuICAgIC8vIHdhbnRlZCwgY29tcG9uZW50IG5hbWUgaGFzIHRvIGJlIHNldCBtYW51YWxseSBvciB0aGlzIGNsYXNzIG1ldGhvZCBzaG91bGQgYmUgb3ZlcnJpZGRlbiB3aXRoIGEgY3VzdG9tIGltcGxlbWVudGF0aW9uLlxuICAgIC8vIENhcmUgc2hvdWxkIGJlIHRha2VuIHRoYXQgdW5yZWdpc3RlcmVkIGNvbXBvbmVudHMgaGF2ZSB0aGVpciBvd24gbmFtZSBhbmQgbm90IHRoZSBuYW1lIG9mIHRoZWlyIHBhcmVudCBjbGFzcywgd2hpY2hcbiAgICAvLyB0aGV5IHdvdWxkIGhhdmUgYnkgZGVmYXVsdC4gUHJvYmFibHkgY29tcG9uZW50IG5hbWUgc2hvdWxkIGJlIHNldCBpbiB0aGUgY29uc3RydWN0b3IgZm9yIHN1Y2ggY2xhc3Nlcywgb3IgYnkgY2FsbGluZ1xuICAgIC8vIGNvbXBvbmVudE5hbWUgY2xhc3MgbWV0aG9kIG1hbnVhbGx5IG9uIHRoZSBuZXcgY2xhc3Mgb2YgdGhpcyBuZXcgY29tcG9uZW50LlxuICAgIHN0YXRpYyBjb21wb25lbnROYW1lKGNvbXBvbmVudE5hbWUpIHtcbiAgICAgIC8vIFNldHRlci5cbiAgICAgIGlmIChjb21wb25lbnROYW1lKSB7XG4gICAgICAgIHRoaXMuX2NvbXBvbmVudE5hbWUgPSBjb21wb25lbnROYW1lO1xuICAgICAgICAvLyBUbyBhbGxvdyBjaGFpbmluZy5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9XG4gICAgICAvLyBHZXR0ZXIuXG4gICAgICByZXR1cm4gdGhpcy5fY29tcG9uZW50TmFtZSB8fCBudWxsO1xuICAgIH1cblxuICAgIC8vIFdlIGFsbG93IGFjY2VzcyB0byB0aGUgY29tcG9uZW50IG5hbWUgdGhyb3VnaCBhIG1ldGhvZCBzbyB0aGF0IGl0IGNhbiBiZSBhY2Nlc3NlZCBpbiB0ZW1wbGF0ZXMgaW4gYW4gZWFzeSB3YXkuXG4gICAgLy8gSXQgc2hvdWxkIG5ldmVyIGJlIG92ZXJyaWRkZW4uIFRoZSBpbXBsZW1lbnRhdGlvbiBzaG91bGQgYWx3YXlzIGJlIGV4YWN0bHkgdGhlIHNhbWUgYXMgY2xhc3MgbWV0aG9kIGltcGxlbWVudGF0aW9uLlxuICAgIGNvbXBvbmVudE5hbWUoKSB7XG4gICAgICAvLyBJbnN0YW5jZSBtZXRob2QgaXMganVzdCBhIGdldHRlciwgbm90IGEgc2V0dGVyIGFzIHdlbGwuXG4gICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5jb21wb25lbnROYW1lKCk7XG4gICAgfVxuXG4gICAgLy8gVGhlIG9yZGVyIG9mIGNvbXBvbmVudHMgaXMgYXJiaXRyYXJ5IGFuZCBkb2VzIG5vdCBuZWNlc3NhcnkgbWF0Y2ggc2libGluZ3MgcmVsYXRpb25zIGluIERPTS5cbiAgICAvLyBuYW1lT3JDb21wb25lbnQgaXMgb3B0aW9uYWwgYW5kIGl0IGxpbWl0cyB0aGUgcmV0dXJuZWQgY2hpbGRyZW4gb25seSB0byB0aG9zZS5cbiAgICBjaGlsZENvbXBvbmVudHMobmFtZU9yQ29tcG9uZW50KSB7XG4gICAgICB2YXIgYmFzZSwgY2hpbGQ7XG4gICAgICBpZiAodGhpcy5fY29tcG9uZW50SW50ZXJuYWxzID09IG51bGwpIHtcbiAgICAgICAgdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzID0ge307XG4gICAgICB9XG4gICAgICBpZiAoKGJhc2UgPSB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMpLmNoaWxkQ29tcG9uZW50cyA9PSBudWxsKSB7XG4gICAgICAgIGJhc2UuY2hpbGRDb21wb25lbnRzID0gbmV3IFJlYWN0aXZlRmllbGQoW10sIGFycmF5UmVmZXJlbmNlRXF1YWxzKTtcbiAgICAgIH1cbiAgICAgIGlmICghbmFtZU9yQ29tcG9uZW50KSB7XG4gICAgICAgIHJldHVybiAoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgdmFyIGosIGxlbiwgcmVmLCByZXN1bHRzMTtcbiAgICAgICAgICByZWYgPSB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMuY2hpbGRDb21wb25lbnRzKCk7XG4gICAgICAgICAgcmVzdWx0czEgPSBbXTtcbiAgICAgICAgICBmb3IgKGogPSAwLCBsZW4gPSByZWYubGVuZ3RoOyBqIDwgbGVuOyBqKyspIHtcbiAgICAgICAgICAgIGNoaWxkID0gcmVmW2pdO1xuICAgICAgICAgICAgLy8gUXVpY2sgcGF0aC4gUmV0dXJucyBhIHNoYWxsb3cgY29weS5cbiAgICAgICAgICAgIHJlc3VsdHMxLnB1c2goY2hpbGQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVzdWx0czE7XG4gICAgICAgIH0pLmNhbGwodGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoXy5pc1N0cmluZyhuYW1lT3JDb21wb25lbnQpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNoaWxkQ29tcG9uZW50c1dpdGgoKGNoaWxkLCBwYXJlbnQpID0+IHtcbiAgICAgICAgICByZXR1cm4gY2hpbGQuY29tcG9uZW50TmFtZSgpID09PSBuYW1lT3JDb21wb25lbnQ7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hpbGRDb21wb25lbnRzV2l0aCgoY2hpbGQsIHBhcmVudCkgPT4ge1xuICAgICAgICAgIGlmIChjaGlsZC5jb25zdHJ1Y3RvciA9PT0gbmFtZU9yQ29tcG9uZW50KSB7XG4gICAgICAgICAgICAvLyBuYW1lT3JDb21wb25lbnQgaXMgYSBjbGFzcy5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY2hpbGQgPT09IG5hbWVPckNvbXBvbmVudCkge1xuICAgICAgICAgICAgLy8gbmFtZU9yQ29tcG9uZW50IGlzIGFuIGluc3RhbmNlLCBvciBzb21ldGhpbmcgZWxzZS5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFRoZSBvcmRlciBvZiBjb21wb25lbnRzIGlzIGFyYml0cmFyeSBhbmQgZG9lcyBub3QgbmVjZXNzYXJ5IG1hdGNoIHNpYmxpbmdzIHJlbGF0aW9ucyBpbiBET00uXG4gICAgLy8gUmV0dXJucyBjaGlsZHJlbiB3aGljaCBwYXNzIGEgcHJlZGljYXRlIGZ1bmN0aW9uLlxuICAgIGNoaWxkQ29tcG9uZW50c1dpdGgocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKSB7XG4gICAgICB2YXIgcmVzdWx0cztcbiAgICAgIGFzc2VydChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pO1xuICAgICAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uID0gY3JlYXRlTWF0Y2hlcihwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pO1xuICAgICAgcmVzdWx0cyA9IG5ldyBDb21wdXRlZEZpZWxkKCgpID0+IHtcbiAgICAgICAgdmFyIGNoaWxkLCBqLCBsZW4sIHJlZiwgcmVzdWx0czE7XG4gICAgICAgIHJlZiA9IHRoaXMuY2hpbGRDb21wb25lbnRzKCk7XG4gICAgICAgIHJlc3VsdHMxID0gW107XG4gICAgICAgIGZvciAoaiA9IDAsIGxlbiA9IHJlZi5sZW5ndGg7IGogPCBsZW47IGorKykge1xuICAgICAgICAgIGNoaWxkID0gcmVmW2pdO1xuICAgICAgICAgIGlmIChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24uY2FsbCh0aGlzLCBjaGlsZCwgdGhpcykpIHtcbiAgICAgICAgICAgIHJlc3VsdHMxLnB1c2goY2hpbGQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0czE7XG4gICAgICB9LCBhcnJheVJlZmVyZW5jZUVxdWFscyk7XG4gICAgICByZXR1cm4gcmVzdWx0cygpO1xuICAgIH1cblxuICAgIGFkZENoaWxkQ29tcG9uZW50KGNoaWxkQ29tcG9uZW50KSB7XG4gICAgICB2YXIgYmFzZTtcbiAgICAgIGlmICh0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMgPT0gbnVsbCkge1xuICAgICAgICB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMgPSB7fTtcbiAgICAgIH1cbiAgICAgIGlmICgoYmFzZSA9IHRoaXMuX2NvbXBvbmVudEludGVybmFscykuY2hpbGRDb21wb25lbnRzID09IG51bGwpIHtcbiAgICAgICAgYmFzZS5jaGlsZENvbXBvbmVudHMgPSBuZXcgUmVhY3RpdmVGaWVsZChbXSwgYXJyYXlSZWZlcmVuY2VFcXVhbHMpO1xuICAgICAgfVxuICAgICAgdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLmNoaWxkQ29tcG9uZW50cyhUcmFja2VyLm5vbnJlYWN0aXZlKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvbXBvbmVudEludGVybmFscy5jaGlsZENvbXBvbmVudHMoKS5jb25jYXQoW2NoaWxkQ29tcG9uZW50XSk7XG4gICAgICB9KSk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICByZW1vdmVDaGlsZENvbXBvbmVudChjaGlsZENvbXBvbmVudCkge1xuICAgICAgdmFyIGJhc2U7XG4gICAgICBpZiAodGhpcy5fY29tcG9uZW50SW50ZXJuYWxzID09IG51bGwpIHtcbiAgICAgICAgdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzID0ge307XG4gICAgICB9XG4gICAgICBpZiAoKGJhc2UgPSB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMpLmNoaWxkQ29tcG9uZW50cyA9PSBudWxsKSB7XG4gICAgICAgIGJhc2UuY2hpbGRDb21wb25lbnRzID0gbmV3IFJlYWN0aXZlRmllbGQoW10sIGFycmF5UmVmZXJlbmNlRXF1YWxzKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuX2NvbXBvbmVudEludGVybmFscy5jaGlsZENvbXBvbmVudHMoVHJhY2tlci5ub25yZWFjdGl2ZSgoKSA9PiB7XG4gICAgICAgIHJldHVybiBfLndpdGhvdXQodGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLmNoaWxkQ29tcG9uZW50cygpLCBjaGlsZENvbXBvbmVudCk7XG4gICAgICB9KSk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBwYXJlbnRDb21wb25lbnQocGFyZW50Q29tcG9uZW50KSB7XG4gICAgICB2YXIgYmFzZTtcbiAgICAgIGlmICh0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMgPT0gbnVsbCkge1xuICAgICAgICB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMgPSB7fTtcbiAgICAgIH1cbiAgICAgIC8vIFdlIHVzZSByZWZlcmVuY2UgZXF1YWxpdHkgaGVyZS4gVGhpcyBtYWtlcyByZWFjdGl2aXR5IG5vdCBpbnZhbGlkYXRlIHRoZVxuICAgICAgLy8gY29tcHV0YXRpb24gaWYgdGhlIHNhbWUgY29tcG9uZW50IGluc3RhbmNlIChieSByZWZlcmVuY2UpIGlzIHNldCBhcyBhIHBhcmVudC5cbiAgICAgIGlmICgoYmFzZSA9IHRoaXMuX2NvbXBvbmVudEludGVybmFscykucGFyZW50Q29tcG9uZW50ID09IG51bGwpIHtcbiAgICAgICAgYmFzZS5wYXJlbnRDb21wb25lbnQgPSBuZXcgUmVhY3RpdmVGaWVsZChudWxsLCBmdW5jdGlvbihhLCBiKSB7XG4gICAgICAgICAgcmV0dXJuIGEgPT09IGI7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLy8gU2V0dGVyLlxuICAgICAgaWYgKCFfLmlzVW5kZWZpbmVkKHBhcmVudENvbXBvbmVudCkpIHtcbiAgICAgICAgdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLnBhcmVudENvbXBvbmVudChwYXJlbnRDb21wb25lbnQpO1xuICAgICAgICAvLyBUbyBhbGxvdyBjaGFpbmluZy5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9XG4gICAgICAvLyBHZXR0ZXIuXG4gICAgICByZXR1cm4gdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLnBhcmVudENvbXBvbmVudCgpO1xuICAgIH1cblxuICAgIHN0YXRpYyByZW5kZXJDb21wb25lbnQocGFyZW50Q29tcG9uZW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWRcIik7XG4gICAgfVxuXG4gICAgcmVuZGVyQ29tcG9uZW50KHBhcmVudENvbXBvbmVudCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IGltcGxlbWVudGVkXCIpO1xuICAgIH1cblxuICAgIHN0YXRpYyBleHRlbmRDb21wb25lbnQoY29uc3RydWN0b3IsIG1ldGhvZHMpIHtcbiAgICAgIHZhciBjdXJyZW50Q2xhc3MsIHByb3BlcnR5LCByZWYsIHZhbHVlO1xuICAgICAgY3VycmVudENsYXNzID0gdGhpcztcbiAgICAgIGlmIChfLmlzRnVuY3Rpb24oY29uc3RydWN0b3IpKSB7XG4gICAgICAgIGNvbnN0cnVjdG9yLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoY3VycmVudENsYXNzLnByb3RvdHlwZSwge1xuICAgICAgICAgIGNvbnN0cnVjdG9yOiB7XG4gICAgICAgICAgICB2YWx1ZTogY29uc3RydWN0b3IsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZihjb25zdHJ1Y3RvciwgY3VycmVudENsYXNzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1ldGhvZHMgPSBjb25zdHJ1Y3RvcjtcbiAgICAgICAgY29uc3RydWN0b3IgPSBjbGFzcyBleHRlbmRzIGN1cnJlbnRDbGFzcyB7fTtcbiAgICAgIH1cbiAgICAgIHJlZiA9IG1ldGhvZHMgfHwge307XG4gICAgICBmb3IgKHByb3BlcnR5IGluIHJlZikge1xuICAgICAgICBpZiAoIWhhc1Byb3AuY2FsbChyZWYsIHByb3BlcnR5KSkgY29udGludWU7XG4gICAgICAgIHZhbHVlID0gcmVmW3Byb3BlcnR5XTtcbiAgICAgICAgY29uc3RydWN0b3IucHJvdG90eXBlW3Byb3BlcnR5XSA9IHZhbHVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNvbnN0cnVjdG9yO1xuICAgIH1cblxuICAgIC8vIERlcHJlY2F0ZWQgbWV0aG9kIG5hbWVzLlxuICAgIC8vIFRPRE86IFJlbW92ZSB0aGVtIGluIHRoZSBmdXR1cmUuXG5cbiAgICAvLyBAZGVwcmVjYXRlZCBVc2UgY2hpbGRDb21wb25lbnRzIGluc3RlYWQuXG4gICAgY29tcG9uZW50Q2hpbGRyZW4oLi4uYXJncykge1xuICAgICAgaWYgKCFjb21wb25lbnRDaGlsZHJlbkRlcHJlY2F0aW9uV2FybmluZykge1xuICAgICAgICBjb21wb25lbnRDaGlsZHJlbkRlcHJlY2F0aW9uV2FybmluZyA9IHRydWU7XG4gICAgICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBjb25zb2xlICE9PSBudWxsKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwiY29tcG9uZW50Q2hpbGRyZW4gaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIGNoaWxkQ29tcG9uZW50cyBpbnN0ZWFkLlwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuY2hpbGRDb21wb25lbnRzKC4uLmFyZ3MpO1xuICAgIH1cblxuICAgIC8vIEBkZXByZWNhdGVkIFVzZSBjaGlsZENvbXBvbmVudHNXaXRoIGluc3RlYWQuXG4gICAgY29tcG9uZW50Q2hpbGRyZW5XaXRoKC4uLmFyZ3MpIHtcbiAgICAgIGlmICghY29tcG9uZW50Q2hpbGRyZW5XaXRoRGVwcmVjYXRpb25XYXJuaW5nKSB7XG4gICAgICAgIGNvbXBvbmVudENoaWxkcmVuV2l0aERlcHJlY2F0aW9uV2FybmluZyA9IHRydWU7XG4gICAgICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBjb25zb2xlICE9PSBudWxsKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwiY29tcG9uZW50Q2hpbGRyZW5XaXRoIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBjaGlsZENvbXBvbmVudHNXaXRoIGluc3RlYWQuXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5jaGlsZENvbXBvbmVudHNXaXRoKC4uLmFyZ3MpO1xuICAgIH1cblxuICAgIC8vIEBkZXByZWNhdGVkIFVzZSBhZGRDaGlsZENvbXBvbmVudCBpbnN0ZWFkLlxuICAgIGFkZENvbXBvbmVudENoaWxkKC4uLmFyZ3MpIHtcbiAgICAgIGlmICghYWRkQ29tcG9uZW50Q2hpbGREZXByZWNhdGlvbldhcm5pbmcpIHtcbiAgICAgICAgYWRkQ29tcG9uZW50Q2hpbGREZXByZWNhdGlvbldhcm5pbmcgPSB0cnVlO1xuICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUgIT09IFwidW5kZWZpbmVkXCIgJiYgY29uc29sZSAhPT0gbnVsbCkge1xuICAgICAgICAgIGNvbnNvbGUud2FybihcImFkZENvbXBvbmVudENoaWxkIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBhZGRDaGlsZENvbXBvbmVudCBpbnN0ZWFkLlwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuYWRkQ2hpbGRDb21wb25lbnQoLi4uYXJncyk7XG4gICAgfVxuXG4gICAgLy8gQGRlcHJlY2F0ZWQgVXNlIHJlbW92ZUNoaWxkQ29tcG9uZW50IGluc3RlYWQuXG4gICAgcmVtb3ZlQ29tcG9uZW50Q2hpbGQoLi4uYXJncykge1xuICAgICAgaWYgKCFyZW1vdmVDb21wb25lbnRDaGlsZERlcHJlY2F0aW9uV2FybmluZykge1xuICAgICAgICByZW1vdmVDb21wb25lbnRDaGlsZERlcHJlY2F0aW9uV2FybmluZyA9IHRydWU7XG4gICAgICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBjb25zb2xlICE9PSBudWxsKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwicmVtb3ZlQ29tcG9uZW50Q2hpbGQgaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIHJlbW92ZUNoaWxkQ29tcG9uZW50IGluc3RlYWQuXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5yZW1vdmVDaGlsZENvbXBvbmVudCguLi5hcmdzKTtcbiAgICB9XG5cbiAgICAvLyBAZGVwcmVjYXRlZCBVc2UgcGFyZW50Q29tcG9uZW50IGluc3RlYWQuXG4gICAgY29tcG9uZW50UGFyZW50KC4uLmFyZ3MpIHtcbiAgICAgIGlmICghY29tcG9uZW50UGFyZW50RGVwcmVjYXRpb25XYXJuaW5nKSB7XG4gICAgICAgIGNvbXBvbmVudFBhcmVudERlcHJlY2F0aW9uV2FybmluZyA9IHRydWU7XG4gICAgICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBjb25zb2xlICE9PSBudWxsKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwiY29tcG9uZW50UGFyZW50IGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBwYXJlbnRDb21wb25lbnQgaW5zdGVhZC5cIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnBhcmVudENvbXBvbmVudCguLi5hcmdzKTtcbiAgICB9XG5cbiAgICAvLyBAZGVwcmVjYXRlZCBVc2UgY2hpbGRDb21wb25lbnRzIGluc3RlYWQuXG4gICAgY2hpbGRyZW5Db21wb25lbnRzKC4uLmFyZ3MpIHtcbiAgICAgIGlmICghY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmcpIHtcbiAgICAgICAgY29tcG9uZW50Q2hpbGRyZW5EZXByZWNhdGlvbldhcm5pbmcgPSB0cnVlO1xuICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUgIT09IFwidW5kZWZpbmVkXCIgJiYgY29uc29sZSAhPT0gbnVsbCkge1xuICAgICAgICAgIGNvbnNvbGUud2FybihcImNoaWxkcmVuQ29tcG9uZW50cyBoYXMgYmVlbiBkZXByZWNhdGVkLiBVc2UgY2hpbGRDb21wb25lbnRzIGluc3RlYWQuXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5jaGlsZENvbXBvbmVudHMoLi4uYXJncyk7XG4gICAgfVxuXG4gICAgLy8gQGRlcHJlY2F0ZWQgVXNlIGNoaWxkQ29tcG9uZW50c1dpdGggaW5zdGVhZC5cbiAgICBjaGlsZHJlbkNvbXBvbmVudHNXaXRoKC4uLmFyZ3MpIHtcbiAgICAgIGlmICghY29tcG9uZW50Q2hpbGRyZW5XaXRoRGVwcmVjYXRpb25XYXJuaW5nKSB7XG4gICAgICAgIGNvbXBvbmVudENoaWxkcmVuV2l0aERlcHJlY2F0aW9uV2FybmluZyA9IHRydWU7XG4gICAgICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBjb25zb2xlICE9PSBudWxsKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwiY2hpbGRyZW5Db21wb25lbnRzV2l0aCBoYXMgYmVlbiBkZXByZWNhdGVkLiBVc2UgY2hpbGRDb21wb25lbnRzV2l0aCBpbnN0ZWFkLlwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuY2hpbGRDb21wb25lbnRzV2l0aCguLi5hcmdzKTtcbiAgICB9XG5cbiAgfTtcblxuICBCYXNlQ29tcG9uZW50LmNvbXBvbmVudHMgPSBuZXcgQ29tcG9uZW50c05hbWVzcGFjZSgpO1xuXG4gIHJldHVybiBCYXNlQ29tcG9uZW50O1xuXG59KS5jYWxsKHRoaXMpO1xuIiwiY2xhc3MgQmFzZUNvbXBvbmVudERlYnVnXG4gIEBzdGFydENvbXBvbmVudDogKGNvbXBvbmVudCkgLT5cbiAgICBuYW1lID0gY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSBvciAndW5uYW1lZCdcbiAgICBjb25zb2xlLmdyb3VwIG5hbWVcbiAgICBjb25zb2xlLmxvZyAnJW8nLCBjb21wb25lbnRcblxuICBAZW5kQ29tcG9uZW50OiAoY29tcG9uZW50KSAtPlxuICAgIGNvbnNvbGUuZ3JvdXBFbmQoKVxuXG4gIEBzdGFydE1hcmtlZENvbXBvbmVudDogKGNvbXBvbmVudCkgLT5cbiAgICBuYW1lID0gY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSBvciAndW5uYW1lZCdcbiAgICBjb25zb2xlLmdyb3VwICclYyVzJywgJ3RleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lJywgbmFtZVxuICAgIGNvbnNvbGUubG9nICclbycsIGNvbXBvbmVudFxuXG4gIEBlbmRNYXJrZWRDb21wb25lbnQ6IChjb21wb25lbnQpIC0+XG4gICAgQGVuZENvbXBvbmVudCBjb21wb25lbnRcblxuICBAZHVtcENvbXBvbmVudFN1YnRyZWU6IChyb290Q29tcG9uZW50LCBfbWFya0NvbXBvbmVudD0oLT4pKSAtPlxuICAgIHJldHVybiB1bmxlc3Mgcm9vdENvbXBvbmVudFxuXG4gICAgbWFya2VkID0gX21hcmtDb21wb25lbnQgcm9vdENvbXBvbmVudFxuXG4gICAgaWYgbWFya2VkXG4gICAgICBAc3RhcnRNYXJrZWRDb21wb25lbnQgcm9vdENvbXBvbmVudFxuICAgIGVsc2VcbiAgICAgIEBzdGFydENvbXBvbmVudCByb290Q29tcG9uZW50XG5cbiAgICBmb3IgY2hpbGQgaW4gcm9vdENvbXBvbmVudC5jaGlsZENvbXBvbmVudHMoKVxuICAgICAgQGR1bXBDb21wb25lbnRTdWJ0cmVlIGNoaWxkLCBfbWFya0NvbXBvbmVudFxuXG4gICAgaWYgbWFya2VkXG4gICAgICBAZW5kTWFya2VkQ29tcG9uZW50IHJvb3RDb21wb25lbnRcbiAgICBlbHNlXG4gICAgICBAZW5kQ29tcG9uZW50IHJvb3RDb21wb25lbnRcblxuICAgIHJldHVyblxuXG4gIEBjb21wb25lbnRSb290OiAoY29tcG9uZW50KSAtPlxuICAgIHdoaWxlIHBhcmVudENvbXBvbmVudCA9IGNvbXBvbmVudC5wYXJlbnRDb21wb25lbnQoKVxuICAgICAgY29tcG9uZW50ID0gcGFyZW50Q29tcG9uZW50XG5cbiAgICBjb21wb25lbnRcblxuICBAZHVtcENvbXBvbmVudFRyZWU6IChjb21wb25lbnQpIC0+XG4gICAgcmV0dXJuIHVubGVzcyBjb21wb25lbnRcblxuICAgIEBkdW1wQ29tcG9uZW50U3VidHJlZSBAY29tcG9uZW50Um9vdChjb21wb25lbnQpLCAoYykgLT4gYyBpcyBjb21wb25lbnRcbiIsIiAgICAgICAgICAgICAgICAgICAgICAgXG5cbkJhc2VDb21wb25lbnREZWJ1ZyA9IGNsYXNzIEJhc2VDb21wb25lbnREZWJ1ZyB7XG4gIHN0YXRpYyBzdGFydENvbXBvbmVudChjb21wb25lbnQpIHtcbiAgICB2YXIgbmFtZTtcbiAgICBuYW1lID0gY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSB8fCAndW5uYW1lZCc7XG4gICAgY29uc29sZS5ncm91cChuYW1lKTtcbiAgICByZXR1cm4gY29uc29sZS5sb2coJyVvJywgY29tcG9uZW50KTtcbiAgfVxuXG4gIHN0YXRpYyBlbmRDb21wb25lbnQoY29tcG9uZW50KSB7XG4gICAgcmV0dXJuIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgfVxuXG4gIHN0YXRpYyBzdGFydE1hcmtlZENvbXBvbmVudChjb21wb25lbnQpIHtcbiAgICB2YXIgbmFtZTtcbiAgICBuYW1lID0gY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSB8fCAndW5uYW1lZCc7XG4gICAgY29uc29sZS5ncm91cCgnJWMlcycsICd0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZScsIG5hbWUpO1xuICAgIHJldHVybiBjb25zb2xlLmxvZygnJW8nLCBjb21wb25lbnQpO1xuICB9XG5cbiAgc3RhdGljIGVuZE1hcmtlZENvbXBvbmVudChjb21wb25lbnQpIHtcbiAgICByZXR1cm4gdGhpcy5lbmRDb21wb25lbnQoY29tcG9uZW50KTtcbiAgfVxuXG4gIHN0YXRpYyBkdW1wQ29tcG9uZW50U3VidHJlZShyb290Q29tcG9uZW50LCBfbWFya0NvbXBvbmVudCA9IChmdW5jdGlvbigpIHt9KSkge1xuICAgIHZhciBjaGlsZCwgaSwgbGVuLCBtYXJrZWQsIHJlZjtcbiAgICBpZiAoIXJvb3RDb21wb25lbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbWFya2VkID0gX21hcmtDb21wb25lbnQocm9vdENvbXBvbmVudCk7XG4gICAgaWYgKG1hcmtlZCkge1xuICAgICAgdGhpcy5zdGFydE1hcmtlZENvbXBvbmVudChyb290Q29tcG9uZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdGFydENvbXBvbmVudChyb290Q29tcG9uZW50KTtcbiAgICB9XG4gICAgcmVmID0gcm9vdENvbXBvbmVudC5jaGlsZENvbXBvbmVudHMoKTtcbiAgICBmb3IgKGkgPSAwLCBsZW4gPSByZWYubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGNoaWxkID0gcmVmW2ldO1xuICAgICAgdGhpcy5kdW1wQ29tcG9uZW50U3VidHJlZShjaGlsZCwgX21hcmtDb21wb25lbnQpO1xuICAgIH1cbiAgICBpZiAobWFya2VkKSB7XG4gICAgICB0aGlzLmVuZE1hcmtlZENvbXBvbmVudChyb290Q29tcG9uZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5lbmRDb21wb25lbnQocm9vdENvbXBvbmVudCk7XG4gICAgfVxuICB9XG5cbiAgc3RhdGljIGNvbXBvbmVudFJvb3QoY29tcG9uZW50KSB7XG4gICAgdmFyIHBhcmVudENvbXBvbmVudDtcbiAgICB3aGlsZSAocGFyZW50Q29tcG9uZW50ID0gY29tcG9uZW50LnBhcmVudENvbXBvbmVudCgpKSB7XG4gICAgICBjb21wb25lbnQgPSBwYXJlbnRDb21wb25lbnQ7XG4gICAgfVxuICAgIHJldHVybiBjb21wb25lbnQ7XG4gIH1cblxuICBzdGF0aWMgZHVtcENvbXBvbmVudFRyZWUoY29tcG9uZW50KSB7XG4gICAgaWYgKCFjb21wb25lbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZHVtcENvbXBvbmVudFN1YnRyZWUodGhpcy5jb21wb25lbnRSb290KGNvbXBvbmVudCksIGZ1bmN0aW9uKGMpIHtcbiAgICAgIHJldHVybiBjID09PSBjb21wb25lbnQ7XG4gICAgfSk7XG4gIH1cblxufTtcbiJdfQ==
