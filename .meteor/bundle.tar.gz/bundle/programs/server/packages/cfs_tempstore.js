(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var FS = Package['cfs:base-package'].FS;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var _chunkPath, _fileReference;

var require = meteorInstall({"node_modules":{"meteor":{"cfs:tempstore":{"tempStore.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/cfs_tempstore/tempStore.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ##Temporary Storage
//
// Temporary storage is used for chunked uploads until all chunks are received
// and all copies have been made or given up. In some cases, the original file
// is stored only in temporary storage (for example, if all copies do some
// manipulation in beforeSave). This is why we use the temporary file as the
// basis for each saved copy, and then remove it after all copies are saved.
//
// Every chunk is saved as an individual temporary file. This is safer than
// attempting to write multiple incoming chunks to different positions in a
// single temporary file, which can lead to write conflicts.
//
// Using temp files also allows us to easily resume uploads, even if the server
// restarts, and to keep the working memory clear.
// The FS.TempStore emits events that others are able to listen to
var EventEmitter = Npm.require('events').EventEmitter; // We have a special stream concating all chunk files into one readable stream


var CombinedStream = Npm.require('combined-stream');
/** @namespace FS.TempStore
 * @property FS.TempStore
 * @type {object}
 * @public
 * @summary An event emitter
 */


FS.TempStore = new EventEmitter(); // Create a tracker collection for keeping track of all chunks for any files that are currently in the temp store

var tracker = FS.TempStore.Tracker = new Mongo.Collection('cfs._tempstore.chunks');
/**
 * @property FS.TempStore.Storage
 * @type {StorageAdapter}
 * @namespace FS.TempStore
 * @private
 * @summary This property is set to either `FS.Store.FileSystem` or `FS.Store.GridFS`
 *
 * __When and why:__
 * We normally default to `cfs-filesystem` unless its not installed. *(we default to gridfs if installed)*
 * But if `cfs-gridfs` and `cfs-worker` is installed we default to `cfs-gridfs`
 *
 * If `cfs-gridfs` and `cfs-filesystem` is not installed we log a warning.
 * the user can set `FS.TempStore.Storage` them selfs eg.:
 * ```js
 *   // Its important to set `internal: true` this lets the SA know that we
 *   // are using this internally and it will give us direct SA api
 *   FS.TempStore.Storage = new FS.Store.GridFS('_tempstore', { internal: true });
 * ```
 *
 * > Note: This is considered as `advanced` use, its not a common pattern.
 */

FS.TempStore.Storage = null; // We will not mount a storage adapter until needed. This allows us to check for the
// existance of FS.FileWorker, which is loaded after this package because it
// depends on this package.

function mountStorage() {
  if (FS.TempStore.Storage) return; // XXX: We could replace this test, testing the FS scope for grifFS etc.
  // This is on the todo later when we get "stable"

  if (Package["cfs:gridfs"] && (Package["cfs:worker"] || !Package["cfs:filesystem"])) {
    // If the file worker is installed we would prefer to use the gridfs sa
    // for scalability. We also default to gridfs if filesystem is not found
    // Use the gridfs
    FS.TempStore.Storage = new FS.Store.GridFS('_tempstore', {
      internal: true
    });
  } else if (Package["cfs:filesystem"]) {
    // use the Filesystem
    FS.TempStore.Storage = new FS.Store.FileSystem('_tempstore', {
      internal: true
    });
  } else {
    throw new Error('FS.TempStore.Storage is not set: Install cfs:filesystem or cfs:gridfs or set it manually');
  }

  FS.debug && console.log('TempStore is mounted on', FS.TempStore.Storage.typeName);
}

function mountFile(fileObj, name) {
  if (!fileObj.isMounted()) {
    throw new Error(name + ' cannot work with unmounted file');
  }
} // We update the fileObj on progress


FS.TempStore.on('progress', function (fileObj, chunkNum, count, total, result) {
  FS.debug && console.log('TempStore progress: Received ' + count + ' of ' + total + ' chunks for ' + fileObj.name());
}); // XXX: TODO
// FS.TempStore.on('stored', function(fileObj, chunkCount, result) {
//   // This should work if we pass on result from the SA on stored event...
//   fileObj.update({ $set: { chunkSum: 1, chunkCount: chunkCount, size: result.size } });
// });
// Stream implementation

/**
 * @method _chunkPath
 * @private
 * @param {Number} [n] Chunk number
 * @returns {String} Chunk naming convention
 */

_chunkPath = function (n) {
  return (n || 0) + '.chunk';
};
/**
 * @method _fileReference
 * @param {FS.File} fileObj
 * @param {Number} chunk
 * @private
 * @returns {String} Generated SA specific fileKey for the chunk
 *
 * Note: Calling function should call mountStorage() first, and
 * make sure that fileObj is mounted.
 */


_fileReference = function (fileObj, chunk, existing) {
  // Maybe it's a chunk we've already saved
  existing = existing || tracker.findOne({
    fileId: fileObj._id,
    collectionName: fileObj.collectionName
  }); // Make a temporary fileObj just for fileKey generation

  var tempFileObj = new FS.File({
    collectionName: fileObj.collectionName,
    _id: fileObj._id,
    original: {
      name: _chunkPath(chunk)
    },
    copies: {
      _tempstore: {
        key: existing && existing.keys[chunk]
      }
    }
  }); // Return a fitting fileKey SA specific

  return FS.TempStore.Storage.adapter.fileKey(tempFileObj);
};
/**
 * @method FS.TempStore.exists
 * @param {FS.File} File object
 * @returns {Boolean} Is this file, or parts of it, currently stored in the TempStore
 */


FS.TempStore.exists = function (fileObj) {
  var existing = tracker.findOne({
    fileId: fileObj._id,
    collectionName: fileObj.collectionName
  });
  return !!existing;
};
/**
 * @method FS.TempStore.listParts
 * @param {FS.File} fileObj
 * @returns {Object} of parts already stored
 * @todo This is not yet implemented, milestone 1.1.0
 */


FS.TempStore.listParts = function fsTempStoreListParts(fileObj) {
  var self = this;
  console.warn('This function is not correctly implemented using SA in TempStore'); //XXX This function might be necessary for resume. Not currently supported.
};
/**
 * @method FS.TempStore.removeFile
 * @public
 * @param {FS.File} fileObj
 * This function removes the file from tempstorage - it cares not if file is
 * already removed or not found, goal is reached anyway.
 */


FS.TempStore.removeFile = function fsTempStoreRemoveFile(fileObj) {
  var self = this; // Ensure that we have a storage adapter mounted; if not, throw an error.

  mountStorage(); // If fileObj is not mounted or can't be, throw an error

  mountFile(fileObj, 'FS.TempStore.removeFile'); // Emit event

  self.emit('remove', fileObj);
  var chunkInfo = tracker.findOne({
    fileId: fileObj._id,
    collectionName: fileObj.collectionName
  });

  if (chunkInfo) {
    // Unlink each file
    FS.Utility.each(chunkInfo.keys || {}, function (key, chunk) {
      var fileKey = _fileReference(fileObj, chunk, chunkInfo);

      FS.TempStore.Storage.adapter.remove(fileKey, FS.Utility.noop);
    }); // Remove fileObj from tracker collection, too

    tracker.remove({
      _id: chunkInfo._id
    });
  }
};
/**
 * @method FS.TempStore.removeAll
 * @public
 * @summary This function removes all files from tempstorage - it cares not if file is
 * already removed or not found, goal is reached anyway.
 */


FS.TempStore.removeAll = function fsTempStoreRemoveAll() {
  var self = this; // Ensure that we have a storage adapter mounted; if not, throw an error.

  mountStorage();
  tracker.find().forEach(function (chunkInfo) {
    // Unlink each file
    FS.Utility.each(chunkInfo.keys || {}, function (key, chunk) {
      var fileKey = _fileReference({
        _id: chunkInfo.fileId,
        collectionName: chunkInfo.collectionName
      }, chunk, chunkInfo);

      FS.TempStore.Storage.adapter.remove(fileKey, FS.Utility.noop);
    }); // Remove from tracker collection, too

    tracker.remove({
      _id: chunkInfo._id
    });
  });
};
/**
 * @method FS.TempStore.createWriteStream
 * @public
 * @param {FS.File} fileObj File to store in temporary storage
 * @param {Number | String} [options]
 * @returns {Stream} Writeable stream
 *
 * `options` of different types mean differnt things:
 * * `undefined` We store the file in one part
 * *(Normal server-side api usage)*
 * * `Number` the number is the part number total
 * *(multipart uploads will use this api)*
 * * `String` the string is the name of the `store` that wants to store file data
 * *(stores that want to sync their data to the rest of the files stores will use this)*
 *
 * > Note: fileObj must be mounted on a `FS.Collection`, it makes no sense to store otherwise
 */


FS.TempStore.createWriteStream = function (fileObj, options) {
  var self = this; // Ensure that we have a storage adapter mounted; if not, throw an error.

  mountStorage(); // If fileObj is not mounted or can't be, throw an error

  mountFile(fileObj, 'FS.TempStore.createWriteStream'); // Cache the selector for use multiple times below

  var selector = {
    fileId: fileObj._id,
    collectionName: fileObj.collectionName
  }; // TODO, should pass in chunkSum so we don't need to use FS.File for it

  var chunkSum = fileObj.chunkSum || 1; // Add fileObj to tracker collection

  tracker.upsert(selector, {
    $setOnInsert: {
      keys: {}
    }
  }); // Determine how we're using the writeStream

  var isOnePart = false,
      isMultiPart = false,
      isStoreSync = false,
      chunkNum = 0;

  if (options === +options) {
    isMultiPart = true;
    chunkNum = options;
  } else if (options === '' + options) {
    isStoreSync = true;
  } else {
    isOnePart = true;
  } // XXX: it should be possible for a store to sync by storing data into the
  // tempstore - this could be done nicely by setting the store name as string
  // in the chunk variable?
  // This store name could be passed on the the fileworker via the uploaded
  // event
  // So the uploaded event can return:
  // undefined - if data is stored into and should sync out to all storage adapters
  // number - if a chunk has been uploaded
  // string - if a storage adapter wants to sync its data to the other SA's
  // Find a nice location for the chunk data


  var fileKey = _fileReference(fileObj, chunkNum); // Create the stream as Meteor safe stream


  var writeStream = FS.TempStore.Storage.adapter.createWriteStream(fileKey); // When the stream closes we update the chunkCount

  writeStream.safeOn('stored', function (result) {
    // Save key in tracker document
    var setObj = {};
    setObj['keys.' + chunkNum] = result.fileKey;
    tracker.update(selector, {
      $set: setObj
    });
    var temp = tracker.findOne(selector);

    if (!temp) {
      FS.debug && console.log('NOT FOUND FROM TEMPSTORE => EXIT (REMOVED)');
      return;
    } // Get updated chunkCount


    var chunkCount = FS.Utility.size(temp.keys); // Progress

    self.emit('progress', fileObj, chunkNum, chunkCount, chunkSum, result);
    var modifier = {
      $set: {}
    };

    if (!fileObj.instance_id) {
      modifier.$set.instance_id = process.env.COLLECTIONFS_ENV_NAME_UNIQUE_ID ? process.env[process.env.COLLECTIONFS_ENV_NAME_UNIQUE_ID] : process.env.METEOR_PARENT_PID;
    } // If upload is completed


    if (chunkCount === chunkSum) {
      // We no longer need the chunk info
      modifier.$unset = {
        chunkCount: 1,
        chunkSum: 1,
        chunkSize: 1
      }; // Check if the file has been uploaded before

      if (typeof fileObj.uploadedAt === 'undefined') {
        // We set the uploadedAt date
        modifier.$set.uploadedAt = new Date();
      } else {
        // We have been uploaded so an event were file data is updated is
        // called synchronizing - so this must be a synchronizedAt?
        modifier.$set.synchronizedAt = new Date();
      } // Update the fileObject


      fileObj.update(modifier); // Fire ending events

      var eventName = isStoreSync ? 'synchronized' : 'stored';
      self.emit(eventName, fileObj, result); // XXX is emitting "ready" necessary?

      self.emit('ready', fileObj, chunkCount, result);
    } else {
      // Update the chunkCount on the fileObject
      modifier.$set.chunkCount = chunkCount;
      fileObj.update(modifier);
    }
  }); // Emit errors

  writeStream.on('error', function (error) {
    FS.debug && console.log('TempStore writeStream error:', error);
    self.emit('error', error, fileObj);
  });
  return writeStream;
};
/**
  * @method FS.TempStore.createReadStream
  * @public
  * @param {FS.File} fileObj The file to read
  * @return {Stream} Returns readable stream
  *
  */


FS.TempStore.createReadStream = function (fileObj) {
  // Ensure that we have a storage adapter mounted; if not, throw an error.
  mountStorage(); // If fileObj is not mounted or can't be, throw an error

  mountFile(fileObj, 'FS.TempStore.createReadStream');
  FS.debug && console.log('FS.TempStore creating read stream for ' + fileObj._id); // Determine how many total chunks there are from the tracker collection

  var chunkInfo = tracker.findOne({
    fileId: fileObj._id,
    collectionName: fileObj.collectionName
  }) || {};
  var totalChunks = FS.Utility.size(chunkInfo.keys);

  function getNextStreamFunc(chunk) {
    return Meteor.bindEnvironment(function (next) {
      var fileKey = _fileReference(fileObj, chunk);

      var chunkReadStream = FS.TempStore.Storage.adapter.createReadStream(fileKey);
      next(chunkReadStream);
    }, function (error) {
      throw error;
    });
  } // Make a combined stream


  var combinedStream = CombinedStream.create(); // Add each chunk stream to the combined stream when the previous chunk stream ends

  var currentChunk = 0;

  for (var chunk = 0; chunk < totalChunks; chunk++) {
    combinedStream.append(getNextStreamFunc(chunk));
  } // Return the combined stream


  return combinedStream;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/cfs:tempstore/tempStore.js");

/* Exports */
Package._define("cfs:tempstore");

})();

//# sourceURL=meteor://💻app/packages/cfs_tempstore.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvY2ZzOnRlbXBzdG9yZS90ZW1wU3RvcmUuanMiXSwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIiwiTnBtIiwicmVxdWlyZSIsIkNvbWJpbmVkU3RyZWFtIiwiRlMiLCJUZW1wU3RvcmUiLCJ0cmFja2VyIiwiVHJhY2tlciIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIlN0b3JhZ2UiLCJtb3VudFN0b3JhZ2UiLCJQYWNrYWdlIiwiU3RvcmUiLCJHcmlkRlMiLCJpbnRlcm5hbCIsIkZpbGVTeXN0ZW0iLCJFcnJvciIsImRlYnVnIiwiY29uc29sZSIsImxvZyIsInR5cGVOYW1lIiwibW91bnRGaWxlIiwiZmlsZU9iaiIsIm5hbWUiLCJpc01vdW50ZWQiLCJvbiIsImNodW5rTnVtIiwiY291bnQiLCJ0b3RhbCIsInJlc3VsdCIsIl9jaHVua1BhdGgiLCJuIiwiX2ZpbGVSZWZlcmVuY2UiLCJjaHVuayIsImV4aXN0aW5nIiwiZmluZE9uZSIsImZpbGVJZCIsIl9pZCIsImNvbGxlY3Rpb25OYW1lIiwidGVtcEZpbGVPYmoiLCJGaWxlIiwib3JpZ2luYWwiLCJjb3BpZXMiLCJfdGVtcHN0b3JlIiwia2V5Iiwia2V5cyIsImFkYXB0ZXIiLCJmaWxlS2V5IiwiZXhpc3RzIiwibGlzdFBhcnRzIiwiZnNUZW1wU3RvcmVMaXN0UGFydHMiLCJzZWxmIiwid2FybiIsInJlbW92ZUZpbGUiLCJmc1RlbXBTdG9yZVJlbW92ZUZpbGUiLCJlbWl0IiwiY2h1bmtJbmZvIiwiVXRpbGl0eSIsImVhY2giLCJyZW1vdmUiLCJub29wIiwicmVtb3ZlQWxsIiwiZnNUZW1wU3RvcmVSZW1vdmVBbGwiLCJmaW5kIiwiZm9yRWFjaCIsImNyZWF0ZVdyaXRlU3RyZWFtIiwib3B0aW9ucyIsInNlbGVjdG9yIiwiY2h1bmtTdW0iLCJ1cHNlcnQiLCIkc2V0T25JbnNlcnQiLCJpc09uZVBhcnQiLCJpc011bHRpUGFydCIsImlzU3RvcmVTeW5jIiwid3JpdGVTdHJlYW0iLCJzYWZlT24iLCJzZXRPYmoiLCJ1cGRhdGUiLCIkc2V0IiwidGVtcCIsImNodW5rQ291bnQiLCJzaXplIiwibW9kaWZpZXIiLCJpbnN0YW5jZV9pZCIsInByb2Nlc3MiLCJlbnYiLCJDT0xMRUNUSU9ORlNfRU5WX05BTUVfVU5JUVVFX0lEIiwiTUVURU9SX1BBUkVOVF9QSUQiLCIkdW5zZXQiLCJjaHVua1NpemUiLCJ1cGxvYWRlZEF0IiwiRGF0ZSIsInN5bmNocm9uaXplZEF0IiwiZXZlbnROYW1lIiwiZXJyb3IiLCJjcmVhdGVSZWFkU3RyZWFtIiwidG90YWxDaHVua3MiLCJnZXROZXh0U3RyZWFtRnVuYyIsIk1ldGVvciIsImJpbmRFbnZpcm9ubWVudCIsIm5leHQiLCJjaHVua1JlYWRTdHJlYW0iLCJjb21iaW5lZFN0cmVhbSIsImNyZWF0ZSIsImN1cnJlbnRDaHVuayIsImFwcGVuZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0EsSUFBSUEsWUFBWSxHQUFHQyxHQUFHLENBQUNDLE9BQUosQ0FBWSxRQUFaLEVBQXNCRixZQUF6QyxDLENBRUE7OztBQUNBLElBQUlHLGNBQWMsR0FBR0YsR0FBRyxDQUFDQyxPQUFKLENBQVksaUJBQVosQ0FBckI7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBRSxFQUFFLENBQUNDLFNBQUgsR0FBZSxJQUFJTCxZQUFKLEVBQWYsQyxDQUVBOztBQUNBLElBQUlNLE9BQU8sR0FBR0YsRUFBRSxDQUFDQyxTQUFILENBQWFFLE9BQWIsR0FBdUIsSUFBSUMsS0FBSyxDQUFDQyxVQUFWLENBQXFCLHVCQUFyQixDQUFyQztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQUwsRUFBRSxDQUFDQyxTQUFILENBQWFLLE9BQWIsR0FBdUIsSUFBdkIsQyxDQUVBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTQyxZQUFULEdBQXdCO0FBRXRCLE1BQUlQLEVBQUUsQ0FBQ0MsU0FBSCxDQUFhSyxPQUFqQixFQUEwQixPQUZKLENBSXRCO0FBQ0E7O0FBQ0EsTUFBSUUsT0FBTyxDQUFDLFlBQUQsQ0FBUCxLQUEwQkEsT0FBTyxDQUFDLFlBQUQsQ0FBUCxJQUF5QixDQUFDQSxPQUFPLENBQUMsZ0JBQUQsQ0FBM0QsQ0FBSixFQUFvRjtBQUNsRjtBQUNBO0FBRUE7QUFDQVIsTUFBRSxDQUFDQyxTQUFILENBQWFLLE9BQWIsR0FBdUIsSUFBSU4sRUFBRSxDQUFDUyxLQUFILENBQVNDLE1BQWIsQ0FBb0IsWUFBcEIsRUFBa0M7QUFBRUMsY0FBUSxFQUFFO0FBQVosS0FBbEMsQ0FBdkI7QUFDRCxHQU5ELE1BTU8sSUFBSUgsT0FBTyxDQUFDLGdCQUFELENBQVgsRUFBK0I7QUFFcEM7QUFDQVIsTUFBRSxDQUFDQyxTQUFILENBQWFLLE9BQWIsR0FBdUIsSUFBSU4sRUFBRSxDQUFDUyxLQUFILENBQVNHLFVBQWIsQ0FBd0IsWUFBeEIsRUFBc0M7QUFBRUQsY0FBUSxFQUFFO0FBQVosS0FBdEMsQ0FBdkI7QUFDRCxHQUpNLE1BSUE7QUFDTCxVQUFNLElBQUlFLEtBQUosQ0FBVSwwRkFBVixDQUFOO0FBQ0Q7O0FBRURiLElBQUUsQ0FBQ2MsS0FBSCxJQUFZQyxPQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUF1Q2hCLEVBQUUsQ0FBQ0MsU0FBSCxDQUFhSyxPQUFiLENBQXFCVyxRQUE1RCxDQUFaO0FBQ0Q7O0FBRUQsU0FBU0MsU0FBVCxDQUFtQkMsT0FBbkIsRUFBNEJDLElBQTVCLEVBQWtDO0FBQ2hDLE1BQUksQ0FBQ0QsT0FBTyxDQUFDRSxTQUFSLEVBQUwsRUFBMEI7QUFDeEIsVUFBTSxJQUFJUixLQUFKLENBQVVPLElBQUksR0FBRyxrQ0FBakIsQ0FBTjtBQUNEO0FBQ0YsQyxDQUVEOzs7QUFDQXBCLEVBQUUsQ0FBQ0MsU0FBSCxDQUFhcUIsRUFBYixDQUFnQixVQUFoQixFQUE0QixVQUFTSCxPQUFULEVBQWtCSSxRQUFsQixFQUE0QkMsS0FBNUIsRUFBbUNDLEtBQW5DLEVBQTBDQyxNQUExQyxFQUFrRDtBQUM1RTFCLElBQUUsQ0FBQ2MsS0FBSCxJQUFZQyxPQUFPLENBQUNDLEdBQVIsQ0FBWSxrQ0FBa0NRLEtBQWxDLEdBQTBDLE1BQTFDLEdBQW1EQyxLQUFuRCxHQUEyRCxjQUEzRCxHQUE0RU4sT0FBTyxDQUFDQyxJQUFSLEVBQXhGLENBQVo7QUFDRCxDQUZELEUsQ0FJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBTyxVQUFVLEdBQUcsVUFBU0MsQ0FBVCxFQUFZO0FBQ3ZCLFNBQU8sQ0FBQ0EsQ0FBQyxJQUFJLENBQU4sSUFBVyxRQUFsQjtBQUNELENBRkQ7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FDLGNBQWMsR0FBRyxVQUFTVixPQUFULEVBQWtCVyxLQUFsQixFQUF5QkMsUUFBekIsRUFBbUM7QUFDbEQ7QUFDQUEsVUFBUSxHQUFHQSxRQUFRLElBQUk3QixPQUFPLENBQUM4QixPQUFSLENBQWdCO0FBQUNDLFVBQU0sRUFBRWQsT0FBTyxDQUFDZSxHQUFqQjtBQUFzQkMsa0JBQWMsRUFBRWhCLE9BQU8sQ0FBQ2dCO0FBQTlDLEdBQWhCLENBQXZCLENBRmtELENBSWxEOztBQUNBLE1BQUlDLFdBQVcsR0FBRyxJQUFJcEMsRUFBRSxDQUFDcUMsSUFBUCxDQUFZO0FBQzVCRixrQkFBYyxFQUFFaEIsT0FBTyxDQUFDZ0IsY0FESTtBQUU1QkQsT0FBRyxFQUFFZixPQUFPLENBQUNlLEdBRmU7QUFHNUJJLFlBQVEsRUFBRTtBQUNSbEIsVUFBSSxFQUFFTyxVQUFVLENBQUNHLEtBQUQ7QUFEUixLQUhrQjtBQU01QlMsVUFBTSxFQUFFO0FBQ05DLGdCQUFVLEVBQUU7QUFDVkMsV0FBRyxFQUFFVixRQUFRLElBQUlBLFFBQVEsQ0FBQ1csSUFBVCxDQUFjWixLQUFkO0FBRFA7QUFETjtBQU5vQixHQUFaLENBQWxCLENBTGtELENBa0JsRDs7QUFDQSxTQUFPOUIsRUFBRSxDQUFDQyxTQUFILENBQWFLLE9BQWIsQ0FBcUJxQyxPQUFyQixDQUE2QkMsT0FBN0IsQ0FBcUNSLFdBQXJDLENBQVA7QUFDRCxDQXBCRDtBQXNCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQXBDLEVBQUUsQ0FBQ0MsU0FBSCxDQUFhNEMsTUFBYixHQUFzQixVQUFTMUIsT0FBVCxFQUFrQjtBQUN0QyxNQUFJWSxRQUFRLEdBQUc3QixPQUFPLENBQUM4QixPQUFSLENBQWdCO0FBQUNDLFVBQU0sRUFBRWQsT0FBTyxDQUFDZSxHQUFqQjtBQUFzQkMsa0JBQWMsRUFBRWhCLE9BQU8sQ0FBQ2dCO0FBQTlDLEdBQWhCLENBQWY7QUFDQSxTQUFPLENBQUMsQ0FBQ0osUUFBVDtBQUNELENBSEQ7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBL0IsRUFBRSxDQUFDQyxTQUFILENBQWE2QyxTQUFiLEdBQXlCLFNBQVNDLG9CQUFULENBQThCNUIsT0FBOUIsRUFBdUM7QUFDOUQsTUFBSTZCLElBQUksR0FBRyxJQUFYO0FBQ0FqQyxTQUFPLENBQUNrQyxJQUFSLENBQWEsa0VBQWIsRUFGOEQsQ0FHOUQ7QUFDRCxDQUpEO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBakQsRUFBRSxDQUFDQyxTQUFILENBQWFpRCxVQUFiLEdBQTBCLFNBQVNDLHFCQUFULENBQStCaEMsT0FBL0IsRUFBd0M7QUFDaEUsTUFBSTZCLElBQUksR0FBRyxJQUFYLENBRGdFLENBR2hFOztBQUNBekMsY0FBWSxHQUpvRCxDQU1oRTs7QUFDQVcsV0FBUyxDQUFDQyxPQUFELEVBQVUseUJBQVYsQ0FBVCxDQVBnRSxDQVNoRTs7QUFDQTZCLE1BQUksQ0FBQ0ksSUFBTCxDQUFVLFFBQVYsRUFBb0JqQyxPQUFwQjtBQUVBLE1BQUlrQyxTQUFTLEdBQUduRCxPQUFPLENBQUM4QixPQUFSLENBQWdCO0FBQzlCQyxVQUFNLEVBQUVkLE9BQU8sQ0FBQ2UsR0FEYztBQUU5QkMsa0JBQWMsRUFBRWhCLE9BQU8sQ0FBQ2dCO0FBRk0sR0FBaEIsQ0FBaEI7O0FBS0EsTUFBSWtCLFNBQUosRUFBZTtBQUViO0FBQ0FyRCxNQUFFLENBQUNzRCxPQUFILENBQVdDLElBQVgsQ0FBZ0JGLFNBQVMsQ0FBQ1gsSUFBVixJQUFrQixFQUFsQyxFQUFzQyxVQUFVRCxHQUFWLEVBQWVYLEtBQWYsRUFBc0I7QUFDMUQsVUFBSWMsT0FBTyxHQUFHZixjQUFjLENBQUNWLE9BQUQsRUFBVVcsS0FBVixFQUFpQnVCLFNBQWpCLENBQTVCOztBQUNBckQsUUFBRSxDQUFDQyxTQUFILENBQWFLLE9BQWIsQ0FBcUJxQyxPQUFyQixDQUE2QmEsTUFBN0IsQ0FBb0NaLE9BQXBDLEVBQTZDNUMsRUFBRSxDQUFDc0QsT0FBSCxDQUFXRyxJQUF4RDtBQUNELEtBSEQsRUFIYSxDQVFiOztBQUNBdkQsV0FBTyxDQUFDc0QsTUFBUixDQUFlO0FBQUN0QixTQUFHLEVBQUVtQixTQUFTLENBQUNuQjtBQUFoQixLQUFmO0FBRUQ7QUFDRixDQTdCRDtBQStCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBbEMsRUFBRSxDQUFDQyxTQUFILENBQWF5RCxTQUFiLEdBQXlCLFNBQVNDLG9CQUFULEdBQWdDO0FBQ3ZELE1BQUlYLElBQUksR0FBRyxJQUFYLENBRHVELENBR3ZEOztBQUNBekMsY0FBWTtBQUVaTCxTQUFPLENBQUMwRCxJQUFSLEdBQWVDLE9BQWYsQ0FBdUIsVUFBVVIsU0FBVixFQUFxQjtBQUMxQztBQUNBckQsTUFBRSxDQUFDc0QsT0FBSCxDQUFXQyxJQUFYLENBQWdCRixTQUFTLENBQUNYLElBQVYsSUFBa0IsRUFBbEMsRUFBc0MsVUFBVUQsR0FBVixFQUFlWCxLQUFmLEVBQXNCO0FBQzFELFVBQUljLE9BQU8sR0FBR2YsY0FBYyxDQUFDO0FBQUNLLFdBQUcsRUFBRW1CLFNBQVMsQ0FBQ3BCLE1BQWhCO0FBQXdCRSxzQkFBYyxFQUFFa0IsU0FBUyxDQUFDbEI7QUFBbEQsT0FBRCxFQUFvRUwsS0FBcEUsRUFBMkV1QixTQUEzRSxDQUE1Qjs7QUFDQXJELFFBQUUsQ0FBQ0MsU0FBSCxDQUFhSyxPQUFiLENBQXFCcUMsT0FBckIsQ0FBNkJhLE1BQTdCLENBQW9DWixPQUFwQyxFQUE2QzVDLEVBQUUsQ0FBQ3NELE9BQUgsQ0FBV0csSUFBeEQ7QUFDRCxLQUhELEVBRjBDLENBTzFDOztBQUNBdkQsV0FBTyxDQUFDc0QsTUFBUixDQUFlO0FBQUN0QixTQUFHLEVBQUVtQixTQUFTLENBQUNuQjtBQUFoQixLQUFmO0FBQ0QsR0FURDtBQVVELENBaEJEO0FBa0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBbEMsRUFBRSxDQUFDQyxTQUFILENBQWE2RCxpQkFBYixHQUFpQyxVQUFTM0MsT0FBVCxFQUFrQjRDLE9BQWxCLEVBQTJCO0FBQzFELE1BQUlmLElBQUksR0FBRyxJQUFYLENBRDBELENBRzFEOztBQUNBekMsY0FBWSxHQUo4QyxDQU0xRDs7QUFDQVcsV0FBUyxDQUFDQyxPQUFELEVBQVUsZ0NBQVYsQ0FBVCxDQVAwRCxDQVMxRDs7QUFDQSxNQUFJNkMsUUFBUSxHQUFHO0FBQUMvQixVQUFNLEVBQUVkLE9BQU8sQ0FBQ2UsR0FBakI7QUFBc0JDLGtCQUFjLEVBQUVoQixPQUFPLENBQUNnQjtBQUE5QyxHQUFmLENBVjBELENBWTFEOztBQUNBLE1BQUk4QixRQUFRLEdBQUc5QyxPQUFPLENBQUM4QyxRQUFSLElBQW9CLENBQW5DLENBYjBELENBZTFEOztBQUNBL0QsU0FBTyxDQUFDZ0UsTUFBUixDQUFlRixRQUFmLEVBQXlCO0FBQUNHLGdCQUFZLEVBQUU7QUFBQ3pCLFVBQUksRUFBRTtBQUFQO0FBQWYsR0FBekIsRUFoQjBELENBa0IxRDs7QUFDQSxNQUFJMEIsU0FBUyxHQUFHLEtBQWhCO0FBQUEsTUFBdUJDLFdBQVcsR0FBRyxLQUFyQztBQUFBLE1BQTRDQyxXQUFXLEdBQUcsS0FBMUQ7QUFBQSxNQUFpRS9DLFFBQVEsR0FBRyxDQUE1RTs7QUFDQSxNQUFJd0MsT0FBTyxLQUFLLENBQUNBLE9BQWpCLEVBQTBCO0FBQ3hCTSxlQUFXLEdBQUcsSUFBZDtBQUNBOUMsWUFBUSxHQUFHd0MsT0FBWDtBQUNELEdBSEQsTUFHTyxJQUFJQSxPQUFPLEtBQUssS0FBR0EsT0FBbkIsRUFBNEI7QUFDakNPLGVBQVcsR0FBRyxJQUFkO0FBQ0QsR0FGTSxNQUVBO0FBQ0xGLGFBQVMsR0FBRyxJQUFaO0FBQ0QsR0EzQnlELENBNkIxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7O0FBQ0EsTUFBSXhCLE9BQU8sR0FBR2YsY0FBYyxDQUFDVixPQUFELEVBQVVJLFFBQVYsQ0FBNUIsQ0F4QzBELENBMEMxRDs7O0FBQ0EsTUFBSWdELFdBQVcsR0FBR3ZFLEVBQUUsQ0FBQ0MsU0FBSCxDQUFhSyxPQUFiLENBQXFCcUMsT0FBckIsQ0FBNkJtQixpQkFBN0IsQ0FBK0NsQixPQUEvQyxDQUFsQixDQTNDMEQsQ0E2QzFEOztBQUNBMkIsYUFBVyxDQUFDQyxNQUFaLENBQW1CLFFBQW5CLEVBQTZCLFVBQVM5QyxNQUFULEVBQWlCO0FBQzVDO0FBQ0EsUUFBSStDLE1BQU0sR0FBRyxFQUFiO0FBQ0FBLFVBQU0sQ0FBQyxVQUFVbEQsUUFBWCxDQUFOLEdBQTZCRyxNQUFNLENBQUNrQixPQUFwQztBQUNBMUMsV0FBTyxDQUFDd0UsTUFBUixDQUFlVixRQUFmLEVBQXlCO0FBQUNXLFVBQUksRUFBRUY7QUFBUCxLQUF6QjtBQUVBLFFBQUlHLElBQUksR0FBRzFFLE9BQU8sQ0FBQzhCLE9BQVIsQ0FBZ0JnQyxRQUFoQixDQUFYOztBQUVBLFFBQUksQ0FBQ1ksSUFBTCxFQUFXO0FBQ1Q1RSxRQUFFLENBQUNjLEtBQUgsSUFBWUMsT0FBTyxDQUFDQyxHQUFSLENBQVksNENBQVosQ0FBWjtBQUNBO0FBQ0QsS0FYMkMsQ0FhNUM7OztBQUNBLFFBQUk2RCxVQUFVLEdBQUc3RSxFQUFFLENBQUNzRCxPQUFILENBQVd3QixJQUFYLENBQWdCRixJQUFJLENBQUNsQyxJQUFyQixDQUFqQixDQWQ0QyxDQWdCNUM7O0FBQ0FNLFFBQUksQ0FBQ0ksSUFBTCxDQUFVLFVBQVYsRUFBc0JqQyxPQUF0QixFQUErQkksUUFBL0IsRUFBeUNzRCxVQUF6QyxFQUFxRFosUUFBckQsRUFBK0R2QyxNQUEvRDtBQUVBLFFBQUlxRCxRQUFRLEdBQUc7QUFBRUosVUFBSSxFQUFFO0FBQVIsS0FBZjs7QUFDQSxRQUFJLENBQUN4RCxPQUFPLENBQUM2RCxXQUFiLEVBQTBCO0FBQ3hCRCxjQUFRLENBQUNKLElBQVQsQ0FBY0ssV0FBZCxHQUE0QkMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLCtCQUFaLEdBQThDRixPQUFPLENBQUNDLEdBQVIsQ0FBWUQsT0FBTyxDQUFDQyxHQUFSLENBQVlDLCtCQUF4QixDQUE5QyxHQUF5R0YsT0FBTyxDQUFDQyxHQUFSLENBQVlFLGlCQUFqSjtBQUNELEtBdEIyQyxDQXdCNUM7OztBQUNBLFFBQUlQLFVBQVUsS0FBS1osUUFBbkIsRUFBNkI7QUFDM0I7QUFDQWMsY0FBUSxDQUFDTSxNQUFULEdBQWtCO0FBQUNSLGtCQUFVLEVBQUUsQ0FBYjtBQUFnQlosZ0JBQVEsRUFBRSxDQUExQjtBQUE2QnFCLGlCQUFTLEVBQUU7QUFBeEMsT0FBbEIsQ0FGMkIsQ0FJM0I7O0FBQ0EsVUFBSSxPQUFPbkUsT0FBTyxDQUFDb0UsVUFBZixLQUE4QixXQUFsQyxFQUErQztBQUM3QztBQUNBUixnQkFBUSxDQUFDSixJQUFULENBQWNZLFVBQWQsR0FBMkIsSUFBSUMsSUFBSixFQUEzQjtBQUNELE9BSEQsTUFHTztBQUNMO0FBQ0E7QUFDQVQsZ0JBQVEsQ0FBQ0osSUFBVCxDQUFjYyxjQUFkLEdBQStCLElBQUlELElBQUosRUFBL0I7QUFDRCxPQVowQixDQWMzQjs7O0FBQ0FyRSxhQUFPLENBQUN1RCxNQUFSLENBQWVLLFFBQWYsRUFmMkIsQ0FpQjNCOztBQUNBLFVBQUlXLFNBQVMsR0FBR3BCLFdBQVcsR0FBRyxjQUFILEdBQW9CLFFBQS9DO0FBQ0F0QixVQUFJLENBQUNJLElBQUwsQ0FBVXNDLFNBQVYsRUFBcUJ2RSxPQUFyQixFQUE4Qk8sTUFBOUIsRUFuQjJCLENBcUIzQjs7QUFDQXNCLFVBQUksQ0FBQ0ksSUFBTCxDQUFVLE9BQVYsRUFBbUJqQyxPQUFuQixFQUE0QjBELFVBQTVCLEVBQXdDbkQsTUFBeEM7QUFDRCxLQXZCRCxNQXVCTztBQUNMO0FBQ0FxRCxjQUFRLENBQUNKLElBQVQsQ0FBY0UsVUFBZCxHQUEyQkEsVUFBM0I7QUFDQTFELGFBQU8sQ0FBQ3VELE1BQVIsQ0FBZUssUUFBZjtBQUNEO0FBQ0YsR0FyREQsRUE5QzBELENBcUcxRDs7QUFDQVIsYUFBVyxDQUFDakQsRUFBWixDQUFlLE9BQWYsRUFBd0IsVUFBVXFFLEtBQVYsRUFBaUI7QUFDdkMzRixNQUFFLENBQUNjLEtBQUgsSUFBWUMsT0FBTyxDQUFDQyxHQUFSLENBQVksOEJBQVosRUFBNEMyRSxLQUE1QyxDQUFaO0FBQ0EzQyxRQUFJLENBQUNJLElBQUwsQ0FBVSxPQUFWLEVBQW1CdUMsS0FBbkIsRUFBMEJ4RSxPQUExQjtBQUNELEdBSEQ7QUFLQSxTQUFPb0QsV0FBUDtBQUNELENBNUdEO0FBOEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQXZFLEVBQUUsQ0FBQ0MsU0FBSCxDQUFhMkYsZ0JBQWIsR0FBZ0MsVUFBU3pFLE9BQVQsRUFBa0I7QUFDaEQ7QUFDQVosY0FBWSxHQUZvQyxDQUloRDs7QUFDQVcsV0FBUyxDQUFDQyxPQUFELEVBQVUsK0JBQVYsQ0FBVDtBQUVBbkIsSUFBRSxDQUFDYyxLQUFILElBQVlDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJDQUEyQ0csT0FBTyxDQUFDZSxHQUEvRCxDQUFaLENBUGdELENBU2hEOztBQUNBLE1BQUltQixTQUFTLEdBQUduRCxPQUFPLENBQUM4QixPQUFSLENBQWdCO0FBQUNDLFVBQU0sRUFBRWQsT0FBTyxDQUFDZSxHQUFqQjtBQUFzQkMsa0JBQWMsRUFBRWhCLE9BQU8sQ0FBQ2dCO0FBQTlDLEdBQWhCLEtBQWtGLEVBQWxHO0FBQ0EsTUFBSTBELFdBQVcsR0FBRzdGLEVBQUUsQ0FBQ3NELE9BQUgsQ0FBV3dCLElBQVgsQ0FBZ0J6QixTQUFTLENBQUNYLElBQTFCLENBQWxCOztBQUVBLFdBQVNvRCxpQkFBVCxDQUEyQmhFLEtBQTNCLEVBQWtDO0FBQ2hDLFdBQU9pRSxNQUFNLENBQUNDLGVBQVAsQ0FBdUIsVUFBU0MsSUFBVCxFQUFlO0FBQzNDLFVBQUlyRCxPQUFPLEdBQUdmLGNBQWMsQ0FBQ1YsT0FBRCxFQUFVVyxLQUFWLENBQTVCOztBQUNBLFVBQUlvRSxlQUFlLEdBQUdsRyxFQUFFLENBQUNDLFNBQUgsQ0FBYUssT0FBYixDQUFxQnFDLE9BQXJCLENBQTZCaUQsZ0JBQTdCLENBQThDaEQsT0FBOUMsQ0FBdEI7QUFDQXFELFVBQUksQ0FBQ0MsZUFBRCxDQUFKO0FBQ0QsS0FKTSxFQUlKLFVBQVVQLEtBQVYsRUFBaUI7QUFDbEIsWUFBTUEsS0FBTjtBQUNELEtBTk0sQ0FBUDtBQU9ELEdBckIrQyxDQXVCaEQ7OztBQUNBLE1BQUlRLGNBQWMsR0FBR3BHLGNBQWMsQ0FBQ3FHLE1BQWYsRUFBckIsQ0F4QmdELENBMEJoRDs7QUFDQSxNQUFJQyxZQUFZLEdBQUcsQ0FBbkI7O0FBQ0EsT0FBSyxJQUFJdkUsS0FBSyxHQUFHLENBQWpCLEVBQW9CQSxLQUFLLEdBQUcrRCxXQUE1QixFQUF5Qy9ELEtBQUssRUFBOUMsRUFBa0Q7QUFDaERxRSxrQkFBYyxDQUFDRyxNQUFmLENBQXNCUixpQkFBaUIsQ0FBQ2hFLEtBQUQsQ0FBdkM7QUFDRCxHQTlCK0MsQ0FnQ2hEOzs7QUFDQSxTQUFPcUUsY0FBUDtBQUNELENBbENELEMiLCJmaWxlIjoiL3BhY2thZ2VzL2Nmc190ZW1wc3RvcmUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyAjI1RlbXBvcmFyeSBTdG9yYWdlXG4vL1xuLy8gVGVtcG9yYXJ5IHN0b3JhZ2UgaXMgdXNlZCBmb3IgY2h1bmtlZCB1cGxvYWRzIHVudGlsIGFsbCBjaHVua3MgYXJlIHJlY2VpdmVkXG4vLyBhbmQgYWxsIGNvcGllcyBoYXZlIGJlZW4gbWFkZSBvciBnaXZlbiB1cC4gSW4gc29tZSBjYXNlcywgdGhlIG9yaWdpbmFsIGZpbGVcbi8vIGlzIHN0b3JlZCBvbmx5IGluIHRlbXBvcmFyeSBzdG9yYWdlIChmb3IgZXhhbXBsZSwgaWYgYWxsIGNvcGllcyBkbyBzb21lXG4vLyBtYW5pcHVsYXRpb24gaW4gYmVmb3JlU2F2ZSkuIFRoaXMgaXMgd2h5IHdlIHVzZSB0aGUgdGVtcG9yYXJ5IGZpbGUgYXMgdGhlXG4vLyBiYXNpcyBmb3IgZWFjaCBzYXZlZCBjb3B5LCBhbmQgdGhlbiByZW1vdmUgaXQgYWZ0ZXIgYWxsIGNvcGllcyBhcmUgc2F2ZWQuXG4vL1xuLy8gRXZlcnkgY2h1bmsgaXMgc2F2ZWQgYXMgYW4gaW5kaXZpZHVhbCB0ZW1wb3JhcnkgZmlsZS4gVGhpcyBpcyBzYWZlciB0aGFuXG4vLyBhdHRlbXB0aW5nIHRvIHdyaXRlIG11bHRpcGxlIGluY29taW5nIGNodW5rcyB0byBkaWZmZXJlbnQgcG9zaXRpb25zIGluIGFcbi8vIHNpbmdsZSB0ZW1wb3JhcnkgZmlsZSwgd2hpY2ggY2FuIGxlYWQgdG8gd3JpdGUgY29uZmxpY3RzLlxuLy9cbi8vIFVzaW5nIHRlbXAgZmlsZXMgYWxzbyBhbGxvd3MgdXMgdG8gZWFzaWx5IHJlc3VtZSB1cGxvYWRzLCBldmVuIGlmIHRoZSBzZXJ2ZXJcbi8vIHJlc3RhcnRzLCBhbmQgdG8ga2VlcCB0aGUgd29ya2luZyBtZW1vcnkgY2xlYXIuXG5cbi8vIFRoZSBGUy5UZW1wU3RvcmUgZW1pdHMgZXZlbnRzIHRoYXQgb3RoZXJzIGFyZSBhYmxlIHRvIGxpc3RlbiB0b1xudmFyIEV2ZW50RW1pdHRlciA9IE5wbS5yZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXI7XG5cbi8vIFdlIGhhdmUgYSBzcGVjaWFsIHN0cmVhbSBjb25jYXRpbmcgYWxsIGNodW5rIGZpbGVzIGludG8gb25lIHJlYWRhYmxlIHN0cmVhbVxudmFyIENvbWJpbmVkU3RyZWFtID0gTnBtLnJlcXVpcmUoJ2NvbWJpbmVkLXN0cmVhbScpO1xuXG4vKiogQG5hbWVzcGFjZSBGUy5UZW1wU3RvcmVcbiAqIEBwcm9wZXJ0eSBGUy5UZW1wU3RvcmVcbiAqIEB0eXBlIHtvYmplY3R9XG4gKiBAcHVibGljXG4gKiBAc3VtbWFyeSBBbiBldmVudCBlbWl0dGVyXG4gKi9cbkZTLlRlbXBTdG9yZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuLy8gQ3JlYXRlIGEgdHJhY2tlciBjb2xsZWN0aW9uIGZvciBrZWVwaW5nIHRyYWNrIG9mIGFsbCBjaHVua3MgZm9yIGFueSBmaWxlcyB0aGF0IGFyZSBjdXJyZW50bHkgaW4gdGhlIHRlbXAgc3RvcmVcbnZhciB0cmFja2VyID0gRlMuVGVtcFN0b3JlLlRyYWNrZXIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2ZzLl90ZW1wc3RvcmUuY2h1bmtzJyk7XG5cbi8qKlxuICogQHByb3BlcnR5IEZTLlRlbXBTdG9yZS5TdG9yYWdlXG4gKiBAdHlwZSB7U3RvcmFnZUFkYXB0ZXJ9XG4gKiBAbmFtZXNwYWNlIEZTLlRlbXBTdG9yZVxuICogQHByaXZhdGVcbiAqIEBzdW1tYXJ5IFRoaXMgcHJvcGVydHkgaXMgc2V0IHRvIGVpdGhlciBgRlMuU3RvcmUuRmlsZVN5c3RlbWAgb3IgYEZTLlN0b3JlLkdyaWRGU2BcbiAqXG4gKiBfX1doZW4gYW5kIHdoeTpfX1xuICogV2Ugbm9ybWFsbHkgZGVmYXVsdCB0byBgY2ZzLWZpbGVzeXN0ZW1gIHVubGVzcyBpdHMgbm90IGluc3RhbGxlZC4gKih3ZSBkZWZhdWx0IHRvIGdyaWRmcyBpZiBpbnN0YWxsZWQpKlxuICogQnV0IGlmIGBjZnMtZ3JpZGZzYCBhbmQgYGNmcy13b3JrZXJgIGlzIGluc3RhbGxlZCB3ZSBkZWZhdWx0IHRvIGBjZnMtZ3JpZGZzYFxuICpcbiAqIElmIGBjZnMtZ3JpZGZzYCBhbmQgYGNmcy1maWxlc3lzdGVtYCBpcyBub3QgaW5zdGFsbGVkIHdlIGxvZyBhIHdhcm5pbmcuXG4gKiB0aGUgdXNlciBjYW4gc2V0IGBGUy5UZW1wU3RvcmUuU3RvcmFnZWAgdGhlbSBzZWxmcyBlZy46XG4gKiBgYGBqc1xuICogICAvLyBJdHMgaW1wb3J0YW50IHRvIHNldCBgaW50ZXJuYWw6IHRydWVgIHRoaXMgbGV0cyB0aGUgU0Ega25vdyB0aGF0IHdlXG4gKiAgIC8vIGFyZSB1c2luZyB0aGlzIGludGVybmFsbHkgYW5kIGl0IHdpbGwgZ2l2ZSB1cyBkaXJlY3QgU0EgYXBpXG4gKiAgIEZTLlRlbXBTdG9yZS5TdG9yYWdlID0gbmV3IEZTLlN0b3JlLkdyaWRGUygnX3RlbXBzdG9yZScsIHsgaW50ZXJuYWw6IHRydWUgfSk7XG4gKiBgYGBcbiAqXG4gKiA+IE5vdGU6IFRoaXMgaXMgY29uc2lkZXJlZCBhcyBgYWR2YW5jZWRgIHVzZSwgaXRzIG5vdCBhIGNvbW1vbiBwYXR0ZXJuLlxuICovXG5GUy5UZW1wU3RvcmUuU3RvcmFnZSA9IG51bGw7XG5cbi8vIFdlIHdpbGwgbm90IG1vdW50IGEgc3RvcmFnZSBhZGFwdGVyIHVudGlsIG5lZWRlZC4gVGhpcyBhbGxvd3MgdXMgdG8gY2hlY2sgZm9yIHRoZVxuLy8gZXhpc3RhbmNlIG9mIEZTLkZpbGVXb3JrZXIsIHdoaWNoIGlzIGxvYWRlZCBhZnRlciB0aGlzIHBhY2thZ2UgYmVjYXVzZSBpdFxuLy8gZGVwZW5kcyBvbiB0aGlzIHBhY2thZ2UuXG5mdW5jdGlvbiBtb3VudFN0b3JhZ2UoKSB7XG5cbiAgaWYgKEZTLlRlbXBTdG9yZS5TdG9yYWdlKSByZXR1cm47XG5cbiAgLy8gWFhYOiBXZSBjb3VsZCByZXBsYWNlIHRoaXMgdGVzdCwgdGVzdGluZyB0aGUgRlMgc2NvcGUgZm9yIGdyaWZGUyBldGMuXG4gIC8vIFRoaXMgaXMgb24gdGhlIHRvZG8gbGF0ZXIgd2hlbiB3ZSBnZXQgXCJzdGFibGVcIlxuICBpZiAoUGFja2FnZVtcImNmczpncmlkZnNcIl0gJiYgKFBhY2thZ2VbXCJjZnM6d29ya2VyXCJdIHx8ICFQYWNrYWdlW1wiY2ZzOmZpbGVzeXN0ZW1cIl0pKSB7XG4gICAgLy8gSWYgdGhlIGZpbGUgd29ya2VyIGlzIGluc3RhbGxlZCB3ZSB3b3VsZCBwcmVmZXIgdG8gdXNlIHRoZSBncmlkZnMgc2FcbiAgICAvLyBmb3Igc2NhbGFiaWxpdHkuIFdlIGFsc28gZGVmYXVsdCB0byBncmlkZnMgaWYgZmlsZXN5c3RlbSBpcyBub3QgZm91bmRcblxuICAgIC8vIFVzZSB0aGUgZ3JpZGZzXG4gICAgRlMuVGVtcFN0b3JlLlN0b3JhZ2UgPSBuZXcgRlMuU3RvcmUuR3JpZEZTKCdfdGVtcHN0b3JlJywgeyBpbnRlcm5hbDogdHJ1ZSB9KTtcbiAgfSBlbHNlIGlmIChQYWNrYWdlW1wiY2ZzOmZpbGVzeXN0ZW1cIl0pIHtcblxuICAgIC8vIHVzZSB0aGUgRmlsZXN5c3RlbVxuICAgIEZTLlRlbXBTdG9yZS5TdG9yYWdlID0gbmV3IEZTLlN0b3JlLkZpbGVTeXN0ZW0oJ190ZW1wc3RvcmUnLCB7IGludGVybmFsOiB0cnVlIH0pO1xuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcignRlMuVGVtcFN0b3JlLlN0b3JhZ2UgaXMgbm90IHNldDogSW5zdGFsbCBjZnM6ZmlsZXN5c3RlbSBvciBjZnM6Z3JpZGZzIG9yIHNldCBpdCBtYW51YWxseScpO1xuICB9XG5cbiAgRlMuZGVidWcgJiYgY29uc29sZS5sb2coJ1RlbXBTdG9yZSBpcyBtb3VudGVkIG9uJywgRlMuVGVtcFN0b3JlLlN0b3JhZ2UudHlwZU5hbWUpO1xufVxuXG5mdW5jdGlvbiBtb3VudEZpbGUoZmlsZU9iaiwgbmFtZSkge1xuICBpZiAoIWZpbGVPYmouaXNNb3VudGVkKCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IobmFtZSArICcgY2Fubm90IHdvcmsgd2l0aCB1bm1vdW50ZWQgZmlsZScpO1xuICB9XG59XG5cbi8vIFdlIHVwZGF0ZSB0aGUgZmlsZU9iaiBvbiBwcm9ncmVzc1xuRlMuVGVtcFN0b3JlLm9uKCdwcm9ncmVzcycsIGZ1bmN0aW9uKGZpbGVPYmosIGNodW5rTnVtLCBjb3VudCwgdG90YWwsIHJlc3VsdCkge1xuICBGUy5kZWJ1ZyAmJiBjb25zb2xlLmxvZygnVGVtcFN0b3JlIHByb2dyZXNzOiBSZWNlaXZlZCAnICsgY291bnQgKyAnIG9mICcgKyB0b3RhbCArICcgY2h1bmtzIGZvciAnICsgZmlsZU9iai5uYW1lKCkpO1xufSk7XG5cbi8vIFhYWDogVE9ET1xuLy8gRlMuVGVtcFN0b3JlLm9uKCdzdG9yZWQnLCBmdW5jdGlvbihmaWxlT2JqLCBjaHVua0NvdW50LCByZXN1bHQpIHtcbi8vICAgLy8gVGhpcyBzaG91bGQgd29yayBpZiB3ZSBwYXNzIG9uIHJlc3VsdCBmcm9tIHRoZSBTQSBvbiBzdG9yZWQgZXZlbnQuLi5cbi8vICAgZmlsZU9iai51cGRhdGUoeyAkc2V0OiB7IGNodW5rU3VtOiAxLCBjaHVua0NvdW50OiBjaHVua0NvdW50LCBzaXplOiByZXN1bHQuc2l6ZSB9IH0pO1xuLy8gfSk7XG5cbi8vIFN0cmVhbSBpbXBsZW1lbnRhdGlvblxuXG4vKipcbiAqIEBtZXRob2QgX2NodW5rUGF0aFxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7TnVtYmVyfSBbbl0gQ2h1bmsgbnVtYmVyXG4gKiBAcmV0dXJucyB7U3RyaW5nfSBDaHVuayBuYW1pbmcgY29udmVudGlvblxuICovXG5fY2h1bmtQYXRoID0gZnVuY3Rpb24obikge1xuICByZXR1cm4gKG4gfHwgMCkgKyAnLmNodW5rJztcbn07XG5cbi8qKlxuICogQG1ldGhvZCBfZmlsZVJlZmVyZW5jZVxuICogQHBhcmFtIHtGUy5GaWxlfSBmaWxlT2JqXG4gKiBAcGFyYW0ge051bWJlcn0gY2h1bmtcbiAqIEBwcml2YXRlXG4gKiBAcmV0dXJucyB7U3RyaW5nfSBHZW5lcmF0ZWQgU0Egc3BlY2lmaWMgZmlsZUtleSBmb3IgdGhlIGNodW5rXG4gKlxuICogTm90ZTogQ2FsbGluZyBmdW5jdGlvbiBzaG91bGQgY2FsbCBtb3VudFN0b3JhZ2UoKSBmaXJzdCwgYW5kXG4gKiBtYWtlIHN1cmUgdGhhdCBmaWxlT2JqIGlzIG1vdW50ZWQuXG4gKi9cbl9maWxlUmVmZXJlbmNlID0gZnVuY3Rpb24oZmlsZU9iaiwgY2h1bmssIGV4aXN0aW5nKSB7XG4gIC8vIE1heWJlIGl0J3MgYSBjaHVuayB3ZSd2ZSBhbHJlYWR5IHNhdmVkXG4gIGV4aXN0aW5nID0gZXhpc3RpbmcgfHwgdHJhY2tlci5maW5kT25lKHtmaWxlSWQ6IGZpbGVPYmouX2lkLCBjb2xsZWN0aW9uTmFtZTogZmlsZU9iai5jb2xsZWN0aW9uTmFtZX0pO1xuXG4gIC8vIE1ha2UgYSB0ZW1wb3JhcnkgZmlsZU9iaiBqdXN0IGZvciBmaWxlS2V5IGdlbmVyYXRpb25cbiAgdmFyIHRlbXBGaWxlT2JqID0gbmV3IEZTLkZpbGUoe1xuICAgIGNvbGxlY3Rpb25OYW1lOiBmaWxlT2JqLmNvbGxlY3Rpb25OYW1lLFxuICAgIF9pZDogZmlsZU9iai5faWQsXG4gICAgb3JpZ2luYWw6IHtcbiAgICAgIG5hbWU6IF9jaHVua1BhdGgoY2h1bmspXG4gICAgfSxcbiAgICBjb3BpZXM6IHtcbiAgICAgIF90ZW1wc3RvcmU6IHtcbiAgICAgICAga2V5OiBleGlzdGluZyAmJiBleGlzdGluZy5rZXlzW2NodW5rXVxuICAgICAgfVxuICAgIH1cbiAgfSk7XG5cbiAgLy8gUmV0dXJuIGEgZml0dGluZyBmaWxlS2V5IFNBIHNwZWNpZmljXG4gIHJldHVybiBGUy5UZW1wU3RvcmUuU3RvcmFnZS5hZGFwdGVyLmZpbGVLZXkodGVtcEZpbGVPYmopO1xufTtcblxuLyoqXG4gKiBAbWV0aG9kIEZTLlRlbXBTdG9yZS5leGlzdHNcbiAqIEBwYXJhbSB7RlMuRmlsZX0gRmlsZSBvYmplY3RcbiAqIEByZXR1cm5zIHtCb29sZWFufSBJcyB0aGlzIGZpbGUsIG9yIHBhcnRzIG9mIGl0LCBjdXJyZW50bHkgc3RvcmVkIGluIHRoZSBUZW1wU3RvcmVcbiAqL1xuRlMuVGVtcFN0b3JlLmV4aXN0cyA9IGZ1bmN0aW9uKGZpbGVPYmopIHtcbiAgdmFyIGV4aXN0aW5nID0gdHJhY2tlci5maW5kT25lKHtmaWxlSWQ6IGZpbGVPYmouX2lkLCBjb2xsZWN0aW9uTmFtZTogZmlsZU9iai5jb2xsZWN0aW9uTmFtZX0pO1xuICByZXR1cm4gISFleGlzdGluZztcbn07XG5cbi8qKlxuICogQG1ldGhvZCBGUy5UZW1wU3RvcmUubGlzdFBhcnRzXG4gKiBAcGFyYW0ge0ZTLkZpbGV9IGZpbGVPYmpcbiAqIEByZXR1cm5zIHtPYmplY3R9IG9mIHBhcnRzIGFscmVhZHkgc3RvcmVkXG4gKiBAdG9kbyBUaGlzIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWQsIG1pbGVzdG9uZSAxLjEuMFxuICovXG5GUy5UZW1wU3RvcmUubGlzdFBhcnRzID0gZnVuY3Rpb24gZnNUZW1wU3RvcmVMaXN0UGFydHMoZmlsZU9iaikge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIGNvbnNvbGUud2FybignVGhpcyBmdW5jdGlvbiBpcyBub3QgY29ycmVjdGx5IGltcGxlbWVudGVkIHVzaW5nIFNBIGluIFRlbXBTdG9yZScpO1xuICAvL1hYWCBUaGlzIGZ1bmN0aW9uIG1pZ2h0IGJlIG5lY2Vzc2FyeSBmb3IgcmVzdW1lLiBOb3QgY3VycmVudGx5IHN1cHBvcnRlZC5cbn07XG5cbi8qKlxuICogQG1ldGhvZCBGUy5UZW1wU3RvcmUucmVtb3ZlRmlsZVxuICogQHB1YmxpY1xuICogQHBhcmFtIHtGUy5GaWxlfSBmaWxlT2JqXG4gKiBUaGlzIGZ1bmN0aW9uIHJlbW92ZXMgdGhlIGZpbGUgZnJvbSB0ZW1wc3RvcmFnZSAtIGl0IGNhcmVzIG5vdCBpZiBmaWxlIGlzXG4gKiBhbHJlYWR5IHJlbW92ZWQgb3Igbm90IGZvdW5kLCBnb2FsIGlzIHJlYWNoZWQgYW55d2F5LlxuICovXG5GUy5UZW1wU3RvcmUucmVtb3ZlRmlsZSA9IGZ1bmN0aW9uIGZzVGVtcFN0b3JlUmVtb3ZlRmlsZShmaWxlT2JqKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICAvLyBFbnN1cmUgdGhhdCB3ZSBoYXZlIGEgc3RvcmFnZSBhZGFwdGVyIG1vdW50ZWQ7IGlmIG5vdCwgdGhyb3cgYW4gZXJyb3IuXG4gIG1vdW50U3RvcmFnZSgpO1xuXG4gIC8vIElmIGZpbGVPYmogaXMgbm90IG1vdW50ZWQgb3IgY2FuJ3QgYmUsIHRocm93IGFuIGVycm9yXG4gIG1vdW50RmlsZShmaWxlT2JqLCAnRlMuVGVtcFN0b3JlLnJlbW92ZUZpbGUnKTtcblxuICAvLyBFbWl0IGV2ZW50XG4gIHNlbGYuZW1pdCgncmVtb3ZlJywgZmlsZU9iaik7XG5cbiAgdmFyIGNodW5rSW5mbyA9IHRyYWNrZXIuZmluZE9uZSh7XG4gICAgZmlsZUlkOiBmaWxlT2JqLl9pZCxcbiAgICBjb2xsZWN0aW9uTmFtZTogZmlsZU9iai5jb2xsZWN0aW9uTmFtZVxuICB9KTtcblxuICBpZiAoY2h1bmtJbmZvKSB7XG5cbiAgICAvLyBVbmxpbmsgZWFjaCBmaWxlXG4gICAgRlMuVXRpbGl0eS5lYWNoKGNodW5rSW5mby5rZXlzIHx8IHt9LCBmdW5jdGlvbiAoa2V5LCBjaHVuaykge1xuICAgICAgdmFyIGZpbGVLZXkgPSBfZmlsZVJlZmVyZW5jZShmaWxlT2JqLCBjaHVuaywgY2h1bmtJbmZvKTtcbiAgICAgIEZTLlRlbXBTdG9yZS5TdG9yYWdlLmFkYXB0ZXIucmVtb3ZlKGZpbGVLZXksIEZTLlV0aWxpdHkubm9vcCk7XG4gICAgfSk7XG5cbiAgICAvLyBSZW1vdmUgZmlsZU9iaiBmcm9tIHRyYWNrZXIgY29sbGVjdGlvbiwgdG9vXG4gICAgdHJhY2tlci5yZW1vdmUoe19pZDogY2h1bmtJbmZvLl9pZH0pO1xuXG4gIH1cbn07XG5cbi8qKlxuICogQG1ldGhvZCBGUy5UZW1wU3RvcmUucmVtb3ZlQWxsXG4gKiBAcHVibGljXG4gKiBAc3VtbWFyeSBUaGlzIGZ1bmN0aW9uIHJlbW92ZXMgYWxsIGZpbGVzIGZyb20gdGVtcHN0b3JhZ2UgLSBpdCBjYXJlcyBub3QgaWYgZmlsZSBpc1xuICogYWxyZWFkeSByZW1vdmVkIG9yIG5vdCBmb3VuZCwgZ29hbCBpcyByZWFjaGVkIGFueXdheS5cbiAqL1xuRlMuVGVtcFN0b3JlLnJlbW92ZUFsbCA9IGZ1bmN0aW9uIGZzVGVtcFN0b3JlUmVtb3ZlQWxsKCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgLy8gRW5zdXJlIHRoYXQgd2UgaGF2ZSBhIHN0b3JhZ2UgYWRhcHRlciBtb3VudGVkOyBpZiBub3QsIHRocm93IGFuIGVycm9yLlxuICBtb3VudFN0b3JhZ2UoKTtcblxuICB0cmFja2VyLmZpbmQoKS5mb3JFYWNoKGZ1bmN0aW9uIChjaHVua0luZm8pIHtcbiAgICAvLyBVbmxpbmsgZWFjaCBmaWxlXG4gICAgRlMuVXRpbGl0eS5lYWNoKGNodW5rSW5mby5rZXlzIHx8IHt9LCBmdW5jdGlvbiAoa2V5LCBjaHVuaykge1xuICAgICAgdmFyIGZpbGVLZXkgPSBfZmlsZVJlZmVyZW5jZSh7X2lkOiBjaHVua0luZm8uZmlsZUlkLCBjb2xsZWN0aW9uTmFtZTogY2h1bmtJbmZvLmNvbGxlY3Rpb25OYW1lfSwgY2h1bmssIGNodW5rSW5mbyk7XG4gICAgICBGUy5UZW1wU3RvcmUuU3RvcmFnZS5hZGFwdGVyLnJlbW92ZShmaWxlS2V5LCBGUy5VdGlsaXR5Lm5vb3ApO1xuICAgIH0pO1xuXG4gICAgLy8gUmVtb3ZlIGZyb20gdHJhY2tlciBjb2xsZWN0aW9uLCB0b29cbiAgICB0cmFja2VyLnJlbW92ZSh7X2lkOiBjaHVua0luZm8uX2lkfSk7XG4gIH0pO1xufTtcblxuLyoqXG4gKiBAbWV0aG9kIEZTLlRlbXBTdG9yZS5jcmVhdGVXcml0ZVN0cmVhbVxuICogQHB1YmxpY1xuICogQHBhcmFtIHtGUy5GaWxlfSBmaWxlT2JqIEZpbGUgdG8gc3RvcmUgaW4gdGVtcG9yYXJ5IHN0b3JhZ2VcbiAqIEBwYXJhbSB7TnVtYmVyIHwgU3RyaW5nfSBbb3B0aW9uc11cbiAqIEByZXR1cm5zIHtTdHJlYW19IFdyaXRlYWJsZSBzdHJlYW1cbiAqXG4gKiBgb3B0aW9uc2Agb2YgZGlmZmVyZW50IHR5cGVzIG1lYW4gZGlmZmVybnQgdGhpbmdzOlxuICogKiBgdW5kZWZpbmVkYCBXZSBzdG9yZSB0aGUgZmlsZSBpbiBvbmUgcGFydFxuICogKihOb3JtYWwgc2VydmVyLXNpZGUgYXBpIHVzYWdlKSpcbiAqICogYE51bWJlcmAgdGhlIG51bWJlciBpcyB0aGUgcGFydCBudW1iZXIgdG90YWxcbiAqICoobXVsdGlwYXJ0IHVwbG9hZHMgd2lsbCB1c2UgdGhpcyBhcGkpKlxuICogKiBgU3RyaW5nYCB0aGUgc3RyaW5nIGlzIHRoZSBuYW1lIG9mIHRoZSBgc3RvcmVgIHRoYXQgd2FudHMgdG8gc3RvcmUgZmlsZSBkYXRhXG4gKiAqKHN0b3JlcyB0aGF0IHdhbnQgdG8gc3luYyB0aGVpciBkYXRhIHRvIHRoZSByZXN0IG9mIHRoZSBmaWxlcyBzdG9yZXMgd2lsbCB1c2UgdGhpcykqXG4gKlxuICogPiBOb3RlOiBmaWxlT2JqIG11c3QgYmUgbW91bnRlZCBvbiBhIGBGUy5Db2xsZWN0aW9uYCwgaXQgbWFrZXMgbm8gc2Vuc2UgdG8gc3RvcmUgb3RoZXJ3aXNlXG4gKi9cbkZTLlRlbXBTdG9yZS5jcmVhdGVXcml0ZVN0cmVhbSA9IGZ1bmN0aW9uKGZpbGVPYmosIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIC8vIEVuc3VyZSB0aGF0IHdlIGhhdmUgYSBzdG9yYWdlIGFkYXB0ZXIgbW91bnRlZDsgaWYgbm90LCB0aHJvdyBhbiBlcnJvci5cbiAgbW91bnRTdG9yYWdlKCk7XG5cbiAgLy8gSWYgZmlsZU9iaiBpcyBub3QgbW91bnRlZCBvciBjYW4ndCBiZSwgdGhyb3cgYW4gZXJyb3JcbiAgbW91bnRGaWxlKGZpbGVPYmosICdGUy5UZW1wU3RvcmUuY3JlYXRlV3JpdGVTdHJlYW0nKTtcblxuICAvLyBDYWNoZSB0aGUgc2VsZWN0b3IgZm9yIHVzZSBtdWx0aXBsZSB0aW1lcyBiZWxvd1xuICB2YXIgc2VsZWN0b3IgPSB7ZmlsZUlkOiBmaWxlT2JqLl9pZCwgY29sbGVjdGlvbk5hbWU6IGZpbGVPYmouY29sbGVjdGlvbk5hbWV9O1xuXG4gIC8vIFRPRE8sIHNob3VsZCBwYXNzIGluIGNodW5rU3VtIHNvIHdlIGRvbid0IG5lZWQgdG8gdXNlIEZTLkZpbGUgZm9yIGl0XG4gIHZhciBjaHVua1N1bSA9IGZpbGVPYmouY2h1bmtTdW0gfHwgMTtcblxuICAvLyBBZGQgZmlsZU9iaiB0byB0cmFja2VyIGNvbGxlY3Rpb25cbiAgdHJhY2tlci51cHNlcnQoc2VsZWN0b3IsIHskc2V0T25JbnNlcnQ6IHtrZXlzOiB7fX19KTtcblxuICAvLyBEZXRlcm1pbmUgaG93IHdlJ3JlIHVzaW5nIHRoZSB3cml0ZVN0cmVhbVxuICB2YXIgaXNPbmVQYXJ0ID0gZmFsc2UsIGlzTXVsdGlQYXJ0ID0gZmFsc2UsIGlzU3RvcmVTeW5jID0gZmFsc2UsIGNodW5rTnVtID0gMDtcbiAgaWYgKG9wdGlvbnMgPT09ICtvcHRpb25zKSB7XG4gICAgaXNNdWx0aVBhcnQgPSB0cnVlO1xuICAgIGNodW5rTnVtID0gb3B0aW9ucztcbiAgfSBlbHNlIGlmIChvcHRpb25zID09PSAnJytvcHRpb25zKSB7XG4gICAgaXNTdG9yZVN5bmMgPSB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGlzT25lUGFydCA9IHRydWU7XG4gIH1cblxuICAvLyBYWFg6IGl0IHNob3VsZCBiZSBwb3NzaWJsZSBmb3IgYSBzdG9yZSB0byBzeW5jIGJ5IHN0b3JpbmcgZGF0YSBpbnRvIHRoZVxuICAvLyB0ZW1wc3RvcmUgLSB0aGlzIGNvdWxkIGJlIGRvbmUgbmljZWx5IGJ5IHNldHRpbmcgdGhlIHN0b3JlIG5hbWUgYXMgc3RyaW5nXG4gIC8vIGluIHRoZSBjaHVuayB2YXJpYWJsZT9cbiAgLy8gVGhpcyBzdG9yZSBuYW1lIGNvdWxkIGJlIHBhc3NlZCBvbiB0aGUgdGhlIGZpbGV3b3JrZXIgdmlhIHRoZSB1cGxvYWRlZFxuICAvLyBldmVudFxuICAvLyBTbyB0aGUgdXBsb2FkZWQgZXZlbnQgY2FuIHJldHVybjpcbiAgLy8gdW5kZWZpbmVkIC0gaWYgZGF0YSBpcyBzdG9yZWQgaW50byBhbmQgc2hvdWxkIHN5bmMgb3V0IHRvIGFsbCBzdG9yYWdlIGFkYXB0ZXJzXG4gIC8vIG51bWJlciAtIGlmIGEgY2h1bmsgaGFzIGJlZW4gdXBsb2FkZWRcbiAgLy8gc3RyaW5nIC0gaWYgYSBzdG9yYWdlIGFkYXB0ZXIgd2FudHMgdG8gc3luYyBpdHMgZGF0YSB0byB0aGUgb3RoZXIgU0Enc1xuXG4gIC8vIEZpbmQgYSBuaWNlIGxvY2F0aW9uIGZvciB0aGUgY2h1bmsgZGF0YVxuICB2YXIgZmlsZUtleSA9IF9maWxlUmVmZXJlbmNlKGZpbGVPYmosIGNodW5rTnVtKTtcblxuICAvLyBDcmVhdGUgdGhlIHN0cmVhbSBhcyBNZXRlb3Igc2FmZSBzdHJlYW1cbiAgdmFyIHdyaXRlU3RyZWFtID0gRlMuVGVtcFN0b3JlLlN0b3JhZ2UuYWRhcHRlci5jcmVhdGVXcml0ZVN0cmVhbShmaWxlS2V5KTtcblxuICAvLyBXaGVuIHRoZSBzdHJlYW0gY2xvc2VzIHdlIHVwZGF0ZSB0aGUgY2h1bmtDb3VudFxuICB3cml0ZVN0cmVhbS5zYWZlT24oJ3N0b3JlZCcsIGZ1bmN0aW9uKHJlc3VsdCkge1xuICAgIC8vIFNhdmUga2V5IGluIHRyYWNrZXIgZG9jdW1lbnRcbiAgICB2YXIgc2V0T2JqID0ge307XG4gICAgc2V0T2JqWydrZXlzLicgKyBjaHVua051bV0gPSByZXN1bHQuZmlsZUtleTtcbiAgICB0cmFja2VyLnVwZGF0ZShzZWxlY3RvciwgeyRzZXQ6IHNldE9ian0pO1xuXG4gICAgdmFyIHRlbXAgPSB0cmFja2VyLmZpbmRPbmUoc2VsZWN0b3IpO1xuXG4gICAgaWYgKCF0ZW1wKSB7XG4gICAgICBGUy5kZWJ1ZyAmJiBjb25zb2xlLmxvZygnTk9UIEZPVU5EIEZST00gVEVNUFNUT1JFID0+IEVYSVQgKFJFTU9WRUQpJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gR2V0IHVwZGF0ZWQgY2h1bmtDb3VudFxuICAgIHZhciBjaHVua0NvdW50ID0gRlMuVXRpbGl0eS5zaXplKHRlbXAua2V5cyk7XG5cbiAgICAvLyBQcm9ncmVzc1xuICAgIHNlbGYuZW1pdCgncHJvZ3Jlc3MnLCBmaWxlT2JqLCBjaHVua051bSwgY2h1bmtDb3VudCwgY2h1bmtTdW0sIHJlc3VsdCk7XG5cbiAgICB2YXIgbW9kaWZpZXIgPSB7ICRzZXQ6IHt9IH07XG4gICAgaWYgKCFmaWxlT2JqLmluc3RhbmNlX2lkKSB7XG4gICAgICBtb2RpZmllci4kc2V0Lmluc3RhbmNlX2lkID0gcHJvY2Vzcy5lbnYuQ09MTEVDVElPTkZTX0VOVl9OQU1FX1VOSVFVRV9JRCA/IHByb2Nlc3MuZW52W3Byb2Nlc3MuZW52LkNPTExFQ1RJT05GU19FTlZfTkFNRV9VTklRVUVfSURdIDogcHJvY2Vzcy5lbnYuTUVURU9SX1BBUkVOVF9QSUQ7XG4gICAgfVxuXG4gICAgLy8gSWYgdXBsb2FkIGlzIGNvbXBsZXRlZFxuICAgIGlmIChjaHVua0NvdW50ID09PSBjaHVua1N1bSkge1xuICAgICAgLy8gV2Ugbm8gbG9uZ2VyIG5lZWQgdGhlIGNodW5rIGluZm9cbiAgICAgIG1vZGlmaWVyLiR1bnNldCA9IHtjaHVua0NvdW50OiAxLCBjaHVua1N1bTogMSwgY2h1bmtTaXplOiAxfTtcblxuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGZpbGUgaGFzIGJlZW4gdXBsb2FkZWQgYmVmb3JlXG4gICAgICBpZiAodHlwZW9mIGZpbGVPYmoudXBsb2FkZWRBdCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgLy8gV2Ugc2V0IHRoZSB1cGxvYWRlZEF0IGRhdGVcbiAgICAgICAgbW9kaWZpZXIuJHNldC51cGxvYWRlZEF0ID0gbmV3IERhdGUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFdlIGhhdmUgYmVlbiB1cGxvYWRlZCBzbyBhbiBldmVudCB3ZXJlIGZpbGUgZGF0YSBpcyB1cGRhdGVkIGlzXG4gICAgICAgIC8vIGNhbGxlZCBzeW5jaHJvbml6aW5nIC0gc28gdGhpcyBtdXN0IGJlIGEgc3luY2hyb25pemVkQXQ/XG4gICAgICAgIG1vZGlmaWVyLiRzZXQuc3luY2hyb25pemVkQXQgPSBuZXcgRGF0ZSgpO1xuICAgICAgfVxuXG4gICAgICAvLyBVcGRhdGUgdGhlIGZpbGVPYmplY3RcbiAgICAgIGZpbGVPYmoudXBkYXRlKG1vZGlmaWVyKTtcblxuICAgICAgLy8gRmlyZSBlbmRpbmcgZXZlbnRzXG4gICAgICB2YXIgZXZlbnROYW1lID0gaXNTdG9yZVN5bmMgPyAnc3luY2hyb25pemVkJyA6ICdzdG9yZWQnO1xuICAgICAgc2VsZi5lbWl0KGV2ZW50TmFtZSwgZmlsZU9iaiwgcmVzdWx0KTtcblxuICAgICAgLy8gWFhYIGlzIGVtaXR0aW5nIFwicmVhZHlcIiBuZWNlc3Nhcnk/XG4gICAgICBzZWxmLmVtaXQoJ3JlYWR5JywgZmlsZU9iaiwgY2h1bmtDb3VudCwgcmVzdWx0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVXBkYXRlIHRoZSBjaHVua0NvdW50IG9uIHRoZSBmaWxlT2JqZWN0XG4gICAgICBtb2RpZmllci4kc2V0LmNodW5rQ291bnQgPSBjaHVua0NvdW50O1xuICAgICAgZmlsZU9iai51cGRhdGUobW9kaWZpZXIpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gRW1pdCBlcnJvcnNcbiAgd3JpdGVTdHJlYW0ub24oJ2Vycm9yJywgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgRlMuZGVidWcgJiYgY29uc29sZS5sb2coJ1RlbXBTdG9yZSB3cml0ZVN0cmVhbSBlcnJvcjonLCBlcnJvcik7XG4gICAgc2VsZi5lbWl0KCdlcnJvcicsIGVycm9yLCBmaWxlT2JqKTtcbiAgfSk7XG5cbiAgcmV0dXJuIHdyaXRlU3RyZWFtO1xufTtcblxuLyoqXG4gICogQG1ldGhvZCBGUy5UZW1wU3RvcmUuY3JlYXRlUmVhZFN0cmVhbVxuICAqIEBwdWJsaWNcbiAgKiBAcGFyYW0ge0ZTLkZpbGV9IGZpbGVPYmogVGhlIGZpbGUgdG8gcmVhZFxuICAqIEByZXR1cm4ge1N0cmVhbX0gUmV0dXJucyByZWFkYWJsZSBzdHJlYW1cbiAgKlxuICAqL1xuRlMuVGVtcFN0b3JlLmNyZWF0ZVJlYWRTdHJlYW0gPSBmdW5jdGlvbihmaWxlT2JqKSB7XG4gIC8vIEVuc3VyZSB0aGF0IHdlIGhhdmUgYSBzdG9yYWdlIGFkYXB0ZXIgbW91bnRlZDsgaWYgbm90LCB0aHJvdyBhbiBlcnJvci5cbiAgbW91bnRTdG9yYWdlKCk7XG5cbiAgLy8gSWYgZmlsZU9iaiBpcyBub3QgbW91bnRlZCBvciBjYW4ndCBiZSwgdGhyb3cgYW4gZXJyb3JcbiAgbW91bnRGaWxlKGZpbGVPYmosICdGUy5UZW1wU3RvcmUuY3JlYXRlUmVhZFN0cmVhbScpO1xuXG4gIEZTLmRlYnVnICYmIGNvbnNvbGUubG9nKCdGUy5UZW1wU3RvcmUgY3JlYXRpbmcgcmVhZCBzdHJlYW0gZm9yICcgKyBmaWxlT2JqLl9pZCk7XG5cbiAgLy8gRGV0ZXJtaW5lIGhvdyBtYW55IHRvdGFsIGNodW5rcyB0aGVyZSBhcmUgZnJvbSB0aGUgdHJhY2tlciBjb2xsZWN0aW9uXG4gIHZhciBjaHVua0luZm8gPSB0cmFja2VyLmZpbmRPbmUoe2ZpbGVJZDogZmlsZU9iai5faWQsIGNvbGxlY3Rpb25OYW1lOiBmaWxlT2JqLmNvbGxlY3Rpb25OYW1lfSkgfHwge307XG4gIHZhciB0b3RhbENodW5rcyA9IEZTLlV0aWxpdHkuc2l6ZShjaHVua0luZm8ua2V5cyk7XG5cbiAgZnVuY3Rpb24gZ2V0TmV4dFN0cmVhbUZ1bmMoY2h1bmspIHtcbiAgICByZXR1cm4gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChmdW5jdGlvbihuZXh0KSB7XG4gICAgICB2YXIgZmlsZUtleSA9IF9maWxlUmVmZXJlbmNlKGZpbGVPYmosIGNodW5rKTtcbiAgICAgIHZhciBjaHVua1JlYWRTdHJlYW0gPSBGUy5UZW1wU3RvcmUuU3RvcmFnZS5hZGFwdGVyLmNyZWF0ZVJlYWRTdHJlYW0oZmlsZUtleSk7XG4gICAgICBuZXh0KGNodW5rUmVhZFN0cmVhbSk7XG4gICAgfSwgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIE1ha2UgYSBjb21iaW5lZCBzdHJlYW1cbiAgdmFyIGNvbWJpbmVkU3RyZWFtID0gQ29tYmluZWRTdHJlYW0uY3JlYXRlKCk7XG5cbiAgLy8gQWRkIGVhY2ggY2h1bmsgc3RyZWFtIHRvIHRoZSBjb21iaW5lZCBzdHJlYW0gd2hlbiB0aGUgcHJldmlvdXMgY2h1bmsgc3RyZWFtIGVuZHNcbiAgdmFyIGN1cnJlbnRDaHVuayA9IDA7XG4gIGZvciAodmFyIGNodW5rID0gMDsgY2h1bmsgPCB0b3RhbENodW5rczsgY2h1bmsrKykge1xuICAgIGNvbWJpbmVkU3RyZWFtLmFwcGVuZChnZXROZXh0U3RyZWFtRnVuYyhjaHVuaykpO1xuICB9XG5cbiAgLy8gUmV0dXJuIHRoZSBjb21iaW5lZCBzdHJlYW1cbiAgcmV0dXJuIGNvbWJpbmVkU3RyZWFtO1xufTtcbiJdfQ==
