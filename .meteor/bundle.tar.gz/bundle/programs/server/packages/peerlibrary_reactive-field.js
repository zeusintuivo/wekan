(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var storePrevious, equalsFunc, ReactiveField;

var require = meteorInstall({"node_modules":{"meteor":{"peerlibrary:reactive-field":{"lib.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/peerlibrary_reactive-field/lib.js                                                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  ReactiveField: () => ReactiveField
});

class ReactiveField {
  constructor(initialValue, equalsFunc, storePrevious) {
    // To allow not passing equalsFunc, but just storePrevious.
    if (!_.isFunction(equalsFunc) && arguments.length === 2) {
      storePrevious = equalsFunc;
      equalsFunc = null;
    }

    let previousValue = undefined;
    const value = new ReactiveVar(initialValue, equalsFunc);

    const getterSetter = function (newValue) {
      if (arguments.length > 0) {
        if (storePrevious) {
          Tracker.nonreactive(() => {
            const oldValue = value.get(); // Only if the new value is different than currently stored value, we update the previous value.

            if (!(equalsFunc || ReactiveVar._isEqual)(oldValue, newValue)) {
              previousValue = oldValue;
            }
          });
        }

        value.set(newValue); // We return the value as well, but we do not want to register a dependency.

        return Tracker.nonreactive(() => {
          return value.get();
        });
      }

      return value.get();
    }; // We mingle the prototype so that getterSetter instanceof ReactiveField is true.


    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(getterSetter, this.constructor.prototype);
    } else {
      getterSetter.__proto__ = this.constructor.prototype;
    }

    getterSetter.toString = function () {
      return "ReactiveField{".concat(this(), "}");
    };

    getterSetter.apply = function (obj, args) {
      if (args && args.length > 0) {
        return getterSetter(args[0]);
      } else {
        return getterSetter();
      }
    };

    getterSetter.call = function (obj, arg) {
      if (arguments.length > 1) {
        return getterSetter(arg);
      } else {
        return getterSetter();
      }
    };

    getterSetter.previous = function () {
      if (!storePrevious) {
        throw new Error("Storing previous value is not enabled.");
      }

      return previousValue;
    };

    return getterSetter;
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/peerlibrary:reactive-field/lib.js");

/* Exports */
Package._define("peerlibrary:reactive-field", exports, {
  ReactiveField: ReactiveField
});

})();

//# sourceURL=meteor://💻app/packages/peerlibrary_reactive-field.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnk6cmVhY3RpdmUtZmllbGQvbGliLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIlJlYWN0aXZlRmllbGQiLCJjb25zdHJ1Y3RvciIsImluaXRpYWxWYWx1ZSIsImVxdWFsc0Z1bmMiLCJzdG9yZVByZXZpb3VzIiwiXyIsImlzRnVuY3Rpb24iLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJwcmV2aW91c1ZhbHVlIiwidW5kZWZpbmVkIiwidmFsdWUiLCJSZWFjdGl2ZVZhciIsImdldHRlclNldHRlciIsIm5ld1ZhbHVlIiwiVHJhY2tlciIsIm5vbnJlYWN0aXZlIiwib2xkVmFsdWUiLCJnZXQiLCJfaXNFcXVhbCIsInNldCIsIk9iamVjdCIsInNldFByb3RvdHlwZU9mIiwicHJvdG90eXBlIiwiX19wcm90b19fIiwidG9TdHJpbmciLCJhcHBseSIsIm9iaiIsImFyZ3MiLCJjYWxsIiwiYXJnIiwicHJldmlvdXMiLCJFcnJvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDs7QUFBTyxNQUFNQSxhQUFOLENBQW9CO0FBQ3pCQyxhQUFXLENBQUNDLFlBQUQsRUFBZUMsVUFBZixFQUEyQkMsYUFBM0IsRUFBMEM7QUFDbkQ7QUFDQSxRQUFJLENBQUNDLENBQUMsQ0FBQ0MsVUFBRixDQUFhSCxVQUFiLENBQUQsSUFBOEJJLFNBQVMsQ0FBQ0MsTUFBVixLQUFxQixDQUF2RCxFQUEyRDtBQUN6REosbUJBQWEsR0FBR0QsVUFBaEI7QUFDQUEsZ0JBQVUsR0FBRyxJQUFiO0FBQ0Q7O0FBQ0QsUUFBSU0sYUFBYSxHQUFHQyxTQUFwQjtBQUNBLFVBQU1DLEtBQUssR0FBRyxJQUFJQyxXQUFKLENBQWdCVixZQUFoQixFQUE4QkMsVUFBOUIsQ0FBZDs7QUFFQSxVQUFNVSxZQUFZLEdBQUcsVUFBVUMsUUFBVixFQUFvQjtBQUN2QyxVQUFJUCxTQUFTLENBQUNDLE1BQVYsR0FBbUIsQ0FBdkIsRUFBMEI7QUFDeEIsWUFBSUosYUFBSixFQUFtQjtBQUNqQlcsaUJBQU8sQ0FBQ0MsV0FBUixDQUFvQixNQUFNO0FBQ3hCLGtCQUFNQyxRQUFRLEdBQUdOLEtBQUssQ0FBQ08sR0FBTixFQUFqQixDQUR3QixDQUV4Qjs7QUFDQSxnQkFBSSxDQUFDLENBQUNmLFVBQVUsSUFBSVMsV0FBVyxDQUFDTyxRQUEzQixFQUFxQ0YsUUFBckMsRUFBK0NILFFBQS9DLENBQUwsRUFBK0Q7QUFDN0RMLDJCQUFhLEdBQUdRLFFBQWhCO0FBQ0Q7QUFDRixXQU5EO0FBT0Q7O0FBRUROLGFBQUssQ0FBQ1MsR0FBTixDQUFVTixRQUFWLEVBWHdCLENBWXhCOztBQUNBLGVBQU9DLE9BQU8sQ0FBQ0MsV0FBUixDQUFvQixNQUFNO0FBQy9CLGlCQUFPTCxLQUFLLENBQUNPLEdBQU4sRUFBUDtBQUNELFNBRk0sQ0FBUDtBQUdEOztBQUVELGFBQU9QLEtBQUssQ0FBQ08sR0FBTixFQUFQO0FBQ0QsS0FwQkQsQ0FUbUQsQ0ErQm5EOzs7QUFDQSxRQUFJRyxNQUFNLENBQUNDLGNBQVgsRUFBMkI7QUFDekJELFlBQU0sQ0FBQ0MsY0FBUCxDQUFzQlQsWUFBdEIsRUFBb0MsS0FBS1osV0FBTCxDQUFpQnNCLFNBQXJEO0FBQ0QsS0FGRCxNQUdLO0FBQ0hWLGtCQUFZLENBQUNXLFNBQWIsR0FBeUIsS0FBS3ZCLFdBQUwsQ0FBaUJzQixTQUExQztBQUNEOztBQUVEVixnQkFBWSxDQUFDWSxRQUFiLEdBQXdCLFlBQVk7QUFDbEMscUNBQXdCLE1BQXhCO0FBQ0QsS0FGRDs7QUFJQVosZ0JBQVksQ0FBQ2EsS0FBYixHQUFxQixVQUFVQyxHQUFWLEVBQWVDLElBQWYsRUFBcUI7QUFDeEMsVUFBSUEsSUFBSSxJQUFJQSxJQUFJLENBQUNwQixNQUFMLEdBQWMsQ0FBMUIsRUFBNkI7QUFDM0IsZUFBT0ssWUFBWSxDQUFDZSxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQW5CO0FBQ0QsT0FGRCxNQUdLO0FBQ0gsZUFBT2YsWUFBWSxFQUFuQjtBQUNEO0FBQ0YsS0FQRDs7QUFTQUEsZ0JBQVksQ0FBQ2dCLElBQWIsR0FBb0IsVUFBVUYsR0FBVixFQUFlRyxHQUFmLEVBQW9CO0FBQ3RDLFVBQUl2QixTQUFTLENBQUNDLE1BQVYsR0FBbUIsQ0FBdkIsRUFBMEI7QUFDeEIsZUFBT0ssWUFBWSxDQUFDaUIsR0FBRCxDQUFuQjtBQUNELE9BRkQsTUFHSztBQUNILGVBQU9qQixZQUFZLEVBQW5CO0FBQ0Q7QUFDRixLQVBEOztBQVNBQSxnQkFBWSxDQUFDa0IsUUFBYixHQUF3QixZQUFXO0FBQ2pDLFVBQUksQ0FBQzNCLGFBQUwsRUFBb0I7QUFDbEIsY0FBTSxJQUFJNEIsS0FBSixDQUFVLHdDQUFWLENBQU47QUFDRDs7QUFDRCxhQUFPdkIsYUFBUDtBQUNELEtBTEQ7O0FBT0EsV0FBT0ksWUFBUDtBQUNEOztBQXRFd0IsQyIsImZpbGUiOiIvcGFja2FnZXMvcGVlcmxpYnJhcnlfcmVhY3RpdmUtZmllbGQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgUmVhY3RpdmVGaWVsZCB7XG4gIGNvbnN0cnVjdG9yKGluaXRpYWxWYWx1ZSwgZXF1YWxzRnVuYywgc3RvcmVQcmV2aW91cykge1xuICAgIC8vIFRvIGFsbG93IG5vdCBwYXNzaW5nIGVxdWFsc0Z1bmMsIGJ1dCBqdXN0IHN0b3JlUHJldmlvdXMuXG4gICAgaWYgKCFfLmlzRnVuY3Rpb24oZXF1YWxzRnVuYykgJiYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDIpKSB7XG4gICAgICBzdG9yZVByZXZpb3VzID0gZXF1YWxzRnVuYztcbiAgICAgIGVxdWFsc0Z1bmMgPSBudWxsO1xuICAgIH1cbiAgICBsZXQgcHJldmlvdXNWYWx1ZSA9IHVuZGVmaW5lZDtcbiAgICBjb25zdCB2YWx1ZSA9IG5ldyBSZWFjdGl2ZVZhcihpbml0aWFsVmFsdWUsIGVxdWFsc0Z1bmMpO1xuXG4gICAgY29uc3QgZ2V0dGVyU2V0dGVyID0gZnVuY3Rpb24gKG5ld1ZhbHVlKSB7XG4gICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgaWYgKHN0b3JlUHJldmlvdXMpIHtcbiAgICAgICAgICBUcmFja2VyLm5vbnJlYWN0aXZlKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG9sZFZhbHVlID0gdmFsdWUuZ2V0KCk7XG4gICAgICAgICAgICAvLyBPbmx5IGlmIHRoZSBuZXcgdmFsdWUgaXMgZGlmZmVyZW50IHRoYW4gY3VycmVudGx5IHN0b3JlZCB2YWx1ZSwgd2UgdXBkYXRlIHRoZSBwcmV2aW91cyB2YWx1ZS5cbiAgICAgICAgICAgIGlmICghKGVxdWFsc0Z1bmMgfHwgUmVhY3RpdmVWYXIuX2lzRXF1YWwpKG9sZFZhbHVlLCBuZXdWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgcHJldmlvdXNWYWx1ZSA9IG9sZFZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFsdWUuc2V0KG5ld1ZhbHVlKTtcbiAgICAgICAgLy8gV2UgcmV0dXJuIHRoZSB2YWx1ZSBhcyB3ZWxsLCBidXQgd2UgZG8gbm90IHdhbnQgdG8gcmVnaXN0ZXIgYSBkZXBlbmRlbmN5LlxuICAgICAgICByZXR1cm4gVHJhY2tlci5ub25yZWFjdGl2ZSgoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlLmdldCgpO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHZhbHVlLmdldCgpO1xuICAgIH07XG5cbiAgICAvLyBXZSBtaW5nbGUgdGhlIHByb3RvdHlwZSBzbyB0aGF0IGdldHRlclNldHRlciBpbnN0YW5jZW9mIFJlYWN0aXZlRmllbGQgaXMgdHJ1ZS5cbiAgICBpZiAoT2JqZWN0LnNldFByb3RvdHlwZU9mKSB7XG4gICAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YoZ2V0dGVyU2V0dGVyLCB0aGlzLmNvbnN0cnVjdG9yLnByb3RvdHlwZSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ2V0dGVyU2V0dGVyLl9fcHJvdG9fXyA9IHRoaXMuY29uc3RydWN0b3IucHJvdG90eXBlO1xuICAgIH1cblxuICAgIGdldHRlclNldHRlci50b1N0cmluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBgUmVhY3RpdmVGaWVsZHske3RoaXMoKX19YDtcbiAgICB9O1xuXG4gICAgZ2V0dGVyU2V0dGVyLmFwcGx5ID0gZnVuY3Rpb24gKG9iaiwgYXJncykge1xuICAgICAgaWYgKGFyZ3MgJiYgYXJncy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiBnZXR0ZXJTZXR0ZXIoYXJnc1swXSk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGdldHRlclNldHRlcigpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBnZXR0ZXJTZXR0ZXIuY2FsbCA9IGZ1bmN0aW9uIChvYmosIGFyZykge1xuICAgICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICAgIHJldHVybiBnZXR0ZXJTZXR0ZXIoYXJnKTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gZ2V0dGVyU2V0dGVyKCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGdldHRlclNldHRlci5wcmV2aW91cyA9IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKCFzdG9yZVByZXZpb3VzKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlN0b3JpbmcgcHJldmlvdXMgdmFsdWUgaXMgbm90IGVuYWJsZWQuXCIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHByZXZpb3VzVmFsdWU7XG4gICAgfTtcblxuICAgIHJldHVybiBnZXR0ZXJTZXR0ZXI7XG4gIH1cbn1cbiJdfQ==
