(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var InjectData = Package['staringatlights:inject-data'].InjectData;
var Picker = Package['meteorhacks:picker'].Picker;
var MeteorX = Package['lamhieu:meteorx'].MeteorX;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var EJSON = Package.ejson.EJSON;
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var Accounts = Package['accounts-base'].Accounts;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"staringatlights:fast-render":{"lib":{"server":{"namespace.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/staringatlights_fast-render/lib/server/namespace.js                                                 //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({
  FastRender: () => FastRender
});
const FastRender = {
  _routes: [],
  _onAllRoutes: []
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/staringatlights_fast-render/lib/server/utils.js                                                     //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({
  IsAppUrl: () => IsAppUrl
});
let RoutePolicy;
module.link("meteor/routepolicy", {
  RoutePolicy(v) {
    RoutePolicy = v;
  }

}, 0);

const IsAppUrl = function (req) {
  var url = req.url;

  if (url === '/favicon.ico' || url === '/robots.txt') {
    return false;
  } // NOTE: app.manifest is not a web standard like favicon.ico and
  // robots.txt. It is a file name we have chosen to use for HTML5
  // appcache URLs. It is included here to prevent using an appcache
  // then removing it from poisoning an app permanently. Eventually,
  // once we have server side routing, this won't be needed as
  // unknown URLs with return a 404 automatically.


  if (url === '/app.manifest') {
    return false;
  } // Avoid serving app HTML for declared routes such as /sockjs/.


  if (RoutePolicy.classify(url)) {
    return false;
  } // we only need to support HTML pages only
  // this is a check to do it


  return /html/.test(req.headers['accept']);
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/staringatlights_fast-render/lib/server/routes.js                                                    //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Fiber;
module.link("fibers", {
  default(v) {
    Fiber = v;
  }

}, 0);
let FastRender;
module.link("./namespace", {
  FastRender(v) {
    FastRender = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let Picker;
module.link("meteor/meteorhacks:picker", {
  Picker(v) {
    Picker = v;
  }

}, 3);
let InjectData;
module.link("meteor/staringatlights:inject-data", {
  InjectData(v) {
    InjectData = v;
  }

}, 4);
let PublishContext;
module.link("./publish_context", {
  default(v) {
    PublishContext = v;
  }

}, 5);
let IsAppUrl;
module.link("./utils", {
  IsAppUrl(v) {
    IsAppUrl = v;
  }

}, 6);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 7);
let cookieParser;
module.link("cookie-parser", {
  default(v) {
    cookieParser = v;
  }

}, 8);
FastRender._onAllRoutes = [];
FastRender.frContext = new Meteor.EnvironmentVariable();
var fastRenderRoutes = Picker.filter(function (req, res) {
  return IsAppUrl(req);
});
fastRenderRoutes.middleware(cookieParser());
fastRenderRoutes.middleware(function (req, res, next) {
  FastRender.handleOnAllRoutes(req, res, next);
}); // handling specific routes

FastRender.route = function route(path, callback) {
  if (path.indexOf('/') !== 0) {
    throw new Error('Error: path (' + path + ') must begin with a leading slash "/"');
  }

  fastRenderRoutes.route(path, FastRender.handleRoute.bind(null, callback));
};

function setQueryDataCallback(req, next) {
  return function (queryData) {
    if (!queryData) return next();
    var existingPayload = InjectData.getData(req, 'fast-render-data');

    if (!existingPayload) {
      InjectData.pushData(req, 'fast-render-data', queryData);
    } else {
      // it's possible to execute this callback twice
      // the we need to merge exisitng data with the new one
      _.extend(existingPayload.subscriptions, queryData.subscriptions);

      _.each(queryData.collectionData, function (data, pubName) {
        var existingData = existingPayload.collectionData[pubName];

        if (existingData) {
          data = existingData.concat(data);
        }

        existingPayload.collectionData[pubName] = data;
        InjectData.pushData(req, 'fast-render-data', existingPayload);
      });
    }

    next();
  };
}

FastRender.handleRoute = function (processingCallback, params, req, res, next) {
  var afterProcessed = setQueryDataCallback(req, next);

  FastRender._processRoutes(params, req, processingCallback, afterProcessed);
};

FastRender.handleOnAllRoutes = function (req, res, next) {
  var afterProcessed = setQueryDataCallback(req, next);

  FastRender._processAllRoutes(req, afterProcessed);
};

FastRender.onAllRoutes = function onAllRoutes(callback) {
  FastRender._onAllRoutes.push(callback);
};

FastRender._processRoutes = function _processRoutes(params, req, routeCallback, callback) {
  callback = callback || function () {};

  var path = req.url;
  var loginToken = req.cookies['meteor_login_token'];
  var headers = req.headers;
  var context = new FastRender._Context(loginToken, {
    headers: headers
  });

  try {
    FastRender.frContext.withValue(context, function () {
      routeCallback.call(context, params, path);
    });

    if (context.stop) {
      return;
    }

    callback(context.getData());
  } catch (err) {
    handleError(err, path, callback);
  }
};

FastRender._processAllRoutes = function _processAllRoutes(req, callback) {
  callback = callback || function () {};

  var path = req.url;
  var loginToken = req.cookies['meteor_login_token'];
  var headers = req.headers;
  new Fiber(function () {
    var context = new FastRender._Context(loginToken, {
      headers: headers
    });

    try {
      FastRender._onAllRoutes.forEach(function (callback) {
        callback.call(context, req.url);
      });

      callback(context.getData());
    } catch (err) {
      handleError(err, path, callback);
    }
  }).run();
};

function handleError(err, path, callback) {
  var message = 'error on fast-rendering path: ' + path + ' ; error: ' + err.stack;
  console.error(message);
  callback(null);
} // adding support for null publications


FastRender.onAllRoutes(function () {
  var context = this;
  var nullHandlers = Meteor.default_server.universal_publish_handlers;

  if (nullHandlers) {
    nullHandlers.forEach(function (publishHandler) {
      // universal subs have subscription ID, params, and name undefined
      var publishContext = new PublishContext(context, publishHandler);
      context.processPublication(publishContext);
    });
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish_context.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/staringatlights_fast-render/lib/server/publish_context.js                                           //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 0);
let EJSON;
module.link("meteor/ejson", {
  EJSON(v) {
    EJSON = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 3);
let MeteorX;
module.link("meteor/lamhieu:meteorx", {
  MeteorX(v) {
    MeteorX = v;
  }

}, 4);

const PublishContext = function PublishContext(context, handler, subscriptionId, params, name) {
  var self = this; // mock session

  var sessionId = Random.id();
  var session = {
    id: sessionId,
    userId: context.userId,
    // not null
    inQueue: {},
    connectionHandle: {
      id: sessionId,
      close: function () {},
      onClose: function () {},
      clientAddress: '127.0.0.1',
      httpHeaders: context.headers
    },
    added: function (subscriptionHandle, collectionName, strId, fields) {
      // Don't share state with the data passed in by the user.
      var doc = EJSON.clone(fields);
      doc._id = self._idFilter.idParse(strId);
      Meteor._ensure(self._collectionData, collectionName)[strId] = doc;
    },
    changed: function (subscriptionHandle, collectionName, strId, fields) {
      var doc = self._collectionData[collectionName][strId];

      if (!doc) {
        throw new Error('Could not find element with id ' + strId + ' to change');
      }

      _.each(fields, function (value, key) {
        // Publish API ignores _id if present in fields.
        if (key === '_id') return;

        if (value === undefined) {
          delete doc[key];
        } else {
          // Don't share state with the data passed in by the user.
          doc[key] = EJSON.clone(value);
        }
      });
    },
    removed: function (subscriptionHandle, collectionName, strId) {
      if (!(self._collectionData[collectionName] && self._collectionData[collectionName][strId])) {
        throw new Error('Removed nonexistent document ' + strId);
      }

      delete self._collectionData[collectionName][strId];
    },
    sendReady: function (subscriptionIds) {
      // this is called only for non-universal subscriptions
      if (!self._subscriptionId) throw new Error('Assertion.'); // make the subscription be marked as ready

      if (!self._isDeactivated()) {
        self._context.completeSubscriptions(self._name, self._params);
      } // we just stop it


      self.stop();
    }
  };
  MeteorX.Subscription.call(self, session, handler, subscriptionId, params, name);

  self.unblock = function () {};

  self._context = context;
  self._collectionData = {};
};

PublishContext.prototype = Object.create(MeteorX.Subscription.prototype);
PublishContext.prototype.constructor = PublishContext;

PublishContext.prototype.stop = function () {
  // our stop does not remove all documents (it just calls deactivate)
  // Meteor one removes documents for non-universal subscription
  // we deactivate both for universal and named subscriptions
  // hopefully this is right in our case
  // Meteor does it just for named subscriptions
  this._deactivate();
};

PublishContext.prototype.error = function (error) {
  // TODO: Should we pass the error to the subscription somehow?
  console.warn('error caught on publication: ', this._name, ': ', error.message || error);
  this.stop();
};

module.exportDefault(PublishContext);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"context.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/staringatlights_fast-render/lib/server/context.js                                                   //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Fibers;
module.link("fibers", {
  default(v) {
    Fibers = v;
  }

}, 1);
let Future;
module.link("fibers/future", {
  default(v) {
    Future = v;
  }

}, 2);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 3);
let DDP;
module.link("meteor/ddp", {
  DDP(v) {
    DDP = v;
  }

}, 4);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 5);
let PublishContext;
module.link("./publish_context", {
  default(v) {
    PublishContext = v;
  }

}, 6);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 7);
let EJSON;
module.link("meteor/ejson", {
  EJSON(v) {
    EJSON = v;
  }

}, 8);
let FastRender;
module.link("./namespace", {
  FastRender(v) {
    FastRender = v;
  }

}, 9);

const Context = function Context(loginToken, otherParams) {
  this._collectionData = {};
  this._subscriptions = {};
  this._loginToken = loginToken;

  _.extend(this, otherParams); // get the user


  if (Meteor.users) {
    // check to make sure, we've the loginToken,
    // otherwise a random user will fetched from the db
    if (loginToken) {
      var hashedToken = loginToken && Accounts._hashLoginToken(loginToken);

      var query = {
        'services.resume.loginTokens.hashedToken': hashedToken
      };
      var options = {
        fields: {
          _id: 1
        }
      };
      var user = Meteor.users.findOne(query, options);
    } // support for Meteor.user


    Fibers.current._meteor_dynamics = [];
    Fibers.current._meteor_dynamics[DDP._CurrentInvocation.slot] = this;

    if (user) {
      this.userId = user._id;
    }
  }
};

Context.prototype.subscribe = function (subName
/*, params */
) {
  var publishHandler = Meteor.default_server.publish_handlers[subName];

  if (publishHandler) {
    var params = Array.prototype.slice.call(arguments, 1); // non-universal subs have subscription id

    var subscriptionId = Random.id();
    var publishContext = new PublishContext(this, publishHandler, subscriptionId, params, subName);
    return this.processPublication(publishContext);
  } else {
    console.warn('There is no such publish handler named:', subName);
    return {};
  }
};

Context.prototype.processPublication = function (publishContext) {
  var self = this;
  var data = {};

  var ensureCollection = function (collectionName) {
    self._ensureCollection(collectionName);

    if (!data[collectionName]) {
      data[collectionName] = [];
    }
  };

  var future = new Future(); // detect when the context is ready to be sent to the client

  publishContext.onStop(function () {
    if (!future.isResolved()) {
      future.return();
    }
  });

  publishContext._runHandler();

  if (!publishContext._subscriptionId) {
    // universal subscription, we stop it (same as marking it as ready) ourselves
    // they otherwise do not have ready or stopped state, but in our case they do
    publishContext.stop();
  }

  if (!future.isResolved()) {
    // don't wait forever for handler to fire ready()
    Meteor.setTimeout(function () {
      if (!future.isResolved()) {
        // publish handler failed to send ready signal in time
        // maybe your non-universal publish handler is not calling this.ready()?
        // or maybe it is returning null to signal empty publish?
        // it should still call this.ready() or return an empty array []
        var message = 'Publish handler for ' + publishContext._name + ' sent no ready signal\n' + ' This could be because this publication `return null`.\n' + ' Use `return this.ready()` instead.';
        console.warn(message);
        future.return();
      }
    }, 500); // arbitrarially set timeout to 500ms, should probably be configurable
    //  wait for the subscription became ready.

    future.wait();
  } // stop any runaway subscription
  // this can happen if a publish handler never calls ready or stop, for example
  // it does not hurt to call it multiple times


  publishContext.stop(); // get the data

  _.each(publishContext._collectionData, function (collData, collectionName) {
    // making an array from a map
    collData = _.values(collData);
    ensureCollection(collectionName);
    data[collectionName].push(collData); // copy the collection data in publish context into the FR context

    self._collectionData[collectionName].push(collData);
  });

  return data;
};

Context.prototype.completeSubscriptions = function (name, params) {
  var subs = this._subscriptions[name];

  if (!subs) {
    subs = this._subscriptions[name] = {};
  }

  if (params && params.length) {
    var lastParam = params[params.length - 1];

    if (lastParam && (lastParam.hasOwnProperty('onStop') || lastParam.hasOwnProperty('onReady'))) {
      params.pop();
    }
  }

  subs[EJSON.stringify(params)] = true;
};

Context.prototype._ensureCollection = function (collectionName) {
  if (!this._collectionData[collectionName]) {
    this._collectionData[collectionName] = [];
  }
};

Context.prototype.getData = function () {
  return {
    collectionData: this._collectionData,
    subscriptions: this._subscriptions,
    loginToken: this._loginToken
  };
};

FastRender._Context = Context;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ssr_helper.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/staringatlights_fast-render/lib/server/ssr_helper.js                                                //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let FastRender;
module.link("meteor/staringatlights:fast-render", {
  FastRender(v) {
    FastRender = v;
  }

}, 1);
let InjectData;
module.link("meteor/staringatlights:inject-data", {
  InjectData(v) {
    InjectData = v;
  }

}, 2);
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 3);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 4);
const originalSubscribe = Meteor.subscribe;

Meteor.subscribe = function (name) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }

  const frContext = FastRender.frContext.get();

  if (!frContext) {
    throw new Error("Cannot add a subscription: ".concat(name, " without FastRender Context"));
  }

  frContext.subscribe(name, ...args);

  if (originalSubscribe) {
    originalSubscribe.apply(this, arguments);
  }

  return {
    ready: () => true
  };
};

FastRender._mergeFrData = function (req, queryData) {
  var existingPayload = InjectData.getData(req, 'fast-render-data');

  if (!existingPayload) {
    InjectData.pushData(req, 'fast-render-data', queryData);
  } else {
    // it's possible to execute this callback twice
    // the we need to merge exisitng data with the new one
    _.extend(existingPayload.subscriptions, queryData.subscriptions);

    _.each(queryData.collectionData, function (data, pubName) {
      var existingData = existingPayload.collectionData[pubName];

      if (existingData) {
        data = existingData.concat(data);
      }

      existingPayload.collectionData[pubName] = data;
      InjectData.pushData(req, 'fast-render-data', existingPayload);
    });
  }
};

FastRender.onPageLoad = function (callback) {
  InjectData.injectToHead = false;
  onPageLoad(sink => Promise.asyncApply(() => {
    const frContext = new FastRender._Context(sink.request.cookies.meteor_login_token, {
      headers: sink.headers
    });
    Promise.await(FastRender.frContext.withValue(frContext, function () {
      return Promise.asyncApply(() => {
        Promise.await(callback(sink));

        FastRender._mergeFrData(sink.request, FastRender.frContext.get().getData());
      });
    }));
  }));
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"node_modules":{"cookie-parser":{"package.json":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// node_modules/meteor/staringatlights_fast-render/node_modules/cookie-parser/package.json                      //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.exports = {
  "name": "cookie-parser",
  "version": "1.4.4"
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// node_modules/meteor/staringatlights_fast-render/node_modules/cookie-parser/index.js                          //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/staringatlights:fast-render/lib/server/namespace.js");
require("/node_modules/meteor/staringatlights:fast-render/lib/server/utils.js");
require("/node_modules/meteor/staringatlights:fast-render/lib/server/routes.js");
require("/node_modules/meteor/staringatlights:fast-render/lib/server/publish_context.js");
require("/node_modules/meteor/staringatlights:fast-render/lib/server/context.js");
require("/node_modules/meteor/staringatlights:fast-render/lib/server/ssr_helper.js");

/* Exports */
Package._define("staringatlights:fast-render", exports);

})();

//# sourceURL=meteor://💻app/packages/staringatlights_fast-render.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvc3RhcmluZ2F0bGlnaHRzOmZhc3QtcmVuZGVyL2xpYi9zZXJ2ZXIvbmFtZXNwYWNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9zdGFyaW5nYXRsaWdodHM6ZmFzdC1yZW5kZXIvbGliL3NlcnZlci91dGlscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvc3RhcmluZ2F0bGlnaHRzOmZhc3QtcmVuZGVyL2xpYi9zZXJ2ZXIvcm91dGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9zdGFyaW5nYXRsaWdodHM6ZmFzdC1yZW5kZXIvbGliL3NlcnZlci9wdWJsaXNoX2NvbnRleHQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3N0YXJpbmdhdGxpZ2h0czpmYXN0LXJlbmRlci9saWIvc2VydmVyL2NvbnRleHQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3N0YXJpbmdhdGxpZ2h0czpmYXN0LXJlbmRlci9saWIvc2VydmVyL3Nzcl9oZWxwZXIuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRmFzdFJlbmRlciIsIl9yb3V0ZXMiLCJfb25BbGxSb3V0ZXMiLCJJc0FwcFVybCIsIlJvdXRlUG9saWN5IiwibGluayIsInYiLCJyZXEiLCJ1cmwiLCJjbGFzc2lmeSIsInRlc3QiLCJoZWFkZXJzIiwiRmliZXIiLCJkZWZhdWx0IiwiTWV0ZW9yIiwiUGlja2VyIiwiSW5qZWN0RGF0YSIsIlB1Ymxpc2hDb250ZXh0IiwiXyIsImNvb2tpZVBhcnNlciIsImZyQ29udGV4dCIsIkVudmlyb25tZW50VmFyaWFibGUiLCJmYXN0UmVuZGVyUm91dGVzIiwiZmlsdGVyIiwicmVzIiwibWlkZGxld2FyZSIsIm5leHQiLCJoYW5kbGVPbkFsbFJvdXRlcyIsInJvdXRlIiwicGF0aCIsImNhbGxiYWNrIiwiaW5kZXhPZiIsIkVycm9yIiwiaGFuZGxlUm91dGUiLCJiaW5kIiwic2V0UXVlcnlEYXRhQ2FsbGJhY2siLCJxdWVyeURhdGEiLCJleGlzdGluZ1BheWxvYWQiLCJnZXREYXRhIiwicHVzaERhdGEiLCJleHRlbmQiLCJzdWJzY3JpcHRpb25zIiwiZWFjaCIsImNvbGxlY3Rpb25EYXRhIiwiZGF0YSIsInB1Yk5hbWUiLCJleGlzdGluZ0RhdGEiLCJjb25jYXQiLCJwcm9jZXNzaW5nQ2FsbGJhY2siLCJwYXJhbXMiLCJhZnRlclByb2Nlc3NlZCIsIl9wcm9jZXNzUm91dGVzIiwiX3Byb2Nlc3NBbGxSb3V0ZXMiLCJvbkFsbFJvdXRlcyIsInB1c2giLCJyb3V0ZUNhbGxiYWNrIiwibG9naW5Ub2tlbiIsImNvb2tpZXMiLCJjb250ZXh0IiwiX0NvbnRleHQiLCJ3aXRoVmFsdWUiLCJjYWxsIiwic3RvcCIsImVyciIsImhhbmRsZUVycm9yIiwiZm9yRWFjaCIsInJ1biIsIm1lc3NhZ2UiLCJzdGFjayIsImNvbnNvbGUiLCJlcnJvciIsIm51bGxIYW5kbGVycyIsImRlZmF1bHRfc2VydmVyIiwidW5pdmVyc2FsX3B1Ymxpc2hfaGFuZGxlcnMiLCJwdWJsaXNoSGFuZGxlciIsInB1Ymxpc2hDb250ZXh0IiwicHJvY2Vzc1B1YmxpY2F0aW9uIiwiUmFuZG9tIiwiRUpTT04iLCJNZXRlb3JYIiwiaGFuZGxlciIsInN1YnNjcmlwdGlvbklkIiwibmFtZSIsInNlbGYiLCJzZXNzaW9uSWQiLCJpZCIsInNlc3Npb24iLCJ1c2VySWQiLCJpblF1ZXVlIiwiY29ubmVjdGlvbkhhbmRsZSIsImNsb3NlIiwib25DbG9zZSIsImNsaWVudEFkZHJlc3MiLCJodHRwSGVhZGVycyIsImFkZGVkIiwic3Vic2NyaXB0aW9uSGFuZGxlIiwiY29sbGVjdGlvbk5hbWUiLCJzdHJJZCIsImZpZWxkcyIsImRvYyIsImNsb25lIiwiX2lkIiwiX2lkRmlsdGVyIiwiaWRQYXJzZSIsIl9lbnN1cmUiLCJfY29sbGVjdGlvbkRhdGEiLCJjaGFuZ2VkIiwidmFsdWUiLCJrZXkiLCJ1bmRlZmluZWQiLCJyZW1vdmVkIiwic2VuZFJlYWR5Iiwic3Vic2NyaXB0aW9uSWRzIiwiX3N1YnNjcmlwdGlvbklkIiwiX2lzRGVhY3RpdmF0ZWQiLCJfY29udGV4dCIsImNvbXBsZXRlU3Vic2NyaXB0aW9ucyIsIl9uYW1lIiwiX3BhcmFtcyIsIlN1YnNjcmlwdGlvbiIsInVuYmxvY2siLCJwcm90b3R5cGUiLCJPYmplY3QiLCJjcmVhdGUiLCJjb25zdHJ1Y3RvciIsIl9kZWFjdGl2YXRlIiwid2FybiIsImV4cG9ydERlZmF1bHQiLCJGaWJlcnMiLCJGdXR1cmUiLCJBY2NvdW50cyIsIkREUCIsIkNvbnRleHQiLCJvdGhlclBhcmFtcyIsIl9zdWJzY3JpcHRpb25zIiwiX2xvZ2luVG9rZW4iLCJ1c2VycyIsImhhc2hlZFRva2VuIiwiX2hhc2hMb2dpblRva2VuIiwicXVlcnkiLCJvcHRpb25zIiwidXNlciIsImZpbmRPbmUiLCJjdXJyZW50IiwiX21ldGVvcl9keW5hbWljcyIsIl9DdXJyZW50SW52b2NhdGlvbiIsInNsb3QiLCJzdWJzY3JpYmUiLCJzdWJOYW1lIiwicHVibGlzaF9oYW5kbGVycyIsIkFycmF5Iiwic2xpY2UiLCJhcmd1bWVudHMiLCJlbnN1cmVDb2xsZWN0aW9uIiwiX2Vuc3VyZUNvbGxlY3Rpb24iLCJmdXR1cmUiLCJvblN0b3AiLCJpc1Jlc29sdmVkIiwicmV0dXJuIiwiX3J1bkhhbmRsZXIiLCJzZXRUaW1lb3V0Iiwid2FpdCIsImNvbGxEYXRhIiwidmFsdWVzIiwic3VicyIsImxlbmd0aCIsImxhc3RQYXJhbSIsImhhc093blByb3BlcnR5IiwicG9wIiwic3RyaW5naWZ5Iiwib25QYWdlTG9hZCIsIm9yaWdpbmFsU3Vic2NyaWJlIiwiYXJncyIsImdldCIsImFwcGx5IiwicmVhZHkiLCJfbWVyZ2VGckRhdGEiLCJpbmplY3RUb0hlYWQiLCJzaW5rIiwicmVxdWVzdCIsIm1ldGVvcl9sb2dpbl90b2tlbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQU8sTUFBTUEsVUFBVSxHQUFHO0FBQ3pCQyxTQUFPLEVBQUUsRUFEZ0I7QUFFekJDLGNBQVksRUFBRTtBQUZXLENBQW5CLEM7Ozs7Ozs7Ozs7O0FDQVBKLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNJLFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSUMsV0FBSjtBQUFnQk4sTUFBTSxDQUFDTyxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ0QsYUFBVyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsZUFBVyxHQUFDRSxDQUFaO0FBQWM7O0FBQTlCLENBQWpDLEVBQWlFLENBQWpFOztBQUdoRCxNQUFNSCxRQUFRLEdBQUcsVUFBU0ksR0FBVCxFQUFjO0FBQ3JDLE1BQUlDLEdBQUcsR0FBR0QsR0FBRyxDQUFDQyxHQUFkOztBQUNBLE1BQUlBLEdBQUcsS0FBSyxjQUFSLElBQTBCQSxHQUFHLEtBQUssYUFBdEMsRUFBcUQ7QUFDcEQsV0FBTyxLQUFQO0FBQ0EsR0FKb0MsQ0FNckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFJQSxHQUFHLEtBQUssZUFBWixFQUE2QjtBQUM1QixXQUFPLEtBQVA7QUFDQSxHQWRvQyxDQWdCckM7OztBQUNBLE1BQUlKLFdBQVcsQ0FBQ0ssUUFBWixDQUFxQkQsR0FBckIsQ0FBSixFQUErQjtBQUM5QixXQUFPLEtBQVA7QUFDQSxHQW5Cb0MsQ0FxQnJDO0FBQ0E7OztBQUNBLFNBQU8sT0FBT0UsSUFBUCxDQUFZSCxHQUFHLENBQUNJLE9BQUosQ0FBWSxRQUFaLENBQVosQ0FBUDtBQUNBLENBeEJNLEM7Ozs7Ozs7Ozs7O0FDSFAsSUFBSUMsS0FBSjtBQUFVZCxNQUFNLENBQUNPLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNRLFNBQU8sQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNNLFNBQUssR0FBQ04sQ0FBTjtBQUFROztBQUFwQixDQUFyQixFQUEyQyxDQUEzQztBQUE4QyxJQUFJTixVQUFKO0FBQWVGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0wsWUFBVSxDQUFDTSxDQUFELEVBQUc7QUFBQ04sY0FBVSxHQUFDTSxDQUFYO0FBQWE7O0FBQTVCLENBQTFCLEVBQXdELENBQXhEO0FBQTJELElBQUlRLE1BQUo7QUFBV2hCLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ1MsUUFBTSxDQUFDUixDQUFELEVBQUc7QUFBQ1EsVUFBTSxHQUFDUixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlTLE1BQUo7QUFBV2pCLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLDJCQUFaLEVBQXdDO0FBQUNVLFFBQU0sQ0FBQ1QsQ0FBRCxFQUFHO0FBQUNTLFVBQU0sR0FBQ1QsQ0FBUDtBQUFTOztBQUFwQixDQUF4QyxFQUE4RCxDQUE5RDtBQUFpRSxJQUFJVSxVQUFKO0FBQWVsQixNQUFNLENBQUNPLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDVyxZQUFVLENBQUNWLENBQUQsRUFBRztBQUFDVSxjQUFVLEdBQUNWLENBQVg7QUFBYTs7QUFBNUIsQ0FBakQsRUFBK0UsQ0FBL0U7QUFBa0YsSUFBSVcsY0FBSjtBQUFtQm5CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUNRLFNBQU8sQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNXLGtCQUFjLEdBQUNYLENBQWY7QUFBaUI7O0FBQTdCLENBQWhDLEVBQStELENBQS9EO0FBQWtFLElBQUlILFFBQUo7QUFBYUwsTUFBTSxDQUFDTyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDRixVQUFRLENBQUNHLENBQUQsRUFBRztBQUFDSCxZQUFRLEdBQUNHLENBQVQ7QUFBVzs7QUFBeEIsQ0FBdEIsRUFBZ0QsQ0FBaEQ7O0FBQW1ELElBQUlZLENBQUo7O0FBQU1wQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDYSxHQUFDLENBQUNaLENBQUQsRUFBRztBQUFDWSxLQUFDLEdBQUNaLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJYSxZQUFKO0FBQWlCckIsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDUSxTQUFPLENBQUNQLENBQUQsRUFBRztBQUFDYSxnQkFBWSxHQUFDYixDQUFiO0FBQWU7O0FBQTNCLENBQTVCLEVBQXlELENBQXpEO0FBVTFrQk4sVUFBVSxDQUFDRSxZQUFYLEdBQTBCLEVBQTFCO0FBQ0FGLFVBQVUsQ0FBQ29CLFNBQVgsR0FBdUIsSUFBSU4sTUFBTSxDQUFDTyxtQkFBWCxFQUF2QjtBQUVBLElBQUlDLGdCQUFnQixHQUFHUCxNQUFNLENBQUNRLE1BQVAsQ0FBYyxVQUFTaEIsR0FBVCxFQUFjaUIsR0FBZCxFQUFtQjtBQUN2RCxTQUFPckIsUUFBUSxDQUFDSSxHQUFELENBQWY7QUFDQSxDQUZzQixDQUF2QjtBQUdBZSxnQkFBZ0IsQ0FBQ0csVUFBakIsQ0FBNEJOLFlBQVksRUFBeEM7QUFDQUcsZ0JBQWdCLENBQUNHLFVBQWpCLENBQTRCLFVBQVNsQixHQUFULEVBQWNpQixHQUFkLEVBQW1CRSxJQUFuQixFQUF5QjtBQUNwRDFCLFlBQVUsQ0FBQzJCLGlCQUFYLENBQTZCcEIsR0FBN0IsRUFBa0NpQixHQUFsQyxFQUF1Q0UsSUFBdkM7QUFDQSxDQUZELEUsQ0FJQTs7QUFDQTFCLFVBQVUsQ0FBQzRCLEtBQVgsR0FBbUIsU0FBU0EsS0FBVCxDQUFlQyxJQUFmLEVBQXFCQyxRQUFyQixFQUErQjtBQUNqRCxNQUFJRCxJQUFJLENBQUNFLE9BQUwsQ0FBYSxHQUFiLE1BQXNCLENBQTFCLEVBQTZCO0FBQzVCLFVBQU0sSUFBSUMsS0FBSixDQUNMLGtCQUFrQkgsSUFBbEIsR0FBeUIsdUNBRHBCLENBQU47QUFHQTs7QUFDRFAsa0JBQWdCLENBQUNNLEtBQWpCLENBQXVCQyxJQUF2QixFQUE2QjdCLFVBQVUsQ0FBQ2lDLFdBQVgsQ0FBdUJDLElBQXZCLENBQTRCLElBQTVCLEVBQWtDSixRQUFsQyxDQUE3QjtBQUNBLENBUEQ7O0FBU0EsU0FBU0ssb0JBQVQsQ0FBOEI1QixHQUE5QixFQUFtQ21CLElBQW5DLEVBQXlDO0FBQ3hDLFNBQU8sVUFBU1UsU0FBVCxFQUFvQjtBQUMxQixRQUFJLENBQUNBLFNBQUwsRUFBZ0IsT0FBT1YsSUFBSSxFQUFYO0FBRWhCLFFBQUlXLGVBQWUsR0FBR3JCLFVBQVUsQ0FBQ3NCLE9BQVgsQ0FBbUIvQixHQUFuQixFQUF3QixrQkFBeEIsQ0FBdEI7O0FBQ0EsUUFBSSxDQUFDOEIsZUFBTCxFQUFzQjtBQUNyQnJCLGdCQUFVLENBQUN1QixRQUFYLENBQW9CaEMsR0FBcEIsRUFBeUIsa0JBQXpCLEVBQTZDNkIsU0FBN0M7QUFDQSxLQUZELE1BRU87QUFDTjtBQUNBO0FBQ0FsQixPQUFDLENBQUNzQixNQUFGLENBQVNILGVBQWUsQ0FBQ0ksYUFBekIsRUFBd0NMLFNBQVMsQ0FBQ0ssYUFBbEQ7O0FBQ0F2QixPQUFDLENBQUN3QixJQUFGLENBQU9OLFNBQVMsQ0FBQ08sY0FBakIsRUFBaUMsVUFBU0MsSUFBVCxFQUFlQyxPQUFmLEVBQXdCO0FBQ3hELFlBQUlDLFlBQVksR0FBR1QsZUFBZSxDQUFDTSxjQUFoQixDQUErQkUsT0FBL0IsQ0FBbkI7O0FBQ0EsWUFBSUMsWUFBSixFQUFrQjtBQUNqQkYsY0FBSSxHQUFHRSxZQUFZLENBQUNDLE1BQWIsQ0FBb0JILElBQXBCLENBQVA7QUFDQTs7QUFFRFAsdUJBQWUsQ0FBQ00sY0FBaEIsQ0FBK0JFLE9BQS9CLElBQTBDRCxJQUExQztBQUNBNUIsa0JBQVUsQ0FBQ3VCLFFBQVgsQ0FBb0JoQyxHQUFwQixFQUF5QixrQkFBekIsRUFBNkM4QixlQUE3QztBQUNBLE9BUkQ7QUFTQTs7QUFDRFgsUUFBSTtBQUNKLEdBckJEO0FBc0JBOztBQUVEMUIsVUFBVSxDQUFDaUMsV0FBWCxHQUF5QixVQUFTZSxrQkFBVCxFQUE2QkMsTUFBN0IsRUFBcUMxQyxHQUFyQyxFQUEwQ2lCLEdBQTFDLEVBQStDRSxJQUEvQyxFQUFxRDtBQUM3RSxNQUFJd0IsY0FBYyxHQUFHZixvQkFBb0IsQ0FBQzVCLEdBQUQsRUFBTW1CLElBQU4sQ0FBekM7O0FBQ0ExQixZQUFVLENBQUNtRCxjQUFYLENBQTBCRixNQUExQixFQUFrQzFDLEdBQWxDLEVBQXVDeUMsa0JBQXZDLEVBQTJERSxjQUEzRDtBQUNBLENBSEQ7O0FBS0FsRCxVQUFVLENBQUMyQixpQkFBWCxHQUErQixVQUFTcEIsR0FBVCxFQUFjaUIsR0FBZCxFQUFtQkUsSUFBbkIsRUFBeUI7QUFDdkQsTUFBSXdCLGNBQWMsR0FBR2Ysb0JBQW9CLENBQUM1QixHQUFELEVBQU1tQixJQUFOLENBQXpDOztBQUNBMUIsWUFBVSxDQUFDb0QsaUJBQVgsQ0FBNkI3QyxHQUE3QixFQUFrQzJDLGNBQWxDO0FBQ0EsQ0FIRDs7QUFLQWxELFVBQVUsQ0FBQ3FELFdBQVgsR0FBeUIsU0FBU0EsV0FBVCxDQUFxQnZCLFFBQXJCLEVBQStCO0FBQ3ZEOUIsWUFBVSxDQUFDRSxZQUFYLENBQXdCb0QsSUFBeEIsQ0FBNkJ4QixRQUE3QjtBQUNBLENBRkQ7O0FBSUE5QixVQUFVLENBQUNtRCxjQUFYLEdBQTRCLFNBQVNBLGNBQVQsQ0FDM0JGLE1BRDJCLEVBRTNCMUMsR0FGMkIsRUFHM0JnRCxhQUgyQixFQUkzQnpCLFFBSjJCLEVBSzFCO0FBQ0RBLFVBQVEsR0FBR0EsUUFBUSxJQUFJLFlBQVcsQ0FBRSxDQUFwQzs7QUFFQSxNQUFJRCxJQUFJLEdBQUd0QixHQUFHLENBQUNDLEdBQWY7QUFDQSxNQUFJZ0QsVUFBVSxHQUFHakQsR0FBRyxDQUFDa0QsT0FBSixDQUFZLG9CQUFaLENBQWpCO0FBQ0EsTUFBSTlDLE9BQU8sR0FBR0osR0FBRyxDQUFDSSxPQUFsQjtBQUVBLE1BQUkrQyxPQUFPLEdBQUcsSUFBSTFELFVBQVUsQ0FBQzJELFFBQWYsQ0FBd0JILFVBQXhCLEVBQW9DO0FBQUU3QyxXQUFPLEVBQUVBO0FBQVgsR0FBcEMsQ0FBZDs7QUFFQSxNQUFJO0FBQ0hYLGNBQVUsQ0FBQ29CLFNBQVgsQ0FBcUJ3QyxTQUFyQixDQUErQkYsT0FBL0IsRUFBd0MsWUFBVztBQUNsREgsbUJBQWEsQ0FBQ00sSUFBZCxDQUFtQkgsT0FBbkIsRUFBNEJULE1BQTVCLEVBQW9DcEIsSUFBcEM7QUFDQSxLQUZEOztBQUlBLFFBQUk2QixPQUFPLENBQUNJLElBQVosRUFBa0I7QUFDakI7QUFDQTs7QUFFRGhDLFlBQVEsQ0FBQzRCLE9BQU8sQ0FBQ3BCLE9BQVIsRUFBRCxDQUFSO0FBQ0EsR0FWRCxDQVVFLE9BQU95QixHQUFQLEVBQVk7QUFDYkMsZUFBVyxDQUFDRCxHQUFELEVBQU1sQyxJQUFOLEVBQVlDLFFBQVosQ0FBWDtBQUNBO0FBQ0QsQ0EzQkQ7O0FBNkJBOUIsVUFBVSxDQUFDb0QsaUJBQVgsR0FBK0IsU0FBU0EsaUJBQVQsQ0FBMkI3QyxHQUEzQixFQUFnQ3VCLFFBQWhDLEVBQTBDO0FBQ3hFQSxVQUFRLEdBQUdBLFFBQVEsSUFBSSxZQUFXLENBQUUsQ0FBcEM7O0FBRUEsTUFBSUQsSUFBSSxHQUFHdEIsR0FBRyxDQUFDQyxHQUFmO0FBQ0EsTUFBSWdELFVBQVUsR0FBR2pELEdBQUcsQ0FBQ2tELE9BQUosQ0FBWSxvQkFBWixDQUFqQjtBQUNBLE1BQUk5QyxPQUFPLEdBQUdKLEdBQUcsQ0FBQ0ksT0FBbEI7QUFFQSxNQUFJQyxLQUFKLENBQVUsWUFBVztBQUNwQixRQUFJOEMsT0FBTyxHQUFHLElBQUkxRCxVQUFVLENBQUMyRCxRQUFmLENBQXdCSCxVQUF4QixFQUFvQztBQUFFN0MsYUFBTyxFQUFFQTtBQUFYLEtBQXBDLENBQWQ7O0FBRUEsUUFBSTtBQUNIWCxnQkFBVSxDQUFDRSxZQUFYLENBQXdCK0QsT0FBeEIsQ0FBZ0MsVUFBU25DLFFBQVQsRUFBbUI7QUFDbERBLGdCQUFRLENBQUMrQixJQUFULENBQWNILE9BQWQsRUFBdUJuRCxHQUFHLENBQUNDLEdBQTNCO0FBQ0EsT0FGRDs7QUFJQXNCLGNBQVEsQ0FBQzRCLE9BQU8sQ0FBQ3BCLE9BQVIsRUFBRCxDQUFSO0FBQ0EsS0FORCxDQU1FLE9BQU95QixHQUFQLEVBQVk7QUFDYkMsaUJBQVcsQ0FBQ0QsR0FBRCxFQUFNbEMsSUFBTixFQUFZQyxRQUFaLENBQVg7QUFDQTtBQUNELEdBWkQsRUFZR29DLEdBWkg7QUFhQSxDQXBCRDs7QUFzQkEsU0FBU0YsV0FBVCxDQUFxQkQsR0FBckIsRUFBMEJsQyxJQUExQixFQUFnQ0MsUUFBaEMsRUFBMEM7QUFDekMsTUFBSXFDLE9BQU8sR0FDVixtQ0FBbUN0QyxJQUFuQyxHQUEwQyxZQUExQyxHQUF5RGtDLEdBQUcsQ0FBQ0ssS0FEOUQ7QUFFQUMsU0FBTyxDQUFDQyxLQUFSLENBQWNILE9BQWQ7QUFDQXJDLFVBQVEsQ0FBQyxJQUFELENBQVI7QUFDQSxDLENBRUQ7OztBQUNBOUIsVUFBVSxDQUFDcUQsV0FBWCxDQUF1QixZQUFXO0FBQ2pDLE1BQUlLLE9BQU8sR0FBRyxJQUFkO0FBQ0EsTUFBSWEsWUFBWSxHQUFHekQsTUFBTSxDQUFDMEQsY0FBUCxDQUFzQkMsMEJBQXpDOztBQUVBLE1BQUlGLFlBQUosRUFBa0I7QUFDakJBLGdCQUFZLENBQUNOLE9BQWIsQ0FBcUIsVUFBU1MsY0FBVCxFQUF5QjtBQUM3QztBQUNBLFVBQUlDLGNBQWMsR0FBRyxJQUFJMUQsY0FBSixDQUFtQnlDLE9BQW5CLEVBQTRCZ0IsY0FBNUIsQ0FBckI7QUFDQWhCLGFBQU8sQ0FBQ2tCLGtCQUFSLENBQTJCRCxjQUEzQjtBQUNBLEtBSkQ7QUFLQTtBQUNELENBWEQsRTs7Ozs7Ozs7Ozs7QUNqSUEsSUFBSUUsTUFBSjtBQUFXL0UsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDd0UsUUFBTSxDQUFDdkUsQ0FBRCxFQUFHO0FBQUN1RSxVQUFNLEdBQUN2RSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl3RSxLQUFKO0FBQVVoRixNQUFNLENBQUNPLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5RSxPQUFLLENBQUN4RSxDQUFELEVBQUc7QUFBQ3dFLFNBQUssR0FBQ3hFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSVEsTUFBSjtBQUFXaEIsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDUyxRQUFNLENBQUNSLENBQUQsRUFBRztBQUFDUSxVQUFNLEdBQUNSLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUlZLENBQUo7O0FBQU1wQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDYSxHQUFDLENBQUNaLENBQUQsRUFBRztBQUFDWSxLQUFDLEdBQUNaLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJeUUsT0FBSjtBQUFZakYsTUFBTSxDQUFDTyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQzBFLFNBQU8sQ0FBQ3pFLENBQUQsRUFBRztBQUFDeUUsV0FBTyxHQUFDekUsQ0FBUjtBQUFVOztBQUF0QixDQUFyQyxFQUE2RCxDQUE3RDs7QUFNN1AsTUFBTVcsY0FBYyxHQUFHLFNBQVNBLGNBQVQsQ0FDdEJ5QyxPQURzQixFQUV0QnNCLE9BRnNCLEVBR3RCQyxjQUhzQixFQUl0QmhDLE1BSnNCLEVBS3RCaUMsSUFMc0IsRUFNckI7QUFDRCxNQUFJQyxJQUFJLEdBQUcsSUFBWCxDQURDLENBR0Q7O0FBQ0EsTUFBSUMsU0FBUyxHQUFHUCxNQUFNLENBQUNRLEVBQVAsRUFBaEI7QUFDQSxNQUFJQyxPQUFPLEdBQUc7QUFDYkQsTUFBRSxFQUFFRCxTQURTO0FBRWJHLFVBQU0sRUFBRTdCLE9BQU8sQ0FBQzZCLE1BRkg7QUFHYjtBQUNBQyxXQUFPLEVBQUUsRUFKSTtBQUtiQyxvQkFBZ0IsRUFBRTtBQUNqQkosUUFBRSxFQUFFRCxTQURhO0FBRWpCTSxXQUFLLEVBQUUsWUFBVyxDQUFFLENBRkg7QUFHakJDLGFBQU8sRUFBRSxZQUFXLENBQUUsQ0FITDtBQUlqQkMsbUJBQWEsRUFBRSxXQUpFO0FBS2pCQyxpQkFBVyxFQUFFbkMsT0FBTyxDQUFDL0M7QUFMSixLQUxMO0FBWWJtRixTQUFLLEVBQUUsVUFBU0Msa0JBQVQsRUFBNkJDLGNBQTdCLEVBQTZDQyxLQUE3QyxFQUFvREMsTUFBcEQsRUFBNEQ7QUFDbEU7QUFDQSxVQUFJQyxHQUFHLEdBQUdyQixLQUFLLENBQUNzQixLQUFOLENBQVlGLE1BQVosQ0FBVjtBQUNBQyxTQUFHLENBQUNFLEdBQUosR0FBVWxCLElBQUksQ0FBQ21CLFNBQUwsQ0FBZUMsT0FBZixDQUF1Qk4sS0FBdkIsQ0FBVjtBQUNBbkYsWUFBTSxDQUFDMEYsT0FBUCxDQUFlckIsSUFBSSxDQUFDc0IsZUFBcEIsRUFBcUNULGNBQXJDLEVBQXFEQyxLQUFyRCxJQUE4REUsR0FBOUQ7QUFDQSxLQWpCWTtBQWtCYk8sV0FBTyxFQUFFLFVBQVNYLGtCQUFULEVBQTZCQyxjQUE3QixFQUE2Q0MsS0FBN0MsRUFBb0RDLE1BQXBELEVBQTREO0FBQ3BFLFVBQUlDLEdBQUcsR0FBR2hCLElBQUksQ0FBQ3NCLGVBQUwsQ0FBcUJULGNBQXJCLEVBQXFDQyxLQUFyQyxDQUFWOztBQUNBLFVBQUksQ0FBQ0UsR0FBTCxFQUFVO0FBQ1QsY0FBTSxJQUFJbkUsS0FBSixDQUNMLG9DQUFvQ2lFLEtBQXBDLEdBQTRDLFlBRHZDLENBQU47QUFHQTs7QUFDRC9FLE9BQUMsQ0FBQ3dCLElBQUYsQ0FBT3dELE1BQVAsRUFBZSxVQUFTUyxLQUFULEVBQWdCQyxHQUFoQixFQUFxQjtBQUNuQztBQUNBLFlBQUlBLEdBQUcsS0FBSyxLQUFaLEVBQW1COztBQUVuQixZQUFJRCxLQUFLLEtBQUtFLFNBQWQsRUFBeUI7QUFDeEIsaUJBQU9WLEdBQUcsQ0FBQ1MsR0FBRCxDQUFWO0FBQ0EsU0FGRCxNQUVPO0FBQ047QUFDQVQsYUFBRyxDQUFDUyxHQUFELENBQUgsR0FBVzlCLEtBQUssQ0FBQ3NCLEtBQU4sQ0FBWU8sS0FBWixDQUFYO0FBQ0E7QUFDRCxPQVZEO0FBV0EsS0FwQ1k7QUFxQ2JHLFdBQU8sRUFBRSxVQUFTZixrQkFBVCxFQUE2QkMsY0FBN0IsRUFBNkNDLEtBQTdDLEVBQW9EO0FBQzVELFVBQ0MsRUFDQ2QsSUFBSSxDQUFDc0IsZUFBTCxDQUFxQlQsY0FBckIsS0FDQWIsSUFBSSxDQUFDc0IsZUFBTCxDQUFxQlQsY0FBckIsRUFBcUNDLEtBQXJDLENBRkQsQ0FERCxFQUtFO0FBQ0QsY0FBTSxJQUFJakUsS0FBSixDQUFVLGtDQUFrQ2lFLEtBQTVDLENBQU47QUFDQTs7QUFDRCxhQUFPZCxJQUFJLENBQUNzQixlQUFMLENBQXFCVCxjQUFyQixFQUFxQ0MsS0FBckMsQ0FBUDtBQUNBLEtBL0NZO0FBZ0RiYyxhQUFTLEVBQUUsVUFBU0MsZUFBVCxFQUEwQjtBQUNwQztBQUNBLFVBQUksQ0FBQzdCLElBQUksQ0FBQzhCLGVBQVYsRUFBMkIsTUFBTSxJQUFJakYsS0FBSixDQUFVLFlBQVYsQ0FBTixDQUZTLENBSXBDOztBQUNBLFVBQUksQ0FBQ21ELElBQUksQ0FBQytCLGNBQUwsRUFBTCxFQUE0QjtBQUMzQi9CLFlBQUksQ0FBQ2dDLFFBQUwsQ0FBY0MscUJBQWQsQ0FBb0NqQyxJQUFJLENBQUNrQyxLQUF6QyxFQUFnRGxDLElBQUksQ0FBQ21DLE9BQXJEO0FBQ0EsT0FQbUMsQ0FTcEM7OztBQUNBbkMsVUFBSSxDQUFDckIsSUFBTDtBQUNBO0FBM0RZLEdBQWQ7QUE4REFpQixTQUFPLENBQUN3QyxZQUFSLENBQXFCMUQsSUFBckIsQ0FDQ3NCLElBREQsRUFFQ0csT0FGRCxFQUdDTixPQUhELEVBSUNDLGNBSkQsRUFLQ2hDLE1BTEQsRUFNQ2lDLElBTkQ7O0FBU0FDLE1BQUksQ0FBQ3FDLE9BQUwsR0FBZSxZQUFXLENBQUUsQ0FBNUI7O0FBRUFyQyxNQUFJLENBQUNnQyxRQUFMLEdBQWdCekQsT0FBaEI7QUFDQXlCLE1BQUksQ0FBQ3NCLGVBQUwsR0FBdUIsRUFBdkI7QUFDQSxDQXRGRDs7QUF3RkF4RixjQUFjLENBQUN3RyxTQUFmLEdBQTJCQyxNQUFNLENBQUNDLE1BQVAsQ0FBYzVDLE9BQU8sQ0FBQ3dDLFlBQVIsQ0FBcUJFLFNBQW5DLENBQTNCO0FBQ0F4RyxjQUFjLENBQUN3RyxTQUFmLENBQXlCRyxXQUF6QixHQUF1QzNHLGNBQXZDOztBQUVBQSxjQUFjLENBQUN3RyxTQUFmLENBQXlCM0QsSUFBekIsR0FBZ0MsWUFBVztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBSytELFdBQUw7QUFDQSxDQVBEOztBQVNBNUcsY0FBYyxDQUFDd0csU0FBZixDQUF5Qm5ELEtBQXpCLEdBQWlDLFVBQVNBLEtBQVQsRUFBZ0I7QUFDaEQ7QUFDQUQsU0FBTyxDQUFDeUQsSUFBUixDQUNDLCtCQURELEVBRUMsS0FBS1QsS0FGTixFQUdDLElBSEQsRUFJQy9DLEtBQUssQ0FBQ0gsT0FBTixJQUFpQkcsS0FKbEI7QUFNQSxPQUFLUixJQUFMO0FBQ0EsQ0FURDs7QUExR0FoRSxNQUFNLENBQUNpSSxhQUFQLENBcUhlOUcsY0FySGYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJSCxNQUFKO0FBQVdoQixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNTLFFBQU0sQ0FBQ1IsQ0FBRCxFQUFHO0FBQUNRLFVBQU0sR0FBQ1IsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMEgsTUFBSjtBQUFXbEksTUFBTSxDQUFDTyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDUSxTQUFPLENBQUNQLENBQUQsRUFBRztBQUFDMEgsVUFBTSxHQUFDMUgsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJMkgsTUFBSjtBQUFXbkksTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDUSxTQUFPLENBQUNQLENBQUQsRUFBRztBQUFDMkgsVUFBTSxHQUFDM0gsQ0FBUDtBQUFTOztBQUFyQixDQUE1QixFQUFtRCxDQUFuRDtBQUFzRCxJQUFJNEgsUUFBSjtBQUFhcEksTUFBTSxDQUFDTyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQzZILFVBQVEsQ0FBQzVILENBQUQsRUFBRztBQUFDNEgsWUFBUSxHQUFDNUgsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJNkgsR0FBSjtBQUFRckksTUFBTSxDQUFDTyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDOEgsS0FBRyxDQUFDN0gsQ0FBRCxFQUFHO0FBQUM2SCxPQUFHLEdBQUM3SCxDQUFKO0FBQU07O0FBQWQsQ0FBekIsRUFBeUMsQ0FBekM7QUFBNEMsSUFBSXVFLE1BQUo7QUFBVy9FLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3dFLFFBQU0sQ0FBQ3ZFLENBQUQsRUFBRztBQUFDdUUsVUFBTSxHQUFDdkUsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJVyxjQUFKO0FBQW1CbkIsTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ1EsU0FBTyxDQUFDUCxDQUFELEVBQUc7QUFBQ1csa0JBQWMsR0FBQ1gsQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBaEMsRUFBK0QsQ0FBL0Q7O0FBQWtFLElBQUlZLENBQUo7O0FBQU1wQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDYSxHQUFDLENBQUNaLENBQUQsRUFBRztBQUFDWSxLQUFDLEdBQUNaLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJd0UsS0FBSjtBQUFVaEYsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUUsT0FBSyxDQUFDeEUsQ0FBRCxFQUFHO0FBQUN3RSxTQUFLLEdBQUN4RSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlOLFVBQUo7QUFBZUYsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDTCxZQUFVLENBQUNNLENBQUQsRUFBRztBQUFDTixjQUFVLEdBQUNNLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUIsRUFBd0QsQ0FBeEQ7O0FBV2psQixNQUFNOEgsT0FBTyxHQUFHLFNBQVNBLE9BQVQsQ0FBaUI1RSxVQUFqQixFQUE2QjZFLFdBQTdCLEVBQTBDO0FBQ3pELE9BQUs1QixlQUFMLEdBQXVCLEVBQXZCO0FBQ0EsT0FBSzZCLGNBQUwsR0FBc0IsRUFBdEI7QUFDQSxPQUFLQyxXQUFMLEdBQW1CL0UsVUFBbkI7O0FBRUF0QyxHQUFDLENBQUNzQixNQUFGLENBQVMsSUFBVCxFQUFlNkYsV0FBZixFQUx5RCxDQU96RDs7O0FBQ0EsTUFBSXZILE1BQU0sQ0FBQzBILEtBQVgsRUFBa0I7QUFDakI7QUFDQTtBQUNBLFFBQUloRixVQUFKLEVBQWdCO0FBQ2YsVUFBSWlGLFdBQVcsR0FBR2pGLFVBQVUsSUFBSTBFLFFBQVEsQ0FBQ1EsZUFBVCxDQUF5QmxGLFVBQXpCLENBQWhDOztBQUNBLFVBQUltRixLQUFLLEdBQUc7QUFBRSxtREFBMkNGO0FBQTdDLE9BQVo7QUFDQSxVQUFJRyxPQUFPLEdBQUc7QUFBRTFDLGNBQU0sRUFBRTtBQUFFRyxhQUFHLEVBQUU7QUFBUDtBQUFWLE9BQWQ7QUFDQSxVQUFJd0MsSUFBSSxHQUFHL0gsTUFBTSxDQUFDMEgsS0FBUCxDQUFhTSxPQUFiLENBQXFCSCxLQUFyQixFQUE0QkMsT0FBNUIsQ0FBWDtBQUNBLEtBUmdCLENBVWpCOzs7QUFDQVosVUFBTSxDQUFDZSxPQUFQLENBQWVDLGdCQUFmLEdBQWtDLEVBQWxDO0FBQ0FoQixVQUFNLENBQUNlLE9BQVAsQ0FBZUMsZ0JBQWYsQ0FBZ0NiLEdBQUcsQ0FBQ2Msa0JBQUosQ0FBdUJDLElBQXZELElBQStELElBQS9EOztBQUVBLFFBQUlMLElBQUosRUFBVTtBQUNULFdBQUt0RCxNQUFMLEdBQWNzRCxJQUFJLENBQUN4QyxHQUFuQjtBQUNBO0FBQ0Q7QUFDRCxDQTFCRDs7QUE0QkErQixPQUFPLENBQUNYLFNBQVIsQ0FBa0IwQixTQUFsQixHQUE4QixVQUFTQztBQUFRO0FBQWpCLEVBQWdDO0FBQzdELE1BQUkxRSxjQUFjLEdBQUc1RCxNQUFNLENBQUMwRCxjQUFQLENBQXNCNkUsZ0JBQXRCLENBQXVDRCxPQUF2QyxDQUFyQjs7QUFDQSxNQUFJMUUsY0FBSixFQUFvQjtBQUNuQixRQUFJekIsTUFBTSxHQUFHcUcsS0FBSyxDQUFDN0IsU0FBTixDQUFnQjhCLEtBQWhCLENBQXNCMUYsSUFBdEIsQ0FBMkIyRixTQUEzQixFQUFzQyxDQUF0QyxDQUFiLENBRG1CLENBRW5COztBQUNBLFFBQUl2RSxjQUFjLEdBQUdKLE1BQU0sQ0FBQ1EsRUFBUCxFQUFyQjtBQUNBLFFBQUlWLGNBQWMsR0FBRyxJQUFJMUQsY0FBSixDQUNwQixJQURvQixFQUVwQnlELGNBRm9CLEVBR3BCTyxjQUhvQixFQUlwQmhDLE1BSm9CLEVBS3BCbUcsT0FMb0IsQ0FBckI7QUFRQSxXQUFPLEtBQUt4RSxrQkFBTCxDQUF3QkQsY0FBeEIsQ0FBUDtBQUNBLEdBYkQsTUFhTztBQUNOTixXQUFPLENBQUN5RCxJQUFSLENBQWEseUNBQWIsRUFBd0RzQixPQUF4RDtBQUNBLFdBQU8sRUFBUDtBQUNBO0FBQ0QsQ0FuQkQ7O0FBcUJBaEIsT0FBTyxDQUFDWCxTQUFSLENBQWtCN0Msa0JBQWxCLEdBQXVDLFVBQVNELGNBQVQsRUFBeUI7QUFDL0QsTUFBSVEsSUFBSSxHQUFHLElBQVg7QUFDQSxNQUFJdkMsSUFBSSxHQUFHLEVBQVg7O0FBQ0EsTUFBSTZHLGdCQUFnQixHQUFHLFVBQVN6RCxjQUFULEVBQXlCO0FBQy9DYixRQUFJLENBQUN1RSxpQkFBTCxDQUF1QjFELGNBQXZCOztBQUNBLFFBQUksQ0FBQ3BELElBQUksQ0FBQ29ELGNBQUQsQ0FBVCxFQUEyQjtBQUMxQnBELFVBQUksQ0FBQ29ELGNBQUQsQ0FBSixHQUF1QixFQUF2QjtBQUNBO0FBQ0QsR0FMRDs7QUFPQSxNQUFJMkQsTUFBTSxHQUFHLElBQUkxQixNQUFKLEVBQWIsQ0FWK0QsQ0FXL0Q7O0FBQ0F0RCxnQkFBYyxDQUFDaUYsTUFBZixDQUFzQixZQUFXO0FBQ2hDLFFBQUksQ0FBQ0QsTUFBTSxDQUFDRSxVQUFQLEVBQUwsRUFBMEI7QUFDekJGLFlBQU0sQ0FBQ0csTUFBUDtBQUNBO0FBQ0QsR0FKRDs7QUFNQW5GLGdCQUFjLENBQUNvRixXQUFmOztBQUVBLE1BQUksQ0FBQ3BGLGNBQWMsQ0FBQ3NDLGVBQXBCLEVBQXFDO0FBQ3BDO0FBQ0E7QUFDQXRDLGtCQUFjLENBQUNiLElBQWY7QUFDQTs7QUFFRCxNQUFJLENBQUM2RixNQUFNLENBQUNFLFVBQVAsRUFBTCxFQUEwQjtBQUN6QjtBQUNBL0ksVUFBTSxDQUFDa0osVUFBUCxDQUFrQixZQUFXO0FBQzVCLFVBQUksQ0FBQ0wsTUFBTSxDQUFDRSxVQUFQLEVBQUwsRUFBMEI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFJMUYsT0FBTyxHQUNWLHlCQUNBUSxjQUFjLENBQUMwQyxLQURmLEdBRUEseUJBRkEsR0FHQSwwREFIQSxHQUlBLHFDQUxEO0FBTUFoRCxlQUFPLENBQUN5RCxJQUFSLENBQWEzRCxPQUFiO0FBQ0F3RixjQUFNLENBQUNHLE1BQVA7QUFDQTtBQUNELEtBZkQsRUFlRyxHQWZILEVBRnlCLENBaUJqQjtBQUVSOztBQUNBSCxVQUFNLENBQUNNLElBQVA7QUFDQSxHQS9DOEQsQ0FpRC9EO0FBQ0E7QUFDQTs7O0FBQ0F0RixnQkFBYyxDQUFDYixJQUFmLEdBcEQrRCxDQXNEL0Q7O0FBQ0E1QyxHQUFDLENBQUN3QixJQUFGLENBQU9pQyxjQUFjLENBQUM4QixlQUF0QixFQUF1QyxVQUFTeUQsUUFBVCxFQUFtQmxFLGNBQW5CLEVBQW1DO0FBQ3pFO0FBQ0FrRSxZQUFRLEdBQUdoSixDQUFDLENBQUNpSixNQUFGLENBQVNELFFBQVQsQ0FBWDtBQUVBVCxvQkFBZ0IsQ0FBQ3pELGNBQUQsQ0FBaEI7QUFDQXBELFFBQUksQ0FBQ29ELGNBQUQsQ0FBSixDQUFxQjFDLElBQXJCLENBQTBCNEcsUUFBMUIsRUFMeUUsQ0FPekU7O0FBQ0EvRSxRQUFJLENBQUNzQixlQUFMLENBQXFCVCxjQUFyQixFQUFxQzFDLElBQXJDLENBQTBDNEcsUUFBMUM7QUFDQSxHQVREOztBQVdBLFNBQU90SCxJQUFQO0FBQ0EsQ0FuRUQ7O0FBcUVBd0YsT0FBTyxDQUFDWCxTQUFSLENBQWtCTCxxQkFBbEIsR0FBMEMsVUFBU2xDLElBQVQsRUFBZWpDLE1BQWYsRUFBdUI7QUFDaEUsTUFBSW1ILElBQUksR0FBRyxLQUFLOUIsY0FBTCxDQUFvQnBELElBQXBCLENBQVg7O0FBQ0EsTUFBSSxDQUFDa0YsSUFBTCxFQUFXO0FBQ1ZBLFFBQUksR0FBRyxLQUFLOUIsY0FBTCxDQUFvQnBELElBQXBCLElBQTRCLEVBQW5DO0FBQ0E7O0FBRUQsTUFBSWpDLE1BQU0sSUFBSUEsTUFBTSxDQUFDb0gsTUFBckIsRUFBNkI7QUFDNUIsUUFBSUMsU0FBUyxHQUFHckgsTUFBTSxDQUFDQSxNQUFNLENBQUNvSCxNQUFQLEdBQWdCLENBQWpCLENBQXRCOztBQUNBLFFBQ0NDLFNBQVMsS0FDUkEsU0FBUyxDQUFDQyxjQUFWLENBQXlCLFFBQXpCLEtBQ0FELFNBQVMsQ0FBQ0MsY0FBVixDQUF5QixTQUF6QixDQUZRLENBRFYsRUFJRTtBQUNEdEgsWUFBTSxDQUFDdUgsR0FBUDtBQUNBO0FBQ0Q7O0FBRURKLE1BQUksQ0FBQ3RGLEtBQUssQ0FBQzJGLFNBQU4sQ0FBZ0J4SCxNQUFoQixDQUFELENBQUosR0FBZ0MsSUFBaEM7QUFDQSxDQWxCRDs7QUFvQkFtRixPQUFPLENBQUNYLFNBQVIsQ0FBa0JpQyxpQkFBbEIsR0FBc0MsVUFBUzFELGNBQVQsRUFBeUI7QUFDOUQsTUFBSSxDQUFDLEtBQUtTLGVBQUwsQ0FBcUJULGNBQXJCLENBQUwsRUFBMkM7QUFDMUMsU0FBS1MsZUFBTCxDQUFxQlQsY0FBckIsSUFBdUMsRUFBdkM7QUFDQTtBQUNELENBSkQ7O0FBTUFvQyxPQUFPLENBQUNYLFNBQVIsQ0FBa0JuRixPQUFsQixHQUE0QixZQUFXO0FBQ3RDLFNBQU87QUFDTkssa0JBQWMsRUFBRSxLQUFLOEQsZUFEZjtBQUVOaEUsaUJBQWEsRUFBRSxLQUFLNkYsY0FGZDtBQUdOOUUsY0FBVSxFQUFFLEtBQUsrRTtBQUhYLEdBQVA7QUFLQSxDQU5EOztBQVFBdkksVUFBVSxDQUFDMkQsUUFBWCxHQUFzQnlFLE9BQXRCLEM7Ozs7Ozs7Ozs7O0FDbktBLElBQUl0SCxNQUFKO0FBQVdoQixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNTLFFBQU0sQ0FBQ1IsQ0FBRCxFQUFHO0FBQUNRLFVBQU0sR0FBQ1IsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTixVQUFKO0FBQWVGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNMLFlBQVUsQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLGNBQVUsR0FBQ00sQ0FBWDtBQUFhOztBQUE1QixDQUFqRCxFQUErRSxDQUEvRTtBQUFrRixJQUFJVSxVQUFKO0FBQWVsQixNQUFNLENBQUNPLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDVyxZQUFVLENBQUNWLENBQUQsRUFBRztBQUFDVSxjQUFVLEdBQUNWLENBQVg7QUFBYTs7QUFBNUIsQ0FBakQsRUFBK0UsQ0FBL0U7QUFBa0YsSUFBSW9LLFVBQUo7QUFBZTVLLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNxSyxZQUFVLENBQUNwSyxDQUFELEVBQUc7QUFBQ29LLGNBQVUsR0FBQ3BLLENBQVg7QUFBYTs7QUFBNUIsQ0FBbkMsRUFBaUUsQ0FBakU7O0FBQW9FLElBQUlZLENBQUo7O0FBQU1wQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDYSxHQUFDLENBQUNaLENBQUQsRUFBRztBQUFDWSxLQUFDLEdBQUNaLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQU0zVixNQUFNcUssaUJBQWlCLEdBQUc3SixNQUFNLENBQUNxSSxTQUFqQzs7QUFDQXJJLE1BQU0sQ0FBQ3FJLFNBQVAsR0FBbUIsVUFBU2pFLElBQVQsRUFBd0I7QUFBQSxvQ0FBTjBGLElBQU07QUFBTkEsUUFBTTtBQUFBOztBQUMxQyxRQUFNeEosU0FBUyxHQUFHcEIsVUFBVSxDQUFDb0IsU0FBWCxDQUFxQnlKLEdBQXJCLEVBQWxCOztBQUNBLE1BQUksQ0FBQ3pKLFNBQUwsRUFBZ0I7QUFDZixVQUFNLElBQUlZLEtBQUosc0NBQ3lCa0QsSUFEekIsaUNBQU47QUFHQTs7QUFDRDlELFdBQVMsQ0FBQytILFNBQVYsQ0FBb0JqRSxJQUFwQixFQUEwQixHQUFHMEYsSUFBN0I7O0FBRUEsTUFBSUQsaUJBQUosRUFBdUI7QUFDdEJBLHFCQUFpQixDQUFDRyxLQUFsQixDQUF3QixJQUF4QixFQUE4QnRCLFNBQTlCO0FBQ0E7O0FBRUQsU0FBTztBQUNOdUIsU0FBSyxFQUFFLE1BQU07QUFEUCxHQUFQO0FBR0EsQ0FoQkQ7O0FBa0JBL0ssVUFBVSxDQUFDZ0wsWUFBWCxHQUEwQixVQUFTekssR0FBVCxFQUFjNkIsU0FBZCxFQUF5QjtBQUNsRCxNQUFJQyxlQUFlLEdBQUdyQixVQUFVLENBQUNzQixPQUFYLENBQW1CL0IsR0FBbkIsRUFBd0Isa0JBQXhCLENBQXRCOztBQUNBLE1BQUksQ0FBQzhCLGVBQUwsRUFBc0I7QUFDckJyQixjQUFVLENBQUN1QixRQUFYLENBQW9CaEMsR0FBcEIsRUFBeUIsa0JBQXpCLEVBQTZDNkIsU0FBN0M7QUFDQSxHQUZELE1BRU87QUFDTjtBQUNBO0FBQ0FsQixLQUFDLENBQUNzQixNQUFGLENBQVNILGVBQWUsQ0FBQ0ksYUFBekIsRUFBd0NMLFNBQVMsQ0FBQ0ssYUFBbEQ7O0FBQ0F2QixLQUFDLENBQUN3QixJQUFGLENBQU9OLFNBQVMsQ0FBQ08sY0FBakIsRUFBaUMsVUFBU0MsSUFBVCxFQUFlQyxPQUFmLEVBQXdCO0FBQ3hELFVBQUlDLFlBQVksR0FBR1QsZUFBZSxDQUFDTSxjQUFoQixDQUErQkUsT0FBL0IsQ0FBbkI7O0FBQ0EsVUFBSUMsWUFBSixFQUFrQjtBQUNqQkYsWUFBSSxHQUFHRSxZQUFZLENBQUNDLE1BQWIsQ0FBb0JILElBQXBCLENBQVA7QUFDQTs7QUFFRFAscUJBQWUsQ0FBQ00sY0FBaEIsQ0FBK0JFLE9BQS9CLElBQTBDRCxJQUExQztBQUNBNUIsZ0JBQVUsQ0FBQ3VCLFFBQVgsQ0FBb0JoQyxHQUFwQixFQUF5QixrQkFBekIsRUFBNkM4QixlQUE3QztBQUNBLEtBUkQ7QUFTQTtBQUNELENBbEJEOztBQW9CQXJDLFVBQVUsQ0FBQzBLLFVBQVgsR0FBd0IsVUFBUzVJLFFBQVQsRUFBbUI7QUFDMUNkLFlBQVUsQ0FBQ2lLLFlBQVgsR0FBMEIsS0FBMUI7QUFDQVAsWUFBVSxDQUFPUSxJQUFOLDZCQUFjO0FBQ3hCLFVBQU05SixTQUFTLEdBQUcsSUFBSXBCLFVBQVUsQ0FBQzJELFFBQWYsQ0FDakJ1SCxJQUFJLENBQUNDLE9BQUwsQ0FBYTFILE9BQWIsQ0FBcUIySCxrQkFESixFQUVqQjtBQUNDekssYUFBTyxFQUFFdUssSUFBSSxDQUFDdks7QUFEZixLQUZpQixDQUFsQjtBQU9BLGtCQUFNWCxVQUFVLENBQUNvQixTQUFYLENBQXFCd0MsU0FBckIsQ0FBK0J4QyxTQUEvQixFQUEwQztBQUFBLHNDQUFpQjtBQUNoRSxzQkFBTVUsUUFBUSxDQUFDb0osSUFBRCxDQUFkOztBQUNBbEwsa0JBQVUsQ0FBQ2dMLFlBQVgsQ0FDQ0UsSUFBSSxDQUFDQyxPQUROLEVBRUNuTCxVQUFVLENBQUNvQixTQUFYLENBQXFCeUosR0FBckIsR0FBMkJ2SSxPQUEzQixFQUZEO0FBSUEsT0FOK0M7QUFBQSxLQUExQyxDQUFOO0FBT0EsR0FmVSxDQUFELENBQVY7QUFnQkEsQ0FsQkQsQyIsImZpbGUiOiIvcGFja2FnZXMvc3RhcmluZ2F0bGlnaHRzX2Zhc3QtcmVuZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IEZhc3RSZW5kZXIgPSB7XG5cdF9yb3V0ZXM6IFtdLFxuXHRfb25BbGxSb3V0ZXM6IFtdLFxufVxuIiwiaW1wb3J0IHsgUm91dGVQb2xpY3kgfSBmcm9tICdtZXRlb3Ivcm91dGVwb2xpY3knXG5cbi8vIG1ldGVvciBhbGdvcml0aG0gdG8gY2hlY2sgaWYgdGhpcyBpcyBhIG1ldGVvciBzZXJ2aW5nIGh0dHAgcmVxdWVzdCBvciBub3RcbmV4cG9ydCBjb25zdCBJc0FwcFVybCA9IGZ1bmN0aW9uKHJlcSkge1xuXHR2YXIgdXJsID0gcmVxLnVybFxuXHRpZiAodXJsID09PSAnL2Zhdmljb24uaWNvJyB8fCB1cmwgPT09ICcvcm9ib3RzLnR4dCcpIHtcblx0XHRyZXR1cm4gZmFsc2Vcblx0fVxuXG5cdC8vIE5PVEU6IGFwcC5tYW5pZmVzdCBpcyBub3QgYSB3ZWIgc3RhbmRhcmQgbGlrZSBmYXZpY29uLmljbyBhbmRcblx0Ly8gcm9ib3RzLnR4dC4gSXQgaXMgYSBmaWxlIG5hbWUgd2UgaGF2ZSBjaG9zZW4gdG8gdXNlIGZvciBIVE1MNVxuXHQvLyBhcHBjYWNoZSBVUkxzLiBJdCBpcyBpbmNsdWRlZCBoZXJlIHRvIHByZXZlbnQgdXNpbmcgYW4gYXBwY2FjaGVcblx0Ly8gdGhlbiByZW1vdmluZyBpdCBmcm9tIHBvaXNvbmluZyBhbiBhcHAgcGVybWFuZW50bHkuIEV2ZW50dWFsbHksXG5cdC8vIG9uY2Ugd2UgaGF2ZSBzZXJ2ZXIgc2lkZSByb3V0aW5nLCB0aGlzIHdvbid0IGJlIG5lZWRlZCBhc1xuXHQvLyB1bmtub3duIFVSTHMgd2l0aCByZXR1cm4gYSA0MDQgYXV0b21hdGljYWxseS5cblx0aWYgKHVybCA9PT0gJy9hcHAubWFuaWZlc3QnKSB7XG5cdFx0cmV0dXJuIGZhbHNlXG5cdH1cblxuXHQvLyBBdm9pZCBzZXJ2aW5nIGFwcCBIVE1MIGZvciBkZWNsYXJlZCByb3V0ZXMgc3VjaCBhcyAvc29ja2pzLy5cblx0aWYgKFJvdXRlUG9saWN5LmNsYXNzaWZ5KHVybCkpIHtcblx0XHRyZXR1cm4gZmFsc2Vcblx0fVxuXG5cdC8vIHdlIG9ubHkgbmVlZCB0byBzdXBwb3J0IEhUTUwgcGFnZXMgb25seVxuXHQvLyB0aGlzIGlzIGEgY2hlY2sgdG8gZG8gaXRcblx0cmV0dXJuIC9odG1sLy50ZXN0KHJlcS5oZWFkZXJzWydhY2NlcHQnXSlcbn1cbiIsImltcG9ydCBGaWJlciBmcm9tICdmaWJlcnMnXG5pbXBvcnQgeyBGYXN0UmVuZGVyIH0gZnJvbSAnLi9uYW1lc3BhY2UnXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUGlja2VyIH0gZnJvbSAnbWV0ZW9yL21ldGVvcmhhY2tzOnBpY2tlcidcbmltcG9ydCB7IEluamVjdERhdGEgfSBmcm9tICdtZXRlb3Ivc3RhcmluZ2F0bGlnaHRzOmluamVjdC1kYXRhJ1xuaW1wb3J0IFB1Ymxpc2hDb250ZXh0IGZyb20gJy4vcHVibGlzaF9jb250ZXh0J1xuaW1wb3J0IHsgSXNBcHBVcmwgfSBmcm9tICcuL3V0aWxzJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IGNvb2tpZVBhcnNlciBmcm9tICdjb29raWUtcGFyc2VyJ1xuXG5GYXN0UmVuZGVyLl9vbkFsbFJvdXRlcyA9IFtdXG5GYXN0UmVuZGVyLmZyQ29udGV4dCA9IG5ldyBNZXRlb3IuRW52aXJvbm1lbnRWYXJpYWJsZSgpXG5cbnZhciBmYXN0UmVuZGVyUm91dGVzID0gUGlja2VyLmZpbHRlcihmdW5jdGlvbihyZXEsIHJlcykge1xuXHRyZXR1cm4gSXNBcHBVcmwocmVxKVxufSlcbmZhc3RSZW5kZXJSb3V0ZXMubWlkZGxld2FyZShjb29raWVQYXJzZXIoKSlcbmZhc3RSZW5kZXJSb3V0ZXMubWlkZGxld2FyZShmdW5jdGlvbihyZXEsIHJlcywgbmV4dCkge1xuXHRGYXN0UmVuZGVyLmhhbmRsZU9uQWxsUm91dGVzKHJlcSwgcmVzLCBuZXh0KVxufSlcblxuLy8gaGFuZGxpbmcgc3BlY2lmaWMgcm91dGVzXG5GYXN0UmVuZGVyLnJvdXRlID0gZnVuY3Rpb24gcm91dGUocGF0aCwgY2FsbGJhY2spIHtcblx0aWYgKHBhdGguaW5kZXhPZignLycpICE9PSAwKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKFxuXHRcdFx0J0Vycm9yOiBwYXRoICgnICsgcGF0aCArICcpIG11c3QgYmVnaW4gd2l0aCBhIGxlYWRpbmcgc2xhc2ggXCIvXCInXG5cdFx0KVxuXHR9XG5cdGZhc3RSZW5kZXJSb3V0ZXMucm91dGUocGF0aCwgRmFzdFJlbmRlci5oYW5kbGVSb3V0ZS5iaW5kKG51bGwsIGNhbGxiYWNrKSlcbn1cblxuZnVuY3Rpb24gc2V0UXVlcnlEYXRhQ2FsbGJhY2socmVxLCBuZXh0KSB7XG5cdHJldHVybiBmdW5jdGlvbihxdWVyeURhdGEpIHtcblx0XHRpZiAoIXF1ZXJ5RGF0YSkgcmV0dXJuIG5leHQoKVxuXG5cdFx0dmFyIGV4aXN0aW5nUGF5bG9hZCA9IEluamVjdERhdGEuZ2V0RGF0YShyZXEsICdmYXN0LXJlbmRlci1kYXRhJylcblx0XHRpZiAoIWV4aXN0aW5nUGF5bG9hZCkge1xuXHRcdFx0SW5qZWN0RGF0YS5wdXNoRGF0YShyZXEsICdmYXN0LXJlbmRlci1kYXRhJywgcXVlcnlEYXRhKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBpdCdzIHBvc3NpYmxlIHRvIGV4ZWN1dGUgdGhpcyBjYWxsYmFjayB0d2ljZVxuXHRcdFx0Ly8gdGhlIHdlIG5lZWQgdG8gbWVyZ2UgZXhpc2l0bmcgZGF0YSB3aXRoIHRoZSBuZXcgb25lXG5cdFx0XHRfLmV4dGVuZChleGlzdGluZ1BheWxvYWQuc3Vic2NyaXB0aW9ucywgcXVlcnlEYXRhLnN1YnNjcmlwdGlvbnMpXG5cdFx0XHRfLmVhY2gocXVlcnlEYXRhLmNvbGxlY3Rpb25EYXRhLCBmdW5jdGlvbihkYXRhLCBwdWJOYW1lKSB7XG5cdFx0XHRcdHZhciBleGlzdGluZ0RhdGEgPSBleGlzdGluZ1BheWxvYWQuY29sbGVjdGlvbkRhdGFbcHViTmFtZV1cblx0XHRcdFx0aWYgKGV4aXN0aW5nRGF0YSkge1xuXHRcdFx0XHRcdGRhdGEgPSBleGlzdGluZ0RhdGEuY29uY2F0KGRhdGEpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRleGlzdGluZ1BheWxvYWQuY29sbGVjdGlvbkRhdGFbcHViTmFtZV0gPSBkYXRhXG5cdFx0XHRcdEluamVjdERhdGEucHVzaERhdGEocmVxLCAnZmFzdC1yZW5kZXItZGF0YScsIGV4aXN0aW5nUGF5bG9hZClcblx0XHRcdH0pXG5cdFx0fVxuXHRcdG5leHQoKVxuXHR9XG59XG5cbkZhc3RSZW5kZXIuaGFuZGxlUm91dGUgPSBmdW5jdGlvbihwcm9jZXNzaW5nQ2FsbGJhY2ssIHBhcmFtcywgcmVxLCByZXMsIG5leHQpIHtcblx0dmFyIGFmdGVyUHJvY2Vzc2VkID0gc2V0UXVlcnlEYXRhQ2FsbGJhY2socmVxLCBuZXh0KVxuXHRGYXN0UmVuZGVyLl9wcm9jZXNzUm91dGVzKHBhcmFtcywgcmVxLCBwcm9jZXNzaW5nQ2FsbGJhY2ssIGFmdGVyUHJvY2Vzc2VkKVxufVxuXG5GYXN0UmVuZGVyLmhhbmRsZU9uQWxsUm91dGVzID0gZnVuY3Rpb24ocmVxLCByZXMsIG5leHQpIHtcblx0dmFyIGFmdGVyUHJvY2Vzc2VkID0gc2V0UXVlcnlEYXRhQ2FsbGJhY2socmVxLCBuZXh0KVxuXHRGYXN0UmVuZGVyLl9wcm9jZXNzQWxsUm91dGVzKHJlcSwgYWZ0ZXJQcm9jZXNzZWQpXG59XG5cbkZhc3RSZW5kZXIub25BbGxSb3V0ZXMgPSBmdW5jdGlvbiBvbkFsbFJvdXRlcyhjYWxsYmFjaykge1xuXHRGYXN0UmVuZGVyLl9vbkFsbFJvdXRlcy5wdXNoKGNhbGxiYWNrKVxufVxuXG5GYXN0UmVuZGVyLl9wcm9jZXNzUm91dGVzID0gZnVuY3Rpb24gX3Byb2Nlc3NSb3V0ZXMoXG5cdHBhcmFtcyxcblx0cmVxLFxuXHRyb3V0ZUNhbGxiYWNrLFxuXHRjYWxsYmFja1xuKSB7XG5cdGNhbGxiYWNrID0gY2FsbGJhY2sgfHwgZnVuY3Rpb24oKSB7fVxuXG5cdHZhciBwYXRoID0gcmVxLnVybFxuXHR2YXIgbG9naW5Ub2tlbiA9IHJlcS5jb29raWVzWydtZXRlb3JfbG9naW5fdG9rZW4nXVxuXHR2YXIgaGVhZGVycyA9IHJlcS5oZWFkZXJzXG5cblx0dmFyIGNvbnRleHQgPSBuZXcgRmFzdFJlbmRlci5fQ29udGV4dChsb2dpblRva2VuLCB7IGhlYWRlcnM6IGhlYWRlcnMgfSlcblxuXHR0cnkge1xuXHRcdEZhc3RSZW5kZXIuZnJDb250ZXh0LndpdGhWYWx1ZShjb250ZXh0LCBmdW5jdGlvbigpIHtcblx0XHRcdHJvdXRlQ2FsbGJhY2suY2FsbChjb250ZXh0LCBwYXJhbXMsIHBhdGgpXG5cdFx0fSlcblxuXHRcdGlmIChjb250ZXh0LnN0b3ApIHtcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNhbGxiYWNrKGNvbnRleHQuZ2V0RGF0YSgpKVxuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRoYW5kbGVFcnJvcihlcnIsIHBhdGgsIGNhbGxiYWNrKVxuXHR9XG59XG5cbkZhc3RSZW5kZXIuX3Byb2Nlc3NBbGxSb3V0ZXMgPSBmdW5jdGlvbiBfcHJvY2Vzc0FsbFJvdXRlcyhyZXEsIGNhbGxiYWNrKSB7XG5cdGNhbGxiYWNrID0gY2FsbGJhY2sgfHwgZnVuY3Rpb24oKSB7fVxuXG5cdHZhciBwYXRoID0gcmVxLnVybFxuXHR2YXIgbG9naW5Ub2tlbiA9IHJlcS5jb29raWVzWydtZXRlb3JfbG9naW5fdG9rZW4nXVxuXHR2YXIgaGVhZGVycyA9IHJlcS5oZWFkZXJzXG5cblx0bmV3IEZpYmVyKGZ1bmN0aW9uKCkge1xuXHRcdHZhciBjb250ZXh0ID0gbmV3IEZhc3RSZW5kZXIuX0NvbnRleHQobG9naW5Ub2tlbiwgeyBoZWFkZXJzOiBoZWFkZXJzIH0pXG5cblx0XHR0cnkge1xuXHRcdFx0RmFzdFJlbmRlci5fb25BbGxSb3V0ZXMuZm9yRWFjaChmdW5jdGlvbihjYWxsYmFjaykge1xuXHRcdFx0XHRjYWxsYmFjay5jYWxsKGNvbnRleHQsIHJlcS51cmwpXG5cdFx0XHR9KVxuXG5cdFx0XHRjYWxsYmFjayhjb250ZXh0LmdldERhdGEoKSlcblx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdGhhbmRsZUVycm9yKGVyciwgcGF0aCwgY2FsbGJhY2spXG5cdFx0fVxuXHR9KS5ydW4oKVxufVxuXG5mdW5jdGlvbiBoYW5kbGVFcnJvcihlcnIsIHBhdGgsIGNhbGxiYWNrKSB7XG5cdHZhciBtZXNzYWdlID1cblx0XHQnZXJyb3Igb24gZmFzdC1yZW5kZXJpbmcgcGF0aDogJyArIHBhdGggKyAnIDsgZXJyb3I6ICcgKyBlcnIuc3RhY2tcblx0Y29uc29sZS5lcnJvcihtZXNzYWdlKVxuXHRjYWxsYmFjayhudWxsKVxufVxuXG4vLyBhZGRpbmcgc3VwcG9ydCBmb3IgbnVsbCBwdWJsaWNhdGlvbnNcbkZhc3RSZW5kZXIub25BbGxSb3V0ZXMoZnVuY3Rpb24oKSB7XG5cdHZhciBjb250ZXh0ID0gdGhpc1xuXHR2YXIgbnVsbEhhbmRsZXJzID0gTWV0ZW9yLmRlZmF1bHRfc2VydmVyLnVuaXZlcnNhbF9wdWJsaXNoX2hhbmRsZXJzXG5cblx0aWYgKG51bGxIYW5kbGVycykge1xuXHRcdG51bGxIYW5kbGVycy5mb3JFYWNoKGZ1bmN0aW9uKHB1Ymxpc2hIYW5kbGVyKSB7XG5cdFx0XHQvLyB1bml2ZXJzYWwgc3VicyBoYXZlIHN1YnNjcmlwdGlvbiBJRCwgcGFyYW1zLCBhbmQgbmFtZSB1bmRlZmluZWRcblx0XHRcdHZhciBwdWJsaXNoQ29udGV4dCA9IG5ldyBQdWJsaXNoQ29udGV4dChjb250ZXh0LCBwdWJsaXNoSGFuZGxlcilcblx0XHRcdGNvbnRleHQucHJvY2Vzc1B1YmxpY2F0aW9uKHB1Ymxpc2hDb250ZXh0KVxuXHRcdH0pXG5cdH1cbn0pXG4iLCJpbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgRUpTT04gfSBmcm9tICdtZXRlb3IvZWpzb24nXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgTWV0ZW9yWCB9IGZyb20gJ21ldGVvci9sYW1oaWV1Om1ldGVvcngnXG5cbmNvbnN0IFB1Ymxpc2hDb250ZXh0ID0gZnVuY3Rpb24gUHVibGlzaENvbnRleHQoXG5cdGNvbnRleHQsXG5cdGhhbmRsZXIsXG5cdHN1YnNjcmlwdGlvbklkLFxuXHRwYXJhbXMsXG5cdG5hbWVcbikge1xuXHR2YXIgc2VsZiA9IHRoaXNcblxuXHQvLyBtb2NrIHNlc3Npb25cblx0dmFyIHNlc3Npb25JZCA9IFJhbmRvbS5pZCgpXG5cdHZhciBzZXNzaW9uID0ge1xuXHRcdGlkOiBzZXNzaW9uSWQsXG5cdFx0dXNlcklkOiBjb250ZXh0LnVzZXJJZCxcblx0XHQvLyBub3QgbnVsbFxuXHRcdGluUXVldWU6IHt9LFxuXHRcdGNvbm5lY3Rpb25IYW5kbGU6IHtcblx0XHRcdGlkOiBzZXNzaW9uSWQsXG5cdFx0XHRjbG9zZTogZnVuY3Rpb24oKSB7fSxcblx0XHRcdG9uQ2xvc2U6IGZ1bmN0aW9uKCkge30sXG5cdFx0XHRjbGllbnRBZGRyZXNzOiAnMTI3LjAuMC4xJyxcblx0XHRcdGh0dHBIZWFkZXJzOiBjb250ZXh0LmhlYWRlcnMsXG5cdFx0fSxcblx0XHRhZGRlZDogZnVuY3Rpb24oc3Vic2NyaXB0aW9uSGFuZGxlLCBjb2xsZWN0aW9uTmFtZSwgc3RySWQsIGZpZWxkcykge1xuXHRcdFx0Ly8gRG9uJ3Qgc2hhcmUgc3RhdGUgd2l0aCB0aGUgZGF0YSBwYXNzZWQgaW4gYnkgdGhlIHVzZXIuXG5cdFx0XHR2YXIgZG9jID0gRUpTT04uY2xvbmUoZmllbGRzKVxuXHRcdFx0ZG9jLl9pZCA9IHNlbGYuX2lkRmlsdGVyLmlkUGFyc2Uoc3RySWQpXG5cdFx0XHRNZXRlb3IuX2Vuc3VyZShzZWxmLl9jb2xsZWN0aW9uRGF0YSwgY29sbGVjdGlvbk5hbWUpW3N0cklkXSA9IGRvY1xuXHRcdH0sXG5cdFx0Y2hhbmdlZDogZnVuY3Rpb24oc3Vic2NyaXB0aW9uSGFuZGxlLCBjb2xsZWN0aW9uTmFtZSwgc3RySWQsIGZpZWxkcykge1xuXHRcdFx0dmFyIGRvYyA9IHNlbGYuX2NvbGxlY3Rpb25EYXRhW2NvbGxlY3Rpb25OYW1lXVtzdHJJZF1cblx0XHRcdGlmICghZG9jKSB7XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcihcblx0XHRcdFx0XHQnQ291bGQgbm90IGZpbmQgZWxlbWVudCB3aXRoIGlkICcgKyBzdHJJZCArICcgdG8gY2hhbmdlJ1xuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRfLmVhY2goZmllbGRzLCBmdW5jdGlvbih2YWx1ZSwga2V5KSB7XG5cdFx0XHRcdC8vIFB1Ymxpc2ggQVBJIGlnbm9yZXMgX2lkIGlmIHByZXNlbnQgaW4gZmllbGRzLlxuXHRcdFx0XHRpZiAoa2V5ID09PSAnX2lkJykgcmV0dXJuXG5cblx0XHRcdFx0aWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRkZWxldGUgZG9jW2tleV1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHQvLyBEb24ndCBzaGFyZSBzdGF0ZSB3aXRoIHRoZSBkYXRhIHBhc3NlZCBpbiBieSB0aGUgdXNlci5cblx0XHRcdFx0XHRkb2Nba2V5XSA9IEVKU09OLmNsb25lKHZhbHVlKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0sXG5cdFx0cmVtb3ZlZDogZnVuY3Rpb24oc3Vic2NyaXB0aW9uSGFuZGxlLCBjb2xsZWN0aW9uTmFtZSwgc3RySWQpIHtcblx0XHRcdGlmIChcblx0XHRcdFx0IShcblx0XHRcdFx0XHRzZWxmLl9jb2xsZWN0aW9uRGF0YVtjb2xsZWN0aW9uTmFtZV0gJiZcblx0XHRcdFx0XHRzZWxmLl9jb2xsZWN0aW9uRGF0YVtjb2xsZWN0aW9uTmFtZV1bc3RySWRdXG5cdFx0XHRcdClcblx0XHRcdCkge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ1JlbW92ZWQgbm9uZXhpc3RlbnQgZG9jdW1lbnQgJyArIHN0cklkKVxuXHRcdFx0fVxuXHRcdFx0ZGVsZXRlIHNlbGYuX2NvbGxlY3Rpb25EYXRhW2NvbGxlY3Rpb25OYW1lXVtzdHJJZF1cblx0XHR9LFxuXHRcdHNlbmRSZWFkeTogZnVuY3Rpb24oc3Vic2NyaXB0aW9uSWRzKSB7XG5cdFx0XHQvLyB0aGlzIGlzIGNhbGxlZCBvbmx5IGZvciBub24tdW5pdmVyc2FsIHN1YnNjcmlwdGlvbnNcblx0XHRcdGlmICghc2VsZi5fc3Vic2NyaXB0aW9uSWQpIHRocm93IG5ldyBFcnJvcignQXNzZXJ0aW9uLicpXG5cblx0XHRcdC8vIG1ha2UgdGhlIHN1YnNjcmlwdGlvbiBiZSBtYXJrZWQgYXMgcmVhZHlcblx0XHRcdGlmICghc2VsZi5faXNEZWFjdGl2YXRlZCgpKSB7XG5cdFx0XHRcdHNlbGYuX2NvbnRleHQuY29tcGxldGVTdWJzY3JpcHRpb25zKHNlbGYuX25hbWUsIHNlbGYuX3BhcmFtcylcblx0XHRcdH1cblxuXHRcdFx0Ly8gd2UganVzdCBzdG9wIGl0XG5cdFx0XHRzZWxmLnN0b3AoKVxuXHRcdH0sXG5cdH1cblxuXHRNZXRlb3JYLlN1YnNjcmlwdGlvbi5jYWxsKFxuXHRcdHNlbGYsXG5cdFx0c2Vzc2lvbixcblx0XHRoYW5kbGVyLFxuXHRcdHN1YnNjcmlwdGlvbklkLFxuXHRcdHBhcmFtcyxcblx0XHRuYW1lXG5cdClcblxuXHRzZWxmLnVuYmxvY2sgPSBmdW5jdGlvbigpIHt9XG5cblx0c2VsZi5fY29udGV4dCA9IGNvbnRleHRcblx0c2VsZi5fY29sbGVjdGlvbkRhdGEgPSB7fVxufVxuXG5QdWJsaXNoQ29udGV4dC5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKE1ldGVvclguU3Vic2NyaXB0aW9uLnByb3RvdHlwZSlcblB1Ymxpc2hDb250ZXh0LnByb3RvdHlwZS5jb25zdHJ1Y3RvciA9IFB1Ymxpc2hDb250ZXh0XG5cblB1Ymxpc2hDb250ZXh0LnByb3RvdHlwZS5zdG9wID0gZnVuY3Rpb24oKSB7XG5cdC8vIG91ciBzdG9wIGRvZXMgbm90IHJlbW92ZSBhbGwgZG9jdW1lbnRzIChpdCBqdXN0IGNhbGxzIGRlYWN0aXZhdGUpXG5cdC8vIE1ldGVvciBvbmUgcmVtb3ZlcyBkb2N1bWVudHMgZm9yIG5vbi11bml2ZXJzYWwgc3Vic2NyaXB0aW9uXG5cdC8vIHdlIGRlYWN0aXZhdGUgYm90aCBmb3IgdW5pdmVyc2FsIGFuZCBuYW1lZCBzdWJzY3JpcHRpb25zXG5cdC8vIGhvcGVmdWxseSB0aGlzIGlzIHJpZ2h0IGluIG91ciBjYXNlXG5cdC8vIE1ldGVvciBkb2VzIGl0IGp1c3QgZm9yIG5hbWVkIHN1YnNjcmlwdGlvbnNcblx0dGhpcy5fZGVhY3RpdmF0ZSgpXG59XG5cblB1Ymxpc2hDb250ZXh0LnByb3RvdHlwZS5lcnJvciA9IGZ1bmN0aW9uKGVycm9yKSB7XG5cdC8vIFRPRE86IFNob3VsZCB3ZSBwYXNzIHRoZSBlcnJvciB0byB0aGUgc3Vic2NyaXB0aW9uIHNvbWVob3c/XG5cdGNvbnNvbGUud2Fybihcblx0XHQnZXJyb3IgY2F1Z2h0IG9uIHB1YmxpY2F0aW9uOiAnLFxuXHRcdHRoaXMuX25hbWUsXG5cdFx0JzogJyxcblx0XHRlcnJvci5tZXNzYWdlIHx8IGVycm9yXG5cdClcblx0dGhpcy5zdG9wKClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUHVibGlzaENvbnRleHRcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgRmliZXJzIGZyb20gJ2ZpYmVycydcbmltcG9ydCBGdXR1cmUgZnJvbSAnZmliZXJzL2Z1dHVyZSdcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnXG5pbXBvcnQgeyBERFAgfSBmcm9tICdtZXRlb3IvZGRwJ1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSdcbmltcG9ydCBQdWJsaXNoQ29udGV4dCBmcm9tICcuL3B1Ymxpc2hfY29udGV4dCdcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IEVKU09OIH0gZnJvbSAnbWV0ZW9yL2Vqc29uJ1xuaW1wb3J0IHsgRmFzdFJlbmRlciB9IGZyb20gJy4vbmFtZXNwYWNlJ1xuXG5jb25zdCBDb250ZXh0ID0gZnVuY3Rpb24gQ29udGV4dChsb2dpblRva2VuLCBvdGhlclBhcmFtcykge1xuXHR0aGlzLl9jb2xsZWN0aW9uRGF0YSA9IHt9XG5cdHRoaXMuX3N1YnNjcmlwdGlvbnMgPSB7fVxuXHR0aGlzLl9sb2dpblRva2VuID0gbG9naW5Ub2tlblxuXG5cdF8uZXh0ZW5kKHRoaXMsIG90aGVyUGFyYW1zKVxuXG5cdC8vIGdldCB0aGUgdXNlclxuXHRpZiAoTWV0ZW9yLnVzZXJzKSB7XG5cdFx0Ly8gY2hlY2sgdG8gbWFrZSBzdXJlLCB3ZSd2ZSB0aGUgbG9naW5Ub2tlbixcblx0XHQvLyBvdGhlcndpc2UgYSByYW5kb20gdXNlciB3aWxsIGZldGNoZWQgZnJvbSB0aGUgZGJcblx0XHRpZiAobG9naW5Ub2tlbikge1xuXHRcdFx0dmFyIGhhc2hlZFRva2VuID0gbG9naW5Ub2tlbiAmJiBBY2NvdW50cy5faGFzaExvZ2luVG9rZW4obG9naW5Ub2tlbilcblx0XHRcdHZhciBxdWVyeSA9IHsgJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucy5oYXNoZWRUb2tlbic6IGhhc2hlZFRva2VuIH1cblx0XHRcdHZhciBvcHRpb25zID0geyBmaWVsZHM6IHsgX2lkOiAxIH0gfVxuXHRcdFx0dmFyIHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZShxdWVyeSwgb3B0aW9ucylcblx0XHR9XG5cblx0XHQvLyBzdXBwb3J0IGZvciBNZXRlb3IudXNlclxuXHRcdEZpYmVycy5jdXJyZW50Ll9tZXRlb3JfZHluYW1pY3MgPSBbXVxuXHRcdEZpYmVycy5jdXJyZW50Ll9tZXRlb3JfZHluYW1pY3NbRERQLl9DdXJyZW50SW52b2NhdGlvbi5zbG90XSA9IHRoaXNcblxuXHRcdGlmICh1c2VyKSB7XG5cdFx0XHR0aGlzLnVzZXJJZCA9IHVzZXIuX2lkXG5cdFx0fVxuXHR9XG59XG5cbkNvbnRleHQucHJvdG90eXBlLnN1YnNjcmliZSA9IGZ1bmN0aW9uKHN1Yk5hbWUgLyosIHBhcmFtcyAqLykge1xuXHR2YXIgcHVibGlzaEhhbmRsZXIgPSBNZXRlb3IuZGVmYXVsdF9zZXJ2ZXIucHVibGlzaF9oYW5kbGVyc1tzdWJOYW1lXVxuXHRpZiAocHVibGlzaEhhbmRsZXIpIHtcblx0XHR2YXIgcGFyYW1zID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAxKVxuXHRcdC8vIG5vbi11bml2ZXJzYWwgc3VicyBoYXZlIHN1YnNjcmlwdGlvbiBpZFxuXHRcdHZhciBzdWJzY3JpcHRpb25JZCA9IFJhbmRvbS5pZCgpXG5cdFx0dmFyIHB1Ymxpc2hDb250ZXh0ID0gbmV3IFB1Ymxpc2hDb250ZXh0KFxuXHRcdFx0dGhpcyxcblx0XHRcdHB1Ymxpc2hIYW5kbGVyLFxuXHRcdFx0c3Vic2NyaXB0aW9uSWQsXG5cdFx0XHRwYXJhbXMsXG5cdFx0XHRzdWJOYW1lXG5cdFx0KVxuXG5cdFx0cmV0dXJuIHRoaXMucHJvY2Vzc1B1YmxpY2F0aW9uKHB1Ymxpc2hDb250ZXh0KVxuXHR9IGVsc2Uge1xuXHRcdGNvbnNvbGUud2FybignVGhlcmUgaXMgbm8gc3VjaCBwdWJsaXNoIGhhbmRsZXIgbmFtZWQ6Jywgc3ViTmFtZSlcblx0XHRyZXR1cm4ge31cblx0fVxufVxuXG5Db250ZXh0LnByb3RvdHlwZS5wcm9jZXNzUHVibGljYXRpb24gPSBmdW5jdGlvbihwdWJsaXNoQ29udGV4dCkge1xuXHR2YXIgc2VsZiA9IHRoaXNcblx0dmFyIGRhdGEgPSB7fVxuXHR2YXIgZW5zdXJlQ29sbGVjdGlvbiA9IGZ1bmN0aW9uKGNvbGxlY3Rpb25OYW1lKSB7XG5cdFx0c2VsZi5fZW5zdXJlQ29sbGVjdGlvbihjb2xsZWN0aW9uTmFtZSlcblx0XHRpZiAoIWRhdGFbY29sbGVjdGlvbk5hbWVdKSB7XG5cdFx0XHRkYXRhW2NvbGxlY3Rpb25OYW1lXSA9IFtdXG5cdFx0fVxuXHR9XG5cblx0dmFyIGZ1dHVyZSA9IG5ldyBGdXR1cmUoKVxuXHQvLyBkZXRlY3Qgd2hlbiB0aGUgY29udGV4dCBpcyByZWFkeSB0byBiZSBzZW50IHRvIHRoZSBjbGllbnRcblx0cHVibGlzaENvbnRleHQub25TdG9wKGZ1bmN0aW9uKCkge1xuXHRcdGlmICghZnV0dXJlLmlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0ZnV0dXJlLnJldHVybigpXG5cdFx0fVxuXHR9KVxuXG5cdHB1Ymxpc2hDb250ZXh0Ll9ydW5IYW5kbGVyKClcblxuXHRpZiAoIXB1Ymxpc2hDb250ZXh0Ll9zdWJzY3JpcHRpb25JZCkge1xuXHRcdC8vIHVuaXZlcnNhbCBzdWJzY3JpcHRpb24sIHdlIHN0b3AgaXQgKHNhbWUgYXMgbWFya2luZyBpdCBhcyByZWFkeSkgb3Vyc2VsdmVzXG5cdFx0Ly8gdGhleSBvdGhlcndpc2UgZG8gbm90IGhhdmUgcmVhZHkgb3Igc3RvcHBlZCBzdGF0ZSwgYnV0IGluIG91ciBjYXNlIHRoZXkgZG9cblx0XHRwdWJsaXNoQ29udGV4dC5zdG9wKClcblx0fVxuXG5cdGlmICghZnV0dXJlLmlzUmVzb2x2ZWQoKSkge1xuXHRcdC8vIGRvbid0IHdhaXQgZm9yZXZlciBmb3IgaGFuZGxlciB0byBmaXJlIHJlYWR5KClcblx0XHRNZXRlb3Iuc2V0VGltZW91dChmdW5jdGlvbigpIHtcblx0XHRcdGlmICghZnV0dXJlLmlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0XHQvLyBwdWJsaXNoIGhhbmRsZXIgZmFpbGVkIHRvIHNlbmQgcmVhZHkgc2lnbmFsIGluIHRpbWVcblx0XHRcdFx0Ly8gbWF5YmUgeW91ciBub24tdW5pdmVyc2FsIHB1Ymxpc2ggaGFuZGxlciBpcyBub3QgY2FsbGluZyB0aGlzLnJlYWR5KCk/XG5cdFx0XHRcdC8vIG9yIG1heWJlIGl0IGlzIHJldHVybmluZyBudWxsIHRvIHNpZ25hbCBlbXB0eSBwdWJsaXNoP1xuXHRcdFx0XHQvLyBpdCBzaG91bGQgc3RpbGwgY2FsbCB0aGlzLnJlYWR5KCkgb3IgcmV0dXJuIGFuIGVtcHR5IGFycmF5IFtdXG5cdFx0XHRcdHZhciBtZXNzYWdlID1cblx0XHRcdFx0XHQnUHVibGlzaCBoYW5kbGVyIGZvciAnICtcblx0XHRcdFx0XHRwdWJsaXNoQ29udGV4dC5fbmFtZSArXG5cdFx0XHRcdFx0JyBzZW50IG5vIHJlYWR5IHNpZ25hbFxcbicgK1xuXHRcdFx0XHRcdCcgVGhpcyBjb3VsZCBiZSBiZWNhdXNlIHRoaXMgcHVibGljYXRpb24gYHJldHVybiBudWxsYC5cXG4nICtcblx0XHRcdFx0XHQnIFVzZSBgcmV0dXJuIHRoaXMucmVhZHkoKWAgaW5zdGVhZC4nXG5cdFx0XHRcdGNvbnNvbGUud2FybihtZXNzYWdlKVxuXHRcdFx0XHRmdXR1cmUucmV0dXJuKClcblx0XHRcdH1cblx0XHR9LCA1MDApIC8vIGFyYml0cmFyaWFsbHkgc2V0IHRpbWVvdXQgdG8gNTAwbXMsIHNob3VsZCBwcm9iYWJseSBiZSBjb25maWd1cmFibGVcblxuXHRcdC8vICB3YWl0IGZvciB0aGUgc3Vic2NyaXB0aW9uIGJlY2FtZSByZWFkeS5cblx0XHRmdXR1cmUud2FpdCgpXG5cdH1cblxuXHQvLyBzdG9wIGFueSBydW5hd2F5IHN1YnNjcmlwdGlvblxuXHQvLyB0aGlzIGNhbiBoYXBwZW4gaWYgYSBwdWJsaXNoIGhhbmRsZXIgbmV2ZXIgY2FsbHMgcmVhZHkgb3Igc3RvcCwgZm9yIGV4YW1wbGVcblx0Ly8gaXQgZG9lcyBub3QgaHVydCB0byBjYWxsIGl0IG11bHRpcGxlIHRpbWVzXG5cdHB1Ymxpc2hDb250ZXh0LnN0b3AoKVxuXG5cdC8vIGdldCB0aGUgZGF0YVxuXHRfLmVhY2gocHVibGlzaENvbnRleHQuX2NvbGxlY3Rpb25EYXRhLCBmdW5jdGlvbihjb2xsRGF0YSwgY29sbGVjdGlvbk5hbWUpIHtcblx0XHQvLyBtYWtpbmcgYW4gYXJyYXkgZnJvbSBhIG1hcFxuXHRcdGNvbGxEYXRhID0gXy52YWx1ZXMoY29sbERhdGEpXG5cblx0XHRlbnN1cmVDb2xsZWN0aW9uKGNvbGxlY3Rpb25OYW1lKVxuXHRcdGRhdGFbY29sbGVjdGlvbk5hbWVdLnB1c2goY29sbERhdGEpXG5cblx0XHQvLyBjb3B5IHRoZSBjb2xsZWN0aW9uIGRhdGEgaW4gcHVibGlzaCBjb250ZXh0IGludG8gdGhlIEZSIGNvbnRleHRcblx0XHRzZWxmLl9jb2xsZWN0aW9uRGF0YVtjb2xsZWN0aW9uTmFtZV0ucHVzaChjb2xsRGF0YSlcblx0fSlcblxuXHRyZXR1cm4gZGF0YVxufVxuXG5Db250ZXh0LnByb3RvdHlwZS5jb21wbGV0ZVN1YnNjcmlwdGlvbnMgPSBmdW5jdGlvbihuYW1lLCBwYXJhbXMpIHtcblx0dmFyIHN1YnMgPSB0aGlzLl9zdWJzY3JpcHRpb25zW25hbWVdXG5cdGlmICghc3Vicykge1xuXHRcdHN1YnMgPSB0aGlzLl9zdWJzY3JpcHRpb25zW25hbWVdID0ge31cblx0fVxuXG5cdGlmIChwYXJhbXMgJiYgcGFyYW1zLmxlbmd0aCkge1xuXHRcdHZhciBsYXN0UGFyYW0gPSBwYXJhbXNbcGFyYW1zLmxlbmd0aCAtIDFdXG5cdFx0aWYgKFxuXHRcdFx0bGFzdFBhcmFtICYmXG5cdFx0XHQobGFzdFBhcmFtLmhhc093blByb3BlcnR5KCdvblN0b3AnKSB8fFxuXHRcdFx0XHRsYXN0UGFyYW0uaGFzT3duUHJvcGVydHkoJ29uUmVhZHknKSlcblx0XHQpIHtcblx0XHRcdHBhcmFtcy5wb3AoKVxuXHRcdH1cblx0fVxuXG5cdHN1YnNbRUpTT04uc3RyaW5naWZ5KHBhcmFtcyldID0gdHJ1ZVxufVxuXG5Db250ZXh0LnByb3RvdHlwZS5fZW5zdXJlQ29sbGVjdGlvbiA9IGZ1bmN0aW9uKGNvbGxlY3Rpb25OYW1lKSB7XG5cdGlmICghdGhpcy5fY29sbGVjdGlvbkRhdGFbY29sbGVjdGlvbk5hbWVdKSB7XG5cdFx0dGhpcy5fY29sbGVjdGlvbkRhdGFbY29sbGVjdGlvbk5hbWVdID0gW11cblx0fVxufVxuXG5Db250ZXh0LnByb3RvdHlwZS5nZXREYXRhID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiB7XG5cdFx0Y29sbGVjdGlvbkRhdGE6IHRoaXMuX2NvbGxlY3Rpb25EYXRhLFxuXHRcdHN1YnNjcmlwdGlvbnM6IHRoaXMuX3N1YnNjcmlwdGlvbnMsXG5cdFx0bG9naW5Ub2tlbjogdGhpcy5fbG9naW5Ub2tlbixcblx0fVxufVxuXG5GYXN0UmVuZGVyLl9Db250ZXh0ID0gQ29udGV4dFxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IEZhc3RSZW5kZXIgfSBmcm9tICdtZXRlb3Ivc3RhcmluZ2F0bGlnaHRzOmZhc3QtcmVuZGVyJ1xuaW1wb3J0IHsgSW5qZWN0RGF0YSB9IGZyb20gJ21ldGVvci9zdGFyaW5nYXRsaWdodHM6aW5qZWN0LWRhdGEnXG5pbXBvcnQgeyBvblBhZ2VMb2FkIH0gZnJvbSAnbWV0ZW9yL3NlcnZlci1yZW5kZXInXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5cbmNvbnN0IG9yaWdpbmFsU3Vic2NyaWJlID0gTWV0ZW9yLnN1YnNjcmliZVxuTWV0ZW9yLnN1YnNjcmliZSA9IGZ1bmN0aW9uKG5hbWUsIC4uLmFyZ3MpIHtcblx0Y29uc3QgZnJDb250ZXh0ID0gRmFzdFJlbmRlci5mckNvbnRleHQuZ2V0KClcblx0aWYgKCFmckNvbnRleHQpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoXG5cdFx0XHRgQ2Fubm90IGFkZCBhIHN1YnNjcmlwdGlvbjogJHtuYW1lfSB3aXRob3V0IEZhc3RSZW5kZXIgQ29udGV4dGBcblx0XHQpXG5cdH1cblx0ZnJDb250ZXh0LnN1YnNjcmliZShuYW1lLCAuLi5hcmdzKVxuXG5cdGlmIChvcmlnaW5hbFN1YnNjcmliZSkge1xuXHRcdG9yaWdpbmFsU3Vic2NyaWJlLmFwcGx5KHRoaXMsIGFyZ3VtZW50cylcblx0fVxuXG5cdHJldHVybiB7XG5cdFx0cmVhZHk6ICgpID0+IHRydWUsXG5cdH1cbn1cblxuRmFzdFJlbmRlci5fbWVyZ2VGckRhdGEgPSBmdW5jdGlvbihyZXEsIHF1ZXJ5RGF0YSkge1xuXHR2YXIgZXhpc3RpbmdQYXlsb2FkID0gSW5qZWN0RGF0YS5nZXREYXRhKHJlcSwgJ2Zhc3QtcmVuZGVyLWRhdGEnKVxuXHRpZiAoIWV4aXN0aW5nUGF5bG9hZCkge1xuXHRcdEluamVjdERhdGEucHVzaERhdGEocmVxLCAnZmFzdC1yZW5kZXItZGF0YScsIHF1ZXJ5RGF0YSlcblx0fSBlbHNlIHtcblx0XHQvLyBpdCdzIHBvc3NpYmxlIHRvIGV4ZWN1dGUgdGhpcyBjYWxsYmFjayB0d2ljZVxuXHRcdC8vIHRoZSB3ZSBuZWVkIHRvIG1lcmdlIGV4aXNpdG5nIGRhdGEgd2l0aCB0aGUgbmV3IG9uZVxuXHRcdF8uZXh0ZW5kKGV4aXN0aW5nUGF5bG9hZC5zdWJzY3JpcHRpb25zLCBxdWVyeURhdGEuc3Vic2NyaXB0aW9ucylcblx0XHRfLmVhY2gocXVlcnlEYXRhLmNvbGxlY3Rpb25EYXRhLCBmdW5jdGlvbihkYXRhLCBwdWJOYW1lKSB7XG5cdFx0XHR2YXIgZXhpc3RpbmdEYXRhID0gZXhpc3RpbmdQYXlsb2FkLmNvbGxlY3Rpb25EYXRhW3B1Yk5hbWVdXG5cdFx0XHRpZiAoZXhpc3RpbmdEYXRhKSB7XG5cdFx0XHRcdGRhdGEgPSBleGlzdGluZ0RhdGEuY29uY2F0KGRhdGEpXG5cdFx0XHR9XG5cblx0XHRcdGV4aXN0aW5nUGF5bG9hZC5jb2xsZWN0aW9uRGF0YVtwdWJOYW1lXSA9IGRhdGFcblx0XHRcdEluamVjdERhdGEucHVzaERhdGEocmVxLCAnZmFzdC1yZW5kZXItZGF0YScsIGV4aXN0aW5nUGF5bG9hZClcblx0XHR9KVxuXHR9XG59XG5cbkZhc3RSZW5kZXIub25QYWdlTG9hZCA9IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XG5cdEluamVjdERhdGEuaW5qZWN0VG9IZWFkID0gZmFsc2Vcblx0b25QYWdlTG9hZChhc3luYyBzaW5rID0+IHtcblx0XHRjb25zdCBmckNvbnRleHQgPSBuZXcgRmFzdFJlbmRlci5fQ29udGV4dChcblx0XHRcdHNpbmsucmVxdWVzdC5jb29raWVzLm1ldGVvcl9sb2dpbl90b2tlbixcblx0XHRcdHtcblx0XHRcdFx0aGVhZGVyczogc2luay5oZWFkZXJzLFxuXHRcdFx0fVxuXHRcdClcblxuXHRcdGF3YWl0IEZhc3RSZW5kZXIuZnJDb250ZXh0LndpdGhWYWx1ZShmckNvbnRleHQsIGFzeW5jIGZ1bmN0aW9uKCkge1xuXHRcdFx0YXdhaXQgY2FsbGJhY2soc2luaylcblx0XHRcdEZhc3RSZW5kZXIuX21lcmdlRnJEYXRhKFxuXHRcdFx0XHRzaW5rLnJlcXVlc3QsXG5cdFx0XHRcdEZhc3RSZW5kZXIuZnJDb250ZXh0LmdldCgpLmdldERhdGEoKVxuXHRcdFx0KVxuXHRcdH0pXG5cdH0pXG59XG4iXX0=
