(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var ActiveRoute = Package['zimme:active-route'].ActiveRoute;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, FlowRouterHelpers;

(function(){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// packages/arillo_flow-router-helpers/client/helpers.coffee                         //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
// check for subscriptions to be ready
var currentRouteName,
    currentRouteOption,
    func,
    helpers,
    isSubReady,
    name,
    param,
    pathFor,
    queryParam,
    subsReady,
    urlFor,
    hasProp = {}.hasOwnProperty;

subsReady = function (...subs) {
  if (subs.length === 1) {
    return FlowRouter.subsReady();
  }

  subs = subs.slice(0, subs.length - 1);
  return _.reduce(subs, function (memo, sub) {
    return memo && FlowRouter.subsReady(sub);
  }, true);
}; // return path


pathFor = function (path, view = {
  hash: {}
}) {
  var hashBang, query, ref;

  if (!path) {
    throw new Error('no path defined');
  }

  if (!view.hash) {
    // set if run on server
    view = {
      hash: view
    };
  }

  if (((ref = path.hash) != null ? ref.route : void 0) != null) {
    view = path;
    path = view.hash.route;
    delete view.hash.route;
  }

  query = view.hash.query ? FlowRouter._qs.parse(view.hash.query) : {};
  hashBang = view.hash.hash ? view.hash.hash : '';
  return FlowRouter.path(path, view.hash, query) + (hashBang ? `#${hashBang}` : '');
}; // return absolute url


urlFor = function (path, view) {
  var relativePath;
  relativePath = pathFor(path, view);
  return Meteor.absoluteUrl(relativePath.substr(1));
}; // get parameter


param = function (name) {
  return FlowRouter.getParam(name);
};

queryParam = function (key) {
  return FlowRouter.getQueryParam(key);
};

currentRouteName = function () {
  return FlowRouter.getRouteName();
}; // get current route options


currentRouteOption = function (optionName) {
  return FlowRouter.current().route.options[optionName];
}; // deprecated


isSubReady = function (sub) {
  if (sub) {
    return FlowRouter.subsReady(sub);
  }

  return FlowRouter.subsReady();
};

helpers = {
  subsReady: subsReady,
  pathFor: pathFor,
  urlFor: urlFor,
  param: param,
  queryParam: queryParam,
  currentRouteName: currentRouteName,
  isSubReady: isSubReady,
  currentRouteOption: currentRouteOption
};

if (Meteor.isClient) {
  for (name in helpers) {
    if (!hasProp.call(helpers, name)) continue;
    func = helpers[name];
    Template.registerHelper(name, func);
  }
}

if (Meteor.isServer) {
  FlowRouterHelpers = {
    pathFor: pathFor,
    urlFor: urlFor
  };
}
///////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("arillo:flow-router-helpers", {
  FlowRouterHelpers: FlowRouterHelpers
});

})();

//# sourceURL=meteor://💻app/packages/arillo_flow-router-helpers.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYXJpbGxvX2Zsb3ctcm91dGVyLWhlbHBlcnMvY2xpZW50L2hlbHBlcnMuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9jbGllbnQvaGVscGVycy5jb2ZmZWUiXSwibmFtZXMiOlsiY3VycmVudFJvdXRlTmFtZSIsImN1cnJlbnRSb3V0ZU9wdGlvbiIsImZ1bmMiLCJoZWxwZXJzIiwiaXNTdWJSZWFkeSIsIm5hbWUiLCJwYXJhbSIsInBhdGhGb3IiLCJxdWVyeVBhcmFtIiwic3Vic1JlYWR5IiwidXJsRm9yIiwiaGFzUHJvcCIsImhhc093blByb3BlcnR5Iiwic3VicyIsImxlbmd0aCIsIkZsb3dSb3V0ZXIiLCJzbGljZSIsIl8iLCJyZWR1Y2UiLCJtZW1vIiwic3ViIiwicGF0aCIsInZpZXciLCJoYXNoIiwiaGFzaEJhbmciLCJxdWVyeSIsInJlZiIsIkVycm9yIiwicm91dGUiLCJfcXMiLCJwYXJzZSIsInJlbGF0aXZlUGF0aCIsIk1ldGVvciIsImFic29sdXRlVXJsIiwic3Vic3RyIiwiZ2V0UGFyYW0iLCJrZXkiLCJnZXRRdWVyeVBhcmFtIiwiZ2V0Um91dGVOYW1lIiwib3B0aW9uTmFtZSIsImN1cnJlbnQiLCJvcHRpb25zIiwiaXNDbGllbnQiLCJjYWxsIiwiVGVtcGxhdGUiLCJyZWdpc3RlckhlbHBlciIsImlzU2VydmVyIiwiRmxvd1JvdXRlckhlbHBlcnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUEsSUFBQUEsZ0JBQUE7QUFBQSxJQUFBQyxrQkFBQTtBQUFBLElBQUFDLElBQUE7QUFBQSxJQUFBQyxPQUFBO0FBQUEsSUFBQUMsVUFBQTtBQUFBLElBQUFDLElBQUE7QUFBQSxJQUFBQyxLQUFBO0FBQUEsSUFBQUMsT0FBQTtBQUFBLElBQUFDLFVBQUE7QUFBQSxJQUFBQyxTQUFBO0FBQUEsSUFBQUMsTUFBQTtBQUFBLElBQUFDLE9BQUEsTUFBQUMsY0FBQTs7QUFDQUgsU0FBQSxHQUFZLGFBQUNJLElBQUQ7QUFDVixNQUFpQ0EsSUFBSSxDQUFDQyxNQUFMLEtBQWUsQ0FBaEQ7QUFBQSxXQUFPQyxVQUFVLENBQUNOLFNBQVgsRUFBUDtBQ0tDOztBREpESSxNQUFBLEdBQU9BLElBQUksQ0FBQ0csS0FBTCxDQUFXLENBQVgsRUFBY0gsSUFBSSxDQUFDQyxNQUFMLEdBQWMsQ0FBNUIsQ0FBUDtBQ01BLFNETEFHLENBQUMsQ0FBQ0MsTUFBRixDQUFTTCxJQUFULEVBQWUsVUFBQ00sSUFBRCxFQUFPQyxHQUFQO0FDTWIsV0RMQUQsSUFBQSxJQUFTSixVQUFVLENBQUNOLFNBQVgsQ0FBcUJXLEdBQXJCLENDS1Q7QURORixLQUVFLElBRkYsQ0NLQTtBRFJVLENBQVosQyxDQ2FBOzs7QURMQWIsT0FBQSxHQUFVLFVBQUNjLElBQUQsRUFBT0MsSUFBQSxHQUFPO0FBQUNDLE1BQUEsRUFBSztBQUFOLENBQWQ7QUFDUixNQUFBQyxRQUFBLEVBQUFDLEtBQUEsRUFBQUMsR0FBQTs7QUFBQSxPQUEwQ0wsSUFBMUM7QUFBQSxVQUFNLElBQUlNLEtBQUosQ0FBVSxpQkFBVixDQUFOO0FDV0M7O0FEVEQsT0FBeUJMLElBQUksQ0FBQ0MsSUFBOUI7QUNXRTtBRFhGRCxRQUFBLEdBQU87QUFBQUMsVUFBQSxFQUFNRDtBQUFOLEtBQVA7QUNlQzs7QURkRCxNQUFHLEVBQUFJLEdBQUEsR0FBQUwsSUFBQSxDQUFBRSxJQUFBLFlBQUFHLEdBQUEsQ0FBQUUsS0FBQSxrQkFBSDtBQUNFTixRQUFBLEdBQU9ELElBQVA7QUFDQUEsUUFBQSxHQUFPQyxJQUFJLENBQUNDLElBQUwsQ0FBVUssS0FBakI7QUFDQSxXQUFPTixJQUFJLENBQUNDLElBQUwsQ0FBVUssS0FBakI7QUNnQkQ7O0FEZkRILE9BQUEsR0FBV0gsSUFBSSxDQUFDQyxJQUFMLENBQVVFLEtBQVYsR0FBcUJWLFVBQVUsQ0FBQ2MsR0FBWCxDQUFlQyxLQUFmLENBQXFCUixJQUFJLENBQUNDLElBQUwsQ0FBVUUsS0FBL0IsQ0FBckIsR0FBZ0UsRUFBM0U7QUFDQUQsVUFBQSxHQUFjRixJQUFJLENBQUNDLElBQUwsQ0FBVUEsSUFBVixHQUFvQkQsSUFBSSxDQUFDQyxJQUFMLENBQVVBLElBQTlCLEdBQXdDLEVBQXREO0FDaUJBLFNEaEJBUixVQUFVLENBQUNNLElBQVgsQ0FBZ0JBLElBQWhCLEVBQXNCQyxJQUFJLENBQUNDLElBQTNCLEVBQWlDRSxLQUFqQyxLQUE4Q0QsUUFBSCxHQUFpQixJQUFJQSxRQUFKLEVBQWpCLEdBQXFDLEVBQWhGLENDZ0JBO0FEMUJRLENBQVYsQyxDQzZCQTs7O0FEaEJBZCxNQUFBLEdBQVMsVUFBQ1csSUFBRCxFQUFPQyxJQUFQO0FBQ1AsTUFBQVMsWUFBQTtBQUFBQSxjQUFBLEdBQWV4QixPQUFBLENBQVFjLElBQVIsRUFBY0MsSUFBZCxDQUFmO0FDbUJBLFNEbEJBVSxNQUFNLENBQUNDLFdBQVAsQ0FBbUJGLFlBQVksQ0FBQ0csTUFBYixDQUFvQixDQUFwQixDQUFuQixDQ2tCQTtBRHBCTyxDQUFULEMsQ0N1QkE7OztBRGxCQTVCLEtBQUEsR0FBUSxVQUFDRCxJQUFEO0FDb0JOLFNEbkJBVSxVQUFVLENBQUNvQixRQUFYLENBQW9COUIsSUFBcEIsQ0NtQkE7QURwQk0sQ0FBUjs7QUFJQUcsVUFBQSxHQUFhLFVBQUM0QixHQUFEO0FDb0JYLFNEbkJBckIsVUFBVSxDQUFDc0IsYUFBWCxDQUF5QkQsR0FBekIsQ0NtQkE7QURwQlcsQ0FBYjs7QUFJQXBDLGdCQUFBLEdBQW1CO0FDb0JqQixTRG5CQWUsVUFBVSxDQUFDdUIsWUFBWCxFQ21CQTtBRHBCaUIsQ0FBbkIsQyxDQ3VCQTs7O0FEbkJBckMsa0JBQUEsR0FBcUIsVUFBQ3NDLFVBQUQ7QUNxQm5CLFNEcEJBeEIsVUFBVSxDQUFDeUIsT0FBWCxHQUFxQlosS0FBckIsQ0FBMkJhLE9BQTNCLENBQW1DRixVQUFuQyxDQ29CQTtBRHJCbUIsQ0FBckIsQyxDQ3dCQTs7O0FEcEJBbkMsVUFBQSxHQUFhLFVBQUNnQixHQUFEO0FBQ1gsTUFBb0NBLEdBQXBDO0FBQUEsV0FBT0wsVUFBVSxDQUFDTixTQUFYLENBQXFCVyxHQUFyQixDQUFQO0FDdUJDOztBRHRCRCxTQUFPTCxVQUFVLENBQUNOLFNBQVgsRUFBUDtBQUZXLENBQWI7O0FBSUFOLE9BQUEsR0FDRTtBQUFBTSxXQUFBLEVBQVdBLFNBQVg7QUFDQUYsU0FBQSxFQUFTQSxPQURUO0FBRUFHLFFBQUEsRUFBUUEsTUFGUjtBQUdBSixPQUFBLEVBQU9BLEtBSFA7QUFJQUUsWUFBQSxFQUFZQSxVQUpaO0FBS0FSLGtCQUFBLEVBQWtCQSxnQkFMbEI7QUFNQUksWUFBQSxFQUFZQSxVQU5aO0FBT0FILG9CQUFBLEVBQW9CQTtBQVBwQixDQURGOztBQVVBLElBQUcrQixNQUFNLENBQUNVLFFBQVY7QUFDcUMsT0FBQXJDLElBQUEsSUFBQUYsT0FBQTtBQzBCakMsUUFBSSxDQUFDUSxPQUFPLENBQUNnQyxJQUFSLENBQWF4QyxPQUFiLEVBQXNCRSxJQUF0QixDQUFMLEVBQWtDO0FBQ2xDSCxRQUFJLEdBQUdDLE9BQU8sQ0FBQ0UsSUFBRCxDQUFkO0FEM0JGdUMsWUFBUSxDQUFDQyxjQUFULENBQXdCeEMsSUFBeEIsRUFBOEJILElBQTlCO0FBREY7QUMrQkM7O0FENUJELElBQUc4QixNQUFNLENBQUNjLFFBQVY7QUFDRUMsbUJBQUEsR0FDRTtBQUFBeEMsV0FBQSxFQUFTQSxPQUFUO0FBQ0FHLFVBQUEsRUFBUUE7QUFEUixHQURGO0FDa0NELEMiLCJmaWxlIjoiL3BhY2thZ2VzL2FyaWxsb19mbG93LXJvdXRlci1oZWxwZXJzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIyBjaGVjayBmb3Igc3Vic2NyaXB0aW9ucyB0byBiZSByZWFkeVxuc3Vic1JlYWR5ID0gKHN1YnMuLi4pIC0+XG4gIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeSgpIGlmIHN1YnMubGVuZ3RoIGlzIDFcbiAgc3VicyA9IHN1YnMuc2xpY2UoMCwgc3Vicy5sZW5ndGggLSAxKVxuICBfLnJlZHVjZSBzdWJzLCAobWVtbywgc3ViKSAtPlxuICAgIG1lbW8gYW5kIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KHN1YilcbiAgLCB0cnVlXG5cbiMgcmV0dXJuIHBhdGhcbnBhdGhGb3IgPSAocGF0aCwgdmlldyA9IHtoYXNoOnt9fSkgLT5cbiAgdGhyb3cgbmV3IEVycm9yKCdubyBwYXRoIGRlZmluZWQnKSB1bmxlc3MgcGF0aFxuICAjIHNldCBpZiBydW4gb24gc2VydmVyXG4gIHZpZXcgPSBoYXNoOiB2aWV3IHVubGVzcyB2aWV3Lmhhc2hcbiAgaWYgcGF0aC5oYXNoPy5yb3V0ZT9cbiAgICB2aWV3ID0gcGF0aFxuICAgIHBhdGggPSB2aWV3Lmhhc2gucm91dGVcbiAgICBkZWxldGUgdmlldy5oYXNoLnJvdXRlXG4gIHF1ZXJ5ID0gaWYgdmlldy5oYXNoLnF1ZXJ5IHRoZW4gRmxvd1JvdXRlci5fcXMucGFyc2Uodmlldy5oYXNoLnF1ZXJ5KSBlbHNlIHt9XG4gIGhhc2hCYW5nID0gaWYgdmlldy5oYXNoLmhhc2ggdGhlbiB2aWV3Lmhhc2guaGFzaCBlbHNlICcnXG4gIEZsb3dSb3V0ZXIucGF0aChwYXRoLCB2aWV3Lmhhc2gsIHF1ZXJ5KSArIChpZiBoYXNoQmFuZyB0aGVuIFwiIyN7aGFzaEJhbmd9XCIgZWxzZSAnJylcblxuIyByZXR1cm4gYWJzb2x1dGUgdXJsXG51cmxGb3IgPSAocGF0aCwgdmlldykgLT5cbiAgcmVsYXRpdmVQYXRoID0gcGF0aEZvcihwYXRoLCB2aWV3KVxuICBNZXRlb3IuYWJzb2x1dGVVcmwocmVsYXRpdmVQYXRoLnN1YnN0cigxKSlcblxuIyBnZXQgcGFyYW1ldGVyXG5wYXJhbSA9IChuYW1lKSAtPlxuICBGbG93Um91dGVyLmdldFBhcmFtKG5hbWUpO1xuXG4jIGdldCBxdWVyeSBwYXJhbWV0ZXJcbnF1ZXJ5UGFyYW0gPSAoa2V5KSAtPlxuICBGbG93Um91dGVyLmdldFF1ZXJ5UGFyYW0oa2V5KTtcblxuIyBnZXQgY3VycmVudCByb3V0ZSBuYW1lXG5jdXJyZW50Um91dGVOYW1lID0gKCkgLT5cbiAgRmxvd1JvdXRlci5nZXRSb3V0ZU5hbWUoKVxuXG4jIGdldCBjdXJyZW50IHJvdXRlIG9wdGlvbnNcbmN1cnJlbnRSb3V0ZU9wdGlvbiA9IChvcHRpb25OYW1lKSAtPlxuICBGbG93Um91dGVyLmN1cnJlbnQoKS5yb3V0ZS5vcHRpb25zW29wdGlvbk5hbWVdXG5cbiMgZGVwcmVjYXRlZFxuaXNTdWJSZWFkeSA9IChzdWIpIC0+XG4gIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeShzdWIpIGlmIHN1YlxuICByZXR1cm4gRmxvd1JvdXRlci5zdWJzUmVhZHkoKVxuXG5oZWxwZXJzID1cbiAgc3Vic1JlYWR5OiBzdWJzUmVhZHlcbiAgcGF0aEZvcjogcGF0aEZvclxuICB1cmxGb3I6IHVybEZvclxuICBwYXJhbTogcGFyYW1cbiAgcXVlcnlQYXJhbTogcXVlcnlQYXJhbVxuICBjdXJyZW50Um91dGVOYW1lOiBjdXJyZW50Um91dGVOYW1lXG4gIGlzU3ViUmVhZHk6IGlzU3ViUmVhZHlcbiAgY3VycmVudFJvdXRlT3B0aW9uOiBjdXJyZW50Um91dGVPcHRpb25cblxuaWYgTWV0ZW9yLmlzQ2xpZW50XG4gIFRlbXBsYXRlLnJlZ2lzdGVySGVscGVyIG5hbWUsIGZ1bmMgZm9yIG93biBuYW1lLCBmdW5jIG9mIGhlbHBlcnNcbiAgXG5pZiBNZXRlb3IuaXNTZXJ2ZXJcbiAgRmxvd1JvdXRlckhlbHBlcnMgPSBcbiAgICBwYXRoRm9yOiBwYXRoRm9yXG4gICAgdXJsRm9yOiB1cmxGb3JcbiIsIiAgLy8gY2hlY2sgZm9yIHN1YnNjcmlwdGlvbnMgdG8gYmUgcmVhZHlcbnZhciBjdXJyZW50Um91dGVOYW1lLCBjdXJyZW50Um91dGVPcHRpb24sIGZ1bmMsIGhlbHBlcnMsIGlzU3ViUmVhZHksIG5hbWUsIHBhcmFtLCBwYXRoRm9yLCBxdWVyeVBhcmFtLCBzdWJzUmVhZHksIHVybEZvciwgICAgICAgICAgICAgICAgICAgXG4gIGhhc1Byb3AgPSB7fS5oYXNPd25Qcm9wZXJ0eTtcblxuc3Vic1JlYWR5ID0gZnVuY3Rpb24oLi4uc3Vicykge1xuICBpZiAoc3Vicy5sZW5ndGggPT09IDEpIHtcbiAgICByZXR1cm4gRmxvd1JvdXRlci5zdWJzUmVhZHkoKTtcbiAgfVxuICBzdWJzID0gc3Vicy5zbGljZSgwLCBzdWJzLmxlbmd0aCAtIDEpO1xuICByZXR1cm4gXy5yZWR1Y2Uoc3VicywgZnVuY3Rpb24obWVtbywgc3ViKSB7XG4gICAgcmV0dXJuIG1lbW8gJiYgRmxvd1JvdXRlci5zdWJzUmVhZHkoc3ViKTtcbiAgfSwgdHJ1ZSk7XG59O1xuXG4vLyByZXR1cm4gcGF0aFxucGF0aEZvciA9IGZ1bmN0aW9uKHBhdGgsIHZpZXcgPSB7XG4gICAgaGFzaDoge31cbiAgfSkge1xuICB2YXIgaGFzaEJhbmcsIHF1ZXJ5LCByZWY7XG4gIGlmICghcGF0aCkge1xuICAgIHRocm93IG5ldyBFcnJvcignbm8gcGF0aCBkZWZpbmVkJyk7XG4gIH1cbiAgaWYgKCF2aWV3Lmhhc2gpIHtcbiAgICAvLyBzZXQgaWYgcnVuIG9uIHNlcnZlclxuICAgIHZpZXcgPSB7XG4gICAgICBoYXNoOiB2aWV3XG4gICAgfTtcbiAgfVxuICBpZiAoKChyZWYgPSBwYXRoLmhhc2gpICE9IG51bGwgPyByZWYucm91dGUgOiB2b2lkIDApICE9IG51bGwpIHtcbiAgICB2aWV3ID0gcGF0aDtcbiAgICBwYXRoID0gdmlldy5oYXNoLnJvdXRlO1xuICAgIGRlbGV0ZSB2aWV3Lmhhc2gucm91dGU7XG4gIH1cbiAgcXVlcnkgPSB2aWV3Lmhhc2gucXVlcnkgPyBGbG93Um91dGVyLl9xcy5wYXJzZSh2aWV3Lmhhc2gucXVlcnkpIDoge307XG4gIGhhc2hCYW5nID0gdmlldy5oYXNoLmhhc2ggPyB2aWV3Lmhhc2guaGFzaCA6ICcnO1xuICByZXR1cm4gRmxvd1JvdXRlci5wYXRoKHBhdGgsIHZpZXcuaGFzaCwgcXVlcnkpICsgKGhhc2hCYW5nID8gYCMke2hhc2hCYW5nfWAgOiAnJyk7XG59O1xuXG4vLyByZXR1cm4gYWJzb2x1dGUgdXJsXG51cmxGb3IgPSBmdW5jdGlvbihwYXRoLCB2aWV3KSB7XG4gIHZhciByZWxhdGl2ZVBhdGg7XG4gIHJlbGF0aXZlUGF0aCA9IHBhdGhGb3IocGF0aCwgdmlldyk7XG4gIHJldHVybiBNZXRlb3IuYWJzb2x1dGVVcmwocmVsYXRpdmVQYXRoLnN1YnN0cigxKSk7XG59O1xuXG4vLyBnZXQgcGFyYW1ldGVyXG5wYXJhbSA9IGZ1bmN0aW9uKG5hbWUpIHtcbiAgcmV0dXJuIEZsb3dSb3V0ZXIuZ2V0UGFyYW0obmFtZSk7XG59O1xuXG5xdWVyeVBhcmFtID0gZnVuY3Rpb24oa2V5KSB7XG4gIHJldHVybiBGbG93Um91dGVyLmdldFF1ZXJ5UGFyYW0oa2V5KTtcbn07XG5cbmN1cnJlbnRSb3V0ZU5hbWUgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIEZsb3dSb3V0ZXIuZ2V0Um91dGVOYW1lKCk7XG59O1xuXG4vLyBnZXQgY3VycmVudCByb3V0ZSBvcHRpb25zXG5jdXJyZW50Um91dGVPcHRpb24gPSBmdW5jdGlvbihvcHRpb25OYW1lKSB7XG4gIHJldHVybiBGbG93Um91dGVyLmN1cnJlbnQoKS5yb3V0ZS5vcHRpb25zW29wdGlvbk5hbWVdO1xufTtcblxuLy8gZGVwcmVjYXRlZFxuaXNTdWJSZWFkeSA9IGZ1bmN0aW9uKHN1Yikge1xuICBpZiAoc3ViKSB7XG4gICAgcmV0dXJuIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KHN1Yik7XG4gIH1cbiAgcmV0dXJuIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KCk7XG59O1xuXG5oZWxwZXJzID0ge1xuICBzdWJzUmVhZHk6IHN1YnNSZWFkeSxcbiAgcGF0aEZvcjogcGF0aEZvcixcbiAgdXJsRm9yOiB1cmxGb3IsXG4gIHBhcmFtOiBwYXJhbSxcbiAgcXVlcnlQYXJhbTogcXVlcnlQYXJhbSxcbiAgY3VycmVudFJvdXRlTmFtZTogY3VycmVudFJvdXRlTmFtZSxcbiAgaXNTdWJSZWFkeTogaXNTdWJSZWFkeSxcbiAgY3VycmVudFJvdXRlT3B0aW9uOiBjdXJyZW50Um91dGVPcHRpb25cbn07XG5cbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgZm9yIChuYW1lIGluIGhlbHBlcnMpIHtcbiAgICBpZiAoIWhhc1Byb3AuY2FsbChoZWxwZXJzLCBuYW1lKSkgY29udGludWU7XG4gICAgZnVuYyA9IGhlbHBlcnNbbmFtZV07XG4gICAgVGVtcGxhdGUucmVnaXN0ZXJIZWxwZXIobmFtZSwgZnVuYyk7XG4gIH1cbn1cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBGbG93Um91dGVySGVscGVycyA9IHtcbiAgICBwYXRoRm9yOiBwYXRoRm9yLFxuICAgIHVybEZvcjogdXJsRm9yXG4gIH07XG59XG4iXX0=
