(function () {



/* Exports */
Package._define("rzymek:fullcalendar");

})();
