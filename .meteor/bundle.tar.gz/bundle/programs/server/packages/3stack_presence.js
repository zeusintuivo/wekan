(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Accounts = Package['accounts-base'].Accounts;
var Random = Package.random.Random;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, presences, Presence;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/3stack_presence/lib/collection.coffee                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
presences = new Mongo.Collection('presences');
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/3stack_presence/lib/heartbeat.coffee                                                                //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Heartbeat;
Heartbeat = class Heartbeat {
  constructor(interval) {
    this.tick = this.tick.bind(this);
    this.tock = this.tock.bind(this);
    this.interval = interval;
    this.heartbeat = null;
    this.action = null;
    this.started = false;
  }

  start(action) {
    this.action = action;

    if (this.started) {
      return;
    }

    this.started = true;

    this._enqueue();
  }

  stop() {
    this.started = false;
    this.action = null;

    this._dequeue();
  }

  tick() {
    if (typeof this.action === "function") {
      this.action();
    }
  }

  tock() {
    if (!this.started) {
      return;
    }

    this._dequeue();

    this._enqueue();
  }

  _dequeue() {
    if (this.heartbeat != null) {
      Meteor.clearTimeout(this.heartbeat);
      this.heartbeat = null;
    }
  }

  _enqueue() {
    this.heartbeat = Meteor.setTimeout(this.tick, this.interval);
  }

};
this.Heartbeat = Heartbeat;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/3stack_presence/lib/server/monitor.coffee                                                           //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var DEFAULT_HEARTBEAT, DEFAULT_TTL, ServerMonitor;
DEFAULT_TTL = 5 * 60 * 1000;
DEFAULT_HEARTBEAT = 60 * 1000;
ServerMonitor = class ServerMonitor {
  constructor() {
    this.onStartup = this.onStartup.bind(this);
    this.onBeat = this.onBeat.bind(this);
    this.serverId = Random.id();
    console.log(`Presence started serverId=${this.serverId}`);
    this.options = {
      ttl: null,
      heartbeatInterval: null,
      checksum: null
    };
    this.heartbeat = new Heartbeat(DEFAULT_HEARTBEAT);
    this.started = false;
    Meteor.startup(this.onStartup);
  }

  configure(options) {
    var ref;

    if (this.started) {
      throw new Error("Must configure Presence on the server before Meteor.startup()");
    }

    _.extend(this.options, options);

    this.heartbeat.interval = (ref = this.options.heartbeatInterval) != null ? ref : DEFAULT_HEARTBEAT;
  }

  getTtl() {
    var ref;
    return new Date(+new Date() + ((ref = this.options.ttl) != null ? ref : DEFAULT_TTL));
  }

  onStartup() {
    this.started = true;
    this.heartbeat.start(this.onBeat);
  }

  onBeat() {
    try {
      presences.update({
        serverId: this.serverId
      }, {
        $set: {
          ttl: this.getTtl()
        }
      }, {
        multi: true
      });
    } finally {
      this.heartbeat.tock();
    }
  }

  checksum(userId, value) {
    if (this.options.checksum != null) {
      return this.options.checksum(userId, value);
    } else {
      return value;
    }
  }

};
this.ServerMonitor = ServerMonitor;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/3stack_presence/lib/server/presence.coffee                                                          //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Presence = new ServerMonitor(); // on any connection - log the client in presences, and set the onClose handler

Meteor.onConnection(function (connection) {
  var now;
  connection.sessionKey = Random.id();
  now = new Date();
  presences.insert({
    _id: connection.sessionKey,
    serverId: Presence.serverId,
    ttl: Presence.getTtl(),
    clientAddress: connection.clientAddress,
    status: 'connected',
    connectedAt: now,
    lastSeen: now,
    state: {},
    userId: null
  });
  connection.onClose(function () {
    presences.remove({
      _id: connection.sessionKey
    });
  });
}); // this autopublish will be called each time the user logs out / in
// it should also be the first call after the Meteor.onConnection call

Meteor.publish(null, function () {
  var loginToken;
  loginToken = null;

  if (this.userId != null) {
    // Use user-defined digest if option provided
    loginToken = Presence.checksum(this.userId, Accounts._getLoginToken(this.connection.id));
  }

  presences.update({
    _id: this.connection.sessionKey
  }, {
    $set: {
      loginToken: loginToken,
      userId: this.userId,
      lastSeen: new Date()
    }
  });
  this.ready();
}); // allow the client to provide stateful information about itself

Meteor.methods({
  'setPresence': function (state) {
    check(state, Match.Any);
    this.unblock();
    presences.update({
      _id: this.connection.sessionKey
    }, {
      $set: {
        userId: this.userId,
        lastSeen: new Date(),
        state: state,
        status: 'online'
      }
    });
    return null;
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("3stack:presence", {
  Presence: Presence,
  presences: presences
});

})();

//# sourceURL=meteor://💻app/packages/3stack_presence.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlL2xpYi9jb2xsZWN0aW9uLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlL2xpYi9oZWFydGJlYXQuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvaGVhcnRiZWF0LmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlL2xpYi9zZXJ2ZXIvbW9uaXRvci5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zZXJ2ZXIvbW9uaXRvci5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzLzNzdGFja19wcmVzZW5jZS9saWIvc2VydmVyL3ByZXNlbmNlLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvbGliL3NlcnZlci9wcmVzZW5jZS5jb2ZmZWUiXSwibmFtZXMiOlsicHJlc2VuY2VzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiSGVhcnRiZWF0IiwiY29uc3RydWN0b3IiLCJpbnRlcnZhbCIsInRpY2siLCJiaW5kIiwidG9jayIsImhlYXJ0YmVhdCIsImFjdGlvbiIsInN0YXJ0ZWQiLCJzdGFydCIsIl9lbnF1ZXVlIiwic3RvcCIsIl9kZXF1ZXVlIiwiTWV0ZW9yIiwiY2xlYXJUaW1lb3V0Iiwic2V0VGltZW91dCIsIkRFRkFVTFRfSEVBUlRCRUFUIiwiREVGQVVMVF9UVEwiLCJTZXJ2ZXJNb25pdG9yIiwib25TdGFydHVwIiwib25CZWF0Iiwic2VydmVySWQiLCJSYW5kb20iLCJpZCIsImNvbnNvbGUiLCJsb2ciLCJvcHRpb25zIiwidHRsIiwiaGVhcnRiZWF0SW50ZXJ2YWwiLCJjaGVja3N1bSIsInN0YXJ0dXAiLCJjb25maWd1cmUiLCJyZWYiLCJFcnJvciIsIl8iLCJleHRlbmQiLCJnZXRUdGwiLCJEYXRlIiwidXBkYXRlIiwiJHNldCIsIm11bHRpIiwidXNlcklkIiwidmFsdWUiLCJQcmVzZW5jZSIsIm9uQ29ubmVjdGlvbiIsImNvbm5lY3Rpb24iLCJub3ciLCJzZXNzaW9uS2V5IiwiaW5zZXJ0IiwiX2lkIiwiY2xpZW50QWRkcmVzcyIsInN0YXR1cyIsImNvbm5lY3RlZEF0IiwibGFzdFNlZW4iLCJzdGF0ZSIsIm9uQ2xvc2UiLCJyZW1vdmUiLCJwdWJsaXNoIiwibG9naW5Ub2tlbiIsIkFjY291bnRzIiwiX2dldExvZ2luVG9rZW4iLCJyZWFkeSIsIm1ldGhvZHMiLCJjaGVjayIsIk1hdGNoIiwiQW55IiwidW5ibG9jayJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsU0FBQSxHQUFZLElBQUlDLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFaLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFBQyxTQUFBO0FBQU1BLFNBQUEsR0FBTixNQUFBQSxTQUFBO0FBQ0VDLGFBQWEsQ0FBQUMsUUFBQTtBQ0dYLFNEZUZDLElDZkUsR0RlRixLQUFBQSxJQUFBLENBQUFDLElBQUEsTUNmRTtBQUNBLFNEa0JGQyxJQ2xCRSxHRGtCRixLQUFBQSxJQUFBLENBQUFELElBQUEsTUNsQkU7QURKWSxTQUFDRixRQUFELEdBQUNBLFFBQUQ7QUFDWixTQUFDSSxTQUFELEdBQWEsSUFBYjtBQUNBLFNBQUNDLE1BQUQsR0FBVSxJQUFWO0FBQ0EsU0FBQ0MsT0FBRCxHQUFXLEtBQVg7QUFIVzs7QUFLYkMsT0FBTyxDQUFBRixNQUFBO0FBQUMsU0FBQ0EsTUFBRCxHQUFDQSxNQUFEOztBQUNOLFFBQUcsS0FBQ0MsT0FBSjtBQUNFO0FDUUQ7O0FEUEQsU0FBQ0EsT0FBRCxHQUFXLElBQVg7O0FBQ0EsU0FBQ0UsUUFBRDtBQUpLOztBQU9QQyxNQUFNO0FBQ0osU0FBQ0gsT0FBRCxHQUFXLEtBQVg7QUFDQSxTQUFDRCxNQUFELEdBQVUsSUFBVjs7QUFDQSxTQUFDSyxRQUFEO0FBSEk7O0FBTU5ULE1BQU07QUNTSixRQUFJLE9BQU8sS0FBS0ksTUFBWixLQUF1QixVQUEzQixFQUF1QztBRFJ2QyxXQUFDQSxNQUFEO0FDVUM7QURYRzs7QUFJTkYsTUFBTTtBQUNKLFNBQU8sS0FBQ0csT0FBUjtBQUNFO0FDV0Q7O0FEVkQsU0FBQ0ksUUFBRDs7QUFDQSxTQUFDRixRQUFEO0FBSkk7O0FBT05FLFVBQVU7QUFDUixRQUFHLEtBQUFOLFNBQUEsUUFBSDtBQUNFTyxZQUFNLENBQUNDLFlBQVAsQ0FBb0IsS0FBQ1IsU0FBckI7QUFDQSxXQUFDQSxTQUFELEdBQWEsSUFBYjtBQ1lEO0FEZk87O0FBTVZJLFVBQVU7QUFDUixTQUFDSixTQUFELEdBQWFPLE1BQU0sQ0FBQ0UsVUFBUCxDQUFrQixLQUFDWixJQUFuQixFQUF5QixLQUFDRCxRQUExQixDQUFiO0FBRFE7O0FBcENaLENBQU07QUF3Q04sS0FBQ0YsU0FBRCxHQUFhQSxTQUFiLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUV4Q0EsSUFBQWdCLGlCQUFBLEVBQUFDLFdBQUEsRUFBQUMsYUFBQTtBQUFBRCxXQUFBLEdBQWMsSUFBRSxFQUFGLEdBQUssSUFBbkI7QUFDQUQsaUJBQUEsR0FBb0IsS0FBRyxJQUF2QjtBQUVNRSxhQUFBLEdBQU4sTUFBQUEsYUFBQTtBQUNFakIsYUFBYTtBQ0lYLFNEaUJGa0IsU0NqQkUsR0RpQkYsS0FBQUEsU0FBQSxDQUFBZixJQUFBLE1DakJFO0FBQ0EsU0RxQkZnQixNQ3JCRSxHRHFCRixLQUFBQSxNQUFBLENBQUFoQixJQUFBLE1DckJFO0FESkEsU0FBQ2lCLFFBQUQsR0FBWUMsTUFBTSxDQUFDQyxFQUFQLEVBQVo7QUFDQUMsV0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQTZCLEtBQUNKLFFBQTlCLEVBQVo7QUFDQSxTQUFDSyxPQUFELEdBQ0U7QUFBQUMsU0FBQSxFQUFLLElBQUw7QUFDQUMsdUJBQUEsRUFBbUIsSUFEbkI7QUFFQUMsY0FBQSxFQUFVO0FBRlYsS0FERjtBQUlBLFNBQUN2QixTQUFELEdBQWEsSUFBSU4sU0FBSixDQUFjZ0IsaUJBQWQsQ0FBYjtBQUNBLFNBQUNSLE9BQUQsR0FBVyxLQUFYO0FBQ0FLLFVBQU0sQ0FBQ2lCLE9BQVAsQ0FBZSxLQUFDWCxTQUFoQjtBQVRXOztBQVdiWSxXQUFXLENBQUNMLE9BQUQ7QUFDVCxRQUFBTSxHQUFBOztBQUFBLFFBQUcsS0FBQ3hCLE9BQUo7QUFDRSxZQUFNLElBQUl5QixLQUFKLENBQVUsK0RBQVYsQ0FBTjtBQ1NEOztBRFJEQyxLQUFDLENBQUNDLE1BQUYsQ0FBUyxLQUFDVCxPQUFWLEVBQW1CQSxPQUFuQjs7QUFFQSxTQUFDcEIsU0FBRCxDQUFXSixRQUFYLElBQUE4QixHQUFBLFFBQUFOLE9BQUEsQ0FBQUUsaUJBQUEsWUFBQUksR0FBQSxHQUFtRGhCLGlCQUFuRDtBQUxTOztBQVFYb0IsUUFBUTtBQUFHLFFBQUFKLEdBQUE7QUNVVCxXRFZTLElBQUlLLElBQUosQ0FBUyxDQUFFLElBQUlBLElBQUosRUFBRixJQUFnQixDQUFBTCxHQUFBLFFBQUFOLE9BQUEsQ0FBQUMsR0FBQSxZQUFBSyxHQUFBLEdBQWdCZixXQUFoQyxDQUFULENDVVQ7QURWTTs7QUFFUkUsV0FBVztBQUNULFNBQUNYLE9BQUQsR0FBVyxJQUFYO0FBQ0EsU0FBQ0YsU0FBRCxDQUFXRyxLQUFYLENBQWlCLEtBQUNXLE1BQWxCO0FBRlM7O0FBS1hBLFFBQVE7QUFDTjtBQUNFdkIsZUFBUyxDQUFDeUMsTUFBVixDQUFpQjtBQUNmakIsZ0JBQUEsRUFBVSxLQUFDQTtBQURJLE9BQWpCLEVBRUc7QUFDRGtCLFlBQUEsRUFBTTtBQUNKWixhQUFBLEVBQUssS0FBQ1MsTUFBRDtBQUREO0FBREwsT0FGSCxFQU1HO0FBQ0RJLGFBQUEsRUFBTztBQUROLE9BTkg7QUFERjtBQVdFLFdBQUNsQyxTQUFELENBQVdELElBQVg7QUNZRDtBRHhCSzs7QUFlUndCLFVBQVUsQ0FBQ1ksTUFBRCxFQUFTQyxLQUFUO0FBQ1IsUUFBRyxLQUFBaEIsT0FBQSxDQUFBRyxRQUFBLFFBQUg7QUFDRSxhQUFPLEtBQUNILE9BQUQsQ0FBU0csUUFBVCxDQUFrQlksTUFBbEIsRUFBMEJDLEtBQTFCLENBQVA7QUFERjtBQUdFLGFBQU9BLEtBQVA7QUNhRDtBRGpCTzs7QUExQ1osQ0FBTTtBQWdETixLQUFDeEIsYUFBRCxHQUFpQkEsYUFBakIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBRW5EQXlCLFFBQUEsR0FBVyxJQUFJekIsYUFBSixFQUFYLEMsQ0NJQTs7QUREQUwsTUFBTSxDQUFDK0IsWUFBUCxDQUFvQixVQUFDQyxVQUFEO0FBQ2xCLE1BQUFDLEdBQUE7QUFBQUQsWUFBVSxDQUFDRSxVQUFYLEdBQXdCekIsTUFBTSxDQUFDQyxFQUFQLEVBQXhCO0FBQ0F1QixLQUFBLEdBQU0sSUFBSVQsSUFBSixFQUFOO0FBQ0F4QyxXQUFTLENBQUNtRCxNQUFWLENBQ0U7QUFBQUMsT0FBQSxFQUFLSixVQUFVLENBQUNFLFVBQWhCO0FBQ0ExQixZQUFBLEVBQVVzQixRQUFRLENBQUN0QixRQURuQjtBQUVBTSxPQUFBLEVBQUtnQixRQUFRLENBQUNQLE1BQVQsRUFGTDtBQUdBYyxpQkFBQSxFQUFlTCxVQUFVLENBQUNLLGFBSDFCO0FBSUFDLFVBQUEsRUFBUSxXQUpSO0FBS0FDLGVBQUEsRUFBYU4sR0FMYjtBQU1BTyxZQUFBLEVBQVVQLEdBTlY7QUFPQVEsU0FBQSxFQUFPLEVBUFA7QUFRQWIsVUFBQSxFQUFRO0FBUlIsR0FERjtBQVdBSSxZQUFVLENBQUNVLE9BQVgsQ0FBbUI7QUFDakIxRCxhQUFTLENBQUMyRCxNQUFWLENBQWlCO0FBQUFQLFNBQUEsRUFBS0osVUFBVSxDQUFDRTtBQUFoQixLQUFqQjtBQURGO0FBZEYsRyxDQ3dCQTtBQUNBOztBREpBbEMsTUFBTSxDQUFDNEMsT0FBUCxDQUFlLElBQWYsRUFBcUI7QUFDbkIsTUFBQUMsVUFBQTtBQUFBQSxZQUFBLEdBQWEsSUFBYjs7QUFDQSxNQUFHLEtBQUFqQixNQUFBLFFBQUg7QUNPRTtBRExBaUIsY0FBQSxHQUFhZixRQUFRLENBQUNkLFFBQVQsQ0FBa0IsS0FBQ1ksTUFBbkIsRUFBMkJrQixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsS0FBQ2YsVUFBRCxDQUFZdEIsRUFBcEMsQ0FBM0IsQ0FBYjtBQ09EOztBRExEMUIsV0FBUyxDQUFDeUMsTUFBVixDQUNFO0FBQUFXLE9BQUEsRUFBSyxLQUFDSixVQUFELENBQVlFO0FBQWpCLEdBREYsRUFHRTtBQUFBUixRQUFBLEVBQ0U7QUFBQW1CLGdCQUFBLEVBQVlBLFVBQVo7QUFDQWpCLFlBQUEsRUFBUSxLQUFDQSxNQURUO0FBRUFZLGNBQUEsRUFBVSxJQUFJaEIsSUFBSjtBQUZWO0FBREYsR0FIRjtBQU9BLE9BQUN3QixLQUFEO0FBYkYsRyxDQ3dCQTs7QURQQWhELE1BQU0sQ0FBQ2lELE9BQVAsQ0FDRTtBQUFBLGlCQUFlLFVBQUNSLEtBQUQ7QUFDYlMsU0FBQSxDQUFNVCxLQUFOLEVBQWFVLEtBQUssQ0FBQ0MsR0FBbkI7QUFDQSxTQUFDQyxPQUFEO0FBRUFyRSxhQUFTLENBQUN5QyxNQUFWLENBQ0U7QUFBQVcsU0FBQSxFQUFLLEtBQUNKLFVBQUQsQ0FBWUU7QUFBakIsS0FERixFQUdFO0FBQUFSLFVBQUEsRUFDRTtBQUFBRSxjQUFBLEVBQVEsS0FBQ0EsTUFBVDtBQUNBWSxnQkFBQSxFQUFVLElBQUloQixJQUFKLEVBRFY7QUFFQWlCLGFBQUEsRUFBT0EsS0FGUDtBQUdBSCxjQUFBLEVBQVE7QUFIUjtBQURGLEtBSEY7QUFTQSxXQUFPLElBQVA7QUFiYTtBQUFmLENBREYsRSIsImZpbGUiOiIvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsicHJlc2VuY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ByZXNlbmNlcycpO1xuIiwiY2xhc3MgSGVhcnRiZWF0XG4gIGNvbnN0cnVjdG9yOiAoQGludGVydmFsKS0+XG4gICAgQGhlYXJ0YmVhdCA9IG51bGxcbiAgICBAYWN0aW9uID0gbnVsbFxuICAgIEBzdGFydGVkID0gZmFsc2VcblxuICBzdGFydDogKEBhY3Rpb24pLT5cbiAgICBpZiBAc3RhcnRlZFxuICAgICAgcmV0dXJuXG4gICAgQHN0YXJ0ZWQgPSB0cnVlXG4gICAgQF9lbnF1ZXVlKClcbiAgICByZXR1cm5cblxuICBzdG9wOiAtPlxuICAgIEBzdGFydGVkID0gZmFsc2VcbiAgICBAYWN0aW9uID0gbnVsbFxuICAgIEBfZGVxdWV1ZSgpXG4gICAgcmV0dXJuXG5cbiAgdGljazogPT5cbiAgICBAYWN0aW9uPygpXG4gICAgcmV0dXJuXG5cbiAgdG9jazogPT5cbiAgICB1bmxlc3MgQHN0YXJ0ZWRcbiAgICAgIHJldHVyblxuICAgIEBfZGVxdWV1ZSgpXG4gICAgQF9lbnF1ZXVlKClcbiAgICByZXR1cm5cblxuICBfZGVxdWV1ZTogLT5cbiAgICBpZiBAaGVhcnRiZWF0P1xuICAgICAgTWV0ZW9yLmNsZWFyVGltZW91dChAaGVhcnRiZWF0KVxuICAgICAgQGhlYXJ0YmVhdCA9IG51bGxcbiAgICByZXR1cm5cblxuICBfZW5xdWV1ZTogLT5cbiAgICBAaGVhcnRiZWF0ID0gTWV0ZW9yLnNldFRpbWVvdXQoQHRpY2ssIEBpbnRlcnZhbClcbiAgICByZXR1cm5cblxuQEhlYXJ0YmVhdCA9IEhlYXJ0YmVhdFxuIiwidmFyIEhlYXJ0YmVhdDtcblxuSGVhcnRiZWF0ID0gY2xhc3MgSGVhcnRiZWF0IHtcbiAgY29uc3RydWN0b3IoaW50ZXJ2YWwpIHtcbiAgICB0aGlzLnRpY2sgPSB0aGlzLnRpY2suYmluZCh0aGlzKTtcbiAgICB0aGlzLnRvY2sgPSB0aGlzLnRvY2suYmluZCh0aGlzKTtcbiAgICB0aGlzLmludGVydmFsID0gaW50ZXJ2YWw7XG4gICAgdGhpcy5oZWFydGJlYXQgPSBudWxsO1xuICAgIHRoaXMuYWN0aW9uID0gbnVsbDtcbiAgICB0aGlzLnN0YXJ0ZWQgPSBmYWxzZTtcbiAgfVxuXG4gIHN0YXJ0KGFjdGlvbikge1xuICAgIHRoaXMuYWN0aW9uID0gYWN0aW9uO1xuICAgIGlmICh0aGlzLnN0YXJ0ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5zdGFydGVkID0gdHJ1ZTtcbiAgICB0aGlzLl9lbnF1ZXVlKCk7XG4gIH1cblxuICBzdG9wKCkge1xuICAgIHRoaXMuc3RhcnRlZCA9IGZhbHNlO1xuICAgIHRoaXMuYWN0aW9uID0gbnVsbDtcbiAgICB0aGlzLl9kZXF1ZXVlKCk7XG4gIH1cblxuICB0aWNrKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy5hY3Rpb24gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhpcy5hY3Rpb24oKTtcbiAgICB9XG4gIH1cblxuICB0b2NrKCkge1xuICAgIGlmICghdGhpcy5zdGFydGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuX2RlcXVldWUoKTtcbiAgICB0aGlzLl9lbnF1ZXVlKCk7XG4gIH1cblxuICBfZGVxdWV1ZSgpIHtcbiAgICBpZiAodGhpcy5oZWFydGJlYXQgIT0gbnVsbCkge1xuICAgICAgTWV0ZW9yLmNsZWFyVGltZW91dCh0aGlzLmhlYXJ0YmVhdCk7XG4gICAgICB0aGlzLmhlYXJ0YmVhdCA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgX2VucXVldWUoKSB7XG4gICAgdGhpcy5oZWFydGJlYXQgPSBNZXRlb3Iuc2V0VGltZW91dCh0aGlzLnRpY2ssIHRoaXMuaW50ZXJ2YWwpO1xuICB9XG5cbn07XG5cbnRoaXMuSGVhcnRiZWF0ID0gSGVhcnRiZWF0O1xuIiwiREVGQVVMVF9UVEwgPSA1KjYwKjEwMDBcbkRFRkFVTFRfSEVBUlRCRUFUID0gNjAqMTAwMFxuXG5jbGFzcyBTZXJ2ZXJNb25pdG9yXG4gIGNvbnN0cnVjdG9yOiAtPlxuICAgIEBzZXJ2ZXJJZCA9IFJhbmRvbS5pZCgpXG4gICAgY29uc29sZS5sb2coXCJQcmVzZW5jZSBzdGFydGVkIHNlcnZlcklkPSN7QHNlcnZlcklkfVwiKVxuICAgIEBvcHRpb25zID1cbiAgICAgIHR0bDogbnVsbFxuICAgICAgaGVhcnRiZWF0SW50ZXJ2YWw6IG51bGxcbiAgICAgIGNoZWNrc3VtOiBudWxsXG4gICAgQGhlYXJ0YmVhdCA9IG5ldyBIZWFydGJlYXQoREVGQVVMVF9IRUFSVEJFQVQpXG4gICAgQHN0YXJ0ZWQgPSBmYWxzZVxuICAgIE1ldGVvci5zdGFydHVwKEBvblN0YXJ0dXApXG5cbiAgY29uZmlndXJlOiAob3B0aW9ucyktPlxuICAgIGlmIEBzdGFydGVkXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNdXN0IGNvbmZpZ3VyZSBQcmVzZW5jZSBvbiB0aGUgc2VydmVyIGJlZm9yZSBNZXRlb3Iuc3RhcnR1cCgpXCIpXG4gICAgXy5leHRlbmQoQG9wdGlvbnMsIG9wdGlvbnMpXG5cbiAgICBAaGVhcnRiZWF0LmludGVydmFsID0gQG9wdGlvbnMuaGVhcnRiZWF0SW50ZXJ2YWwgPyBERUZBVUxUX0hFQVJUQkVBVFxuICAgIHJldHVyblxuXG4gIGdldFR0bDogLT4gbmV3IERhdGUoKyhuZXcgRGF0ZSgpKSArIChAb3B0aW9ucy50dGwgPyBERUZBVUxUX1RUTCkpXG5cbiAgb25TdGFydHVwOiA9PlxuICAgIEBzdGFydGVkID0gdHJ1ZVxuICAgIEBoZWFydGJlYXQuc3RhcnQoQG9uQmVhdClcbiAgICByZXR1cm5cblxuICBvbkJlYXQ6ID0+XG4gICAgdHJ5XG4gICAgICBwcmVzZW5jZXMudXBkYXRlKHtcbiAgICAgICAgc2VydmVySWQ6IEBzZXJ2ZXJJZFxuICAgICAgfSwge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgdHRsOiBAZ2V0VHRsKClcbiAgICAgICAgfVxuICAgICAgfSwge1xuICAgICAgICBtdWx0aTogdHJ1ZVxuICAgICAgfSlcbiAgICBmaW5hbGx5XG4gICAgICBAaGVhcnRiZWF0LnRvY2soKVxuICAgIHJldHVyblxuXG4gIGNoZWNrc3VtOiAodXNlcklkLCB2YWx1ZSktPlxuICAgIGlmIEBvcHRpb25zLmNoZWNrc3VtP1xuICAgICAgcmV0dXJuIEBvcHRpb25zLmNoZWNrc3VtKHVzZXJJZCwgdmFsdWUpXG4gICAgZWxzZVxuICAgICAgcmV0dXJuIHZhbHVlXG5cbkBTZXJ2ZXJNb25pdG9yID0gU2VydmVyTW9uaXRvclxuIiwidmFyIERFRkFVTFRfSEVBUlRCRUFULCBERUZBVUxUX1RUTCwgU2VydmVyTW9uaXRvcjtcblxuREVGQVVMVF9UVEwgPSA1ICogNjAgKiAxMDAwO1xuXG5ERUZBVUxUX0hFQVJUQkVBVCA9IDYwICogMTAwMDtcblxuU2VydmVyTW9uaXRvciA9IGNsYXNzIFNlcnZlck1vbml0b3Ige1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLm9uU3RhcnR1cCA9IHRoaXMub25TdGFydHVwLmJpbmQodGhpcyk7XG4gICAgdGhpcy5vbkJlYXQgPSB0aGlzLm9uQmVhdC5iaW5kKHRoaXMpO1xuICAgIHRoaXMuc2VydmVySWQgPSBSYW5kb20uaWQoKTtcbiAgICBjb25zb2xlLmxvZyhgUHJlc2VuY2Ugc3RhcnRlZCBzZXJ2ZXJJZD0ke3RoaXMuc2VydmVySWR9YCk7XG4gICAgdGhpcy5vcHRpb25zID0ge1xuICAgICAgdHRsOiBudWxsLFxuICAgICAgaGVhcnRiZWF0SW50ZXJ2YWw6IG51bGwsXG4gICAgICBjaGVja3N1bTogbnVsbFxuICAgIH07XG4gICAgdGhpcy5oZWFydGJlYXQgPSBuZXcgSGVhcnRiZWF0KERFRkFVTFRfSEVBUlRCRUFUKTtcbiAgICB0aGlzLnN0YXJ0ZWQgPSBmYWxzZTtcbiAgICBNZXRlb3Iuc3RhcnR1cCh0aGlzLm9uU3RhcnR1cCk7XG4gIH1cblxuICBjb25maWd1cmUob3B0aW9ucykge1xuICAgIHZhciByZWY7XG4gICAgaWYgKHRoaXMuc3RhcnRlZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTXVzdCBjb25maWd1cmUgUHJlc2VuY2Ugb24gdGhlIHNlcnZlciBiZWZvcmUgTWV0ZW9yLnN0YXJ0dXAoKVwiKTtcbiAgICB9XG4gICAgXy5leHRlbmQodGhpcy5vcHRpb25zLCBvcHRpb25zKTtcbiAgICB0aGlzLmhlYXJ0YmVhdC5pbnRlcnZhbCA9IChyZWYgPSB0aGlzLm9wdGlvbnMuaGVhcnRiZWF0SW50ZXJ2YWwpICE9IG51bGwgPyByZWYgOiBERUZBVUxUX0hFQVJUQkVBVDtcbiAgfVxuXG4gIGdldFR0bCgpIHtcbiAgICB2YXIgcmVmO1xuICAgIHJldHVybiBuZXcgRGF0ZSgrKG5ldyBEYXRlKCkpICsgKChyZWYgPSB0aGlzLm9wdGlvbnMudHRsKSAhPSBudWxsID8gcmVmIDogREVGQVVMVF9UVEwpKTtcbiAgfVxuXG4gIG9uU3RhcnR1cCgpIHtcbiAgICB0aGlzLnN0YXJ0ZWQgPSB0cnVlO1xuICAgIHRoaXMuaGVhcnRiZWF0LnN0YXJ0KHRoaXMub25CZWF0KTtcbiAgfVxuXG4gIG9uQmVhdCgpIHtcbiAgICB0cnkge1xuICAgICAgcHJlc2VuY2VzLnVwZGF0ZSh7XG4gICAgICAgIHNlcnZlcklkOiB0aGlzLnNlcnZlcklkXG4gICAgICB9LCB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICB0dGw6IHRoaXMuZ2V0VHRsKClcbiAgICAgICAgfVxuICAgICAgfSwge1xuICAgICAgICBtdWx0aTogdHJ1ZVxuICAgICAgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuaGVhcnRiZWF0LnRvY2soKTtcbiAgICB9XG4gIH1cblxuICBjaGVja3N1bSh1c2VySWQsIHZhbHVlKSB7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5jaGVja3N1bSAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gdGhpcy5vcHRpb25zLmNoZWNrc3VtKHVzZXJJZCwgdmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICB9XG5cbn07XG5cbnRoaXMuU2VydmVyTW9uaXRvciA9IFNlcnZlck1vbml0b3I7XG4iLCJQcmVzZW5jZSA9IG5ldyBTZXJ2ZXJNb25pdG9yKClcblxuIyBvbiBhbnkgY29ubmVjdGlvbiAtIGxvZyB0aGUgY2xpZW50IGluIHByZXNlbmNlcywgYW5kIHNldCB0aGUgb25DbG9zZSBoYW5kbGVyXG5NZXRlb3Iub25Db25uZWN0aW9uIChjb25uZWN0aW9uKS0+XG4gIGNvbm5lY3Rpb24uc2Vzc2lvbktleSA9IFJhbmRvbS5pZCgpXG4gIG5vdyA9IG5ldyBEYXRlKClcbiAgcHJlc2VuY2VzLmluc2VydFxuICAgIF9pZDogY29ubmVjdGlvbi5zZXNzaW9uS2V5XG4gICAgc2VydmVySWQ6IFByZXNlbmNlLnNlcnZlcklkXG4gICAgdHRsOiBQcmVzZW5jZS5nZXRUdGwoKVxuICAgIGNsaWVudEFkZHJlc3M6IGNvbm5lY3Rpb24uY2xpZW50QWRkcmVzc1xuICAgIHN0YXR1czogJ2Nvbm5lY3RlZCdcbiAgICBjb25uZWN0ZWRBdDogbm93XG4gICAgbGFzdFNlZW46IG5vd1xuICAgIHN0YXRlOiB7fVxuICAgIHVzZXJJZDogbnVsbFxuXG4gIGNvbm5lY3Rpb24ub25DbG9zZSAtPlxuICAgIHByZXNlbmNlcy5yZW1vdmUoX2lkOiBjb25uZWN0aW9uLnNlc3Npb25LZXkpXG4gICAgcmV0dXJuXG4gIHJldHVyblxuXG4jIHRoaXMgYXV0b3B1Ymxpc2ggd2lsbCBiZSBjYWxsZWQgZWFjaCB0aW1lIHRoZSB1c2VyIGxvZ3Mgb3V0IC8gaW5cbiMgaXQgc2hvdWxkIGFsc28gYmUgdGhlIGZpcnN0IGNhbGwgYWZ0ZXIgdGhlIE1ldGVvci5vbkNvbm5lY3Rpb24gY2FsbFxuTWV0ZW9yLnB1Ymxpc2ggbnVsbCwgLT5cbiAgbG9naW5Ub2tlbiA9IG51bGxcbiAgaWYgQHVzZXJJZD9cbiAgICAjIFVzZSB1c2VyLWRlZmluZWQgZGlnZXN0IGlmIG9wdGlvbiBwcm92aWRlZFxuICAgIGxvZ2luVG9rZW4gPSBQcmVzZW5jZS5jaGVja3N1bShAdXNlcklkLCBBY2NvdW50cy5fZ2V0TG9naW5Ub2tlbihAY29ubmVjdGlvbi5pZCkpXG5cbiAgcHJlc2VuY2VzLnVwZGF0ZVxuICAgIF9pZDogQGNvbm5lY3Rpb24uc2Vzc2lvbktleVxuICAsXG4gICAgJHNldDpcbiAgICAgIGxvZ2luVG9rZW46IGxvZ2luVG9rZW5cbiAgICAgIHVzZXJJZDogQHVzZXJJZFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKClcbiAgQHJlYWR5KClcbiAgcmV0dXJuXG5cbiMgYWxsb3cgdGhlIGNsaWVudCB0byBwcm92aWRlIHN0YXRlZnVsIGluZm9ybWF0aW9uIGFib3V0IGl0c2VsZlxuTWV0ZW9yLm1ldGhvZHNcbiAgJ3NldFByZXNlbmNlJzogKHN0YXRlKS0+XG4gICAgY2hlY2soc3RhdGUsIE1hdGNoLkFueSlcbiAgICBAdW5ibG9jaygpXG5cbiAgICBwcmVzZW5jZXMudXBkYXRlXG4gICAgICBfaWQ6IEBjb25uZWN0aW9uLnNlc3Npb25LZXlcbiAgICAsXG4gICAgICAkc2V0OlxuICAgICAgICB1c2VySWQ6IEB1c2VySWRcbiAgICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKClcbiAgICAgICAgc3RhdGU6IHN0YXRlXG4gICAgICAgIHN0YXR1czogJ29ubGluZSdcblxuICAgIHJldHVybiBudWxsXG4iLCIgICAgICAgICAgICAgXG5cblByZXNlbmNlID0gbmV3IFNlcnZlck1vbml0b3IoKTtcblxuLy8gb24gYW55IGNvbm5lY3Rpb24gLSBsb2cgdGhlIGNsaWVudCBpbiBwcmVzZW5jZXMsIGFuZCBzZXQgdGhlIG9uQ2xvc2UgaGFuZGxlclxuTWV0ZW9yLm9uQ29ubmVjdGlvbihmdW5jdGlvbihjb25uZWN0aW9uKSB7XG4gIHZhciBub3c7XG4gIGNvbm5lY3Rpb24uc2Vzc2lvbktleSA9IFJhbmRvbS5pZCgpO1xuICBub3cgPSBuZXcgRGF0ZSgpO1xuICBwcmVzZW5jZXMuaW5zZXJ0KHtcbiAgICBfaWQ6IGNvbm5lY3Rpb24uc2Vzc2lvbktleSxcbiAgICBzZXJ2ZXJJZDogUHJlc2VuY2Uuc2VydmVySWQsXG4gICAgdHRsOiBQcmVzZW5jZS5nZXRUdGwoKSxcbiAgICBjbGllbnRBZGRyZXNzOiBjb25uZWN0aW9uLmNsaWVudEFkZHJlc3MsXG4gICAgc3RhdHVzOiAnY29ubmVjdGVkJyxcbiAgICBjb25uZWN0ZWRBdDogbm93LFxuICAgIGxhc3RTZWVuOiBub3csXG4gICAgc3RhdGU6IHt9LFxuICAgIHVzZXJJZDogbnVsbFxuICB9KTtcbiAgY29ubmVjdGlvbi5vbkNsb3NlKGZ1bmN0aW9uKCkge1xuICAgIHByZXNlbmNlcy5yZW1vdmUoe1xuICAgICAgX2lkOiBjb25uZWN0aW9uLnNlc3Npb25LZXlcbiAgICB9KTtcbiAgfSk7XG59KTtcblxuLy8gdGhpcyBhdXRvcHVibGlzaCB3aWxsIGJlIGNhbGxlZCBlYWNoIHRpbWUgdGhlIHVzZXIgbG9ncyBvdXQgLyBpblxuLy8gaXQgc2hvdWxkIGFsc28gYmUgdGhlIGZpcnN0IGNhbGwgYWZ0ZXIgdGhlIE1ldGVvci5vbkNvbm5lY3Rpb24gY2FsbFxuTWV0ZW9yLnB1Ymxpc2gobnVsbCwgZnVuY3Rpb24oKSB7XG4gIHZhciBsb2dpblRva2VuO1xuICBsb2dpblRva2VuID0gbnVsbDtcbiAgaWYgKHRoaXMudXNlcklkICE9IG51bGwpIHtcbiAgICAvLyBVc2UgdXNlci1kZWZpbmVkIGRpZ2VzdCBpZiBvcHRpb24gcHJvdmlkZWRcbiAgICBsb2dpblRva2VuID0gUHJlc2VuY2UuY2hlY2tzdW0odGhpcy51c2VySWQsIEFjY291bnRzLl9nZXRMb2dpblRva2VuKHRoaXMuY29ubmVjdGlvbi5pZCkpO1xuICB9XG4gIHByZXNlbmNlcy51cGRhdGUoe1xuICAgIF9pZDogdGhpcy5jb25uZWN0aW9uLnNlc3Npb25LZXlcbiAgfSwge1xuICAgICRzZXQ6IHtcbiAgICAgIGxvZ2luVG9rZW46IGxvZ2luVG9rZW4sXG4gICAgICB1c2VySWQ6IHRoaXMudXNlcklkLFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKClcbiAgICB9XG4gIH0pO1xuICB0aGlzLnJlYWR5KCk7XG59KTtcblxuLy8gYWxsb3cgdGhlIGNsaWVudCB0byBwcm92aWRlIHN0YXRlZnVsIGluZm9ybWF0aW9uIGFib3V0IGl0c2VsZlxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnc2V0UHJlc2VuY2UnOiBmdW5jdGlvbihzdGF0ZSkge1xuICAgIGNoZWNrKHN0YXRlLCBNYXRjaC5BbnkpO1xuICAgIHRoaXMudW5ibG9jaygpO1xuICAgIHByZXNlbmNlcy51cGRhdGUoe1xuICAgICAgX2lkOiB0aGlzLmNvbm5lY3Rpb24uc2Vzc2lvbktleVxuICAgIH0sIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgdXNlcklkOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKCksXG4gICAgICAgIHN0YXRlOiBzdGF0ZSxcbiAgICAgICAgc3RhdHVzOiAnb25saW5lJ1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBudWxsO1xuICB9XG59KTtcbiJdfQ==
