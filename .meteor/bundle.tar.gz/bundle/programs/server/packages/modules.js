(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var meteorInstall = Package['modules-runtime'].meteorInstall;

var require = meteorInstall({"node_modules":{"meteor":{"modules":{"server.js":function module(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/modules/server.js                                                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
require("./install-packages.js");
require("./process.js");
require("./reify.js");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"install-packages.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/modules/install-packages.js                                                                     //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
function install(name, mainModule) {
  var meteorDir = {};

  // Given a package name <name>, install a stub module in the
  // /node_modules/meteor directory called <name>.js, so that
  // require.resolve("meteor/<name>") will always return
  // /node_modules/meteor/<name>.js instead of something like
  // /node_modules/meteor/<name>/index.js, in the rare but possible event
  // that the package contains a file called index.js (#6590).

  if (typeof mainModule === "string") {
    // Set up an alias from /node_modules/meteor/<package>.js to the main
    // module, e.g. meteor/<package>/index.js.
    meteorDir[name + ".js"] = mainModule;
  } else {
    // back compat with old Meteor packages
    meteorDir[name + ".js"] = function (r, e, module) {
      module.exports = Package[name];
    };
  }

  meteorInstall({
    node_modules: {
      meteor: meteorDir
    }
  });
}

// This file will be modified during computeJsOutputFilesMap to include
// install(<name>) calls for every Meteor package.

install("meteor");
install("meteor-base");
install("ecmascript-runtime");
install("modules-runtime");
install("modules", "meteor/modules/server.js");
install("modern-browsers", "meteor/modern-browsers/modern.js");
install("es5-shim");
install("promise", "meteor/promise/server.js");
install("ecmascript-runtime-client", "meteor/ecmascript-runtime-client/versions.js");
install("ecmascript-runtime-server", "meteor/ecmascript-runtime-server/runtime.js");
install("babel-compiler");
install("ecmascript");
install("babel-runtime", "meteor/babel-runtime/babel-runtime.js");
install("fetch", "meteor/fetch/server.js");
install("inter-process-messaging", "meteor/inter-process-messaging/inter-process-messaging.js");
install("dynamic-import", "meteor/dynamic-import/server.js");
install("minifier-css", "meteor/minifier-css/minifier.js");
install("standard-minifier-css");
install("standard-minifier-js");
install("jquery");
install("tracker");
install("base64", "meteor/base64/base64.js");
install("ejson", "meteor/ejson/ejson.js");
install("check", "meteor/check/match.js");
install("underscore");
install("id-map", "meteor/id-map/id-map.js");
install("random", "meteor/random/main_server.js");
install("mongo-id", "meteor/mongo-id/id.js");
install("diff-sequence", "meteor/diff-sequence/diff.js");
install("observe-sequence");
install("reactive-var");
install("ordered-dict", "meteor/ordered-dict/ordered_dict.js");
install("deps");
install("htmljs");
install("blaze");
install("mquandalle:jade");
install("coffeescript");
install("aldeed:simple-schema");
install("npm-mongo");
install("geojson-utils", "meteor/geojson-utils/main.js");
install("mongo-decimal", "meteor/mongo-decimal/decimal.js");
install("minimongo", "meteor/minimongo/minimongo_server.js");
install("retry", "meteor/retry/retry.js");
install("callback-hook", "meteor/callback-hook/hook.js");
install("ddp-common");
install("reload");
install("socket-stream-client", "meteor/socket-stream-client/node.js");
install("ddp-client", "meteor/ddp-client/server/server.js");
install("rate-limit", "meteor/rate-limit/rate-limit.js");
install("ddp-rate-limiter", "meteor/ddp-rate-limiter/ddp-rate-limiter.js");
install("logging", "meteor/logging/logging.js");
install("routepolicy", "meteor/routepolicy/main.js");
install("boilerplate-generator", "meteor/boilerplate-generator/generator.js");
install("webapp-hashing");
install("webapp", "meteor/webapp/webapp_server.js");
install("audit-argument-checks");
install("ddp-server");
install("ddp");
install("allow-deny");
install("binary-heap", "meteor/binary-heap/binary-heap.js");
install("mongo");
install("raix:eventemitter");
install("aldeed:collection2-core");
install("aldeed:schema-index");
install("aldeed:schema-deny");
install("aldeed:collection2");
install("cfs:standard-packages");
install("cottz:publish-relations", "meteor/cottz:publish-relations/lib/server/index.js");
install("dburles:collection-helpers");
install("idmontie:migrations");
install("accounts-base", "meteor/accounts-base/server_main.js");
install("matb33:collection-hooks");
install("livedata");
install("mongo-livedata");
install("autoupdate", "meteor/autoupdate/autoupdate_server.js");
install("meteor-platform");
install("meteorhacks:collection-utils");
install("meteorhacks:aggregate");
install("session");
install("ui");
install("spacebars");
install("templating-compiler");
install("templating-runtime");
install("templating");
install("matteodem:easy-search");
install("mquandalle:collection-mutations");
install("kenton:accounts-sandstorm");
install("service-configuration");
install("url", "meteor/url/server.js");
install("http", "meteor/http/httpcall_server.js");
install("useraccounts:core");
install("reactive-dict", "meteor/reactive-dict/migration.js");
install("kadira:flow-router");
install("kadira:blaze-layout");
install("softwarerero:accounts-t9n");
install("useraccounts:flow-routing");
install("useraccounts:unstyled");
install("yasaricli:slugify");
install("sha");
install("npm-bcrypt", "meteor/npm-bcrypt/wrapper.js");
install("srp", "meteor/srp/srp.js");
install("email");
install("accounts-password");
install("percolate:synced-cron");
install("wekan-ldap", "meteor/wekan-ldap/server/index.js");
install("wekan-accounts-cas");
install("localstorage");
install("oauth");
install("accounts-oauth");
install("oauth2");
install("wekan-oidc");
install("wekan-accounts-oidc");
install("3stack:presence");
install("zimme:active-route");
install("arillo:flow-router-helpers");
install("kadira:dochead");
install("mquandalle:autofocus");
install("ongoworks:speakingurl");
install("raix:handlebar-helpers");
install("meteorspark:util");
install("cfs:http-methods");
install("tap:i18n");
install("fortawesome:fontawesome");
install("mousetrap:mousetrap");
install("mquandalle:jquery-textcomplete");
install("mquandalle:jquery-ui-drag-drop-sort");
install("mquandalle:mousetrap-bindglobal");
install("peerlibrary:assert");
install("peerlibrary:reactive-field", "meteor/peerlibrary:reactive-field/lib.js");
install("peerlibrary:computed-field", "meteor/peerlibrary:computed-field/lib.js");
install("peerlibrary:base-component");
install("peerlibrary:blaze-components");
install("templates:tabs");
install("verron:autosize");
install("simple:json-routes");
install("rajit:bootstrap3-datepicker");
install("shell-server", "meteor/shell-server/main.js");
install("simple:authenticate-user-by-token");
install("simple:rest-bearer-token-parser");
install("simple:rest-json-error-handler");
install("simple:rest-accounts-password");
install("horka:swipebox");
install("cfs:base-package");
install("cfs:storage-adapter");
install("cfs:gridfs");
install("rzymek:fullcalendar");
install("momentjs:moment");
install("browser-policy-common");
install("browser-policy-framing", "meteor/browser-policy-framing/browser-policy-framing.js");
install("mquandalle:moment");
install("msavin:usercache");
install("coagmano:stylus");
install("lucasantoniassi:accounts-lockout", "meteor/lucasantoniassi:accounts-lockout/accounts-lockout.js");
install("meteorhacks:subs-manager");
install("meteorhacks:picker");
install("lamhieu:meteorx");
install("lamhieu:unblock");
install("wekan-markdown");
install("konecty:mongo-counter");
install("easylogic:summernote");
install("cfs:filesystem");
install("tmeasday:check-npm-versions", "meteor/tmeasday:check-npm-versions/check-npm-versions.js");
install("steffo:meteor-accounts-saml");
install("rajit:bootstrap3-datepicker-fi");
install("rajit:bootstrap3-datepicker-ar");
install("rajit:bootstrap3-datepicker-bg");
install("rajit:bootstrap3-datepicker-br");
install("rajit:bootstrap3-datepicker-ca");
install("rajit:bootstrap3-datepicker-cs");
install("rajit:bootstrap3-datepicker-da");
install("rajit:bootstrap3-datepicker-de");
install("rajit:bootstrap3-datepicker-el");
install("rajit:bootstrap3-datepicker-en-gb");
install("rajit:bootstrap3-datepicker-eo");
install("rajit:bootstrap3-datepicker-es");
install("rajit:bootstrap3-datepicker-eu");
install("rajit:bootstrap3-datepicker-fa");
install("rajit:bootstrap3-datepicker-fr");
install("rajit:bootstrap3-datepicker-gl");
install("rajit:bootstrap3-datepicker-he");
install("rajit:bootstrap3-datepicker-hi");
install("rajit:bootstrap3-datepicker-hu");
install("rajit:bootstrap3-datepicker-hy");
install("rajit:bootstrap3-datepicker-id");
install("rajit:bootstrap3-datepicker-it");
install("rajit:bootstrap3-datepicker-ja");
install("rajit:bootstrap3-datepicker-ka");
install("rajit:bootstrap3-datepicker-km");
install("rajit:bootstrap3-datepicker-ko");
install("rajit:bootstrap3-datepicker-lv");
install("rajit:bootstrap3-datepicker-mk");
install("rajit:bootstrap3-datepicker-mn");
install("rajit:bootstrap3-datepicker-nb");
install("rajit:bootstrap3-datepicker-nl");
install("rajit:bootstrap3-datepicker-oc");
install("rajit:bootstrap3-datepicker-pl");
install("rajit:bootstrap3-datepicker-pt-br");
install("rajit:bootstrap3-datepicker-pt");
install("rajit:bootstrap3-datepicker-ro");
install("rajit:bootstrap3-datepicker-ru");
install("rajit:bootstrap3-datepicker-sl");
install("rajit:bootstrap3-datepicker-sr");
install("rajit:bootstrap3-datepicker-sv");
install("rajit:bootstrap3-datepicker-sw");
install("rajit:bootstrap3-datepicker-ta");
install("rajit:bootstrap3-datepicker-th");
install("rajit:bootstrap3-datepicker-tr");
install("rajit:bootstrap3-datepicker-uk");
install("rajit:bootstrap3-datepicker-vi");
install("rajit:bootstrap3-datepicker-zh-cn");
install("rajit:bootstrap3-datepicker-zh-tw");
install("staringatlights:inject-data", "meteor/staringatlights:inject-data/lib/namespace.js");
install("server-render", "meteor/server-render/server.js");
install("staringatlights:fast-render", "meteor/staringatlights:fast-render/lib/server/namespace.js");
install("hot-code-push");
install("cfs:data-man");
install("cfs:file");
install("cfs:tempstore");
install("cfs:http-publish");
install("cfs:access-point");
install("cfs:reactive-property");
install("cfs:reactive-list");
install("cfs:power-queue");
install("cfs:upload-http");
install("cfs:collection");
install("cfs:collection-filters");
install("cfs:worker");
install("mdg:validation-error");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"process.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/modules/process.js                                                                              //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
if (! global.process) {
  try {
    // The application can run `npm install process` to provide its own
    // process stub; otherwise this module will provide a partial stub.
    global.process = require("process");
  } catch (missing) {
    global.process = {};
  }
}

var proc = global.process;

if (Meteor.isServer) {
  // Make require("process") work on the server in all versions of Node.
  meteorInstall({
    node_modules: {
      "process.js": function (r, e, module) {
        module.exports = proc;
      }
    }
  });
} else {
  proc.platform = "browser";
  proc.nextTick = proc.nextTick || Meteor._setImmediate;
}

if (typeof proc.env !== "object") {
  proc.env = {};
}

var hasOwn = Object.prototype.hasOwnProperty;
for (var key in meteorEnv) {
  if (hasOwn.call(meteorEnv, key)) {
    proc.env[key] = meteorEnv[key];
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"reify.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/modules/reify.js                                                                                //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
require("reify/lib/runtime").enable(
  module.constructor.prototype
);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"reify":{"lib":{"runtime":{"index.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/meteor/modules/node_modules/reify/lib/runtime/index.js                                      //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
meteorInstall({"node_modules":{"@babel":{"runtime":{"helpers":{"objectSpread2.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/@babel/runtime/helpers/objectSpread2.js                                                     //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"objectWithoutProperties.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/@babel/runtime/helpers/objectWithoutProperties.js                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"package.json":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/@babel/runtime/package.json                                                                 //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.exports = {
  "author": {
    "name": "Sebastian McKenzie",
    "email": "sebmck@gmail.com"
  },
  "bugs": {
    "url": "https://github.com/babel/babel/issues"
  },
  "dependencies": {
    "regenerator-runtime": "^0.13.4"
  },
  "description": "babel's modular runtime helpers",
  "devDependencies": {
    "@babel/helpers": "^7.10.1"
  },
  "gitHead": "b0350e5b1e86bd2d53b4a25705e39eb380ec65a2",
  "homepage": "https://babeljs.io/docs/en/next/babel-runtime",
  "license": "MIT",
  "name": "@babel/runtime",
  "publishConfig": {
    "access": "public"
  },
  "repository": {
    "type": "git",
    "url": "git+https://github.com/babel/babel.git",
    "directory": "packages/babel-runtime"
  },
  "version": "7.10.2"
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"papaparse":{"package.json":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/papaparse/package.json                                                                      //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.exports = {
  "name": "papaparse",
  "version": "5.2.0",
  "main": "papaparse.js"
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"papaparse.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/papaparse/papaparse.js                                                                      //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fibers":{"future.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/fibers/future.js                                                                            //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"package.json":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/fibers/package.json                                                                         //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.exports = {
  "name": "fibers",
  "version": "5.0.0",
  "main": "fibers"
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fibers.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/fibers/fibers.js                                                                            //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"bcrypt":{"package.json":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/bcrypt/package.json                                                                         //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.exports = {
  "name": "bcrypt",
  "version": "5.0.0",
  "main": "./bcrypt"
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"bcrypt.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// node_modules/bcrypt/bcrypt.js                                                                            //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json",
    ".coffee",
    ".mjs"
  ]
});

var exports = require("/node_modules/meteor/modules/server.js");

/* Exports */
Package._define("modules", exports, {
  meteorInstall: meteorInstall
});

})();
