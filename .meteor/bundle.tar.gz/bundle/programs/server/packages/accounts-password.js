(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var NpmModuleBcrypt = Package['npm-bcrypt'].NpmModuleBcrypt;
var Accounts = Package['accounts-base'].Accounts;
var SRP = Package.srp.SRP;
var SHA256 = Package.sha.SHA256;
var EJSON = Package.ejson.EJSON;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Email = Package.email.Email;
var EmailInternals = Package.email.EmailInternals;
var Random = Package.random.Random;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"accounts-password":{"email_templates.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/accounts-password/email_templates.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const greet = welcomeMsg => (user, url) => {
  const greeting = user.profile && user.profile.name ? "Hello ".concat(user.profile.name, ",") : "Hello,";
  return "".concat(greeting, "\n\n").concat(welcomeMsg, ", simply click the link below.\n\n").concat(url, "\n\nThanks.\n");
};
/**
 * @summary Options to customize emails sent from the Accounts system.
 * @locus Server
 * @importFromPackage accounts-base
 */


Accounts.emailTemplates = {
  from: "Accounts Example <no-reply@example.com>",
  siteName: Meteor.absoluteUrl().replace(/^https?:\/\//, '').replace(/\/$/, ''),
  resetPassword: {
    subject: () => "How to reset your password on ".concat(Accounts.emailTemplates.siteName),
    text: greet("To reset your password")
  },
  verifyEmail: {
    subject: () => "How to verify email address on ".concat(Accounts.emailTemplates.siteName),
    text: greet("To verify your account email")
  },
  enrollAccount: {
    subject: () => "An account has been created for you on ".concat(Accounts.emailTemplates.siteName),
    text: greet("To start using the service")
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"password_server.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/accounts-password/password_server.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
/// BCRYPT
const bcrypt = NpmModuleBcrypt;
const bcryptHash = Meteor.wrapAsync(bcrypt.hash);
const bcryptCompare = Meteor.wrapAsync(bcrypt.compare); // Utility for grabbing user

const getUserById = (id, options) => Meteor.users.findOne(id, Accounts._addDefaultFieldSelector(options)); // User records have a 'services.password.bcrypt' field on them to hold
// their hashed passwords (unless they have a 'services.password.srp'
// field, in which case they will be upgraded to bcrypt the next time
// they log in).
//
// When the client sends a password to the server, it can either be a
// string (the plaintext password) or an object with keys 'digest' and
// 'algorithm' (must be "sha-256" for now). The Meteor client always sends
// password objects { digest: *, algorithm: "sha-256" }, but DDP clients
// that don't have access to SHA can just send plaintext passwords as
// strings.
//
// When the server receives a plaintext password as a string, it always
// hashes it with SHA256 before passing it into bcrypt. When the server
// receives a password as an object, it asserts that the algorithm is
// "sha-256" and then passes the digest to bcrypt.


Accounts._bcryptRounds = () => Accounts._options.bcryptRounds || 10; // Given a 'password' from the client, extract the string that we should
// bcrypt. 'password' can be one of:
//  - String (the plaintext password)
//  - Object with 'digest' and 'algorithm' keys. 'algorithm' must be "sha-256".
//


const getPasswordString = password => {
  if (typeof password === "string") {
    password = SHA256(password);
  } else {
    // 'password' is an object
    if (password.algorithm !== "sha-256") {
      throw new Error("Invalid password hash algorithm. " + "Only 'sha-256' is allowed.");
    }

    password = password.digest;
  }

  return password;
}; // Use bcrypt to hash the password for storage in the database.
// `password` can be a string (in which case it will be run through
// SHA256 before bcrypt) or an object with properties `digest` and
// `algorithm` (in which case we bcrypt `password.digest`).
//


const hashPassword = password => {
  password = getPasswordString(password);
  return bcryptHash(password, Accounts._bcryptRounds());
}; // Extract the number of rounds used in the specified bcrypt hash.


const getRoundsFromBcryptHash = hash => {
  let rounds;

  if (hash) {
    const hashSegments = hash.split('$');

    if (hashSegments.length > 2) {
      rounds = parseInt(hashSegments[2], 10);
    }
  }

  return rounds;
}; // Check whether the provided password matches the bcrypt'ed password in
// the database user record. `password` can be a string (in which case
// it will be run through SHA256 before bcrypt) or an object with
// properties `digest` and `algorithm` (in which case we bcrypt
// `password.digest`).
//
// The user parameter needs at least user._id and user.services


Accounts._checkPasswordUserFields = {
  _id: 1,
  services: 1
}; //

Accounts._checkPassword = (user, password) => {
  const result = {
    userId: user._id
  };
  const formattedPassword = getPasswordString(password);
  const hash = user.services.password.bcrypt;
  const hashRounds = getRoundsFromBcryptHash(hash);

  if (!bcryptCompare(formattedPassword, hash)) {
    result.error = handleError("Incorrect password", false);
  } else if (hash && Accounts._bcryptRounds() != hashRounds) {
    // The password checks out, but the user's bcrypt hash needs to be updated.
    Meteor.defer(() => {
      Meteor.users.update({
        _id: user._id
      }, {
        $set: {
          'services.password.bcrypt': bcryptHash(formattedPassword, Accounts._bcryptRounds())
        }
      });
    });
  }

  return result;
};

const checkPassword = Accounts._checkPassword; ///
/// ERROR HANDLER
///

const handleError = function (msg) {
  let throwError = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  const error = new Meteor.Error(403, Accounts._options.ambiguousErrorMessages ? "Something went wrong. Please check your credentials." : msg);

  if (throwError) {
    throw error;
  }

  return error;
}; ///
/// LOGIN
///


Accounts._findUserByQuery = (query, options) => {
  let user = null;

  if (query.id) {
    // default field selector is added within getUserById()
    user = getUserById(query.id, options);
  } else {
    options = Accounts._addDefaultFieldSelector(options);
    let fieldName;
    let fieldValue;

    if (query.username) {
      fieldName = 'username';
      fieldValue = query.username;
    } else if (query.email) {
      fieldName = 'emails.address';
      fieldValue = query.email;
    } else {
      throw new Error("shouldn't happen (validation missed something)");
    }

    let selector = {};
    selector[fieldName] = fieldValue;
    user = Meteor.users.findOne(selector, options); // If user is not found, try a case insensitive lookup

    if (!user) {
      selector = selectorForFastCaseInsensitiveLookup(fieldName, fieldValue);
      const candidateUsers = Meteor.users.find(selector, options).fetch(); // No match if multiple candidates are found

      if (candidateUsers.length === 1) {
        user = candidateUsers[0];
      }
    }
  }

  return user;
};
/**
 * @summary Finds the user with the specified username.
 * First tries to match username case sensitively; if that fails, it
 * tries case insensitively; but if more than one user matches the case
 * insensitive search, it returns null.
 * @locus Server
 * @param {String} username The username to look for
 * @param {Object} [options]
 * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
 * @returns {Object} A user if found, else null
 * @importFromPackage accounts-base
 */


Accounts.findUserByUsername = (username, options) => Accounts._findUserByQuery({
  username
}, options);
/**
 * @summary Finds the user with the specified email.
 * First tries to match email case sensitively; if that fails, it
 * tries case insensitively; but if more than one user matches the case
 * insensitive search, it returns null.
 * @locus Server
 * @param {String} email The email address to look for
 * @param {Object} [options]
 * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
 * @returns {Object} A user if found, else null
 * @importFromPackage accounts-base
 */


Accounts.findUserByEmail = (email, options) => Accounts._findUserByQuery({
  email
}, options); // Generates a MongoDB selector that can be used to perform a fast case
// insensitive lookup for the given fieldName and string. Since MongoDB does
// not support case insensitive indexes, and case insensitive regex queries
// are slow, we construct a set of prefix selectors for all permutations of
// the first 4 characters ourselves. We first attempt to matching against
// these, and because 'prefix expression' regex queries do use indexes (see
// http://docs.mongodb.org/v2.6/reference/operator/query/regex/#index-use),
// this has been found to greatly improve performance (from 1200ms to 5ms in a
// test with 1.000.000 users).


const selectorForFastCaseInsensitiveLookup = (fieldName, string) => {
  // Performance seems to improve up to 4 prefix characters
  const prefix = string.substring(0, Math.min(string.length, 4));
  const orClause = generateCasePermutationsForString(prefix).map(prefixPermutation => {
    const selector = {};
    selector[fieldName] = new RegExp("^".concat(Meteor._escapeRegExp(prefixPermutation)));
    return selector;
  });
  const caseInsensitiveClause = {};
  caseInsensitiveClause[fieldName] = new RegExp("^".concat(Meteor._escapeRegExp(string), "$"), 'i');
  return {
    $and: [{
      $or: orClause
    }, caseInsensitiveClause]
  };
}; // Generates permutations of all case variations of a given string.


const generateCasePermutationsForString = string => {
  let permutations = [''];

  for (let i = 0; i < string.length; i++) {
    const ch = string.charAt(i);
    permutations = [].concat(...permutations.map(prefix => {
      const lowerCaseChar = ch.toLowerCase();
      const upperCaseChar = ch.toUpperCase(); // Don't add unneccesary permutations when ch is not a letter

      if (lowerCaseChar === upperCaseChar) {
        return [prefix + ch];
      } else {
        return [prefix + lowerCaseChar, prefix + upperCaseChar];
      }
    }));
  }

  return permutations;
};

const checkForCaseInsensitiveDuplicates = (fieldName, displayName, fieldValue, ownUserId) => {
  // Some tests need the ability to add users with the same case insensitive
  // value, hence the _skipCaseInsensitiveChecksForTest check
  const skipCheck = Object.prototype.hasOwnProperty.call(Accounts._skipCaseInsensitiveChecksForTest, fieldValue);

  if (fieldValue && !skipCheck) {
    const matchedUsers = Meteor.users.find(selectorForFastCaseInsensitiveLookup(fieldName, fieldValue), {
      fields: {
        _id: 1
      },
      // we only need a maximum of 2 users for the logic below to work
      limit: 2
    }).fetch();

    if (matchedUsers.length > 0 && ( // If we don't have a userId yet, any match we find is a duplicate
    !ownUserId || // Otherwise, check to see if there are multiple matches or a match
    // that is not us
    matchedUsers.length > 1 || matchedUsers[0]._id !== ownUserId)) {
      handleError("".concat(displayName, " already exists."));
    }
  }
}; // XXX maybe this belongs in the check package


const NonEmptyString = Match.Where(x => {
  check(x, String);
  return x.length > 0;
});
const userQueryValidator = Match.Where(user => {
  check(user, {
    id: Match.Optional(NonEmptyString),
    username: Match.Optional(NonEmptyString),
    email: Match.Optional(NonEmptyString)
  });
  if (Object.keys(user).length !== 1) throw new Match.Error("User property must have exactly one field");
  return true;
});
const passwordValidator = Match.OneOf(String, {
  digest: String,
  algorithm: String
}); // Handler to login with a password.
//
// The Meteor client sets options.password to an object with keys
// 'digest' (set to SHA256(password)) and 'algorithm' ("sha-256").
//
// For other DDP clients which don't have access to SHA, the handler
// also accepts the plaintext password in options.password as a string.
//
// (It might be nice if servers could turn the plaintext password
// option off. Or maybe it should be opt-in, not opt-out?
// Accounts.config option?)
//
// Note that neither password option is secure without SSL.
//

Accounts.registerLoginHandler("password", options => {
  if (!options.password || options.srp) return undefined; // don't handle

  check(options, {
    user: userQueryValidator,
    password: passwordValidator
  });

  const user = Accounts._findUserByQuery(options.user, {
    fields: _objectSpread({
      services: 1
    }, Accounts._checkPasswordUserFields)
  });

  if (!user) {
    handleError("User not found");
  }

  if (!user.services || !user.services.password || !(user.services.password.bcrypt || user.services.password.srp)) {
    handleError("User has no password set");
  }

  if (!user.services.password.bcrypt) {
    if (typeof options.password === "string") {
      // The client has presented a plaintext password, and the user is
      // not upgraded to bcrypt yet. We don't attempt to tell the client
      // to upgrade to bcrypt, because it might be a standalone DDP
      // client doesn't know how to do such a thing.
      const verifier = user.services.password.srp;
      const newVerifier = SRP.generateVerifier(options.password, {
        identity: verifier.identity,
        salt: verifier.salt
      });

      if (verifier.verifier !== newVerifier.verifier) {
        return {
          userId: Accounts._options.ambiguousErrorMessages ? null : user._id,
          error: handleError("Incorrect password", false)
        };
      }

      return {
        userId: user._id
      };
    } else {
      // Tell the client to use the SRP upgrade process.
      throw new Meteor.Error(400, "old password format", EJSON.stringify({
        format: 'srp',
        identity: user.services.password.srp.identity
      }));
    }
  }

  return checkPassword(user, options.password);
}); // Handler to login using the SRP upgrade path. To use this login
// handler, the client must provide:
//   - srp: H(identity + ":" + password)
//   - password: a string or an object with properties 'digest' and 'algorithm'
//
// We use `options.srp` to verify that the client knows the correct
// password without doing a full SRP flow. Once we've checked that, we
// upgrade the user to bcrypt and remove the SRP information from the
// user document.
//
// The client ends up using this login handler after trying the normal
// login handler (above), which throws an error telling the client to
// try the SRP upgrade path.
//
// XXX COMPAT WITH 0.8.1.3

Accounts.registerLoginHandler("password", options => {
  if (!options.srp || !options.password) {
    return undefined; // don't handle
  }

  check(options, {
    user: userQueryValidator,
    srp: String,
    password: passwordValidator
  });

  const user = Accounts._findUserByQuery(options.user, {
    fields: _objectSpread({
      services: 1
    }, Accounts._checkPasswordUserFields)
  });

  if (!user) {
    handleError("User not found");
  } // Check to see if another simultaneous login has already upgraded
  // the user record to bcrypt.


  if (user.services && user.services.password && user.services.password.bcrypt) {
    return checkPassword(user, options.password);
  }

  if (!(user.services && user.services.password && user.services.password.srp)) {
    handleError("User has no password set");
  }

  const v1 = user.services.password.srp.verifier;
  const v2 = SRP.generateVerifier(null, {
    hashedIdentityAndPassword: options.srp,
    salt: user.services.password.srp.salt
  }).verifier;

  if (v1 !== v2) {
    return {
      userId: Accounts._options.ambiguousErrorMessages ? null : user._id,
      error: handleError("Incorrect password", false)
    };
  } // Upgrade to bcrypt on successful login.


  const salted = hashPassword(options.password);
  Meteor.users.update(user._id, {
    $unset: {
      'services.password.srp': 1
    },
    $set: {
      'services.password.bcrypt': salted
    }
  });
  return {
    userId: user._id
  };
}); ///
/// CHANGING
///

/**
 * @summary Change a user's username. Use this instead of updating the
 * database directly. The operation will fail if there is an existing user
 * with a username only differing in case.
 * @locus Server
 * @param {String} userId The ID of the user to update.
 * @param {String} newUsername A new username for the user.
 * @importFromPackage accounts-base
 */

Accounts.setUsername = (userId, newUsername) => {
  check(userId, NonEmptyString);
  check(newUsername, NonEmptyString);
  const user = getUserById(userId, {
    fields: {
      username: 1
    }
  });

  if (!user) {
    handleError("User not found");
  }

  const oldUsername = user.username; // Perform a case insensitive check for duplicates before update

  checkForCaseInsensitiveDuplicates('username', 'Username', newUsername, user._id);
  Meteor.users.update({
    _id: user._id
  }, {
    $set: {
      username: newUsername
    }
  }); // Perform another check after update, in case a matching user has been
  // inserted in the meantime

  try {
    checkForCaseInsensitiveDuplicates('username', 'Username', newUsername, user._id);
  } catch (ex) {
    // Undo update if the check fails
    Meteor.users.update({
      _id: user._id
    }, {
      $set: {
        username: oldUsername
      }
    });
    throw ex;
  }
}; // Let the user change their own password if they know the old
// password. `oldPassword` and `newPassword` should be objects with keys
// `digest` and `algorithm` (representing the SHA256 of the password).
//
// XXX COMPAT WITH 0.8.1.3
// Like the login method, if the user hasn't been upgraded from SRP to
// bcrypt yet, then this method will throw an 'old password format'
// error. The client should call the SRP upgrade login handler and then
// retry this method again.
//
// UNLIKE the login method, there is no way to avoid getting SRP upgrade
// errors thrown. The reasoning for this is that clients using this
// method directly will need to be updated anyway because we no longer
// support the SRP flow that they would have been doing to use this
// method previously.


Meteor.methods({
  changePassword: function (oldPassword, newPassword) {
    check(oldPassword, passwordValidator);
    check(newPassword, passwordValidator);

    if (!this.userId) {
      throw new Meteor.Error(401, "Must be logged in");
    }

    const user = getUserById(this.userId, {
      fields: _objectSpread({
        services: 1
      }, Accounts._checkPasswordUserFields)
    });

    if (!user) {
      handleError("User not found");
    }

    if (!user.services || !user.services.password || !user.services.password.bcrypt && !user.services.password.srp) {
      handleError("User has no password set");
    }

    if (!user.services.password.bcrypt) {
      throw new Meteor.Error(400, "old password format", EJSON.stringify({
        format: 'srp',
        identity: user.services.password.srp.identity
      }));
    }

    const result = checkPassword(user, oldPassword);

    if (result.error) {
      throw result.error;
    }

    const hashed = hashPassword(newPassword); // It would be better if this removed ALL existing tokens and replaced
    // the token for the current connection with a new one, but that would
    // be tricky, so we'll settle for just replacing all tokens other than
    // the one for the current connection.

    const currentToken = Accounts._getLoginToken(this.connection.id);

    Meteor.users.update({
      _id: this.userId
    }, {
      $set: {
        'services.password.bcrypt': hashed
      },
      $pull: {
        'services.resume.loginTokens': {
          hashedToken: {
            $ne: currentToken
          }
        }
      },
      $unset: {
        'services.password.reset': 1
      }
    });
    return {
      passwordChanged: true
    };
  }
}); // Force change the users password.

/**
 * @summary Forcibly change the password for a user.
 * @locus Server
 * @param {String} userId The id of the user to update.
 * @param {String} newPassword A new password for the user.
 * @param {Object} [options]
 * @param {Object} options.logout Logout all current connections with this userId (default: true)
 * @importFromPackage accounts-base
 */

Accounts.setPassword = (userId, newPlaintextPassword, options) => {
  options = _objectSpread({
    logout: true
  }, options);
  const user = getUserById(userId, {
    fields: {
      _id: 1
    }
  });

  if (!user) {
    throw new Meteor.Error(403, "User not found");
  }

  const update = {
    $unset: {
      'services.password.srp': 1,
      // XXX COMPAT WITH 0.8.1.3
      'services.password.reset': 1
    },
    $set: {
      'services.password.bcrypt': hashPassword(newPlaintextPassword)
    }
  };

  if (options.logout) {
    update.$unset['services.resume.loginTokens'] = 1;
  }

  Meteor.users.update({
    _id: user._id
  }, update);
}; ///
/// RESETTING VIA EMAIL
///
// Utility for plucking addresses from emails


const pluckAddresses = function () {
  let emails = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return emails.map(email => email.address);
}; // Method called by a user to request a password reset email. This is
// the start of the reset process.


Meteor.methods({
  forgotPassword: options => {
    check(options, {
      email: String
    });
    const user = Accounts.findUserByEmail(options.email, {
      fields: {
        emails: 1
      }
    });

    if (!user) {
      handleError("User not found");
    }

    const emails = pluckAddresses(user.emails);
    const caseSensitiveEmail = emails.find(email => email.toLowerCase() === options.email.toLowerCase());
    Accounts.sendResetPasswordEmail(user._id, caseSensitiveEmail);
  }
});
/**
 * @summary Generates a reset token and saves it into the database.
 * @locus Server
 * @param {String} userId The id of the user to generate the reset token for.
 * @param {String} email Which address of the user to generate the reset token for. This address must be in the user's `emails` list. If `null`, defaults to the first email in the list.
 * @param {String} reason `resetPassword` or `enrollAccount`.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token} values.
 * @importFromPackage accounts-base
 */

Accounts.generateResetToken = (userId, email, reason, extraTokenData) => {
  // Make sure the user exists, and email is one of their addresses.
  // Don't limit the fields in the user object since the user is returned
  // by the function and some other fields might be used elsewhere.
  const user = getUserById(userId);

  if (!user) {
    handleError("Can't find user");
  } // pick the first email if we weren't passed an email.


  if (!email && user.emails && user.emails[0]) {
    email = user.emails[0].address;
  } // make sure we have a valid email


  if (!email || !pluckAddresses(user.emails).includes(email)) {
    handleError("No such email for user.");
  }

  const token = Random.secret();
  const tokenRecord = {
    token,
    email,
    when: new Date()
  };

  if (reason === 'resetPassword') {
    tokenRecord.reason = 'reset';
  } else if (reason === 'enrollAccount') {
    tokenRecord.reason = 'enroll';
  } else if (reason) {
    // fallback so that this function can be used for unknown reasons as well
    tokenRecord.reason = reason;
  }

  if (extraTokenData) {
    Object.assign(tokenRecord, extraTokenData);
  }

  Meteor.users.update({
    _id: user._id
  }, {
    $set: {
      'services.password.reset': tokenRecord
    }
  }); // before passing to template, update user object with new token

  Meteor._ensure(user, 'services', 'password').reset = tokenRecord;
  return {
    email,
    user,
    token
  };
};
/**
 * @summary Generates an e-mail verification token and saves it into the database.
 * @locus Server
 * @param {String} userId The id of the user to generate the  e-mail verification token for.
 * @param {String} email Which address of the user to generate the e-mail verification token for. This address must be in the user's `emails` list. If `null`, defaults to the first unverified email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token} values.
 * @importFromPackage accounts-base
 */


Accounts.generateVerificationToken = (userId, email, extraTokenData) => {
  // Make sure the user exists, and email is one of their addresses.
  // Don't limit the fields in the user object since the user is returned
  // by the function and some other fields might be used elsewhere.
  const user = getUserById(userId);

  if (!user) {
    handleError("Can't find user");
  } // pick the first unverified email if we weren't passed an email.


  if (!email) {
    const emailRecord = (user.emails || []).find(e => !e.verified);
    email = (emailRecord || {}).address;

    if (!email) {
      handleError("That user has no unverified email addresses.");
    }
  } // make sure we have a valid email


  if (!email || !pluckAddresses(user.emails).includes(email)) {
    handleError("No such email for user.");
  }

  const token = Random.secret();
  const tokenRecord = {
    token,
    // TODO: This should probably be renamed to "email" to match reset token record.
    address: email,
    when: new Date()
  };

  if (extraTokenData) {
    Object.assign(tokenRecord, extraTokenData);
  }

  Meteor.users.update({
    _id: user._id
  }, {
    $push: {
      'services.email.verificationTokens': tokenRecord
    }
  }); // before passing to template, update user object with new token

  Meteor._ensure(user, 'services', 'email');

  if (!user.services.email.verificationTokens) {
    user.services.email.verificationTokens = [];
  }

  user.services.email.verificationTokens.push(tokenRecord);
  return {
    email,
    user,
    token
  };
};
/**
 * @summary Creates options for email sending for reset password and enroll account emails.
 * You can use this function when customizing a reset password or enroll account email sending.
 * @locus Server
 * @param {Object} email Which address of the user's to send the email to.
 * @param {Object} user The user object to generate options for.
 * @param {String} url URL to which user is directed to confirm the email.
 * @param {String} reason `resetPassword` or `enrollAccount`.
 * @returns {Object} Options which can be passed to `Email.send`.
 * @importFromPackage accounts-base
 */


Accounts.generateOptionsForEmail = (email, user, url, reason) => {
  const options = {
    to: email,
    from: Accounts.emailTemplates[reason].from ? Accounts.emailTemplates[reason].from(user) : Accounts.emailTemplates.from,
    subject: Accounts.emailTemplates[reason].subject(user)
  };

  if (typeof Accounts.emailTemplates[reason].text === 'function') {
    options.text = Accounts.emailTemplates[reason].text(user, url);
  }

  if (typeof Accounts.emailTemplates[reason].html === 'function') {
    options.html = Accounts.emailTemplates[reason].html(user, url);
  }

  if (typeof Accounts.emailTemplates.headers === 'object') {
    options.headers = Accounts.emailTemplates.headers;
  }

  return options;
}; // send the user an email with a link that when opened allows the user
// to set a new password, without the old password.

/**
 * @summary Send an email with a link the user can use to reset their password.
 * @locus Server
 * @param {String} userId The id of the user to send email to.
 * @param {String} [email] Optional. Which address of the user's to send the email to. This address must be in the user's `emails` list. Defaults to the first email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token, url, options} values.
 * @importFromPackage accounts-base
 */


Accounts.sendResetPasswordEmail = (userId, email, extraTokenData) => {
  const {
    email: realEmail,
    user,
    token
  } = Accounts.generateResetToken(userId, email, 'resetPassword', extraTokenData);
  const url = Accounts.urls.resetPassword(token);
  const options = Accounts.generateOptionsForEmail(realEmail, user, url, 'resetPassword');
  Email.send(options);

  if (Meteor.isDevelopment) {
    console.log("\nReset password URL: ".concat(url));
  }

  return {
    email: realEmail,
    user,
    token,
    url,
    options
  };
}; // send the user an email informing them that their account was created, with
// a link that when opened both marks their email as verified and forces them
// to choose their password. The email must be one of the addresses in the
// user's emails field, or undefined to pick the first email automatically.
//
// This is not called automatically. It must be called manually if you
// want to use enrollment emails.

/**
 * @summary Send an email with a link the user can use to set their initial password.
 * @locus Server
 * @param {String} userId The id of the user to send email to.
 * @param {String} [email] Optional. Which address of the user's to send the email to. This address must be in the user's `emails` list. Defaults to the first email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token, url, options} values.
 * @importFromPackage accounts-base
 */


Accounts.sendEnrollmentEmail = (userId, email, extraTokenData) => {
  const {
    email: realEmail,
    user,
    token
  } = Accounts.generateResetToken(userId, email, 'enrollAccount', extraTokenData);
  const url = Accounts.urls.enrollAccount(token);
  const options = Accounts.generateOptionsForEmail(realEmail, user, url, 'enrollAccount');
  Email.send(options);

  if (Meteor.isDevelopment) {
    console.log("\nEnrollment email URL: ".concat(url));
  }

  return {
    email: realEmail,
    user,
    token,
    url,
    options
  };
}; // Take token from sendResetPasswordEmail or sendEnrollmentEmail, change
// the users password, and log them in.


Meteor.methods({
  resetPassword: function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    const token = args[0];
    const newPassword = args[1];
    return Accounts._loginMethod(this, "resetPassword", args, "password", () => {
      check(token, String);
      check(newPassword, passwordValidator);
      const user = Meteor.users.findOne({
        "services.password.reset.token": token
      }, {
        fields: {
          services: 1,
          emails: 1
        }
      });

      if (!user) {
        throw new Meteor.Error(403, "Token expired");
      }

      const {
        when,
        reason,
        email
      } = user.services.password.reset;

      let tokenLifetimeMs = Accounts._getPasswordResetTokenLifetimeMs();

      if (reason === "enroll") {
        tokenLifetimeMs = Accounts._getPasswordEnrollTokenLifetimeMs();
      }

      const currentTimeMs = Date.now();
      if (currentTimeMs - when > tokenLifetimeMs) throw new Meteor.Error(403, "Token expired");
      if (!pluckAddresses(user.emails).includes(email)) return {
        userId: user._id,
        error: new Meteor.Error(403, "Token has invalid email address")
      };
      const hashed = hashPassword(newPassword); // NOTE: We're about to invalidate tokens on the user, who we might be
      // logged in as. Make sure to avoid logging ourselves out if this
      // happens. But also make sure not to leave the connection in a state
      // of having a bad token set if things fail.

      const oldToken = Accounts._getLoginToken(this.connection.id);

      Accounts._setLoginToken(user._id, this.connection, null);

      const resetToOldToken = () => Accounts._setLoginToken(user._id, this.connection, oldToken);

      try {
        // Update the user record by:
        // - Changing the password to the new one
        // - Forgetting about the reset token that was just used
        // - Verifying their email, since they got the password reset via email.
        const affectedRecords = Meteor.users.update({
          _id: user._id,
          'emails.address': email,
          'services.password.reset.token': token
        }, {
          $set: {
            'services.password.bcrypt': hashed,
            'emails.$.verified': true
          },
          $unset: {
            'services.password.reset': 1,
            'services.password.srp': 1
          }
        });
        if (affectedRecords !== 1) return {
          userId: user._id,
          error: new Meteor.Error(403, "Invalid email")
        };
      } catch (err) {
        resetToOldToken();
        throw err;
      } // Replace all valid login tokens with new ones (changing
      // password should invalidate existing sessions).


      Accounts._clearAllLoginTokens(user._id);

      return {
        userId: user._id
      };
    });
  }
}); ///
/// EMAIL VERIFICATION
///
// send the user an email with a link that when opened marks that
// address as verified

/**
 * @summary Send an email with a link the user can use verify their email address.
 * @locus Server
 * @param {String} userId The id of the user to send email to.
 * @param {String} [email] Optional. Which address of the user's to send the email to. This address must be in the user's `emails` list. Defaults to the first unverified email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token, url, options} values.
 * @importFromPackage accounts-base
 */

Accounts.sendVerificationEmail = (userId, email, extraTokenData) => {
  // XXX Also generate a link using which someone can delete this
  // account if they own said address but weren't those who created
  // this account.
  const {
    email: realEmail,
    user,
    token
  } = Accounts.generateVerificationToken(userId, email, extraTokenData);
  const url = Accounts.urls.verifyEmail(token);
  const options = Accounts.generateOptionsForEmail(realEmail, user, url, 'verifyEmail');
  Email.send(options);

  if (Meteor.isDevelopment) {
    console.log("\nVerification email URL: ".concat(url));
  }

  return {
    email: realEmail,
    user,
    token,
    url,
    options
  };
}; // Take token from sendVerificationEmail, mark the email as verified,
// and log them in.


Meteor.methods({
  verifyEmail: function () {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    const token = args[0];
    return Accounts._loginMethod(this, "verifyEmail", args, "password", () => {
      check(token, String);
      const user = Meteor.users.findOne({
        'services.email.verificationTokens.token': token
      }, {
        fields: {
          services: 1,
          emails: 1
        }
      });
      if (!user) throw new Meteor.Error(403, "Verify email link expired");
      const tokenRecord = user.services.email.verificationTokens.find(t => t.token == token);
      if (!tokenRecord) return {
        userId: user._id,
        error: new Meteor.Error(403, "Verify email link expired")
      };
      const emailsRecord = user.emails.find(e => e.address == tokenRecord.address);
      if (!emailsRecord) return {
        userId: user._id,
        error: new Meteor.Error(403, "Verify email link is for unknown address")
      }; // By including the address in the query, we can use 'emails.$' in the
      // modifier to get a reference to the specific object in the emails
      // array. See
      // http://www.mongodb.org/display/DOCS/Updating/#Updating-The%24positionaloperator)
      // http://www.mongodb.org/display/DOCS/Updating#Updating-%24pull

      Meteor.users.update({
        _id: user._id,
        'emails.address': tokenRecord.address
      }, {
        $set: {
          'emails.$.verified': true
        },
        $pull: {
          'services.email.verificationTokens': {
            address: tokenRecord.address
          }
        }
      });
      return {
        userId: user._id
      };
    });
  }
});
/**
 * @summary Add an email address for a user. Use this instead of directly
 * updating the database. The operation will fail if there is a different user
 * with an email only differing in case. If the specified user has an existing
 * email only differing in case however, we replace it.
 * @locus Server
 * @param {String} userId The ID of the user to update.
 * @param {String} newEmail A new email address for the user.
 * @param {Boolean} [verified] Optional - whether the new email address should
 * be marked as verified. Defaults to false.
 * @importFromPackage accounts-base
 */

Accounts.addEmail = (userId, newEmail, verified) => {
  check(userId, NonEmptyString);
  check(newEmail, NonEmptyString);
  check(verified, Match.Optional(Boolean));

  if (verified === void 0) {
    verified = false;
  }

  const user = getUserById(userId, {
    fields: {
      emails: 1
    }
  });
  if (!user) throw new Meteor.Error(403, "User not found"); // Allow users to change their own email to a version with a different case
  // We don't have to call checkForCaseInsensitiveDuplicates to do a case
  // insensitive check across all emails in the database here because: (1) if
  // there is no case-insensitive duplicate between this user and other users,
  // then we are OK and (2) if this would create a conflict with other users
  // then there would already be a case-insensitive duplicate and we can't fix
  // that in this code anyway.

  const caseInsensitiveRegExp = new RegExp("^".concat(Meteor._escapeRegExp(newEmail), "$"), 'i');
  const didUpdateOwnEmail = (user.emails || []).reduce((prev, email) => {
    if (caseInsensitiveRegExp.test(email.address)) {
      Meteor.users.update({
        _id: user._id,
        'emails.address': email.address
      }, {
        $set: {
          'emails.$.address': newEmail,
          'emails.$.verified': verified
        }
      });
      return true;
    } else {
      return prev;
    }
  }, false); // In the other updates below, we have to do another call to
  // checkForCaseInsensitiveDuplicates to make sure that no conflicting values
  // were added to the database in the meantime. We don't have to do this for
  // the case where the user is updating their email address to one that is the
  // same as before, but only different because of capitalization. Read the
  // big comment above to understand why.

  if (didUpdateOwnEmail) {
    return;
  } // Perform a case insensitive check for duplicates before update


  checkForCaseInsensitiveDuplicates('emails.address', 'Email', newEmail, user._id);
  Meteor.users.update({
    _id: user._id
  }, {
    $addToSet: {
      emails: {
        address: newEmail,
        verified: verified
      }
    }
  }); // Perform another check after update, in case a matching user has been
  // inserted in the meantime

  try {
    checkForCaseInsensitiveDuplicates('emails.address', 'Email', newEmail, user._id);
  } catch (ex) {
    // Undo update if the check fails
    Meteor.users.update({
      _id: user._id
    }, {
      $pull: {
        emails: {
          address: newEmail
        }
      }
    });
    throw ex;
  }
};
/**
 * @summary Remove an email address for a user. Use this instead of updating
 * the database directly.
 * @locus Server
 * @param {String} userId The ID of the user to update.
 * @param {String} email The email address to remove.
 * @importFromPackage accounts-base
 */


Accounts.removeEmail = (userId, email) => {
  check(userId, NonEmptyString);
  check(email, NonEmptyString);
  const user = getUserById(userId, {
    fields: {
      _id: 1
    }
  });
  if (!user) throw new Meteor.Error(403, "User not found");
  Meteor.users.update({
    _id: user._id
  }, {
    $pull: {
      emails: {
        address: email
      }
    }
  });
}; ///
/// CREATING USERS
///
// Shared createUser function called from the createUser method, both
// if originates in client or server code. Calls user provided hooks,
// does the actual user insertion.
//
// returns the user id


const createUser = options => {
  // Unknown keys allowed, because a onCreateUserHook can take arbitrary
  // options.
  check(options, Match.ObjectIncluding({
    username: Match.Optional(String),
    email: Match.Optional(String),
    password: Match.Optional(passwordValidator)
  }));
  const {
    username,
    email,
    password
  } = options;
  if (!username && !email) throw new Meteor.Error(400, "Need to set a username or email");
  const user = {
    services: {}
  };

  if (password) {
    const hashed = hashPassword(password);
    user.services.password = {
      bcrypt: hashed
    };
  }

  if (username) user.username = username;
  if (email) user.emails = [{
    address: email,
    verified: false
  }]; // Perform a case insensitive check before insert

  checkForCaseInsensitiveDuplicates('username', 'Username', username);
  checkForCaseInsensitiveDuplicates('emails.address', 'Email', email);
  const userId = Accounts.insertUserDoc(options, user); // Perform another check after insert, in case a matching user has been
  // inserted in the meantime

  try {
    checkForCaseInsensitiveDuplicates('username', 'Username', username, userId);
    checkForCaseInsensitiveDuplicates('emails.address', 'Email', email, userId);
  } catch (ex) {
    // Remove inserted user if the check fails
    Meteor.users.remove(userId);
    throw ex;
  }

  return userId;
}; // method for create user. Requests come from the client.


Meteor.methods({
  createUser: function () {
    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    const options = args[0];
    return Accounts._loginMethod(this, "createUser", args, "password", () => {
      // createUser() above does more checking.
      check(options, Object);
      if (Accounts._options.forbidClientAccountCreation) return {
        error: new Meteor.Error(403, "Signups forbidden")
      };
      const userId = Accounts.createUserVerifyingEmail(options); // client gets logged in as the new user afterwards.

      return {
        userId: userId
      };
    });
  }
}); // Create user directly on the server.
//
// Differently from Accounts.createUser(), this evaluates the Accounts package
// configurations and send a verification email if the user has been registered
// successfully.

Accounts.createUserVerifyingEmail = options => {
  options = _objectSpread({}, options); // Create user. result contains id and token.

  const userId = createUser(options); // safety belt. createUser is supposed to throw on error. send 500 error
  // instead of sending a verification email with empty userid.

  if (!userId) throw new Error("createUser failed to insert new user"); // If `Accounts._options.sendVerificationEmail` is set, register
  // a token to verify the user's primary email, and send it to
  // that address.

  if (options.email && Accounts._options.sendVerificationEmail) {
    if (options.password) {
      Accounts.sendVerificationEmail(userId, options.email);
    } else {
      Accounts.sendEnrollmentEmail(userId, options.email);
    }
  }

  return userId;
}; // Create user directly on the server.
//
// Unlike the client version, this does not log you in as this user
// after creation.
//
// returns userId or throws an error if it can't create
//
// XXX add another argument ("server options") that gets sent to onCreateUser,
// which is always empty when called from the createUser method? eg, "admin:
// true", which we want to prevent the client from setting, but which a custom
// method calling Accounts.createUser could set?
//


Accounts.createUser = (options, callback) => {
  options = _objectSpread({}, options); // XXX allow an optional callback?

  if (callback) {
    throw new Error("Accounts.createUser with callback not supported on the server yet.");
  }

  return createUser(options);
}; ///
/// PASSWORD-SPECIFIC INDEXES ON USERS
///


Meteor.users._ensureIndex('services.email.verificationTokens.token', {
  unique: true,
  sparse: true
});

Meteor.users._ensureIndex('services.password.reset.token', {
  unique: true,
  sparse: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/accounts-password/email_templates.js");
require("/node_modules/meteor/accounts-password/password_server.js");

/* Exports */
Package._define("accounts-password");

})();

//# sourceURL=meteor://💻app/packages/accounts-password.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWNjb3VudHMtcGFzc3dvcmQvZW1haWxfdGVtcGxhdGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9hY2NvdW50cy1wYXNzd29yZC9wYXNzd29yZF9zZXJ2ZXIuanMiXSwibmFtZXMiOlsiZ3JlZXQiLCJ3ZWxjb21lTXNnIiwidXNlciIsInVybCIsImdyZWV0aW5nIiwicHJvZmlsZSIsIm5hbWUiLCJBY2NvdW50cyIsImVtYWlsVGVtcGxhdGVzIiwiZnJvbSIsInNpdGVOYW1lIiwiTWV0ZW9yIiwiYWJzb2x1dGVVcmwiLCJyZXBsYWNlIiwicmVzZXRQYXNzd29yZCIsInN1YmplY3QiLCJ0ZXh0IiwidmVyaWZ5RW1haWwiLCJlbnJvbGxBY2NvdW50IiwiX29iamVjdFNwcmVhZCIsIm1vZHVsZSIsImxpbmsiLCJkZWZhdWx0IiwidiIsImJjcnlwdCIsIk5wbU1vZHVsZUJjcnlwdCIsImJjcnlwdEhhc2giLCJ3cmFwQXN5bmMiLCJoYXNoIiwiYmNyeXB0Q29tcGFyZSIsImNvbXBhcmUiLCJnZXRVc2VyQnlJZCIsImlkIiwib3B0aW9ucyIsInVzZXJzIiwiZmluZE9uZSIsIl9hZGREZWZhdWx0RmllbGRTZWxlY3RvciIsIl9iY3J5cHRSb3VuZHMiLCJfb3B0aW9ucyIsImJjcnlwdFJvdW5kcyIsImdldFBhc3N3b3JkU3RyaW5nIiwicGFzc3dvcmQiLCJTSEEyNTYiLCJhbGdvcml0aG0iLCJFcnJvciIsImRpZ2VzdCIsImhhc2hQYXNzd29yZCIsImdldFJvdW5kc0Zyb21CY3J5cHRIYXNoIiwicm91bmRzIiwiaGFzaFNlZ21lbnRzIiwic3BsaXQiLCJsZW5ndGgiLCJwYXJzZUludCIsIl9jaGVja1Bhc3N3b3JkVXNlckZpZWxkcyIsIl9pZCIsInNlcnZpY2VzIiwiX2NoZWNrUGFzc3dvcmQiLCJyZXN1bHQiLCJ1c2VySWQiLCJmb3JtYXR0ZWRQYXNzd29yZCIsImhhc2hSb3VuZHMiLCJlcnJvciIsImhhbmRsZUVycm9yIiwiZGVmZXIiLCJ1cGRhdGUiLCIkc2V0IiwiY2hlY2tQYXNzd29yZCIsIm1zZyIsInRocm93RXJyb3IiLCJhbWJpZ3VvdXNFcnJvck1lc3NhZ2VzIiwiX2ZpbmRVc2VyQnlRdWVyeSIsInF1ZXJ5IiwiZmllbGROYW1lIiwiZmllbGRWYWx1ZSIsInVzZXJuYW1lIiwiZW1haWwiLCJzZWxlY3RvciIsInNlbGVjdG9yRm9yRmFzdENhc2VJbnNlbnNpdGl2ZUxvb2t1cCIsImNhbmRpZGF0ZVVzZXJzIiwiZmluZCIsImZldGNoIiwiZmluZFVzZXJCeVVzZXJuYW1lIiwiZmluZFVzZXJCeUVtYWlsIiwic3RyaW5nIiwicHJlZml4Iiwic3Vic3RyaW5nIiwiTWF0aCIsIm1pbiIsIm9yQ2xhdXNlIiwiZ2VuZXJhdGVDYXNlUGVybXV0YXRpb25zRm9yU3RyaW5nIiwibWFwIiwicHJlZml4UGVybXV0YXRpb24iLCJSZWdFeHAiLCJfZXNjYXBlUmVnRXhwIiwiY2FzZUluc2Vuc2l0aXZlQ2xhdXNlIiwiJGFuZCIsIiRvciIsInBlcm11dGF0aW9ucyIsImkiLCJjaCIsImNoYXJBdCIsImNvbmNhdCIsImxvd2VyQ2FzZUNoYXIiLCJ0b0xvd2VyQ2FzZSIsInVwcGVyQ2FzZUNoYXIiLCJ0b1VwcGVyQ2FzZSIsImNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcyIsImRpc3BsYXlOYW1lIiwib3duVXNlcklkIiwic2tpcENoZWNrIiwiT2JqZWN0IiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiX3NraXBDYXNlSW5zZW5zaXRpdmVDaGVja3NGb3JUZXN0IiwibWF0Y2hlZFVzZXJzIiwiZmllbGRzIiwibGltaXQiLCJOb25FbXB0eVN0cmluZyIsIk1hdGNoIiwiV2hlcmUiLCJ4IiwiY2hlY2siLCJTdHJpbmciLCJ1c2VyUXVlcnlWYWxpZGF0b3IiLCJPcHRpb25hbCIsImtleXMiLCJwYXNzd29yZFZhbGlkYXRvciIsIk9uZU9mIiwicmVnaXN0ZXJMb2dpbkhhbmRsZXIiLCJzcnAiLCJ1bmRlZmluZWQiLCJ2ZXJpZmllciIsIm5ld1ZlcmlmaWVyIiwiU1JQIiwiZ2VuZXJhdGVWZXJpZmllciIsImlkZW50aXR5Iiwic2FsdCIsIkVKU09OIiwic3RyaW5naWZ5IiwiZm9ybWF0IiwidjEiLCJ2MiIsImhhc2hlZElkZW50aXR5QW5kUGFzc3dvcmQiLCJzYWx0ZWQiLCIkdW5zZXQiLCJzZXRVc2VybmFtZSIsIm5ld1VzZXJuYW1lIiwib2xkVXNlcm5hbWUiLCJleCIsIm1ldGhvZHMiLCJjaGFuZ2VQYXNzd29yZCIsIm9sZFBhc3N3b3JkIiwibmV3UGFzc3dvcmQiLCJoYXNoZWQiLCJjdXJyZW50VG9rZW4iLCJfZ2V0TG9naW5Ub2tlbiIsImNvbm5lY3Rpb24iLCIkcHVsbCIsImhhc2hlZFRva2VuIiwiJG5lIiwicGFzc3dvcmRDaGFuZ2VkIiwic2V0UGFzc3dvcmQiLCJuZXdQbGFpbnRleHRQYXNzd29yZCIsImxvZ291dCIsInBsdWNrQWRkcmVzc2VzIiwiZW1haWxzIiwiYWRkcmVzcyIsImZvcmdvdFBhc3N3b3JkIiwiY2FzZVNlbnNpdGl2ZUVtYWlsIiwic2VuZFJlc2V0UGFzc3dvcmRFbWFpbCIsImdlbmVyYXRlUmVzZXRUb2tlbiIsInJlYXNvbiIsImV4dHJhVG9rZW5EYXRhIiwiaW5jbHVkZXMiLCJ0b2tlbiIsIlJhbmRvbSIsInNlY3JldCIsInRva2VuUmVjb3JkIiwid2hlbiIsIkRhdGUiLCJhc3NpZ24iLCJfZW5zdXJlIiwicmVzZXQiLCJnZW5lcmF0ZVZlcmlmaWNhdGlvblRva2VuIiwiZW1haWxSZWNvcmQiLCJlIiwidmVyaWZpZWQiLCIkcHVzaCIsInZlcmlmaWNhdGlvblRva2VucyIsInB1c2giLCJnZW5lcmF0ZU9wdGlvbnNGb3JFbWFpbCIsInRvIiwiaHRtbCIsImhlYWRlcnMiLCJyZWFsRW1haWwiLCJ1cmxzIiwiRW1haWwiLCJzZW5kIiwiaXNEZXZlbG9wbWVudCIsImNvbnNvbGUiLCJsb2ciLCJzZW5kRW5yb2xsbWVudEVtYWlsIiwiYXJncyIsIl9sb2dpbk1ldGhvZCIsInRva2VuTGlmZXRpbWVNcyIsIl9nZXRQYXNzd29yZFJlc2V0VG9rZW5MaWZldGltZU1zIiwiX2dldFBhc3N3b3JkRW5yb2xsVG9rZW5MaWZldGltZU1zIiwiY3VycmVudFRpbWVNcyIsIm5vdyIsIm9sZFRva2VuIiwiX3NldExvZ2luVG9rZW4iLCJyZXNldFRvT2xkVG9rZW4iLCJhZmZlY3RlZFJlY29yZHMiLCJlcnIiLCJfY2xlYXJBbGxMb2dpblRva2VucyIsInNlbmRWZXJpZmljYXRpb25FbWFpbCIsInQiLCJlbWFpbHNSZWNvcmQiLCJhZGRFbWFpbCIsIm5ld0VtYWlsIiwiQm9vbGVhbiIsImNhc2VJbnNlbnNpdGl2ZVJlZ0V4cCIsImRpZFVwZGF0ZU93bkVtYWlsIiwicmVkdWNlIiwicHJldiIsInRlc3QiLCIkYWRkVG9TZXQiLCJyZW1vdmVFbWFpbCIsImNyZWF0ZVVzZXIiLCJPYmplY3RJbmNsdWRpbmciLCJpbnNlcnRVc2VyRG9jIiwicmVtb3ZlIiwiZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uIiwiY3JlYXRlVXNlclZlcmlmeWluZ0VtYWlsIiwiY2FsbGJhY2siLCJfZW5zdXJlSW5kZXgiLCJ1bmlxdWUiLCJzcGFyc2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE1BQU1BLEtBQUssR0FBR0MsVUFBVSxJQUFJLENBQUNDLElBQUQsRUFBT0MsR0FBUCxLQUFlO0FBQ3JDLFFBQU1DLFFBQVEsR0FBSUYsSUFBSSxDQUFDRyxPQUFMLElBQWdCSCxJQUFJLENBQUNHLE9BQUwsQ0FBYUMsSUFBOUIsbUJBQ0RKLElBQUksQ0FBQ0csT0FBTCxDQUFhQyxJQURaLFNBQ3VCLFFBRHhDO0FBRUEsbUJBQVVGLFFBQVYsaUJBRUpILFVBRkksK0NBSUpFLEdBSkk7QUFRTCxDQVhEO0FBYUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FJLFFBQVEsQ0FBQ0MsY0FBVCxHQUEwQjtBQUN4QkMsTUFBSSxFQUFFLHlDQURrQjtBQUV4QkMsVUFBUSxFQUFFQyxNQUFNLENBQUNDLFdBQVAsR0FBcUJDLE9BQXJCLENBQTZCLGNBQTdCLEVBQTZDLEVBQTdDLEVBQWlEQSxPQUFqRCxDQUF5RCxLQUF6RCxFQUFnRSxFQUFoRSxDQUZjO0FBSXhCQyxlQUFhLEVBQUU7QUFDYkMsV0FBTyxFQUFFLDhDQUF1Q1IsUUFBUSxDQUFDQyxjQUFULENBQXdCRSxRQUEvRCxDQURJO0FBRWJNLFFBQUksRUFBRWhCLEtBQUssQ0FBQyx3QkFBRDtBQUZFLEdBSlM7QUFReEJpQixhQUFXLEVBQUU7QUFDWEYsV0FBTyxFQUFFLCtDQUF3Q1IsUUFBUSxDQUFDQyxjQUFULENBQXdCRSxRQUFoRSxDQURFO0FBRVhNLFFBQUksRUFBRWhCLEtBQUssQ0FBQyw4QkFBRDtBQUZBLEdBUlc7QUFZeEJrQixlQUFhLEVBQUU7QUFDYkgsV0FBTyxFQUFFLHVEQUFnRFIsUUFBUSxDQUFDQyxjQUFULENBQXdCRSxRQUF4RSxDQURJO0FBRWJNLFFBQUksRUFBRWhCLEtBQUssQ0FBQyw0QkFBRDtBQUZFO0FBWlMsQ0FBMUIsQzs7Ozs7Ozs7Ozs7QUNsQkEsSUFBSW1CLGFBQUo7O0FBQWtCQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSixpQkFBYSxHQUFDSSxDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQjtBQUVBLE1BQU1DLE1BQU0sR0FBR0MsZUFBZjtBQUNBLE1BQU1DLFVBQVUsR0FBR2YsTUFBTSxDQUFDZ0IsU0FBUCxDQUFpQkgsTUFBTSxDQUFDSSxJQUF4QixDQUFuQjtBQUNBLE1BQU1DLGFBQWEsR0FBR2xCLE1BQU0sQ0FBQ2dCLFNBQVAsQ0FBaUJILE1BQU0sQ0FBQ00sT0FBeEIsQ0FBdEIsQyxDQUVBOztBQUNBLE1BQU1DLFdBQVcsR0FBRyxDQUFDQyxFQUFELEVBQUtDLE9BQUwsS0FBaUJ0QixNQUFNLENBQUN1QixLQUFQLENBQWFDLE9BQWIsQ0FBcUJILEVBQXJCLEVBQXlCekIsUUFBUSxDQUFDNkIsd0JBQVQsQ0FBa0NILE9BQWxDLENBQXpCLENBQXJDLEMsQ0FFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0ExQixRQUFRLENBQUM4QixhQUFULEdBQXlCLE1BQU05QixRQUFRLENBQUMrQixRQUFULENBQWtCQyxZQUFsQixJQUFrQyxFQUFqRSxDLENBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUdDLFFBQVEsSUFBSTtBQUNwQyxNQUFJLE9BQU9BLFFBQVAsS0FBb0IsUUFBeEIsRUFBa0M7QUFDaENBLFlBQVEsR0FBR0MsTUFBTSxDQUFDRCxRQUFELENBQWpCO0FBQ0QsR0FGRCxNQUVPO0FBQUU7QUFDUCxRQUFJQSxRQUFRLENBQUNFLFNBQVQsS0FBdUIsU0FBM0IsRUFBc0M7QUFDcEMsWUFBTSxJQUFJQyxLQUFKLENBQVUsc0NBQ0EsNEJBRFYsQ0FBTjtBQUVEOztBQUNESCxZQUFRLEdBQUdBLFFBQVEsQ0FBQ0ksTUFBcEI7QUFDRDs7QUFDRCxTQUFPSixRQUFQO0FBQ0QsQ0FYRCxDLENBYUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUssWUFBWSxHQUFHTCxRQUFRLElBQUk7QUFDL0JBLFVBQVEsR0FBR0QsaUJBQWlCLENBQUNDLFFBQUQsQ0FBNUI7QUFDQSxTQUFPZixVQUFVLENBQUNlLFFBQUQsRUFBV2xDLFFBQVEsQ0FBQzhCLGFBQVQsRUFBWCxDQUFqQjtBQUNELENBSEQsQyxDQUtBOzs7QUFDQSxNQUFNVSx1QkFBdUIsR0FBR25CLElBQUksSUFBSTtBQUN0QyxNQUFJb0IsTUFBSjs7QUFDQSxNQUFJcEIsSUFBSixFQUFVO0FBQ1IsVUFBTXFCLFlBQVksR0FBR3JCLElBQUksQ0FBQ3NCLEtBQUwsQ0FBVyxHQUFYLENBQXJCOztBQUNBLFFBQUlELFlBQVksQ0FBQ0UsTUFBYixHQUFzQixDQUExQixFQUE2QjtBQUMzQkgsWUFBTSxHQUFHSSxRQUFRLENBQUNILFlBQVksQ0FBQyxDQUFELENBQWIsRUFBa0IsRUFBbEIsQ0FBakI7QUFDRDtBQUNGOztBQUNELFNBQU9ELE1BQVA7QUFDRCxDQVRELEMsQ0FXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0F6QyxRQUFRLENBQUM4Qyx3QkFBVCxHQUFvQztBQUFDQyxLQUFHLEVBQUUsQ0FBTjtBQUFTQyxVQUFRLEVBQUU7QUFBbkIsQ0FBcEMsQyxDQUNBOztBQUNBaEQsUUFBUSxDQUFDaUQsY0FBVCxHQUEwQixDQUFDdEQsSUFBRCxFQUFPdUMsUUFBUCxLQUFvQjtBQUM1QyxRQUFNZ0IsTUFBTSxHQUFHO0FBQ2JDLFVBQU0sRUFBRXhELElBQUksQ0FBQ29EO0FBREEsR0FBZjtBQUlBLFFBQU1LLGlCQUFpQixHQUFHbkIsaUJBQWlCLENBQUNDLFFBQUQsQ0FBM0M7QUFDQSxRQUFNYixJQUFJLEdBQUcxQixJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJqQixNQUFwQztBQUNBLFFBQU1vQyxVQUFVLEdBQUdiLHVCQUF1QixDQUFDbkIsSUFBRCxDQUExQzs7QUFFQSxNQUFJLENBQUVDLGFBQWEsQ0FBQzhCLGlCQUFELEVBQW9CL0IsSUFBcEIsQ0FBbkIsRUFBOEM7QUFDNUM2QixVQUFNLENBQUNJLEtBQVAsR0FBZUMsV0FBVyxDQUFDLG9CQUFELEVBQXVCLEtBQXZCLENBQTFCO0FBQ0QsR0FGRCxNQUVPLElBQUlsQyxJQUFJLElBQUlyQixRQUFRLENBQUM4QixhQUFULE1BQTRCdUIsVUFBeEMsRUFBb0Q7QUFDekQ7QUFDQWpELFVBQU0sQ0FBQ29ELEtBQVAsQ0FBYSxNQUFNO0FBQ2pCcEQsWUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUFvQjtBQUFFVixXQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQUFaLE9BQXBCLEVBQXVDO0FBQ3JDVyxZQUFJLEVBQUU7QUFDSixzQ0FDRXZDLFVBQVUsQ0FBQ2lDLGlCQUFELEVBQW9CcEQsUUFBUSxDQUFDOEIsYUFBVCxFQUFwQjtBQUZSO0FBRCtCLE9BQXZDO0FBTUQsS0FQRDtBQVFEOztBQUVELFNBQU9vQixNQUFQO0FBQ0QsQ0F4QkQ7O0FBeUJBLE1BQU1TLGFBQWEsR0FBRzNELFFBQVEsQ0FBQ2lELGNBQS9CLEMsQ0FFQTtBQUNBO0FBQ0E7O0FBQ0EsTUFBTU0sV0FBVyxHQUFHLFVBQUNLLEdBQUQsRUFBNEI7QUFBQSxNQUF0QkMsVUFBc0IsdUVBQVQsSUFBUztBQUM5QyxRQUFNUCxLQUFLLEdBQUcsSUFBSWxELE1BQU0sQ0FBQ2lDLEtBQVgsQ0FDWixHQURZLEVBRVpyQyxRQUFRLENBQUMrQixRQUFULENBQWtCK0Isc0JBQWxCLEdBQ0ksc0RBREosR0FFSUYsR0FKUSxDQUFkOztBQU1BLE1BQUlDLFVBQUosRUFBZ0I7QUFDZCxVQUFNUCxLQUFOO0FBQ0Q7O0FBQ0QsU0FBT0EsS0FBUDtBQUNELENBWEQsQyxDQWFBO0FBQ0E7QUFDQTs7O0FBRUF0RCxRQUFRLENBQUMrRCxnQkFBVCxHQUE0QixDQUFDQyxLQUFELEVBQVF0QyxPQUFSLEtBQW9CO0FBQzlDLE1BQUkvQixJQUFJLEdBQUcsSUFBWDs7QUFFQSxNQUFJcUUsS0FBSyxDQUFDdkMsRUFBVixFQUFjO0FBQ1o7QUFDQTlCLFFBQUksR0FBRzZCLFdBQVcsQ0FBQ3dDLEtBQUssQ0FBQ3ZDLEVBQVAsRUFBV0MsT0FBWCxDQUFsQjtBQUNELEdBSEQsTUFHTztBQUNMQSxXQUFPLEdBQUcxQixRQUFRLENBQUM2Qix3QkFBVCxDQUFrQ0gsT0FBbEMsQ0FBVjtBQUNBLFFBQUl1QyxTQUFKO0FBQ0EsUUFBSUMsVUFBSjs7QUFDQSxRQUFJRixLQUFLLENBQUNHLFFBQVYsRUFBb0I7QUFDbEJGLGVBQVMsR0FBRyxVQUFaO0FBQ0FDLGdCQUFVLEdBQUdGLEtBQUssQ0FBQ0csUUFBbkI7QUFDRCxLQUhELE1BR08sSUFBSUgsS0FBSyxDQUFDSSxLQUFWLEVBQWlCO0FBQ3RCSCxlQUFTLEdBQUcsZ0JBQVo7QUFDQUMsZ0JBQVUsR0FBR0YsS0FBSyxDQUFDSSxLQUFuQjtBQUNELEtBSE0sTUFHQTtBQUNMLFlBQU0sSUFBSS9CLEtBQUosQ0FBVSxnREFBVixDQUFOO0FBQ0Q7O0FBQ0QsUUFBSWdDLFFBQVEsR0FBRyxFQUFmO0FBQ0FBLFlBQVEsQ0FBQ0osU0FBRCxDQUFSLEdBQXNCQyxVQUF0QjtBQUNBdkUsUUFBSSxHQUFHUyxNQUFNLENBQUN1QixLQUFQLENBQWFDLE9BQWIsQ0FBcUJ5QyxRQUFyQixFQUErQjNDLE9BQS9CLENBQVAsQ0FmSyxDQWdCTDs7QUFDQSxRQUFJLENBQUMvQixJQUFMLEVBQVc7QUFDVDBFLGNBQVEsR0FBR0Msb0NBQW9DLENBQUNMLFNBQUQsRUFBWUMsVUFBWixDQUEvQztBQUNBLFlBQU1LLGNBQWMsR0FBR25FLE1BQU0sQ0FBQ3VCLEtBQVAsQ0FBYTZDLElBQWIsQ0FBa0JILFFBQWxCLEVBQTRCM0MsT0FBNUIsRUFBcUMrQyxLQUFyQyxFQUF2QixDQUZTLENBR1Q7O0FBQ0EsVUFBSUYsY0FBYyxDQUFDM0IsTUFBZixLQUEwQixDQUE5QixFQUFpQztBQUMvQmpELFlBQUksR0FBRzRFLGNBQWMsQ0FBQyxDQUFELENBQXJCO0FBQ0Q7QUFDRjtBQUNGOztBQUVELFNBQU81RSxJQUFQO0FBQ0QsQ0FsQ0Q7QUFvQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQUssUUFBUSxDQUFDMEUsa0JBQVQsR0FDRSxDQUFDUCxRQUFELEVBQVd6QyxPQUFYLEtBQXVCMUIsUUFBUSxDQUFDK0QsZ0JBQVQsQ0FBMEI7QUFBRUk7QUFBRixDQUExQixFQUF3Q3pDLE9BQXhDLENBRHpCO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTFCLFFBQVEsQ0FBQzJFLGVBQVQsR0FDRSxDQUFDUCxLQUFELEVBQVExQyxPQUFSLEtBQW9CMUIsUUFBUSxDQUFDK0QsZ0JBQVQsQ0FBMEI7QUFBRUs7QUFBRixDQUExQixFQUFxQzFDLE9BQXJDLENBRHRCLEMsQ0FHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU00QyxvQ0FBb0MsR0FBRyxDQUFDTCxTQUFELEVBQVlXLE1BQVosS0FBdUI7QUFDbEU7QUFDQSxRQUFNQyxNQUFNLEdBQUdELE1BQU0sQ0FBQ0UsU0FBUCxDQUFpQixDQUFqQixFQUFvQkMsSUFBSSxDQUFDQyxHQUFMLENBQVNKLE1BQU0sQ0FBQ2hDLE1BQWhCLEVBQXdCLENBQXhCLENBQXBCLENBQWY7QUFDQSxRQUFNcUMsUUFBUSxHQUFHQyxpQ0FBaUMsQ0FBQ0wsTUFBRCxDQUFqQyxDQUEwQ00sR0FBMUMsQ0FDZkMsaUJBQWlCLElBQUk7QUFDbkIsVUFBTWYsUUFBUSxHQUFHLEVBQWpCO0FBQ0FBLFlBQVEsQ0FBQ0osU0FBRCxDQUFSLEdBQ0UsSUFBSW9CLE1BQUosWUFBZWpGLE1BQU0sQ0FBQ2tGLGFBQVAsQ0FBcUJGLGlCQUFyQixDQUFmLEVBREY7QUFFQSxXQUFPZixRQUFQO0FBQ0QsR0FOYyxDQUFqQjtBQU9BLFFBQU1rQixxQkFBcUIsR0FBRyxFQUE5QjtBQUNBQSx1QkFBcUIsQ0FBQ3RCLFNBQUQsQ0FBckIsR0FDRSxJQUFJb0IsTUFBSixZQUFlakYsTUFBTSxDQUFDa0YsYUFBUCxDQUFxQlYsTUFBckIsQ0FBZixRQUFnRCxHQUFoRCxDQURGO0FBRUEsU0FBTztBQUFDWSxRQUFJLEVBQUUsQ0FBQztBQUFDQyxTQUFHLEVBQUVSO0FBQU4sS0FBRCxFQUFrQk0scUJBQWxCO0FBQVAsR0FBUDtBQUNELENBZEQsQyxDQWdCQTs7O0FBQ0EsTUFBTUwsaUNBQWlDLEdBQUdOLE1BQU0sSUFBSTtBQUNsRCxNQUFJYyxZQUFZLEdBQUcsQ0FBQyxFQUFELENBQW5COztBQUNBLE9BQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2YsTUFBTSxDQUFDaEMsTUFBM0IsRUFBbUMrQyxDQUFDLEVBQXBDLEVBQXdDO0FBQ3RDLFVBQU1DLEVBQUUsR0FBR2hCLE1BQU0sQ0FBQ2lCLE1BQVAsQ0FBY0YsQ0FBZCxDQUFYO0FBQ0FELGdCQUFZLEdBQUcsR0FBR0ksTUFBSCxDQUFVLEdBQUlKLFlBQVksQ0FBQ1AsR0FBYixDQUFpQk4sTUFBTSxJQUFJO0FBQ3RELFlBQU1rQixhQUFhLEdBQUdILEVBQUUsQ0FBQ0ksV0FBSCxFQUF0QjtBQUNBLFlBQU1DLGFBQWEsR0FBR0wsRUFBRSxDQUFDTSxXQUFILEVBQXRCLENBRnNELENBR3REOztBQUNBLFVBQUlILGFBQWEsS0FBS0UsYUFBdEIsRUFBcUM7QUFDbkMsZUFBTyxDQUFDcEIsTUFBTSxHQUFHZSxFQUFWLENBQVA7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPLENBQUNmLE1BQU0sR0FBR2tCLGFBQVYsRUFBeUJsQixNQUFNLEdBQUdvQixhQUFsQyxDQUFQO0FBQ0Q7QUFDRixLQVQ0QixDQUFkLENBQWY7QUFVRDs7QUFDRCxTQUFPUCxZQUFQO0FBQ0QsQ0FoQkQ7O0FBa0JBLE1BQU1TLGlDQUFpQyxHQUFHLENBQUNsQyxTQUFELEVBQVltQyxXQUFaLEVBQXlCbEMsVUFBekIsRUFBcUNtQyxTQUFyQyxLQUFtRDtBQUMzRjtBQUNBO0FBQ0EsUUFBTUMsU0FBUyxHQUFHQyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQzFHLFFBQVEsQ0FBQzJHLGlDQUE5QyxFQUFpRnpDLFVBQWpGLENBQWxCOztBQUVBLE1BQUlBLFVBQVUsSUFBSSxDQUFDb0MsU0FBbkIsRUFBOEI7QUFDNUIsVUFBTU0sWUFBWSxHQUFHeEcsTUFBTSxDQUFDdUIsS0FBUCxDQUFhNkMsSUFBYixDQUNuQkYsb0NBQW9DLENBQUNMLFNBQUQsRUFBWUMsVUFBWixDQURqQixFQUVuQjtBQUNFMkMsWUFBTSxFQUFFO0FBQUM5RCxXQUFHLEVBQUU7QUFBTixPQURWO0FBRUU7QUFDQStELFdBQUssRUFBRTtBQUhULEtBRm1CLEVBT25CckMsS0FQbUIsRUFBckI7O0FBU0EsUUFBSW1DLFlBQVksQ0FBQ2hFLE1BQWIsR0FBc0IsQ0FBdEIsTUFDQTtBQUNDLEtBQUN5RCxTQUFELElBQ0Q7QUFDQTtBQUNDTyxnQkFBWSxDQUFDaEUsTUFBYixHQUFzQixDQUF0QixJQUEyQmdFLFlBQVksQ0FBQyxDQUFELENBQVosQ0FBZ0I3RCxHQUFoQixLQUF3QnNELFNBTHBELENBQUosRUFLcUU7QUFDbkU5QyxpQkFBVyxXQUFJNkMsV0FBSixzQkFBWDtBQUNEO0FBQ0Y7QUFDRixDQXhCRCxDLENBMEJBOzs7QUFDQSxNQUFNVyxjQUFjLEdBQUdDLEtBQUssQ0FBQ0MsS0FBTixDQUFZQyxDQUFDLElBQUk7QUFDdENDLE9BQUssQ0FBQ0QsQ0FBRCxFQUFJRSxNQUFKLENBQUw7QUFDQSxTQUFPRixDQUFDLENBQUN0RSxNQUFGLEdBQVcsQ0FBbEI7QUFDRCxDQUhzQixDQUF2QjtBQUtBLE1BQU15RSxrQkFBa0IsR0FBR0wsS0FBSyxDQUFDQyxLQUFOLENBQVl0SCxJQUFJLElBQUk7QUFDN0N3SCxPQUFLLENBQUN4SCxJQUFELEVBQU87QUFDVjhCLE1BQUUsRUFBRXVGLEtBQUssQ0FBQ00sUUFBTixDQUFlUCxjQUFmLENBRE07QUFFVjVDLFlBQVEsRUFBRTZDLEtBQUssQ0FBQ00sUUFBTixDQUFlUCxjQUFmLENBRkE7QUFHVjNDLFNBQUssRUFBRTRDLEtBQUssQ0FBQ00sUUFBTixDQUFlUCxjQUFmO0FBSEcsR0FBUCxDQUFMO0FBS0EsTUFBSVIsTUFBTSxDQUFDZ0IsSUFBUCxDQUFZNUgsSUFBWixFQUFrQmlELE1BQWxCLEtBQTZCLENBQWpDLEVBQ0UsTUFBTSxJQUFJb0UsS0FBSyxDQUFDM0UsS0FBVixDQUFnQiwyQ0FBaEIsQ0FBTjtBQUNGLFNBQU8sSUFBUDtBQUNELENBVDBCLENBQTNCO0FBV0EsTUFBTW1GLGlCQUFpQixHQUFHUixLQUFLLENBQUNTLEtBQU4sQ0FDeEJMLE1BRHdCLEVBRXhCO0FBQUU5RSxRQUFNLEVBQUU4RSxNQUFWO0FBQWtCaEYsV0FBUyxFQUFFZ0Y7QUFBN0IsQ0FGd0IsQ0FBMUIsQyxDQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FwSCxRQUFRLENBQUMwSCxvQkFBVCxDQUE4QixVQUE5QixFQUEwQ2hHLE9BQU8sSUFBSTtBQUNuRCxNQUFJLENBQUVBLE9BQU8sQ0FBQ1EsUUFBVixJQUFzQlIsT0FBTyxDQUFDaUcsR0FBbEMsRUFDRSxPQUFPQyxTQUFQLENBRmlELENBRS9COztBQUVwQlQsT0FBSyxDQUFDekYsT0FBRCxFQUFVO0FBQ2IvQixRQUFJLEVBQUUwSCxrQkFETztBQUVibkYsWUFBUSxFQUFFc0Y7QUFGRyxHQUFWLENBQUw7O0FBTUEsUUFBTTdILElBQUksR0FBR0ssUUFBUSxDQUFDK0QsZ0JBQVQsQ0FBMEJyQyxPQUFPLENBQUMvQixJQUFsQyxFQUF3QztBQUFDa0gsVUFBTTtBQUMxRDdELGNBQVEsRUFBRTtBQURnRCxPQUV2RGhELFFBQVEsQ0FBQzhDLHdCQUY4QztBQUFQLEdBQXhDLENBQWI7O0FBSUEsTUFBSSxDQUFDbkQsSUFBTCxFQUFXO0FBQ1Q0RCxlQUFXLENBQUMsZ0JBQUQsQ0FBWDtBQUNEOztBQUVELE1BQUksQ0FBQzVELElBQUksQ0FBQ3FELFFBQU4sSUFBa0IsQ0FBQ3JELElBQUksQ0FBQ3FELFFBQUwsQ0FBY2QsUUFBakMsSUFDQSxFQUFFdkMsSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUFkLENBQXVCakIsTUFBdkIsSUFBaUN0QixJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJ5RixHQUExRCxDQURKLEVBQ29FO0FBQ2xFcEUsZUFBVyxDQUFDLDBCQUFELENBQVg7QUFDRDs7QUFFRCxNQUFJLENBQUM1RCxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJqQixNQUE1QixFQUFvQztBQUNsQyxRQUFJLE9BQU9TLE9BQU8sQ0FBQ1EsUUFBZixLQUE0QixRQUFoQyxFQUEwQztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQU0yRixRQUFRLEdBQUdsSSxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJ5RixHQUF4QztBQUNBLFlBQU1HLFdBQVcsR0FBR0MsR0FBRyxDQUFDQyxnQkFBSixDQUFxQnRHLE9BQU8sQ0FBQ1EsUUFBN0IsRUFBdUM7QUFDekQrRixnQkFBUSxFQUFFSixRQUFRLENBQUNJLFFBRHNDO0FBQzVCQyxZQUFJLEVBQUVMLFFBQVEsQ0FBQ0s7QUFEYSxPQUF2QyxDQUFwQjs7QUFHQSxVQUFJTCxRQUFRLENBQUNBLFFBQVQsS0FBc0JDLFdBQVcsQ0FBQ0QsUUFBdEMsRUFBZ0Q7QUFDOUMsZUFBTztBQUNMMUUsZ0JBQU0sRUFBRW5ELFFBQVEsQ0FBQytCLFFBQVQsQ0FBa0IrQixzQkFBbEIsR0FBMkMsSUFBM0MsR0FBa0RuRSxJQUFJLENBQUNvRCxHQUQxRDtBQUVMTyxlQUFLLEVBQUVDLFdBQVcsQ0FBQyxvQkFBRCxFQUF1QixLQUF2QjtBQUZiLFNBQVA7QUFJRDs7QUFFRCxhQUFPO0FBQUNKLGNBQU0sRUFBRXhELElBQUksQ0FBQ29EO0FBQWQsT0FBUDtBQUNELEtBakJELE1BaUJPO0FBQ0w7QUFDQSxZQUFNLElBQUkzQyxNQUFNLENBQUNpQyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLHFCQUF0QixFQUE2QzhGLEtBQUssQ0FBQ0MsU0FBTixDQUFnQjtBQUNqRUMsY0FBTSxFQUFFLEtBRHlEO0FBRWpFSixnQkFBUSxFQUFFdEksSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUFkLENBQXVCeUYsR0FBdkIsQ0FBMkJNO0FBRjRCLE9BQWhCLENBQTdDLENBQU47QUFJRDtBQUNGOztBQUVELFNBQU90RSxhQUFhLENBQ2xCaEUsSUFEa0IsRUFFbEIrQixPQUFPLENBQUNRLFFBRlUsQ0FBcEI7QUFJRCxDQXRERCxFLENBd0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQWxDLFFBQVEsQ0FBQzBILG9CQUFULENBQThCLFVBQTlCLEVBQTBDaEcsT0FBTyxJQUFJO0FBQ25ELE1BQUksQ0FBQ0EsT0FBTyxDQUFDaUcsR0FBVCxJQUFnQixDQUFDakcsT0FBTyxDQUFDUSxRQUE3QixFQUF1QztBQUNyQyxXQUFPMEYsU0FBUCxDQURxQyxDQUNuQjtBQUNuQjs7QUFFRFQsT0FBSyxDQUFDekYsT0FBRCxFQUFVO0FBQ2IvQixRQUFJLEVBQUUwSCxrQkFETztBQUViTSxPQUFHLEVBQUVQLE1BRlE7QUFHYmxGLFlBQVEsRUFBRXNGO0FBSEcsR0FBVixDQUFMOztBQU1BLFFBQU03SCxJQUFJLEdBQUdLLFFBQVEsQ0FBQytELGdCQUFULENBQTBCckMsT0FBTyxDQUFDL0IsSUFBbEMsRUFBd0M7QUFBQ2tILFVBQU07QUFDMUQ3RCxjQUFRLEVBQUU7QUFEZ0QsT0FFdkRoRCxRQUFRLENBQUM4Qyx3QkFGOEM7QUFBUCxHQUF4QyxDQUFiOztBQUlBLE1BQUksQ0FBQ25ELElBQUwsRUFBVztBQUNUNEQsZUFBVyxDQUFDLGdCQUFELENBQVg7QUFDRCxHQWpCa0QsQ0FtQm5EO0FBQ0E7OztBQUNBLE1BQUk1RCxJQUFJLENBQUNxRCxRQUFMLElBQWlCckQsSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUEvQixJQUEyQ3ZDLElBQUksQ0FBQ3FELFFBQUwsQ0FBY2QsUUFBZCxDQUF1QmpCLE1BQXRFLEVBQThFO0FBQzVFLFdBQU8wQyxhQUFhLENBQUNoRSxJQUFELEVBQU8rQixPQUFPLENBQUNRLFFBQWYsQ0FBcEI7QUFDRDs7QUFFRCxNQUFJLEVBQUV2QyxJQUFJLENBQUNxRCxRQUFMLElBQWlCckQsSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUEvQixJQUEyQ3ZDLElBQUksQ0FBQ3FELFFBQUwsQ0FBY2QsUUFBZCxDQUF1QnlGLEdBQXBFLENBQUosRUFBOEU7QUFDNUVwRSxlQUFXLENBQUMsMEJBQUQsQ0FBWDtBQUNEOztBQUVELFFBQU0rRSxFQUFFLEdBQUczSSxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJ5RixHQUF2QixDQUEyQkUsUUFBdEM7QUFDQSxRQUFNVSxFQUFFLEdBQUdSLEdBQUcsQ0FBQ0MsZ0JBQUosQ0FDVCxJQURTLEVBRVQ7QUFDRVEsNkJBQXlCLEVBQUU5RyxPQUFPLENBQUNpRyxHQURyQztBQUVFTyxRQUFJLEVBQUV2SSxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJ5RixHQUF2QixDQUEyQk87QUFGbkMsR0FGUyxFQU1UTCxRQU5GOztBQU9BLE1BQUlTLEVBQUUsS0FBS0MsRUFBWCxFQUFlO0FBQ2IsV0FBTztBQUNMcEYsWUFBTSxFQUFFbkQsUUFBUSxDQUFDK0IsUUFBVCxDQUFrQitCLHNCQUFsQixHQUEyQyxJQUEzQyxHQUFrRG5FLElBQUksQ0FBQ29ELEdBRDFEO0FBRUxPLFdBQUssRUFBRUMsV0FBVyxDQUFDLG9CQUFELEVBQXVCLEtBQXZCO0FBRmIsS0FBUDtBQUlELEdBMUNrRCxDQTRDbkQ7OztBQUNBLFFBQU1rRixNQUFNLEdBQUdsRyxZQUFZLENBQUNiLE9BQU8sQ0FBQ1EsUUFBVCxDQUEzQjtBQUNBOUIsUUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUNFOUQsSUFBSSxDQUFDb0QsR0FEUCxFQUVFO0FBQ0UyRixVQUFNLEVBQUU7QUFBRSwrQkFBeUI7QUFBM0IsS0FEVjtBQUVFaEYsUUFBSSxFQUFFO0FBQUUsa0NBQTRCK0U7QUFBOUI7QUFGUixHQUZGO0FBUUEsU0FBTztBQUFDdEYsVUFBTSxFQUFFeEQsSUFBSSxDQUFDb0Q7QUFBZCxHQUFQO0FBQ0QsQ0F2REQsRSxDQTBEQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBL0MsUUFBUSxDQUFDMkksV0FBVCxHQUF1QixDQUFDeEYsTUFBRCxFQUFTeUYsV0FBVCxLQUF5QjtBQUM5Q3pCLE9BQUssQ0FBQ2hFLE1BQUQsRUFBUzRELGNBQVQsQ0FBTDtBQUNBSSxPQUFLLENBQUN5QixXQUFELEVBQWM3QixjQUFkLENBQUw7QUFFQSxRQUFNcEgsSUFBSSxHQUFHNkIsV0FBVyxDQUFDMkIsTUFBRCxFQUFTO0FBQUMwRCxVQUFNLEVBQUU7QUFDeEMxQyxjQUFRLEVBQUU7QUFEOEI7QUFBVCxHQUFULENBQXhCOztBQUdBLE1BQUksQ0FBQ3hFLElBQUwsRUFBVztBQUNUNEQsZUFBVyxDQUFDLGdCQUFELENBQVg7QUFDRDs7QUFFRCxRQUFNc0YsV0FBVyxHQUFHbEosSUFBSSxDQUFDd0UsUUFBekIsQ0FYOEMsQ0FhOUM7O0FBQ0FnQyxtQ0FBaUMsQ0FBQyxVQUFELEVBQWEsVUFBYixFQUF5QnlDLFdBQXpCLEVBQXNDakosSUFBSSxDQUFDb0QsR0FBM0MsQ0FBakM7QUFFQTNDLFFBQU0sQ0FBQ3VCLEtBQVAsQ0FBYThCLE1BQWIsQ0FBb0I7QUFBQ1YsT0FBRyxFQUFFcEQsSUFBSSxDQUFDb0Q7QUFBWCxHQUFwQixFQUFxQztBQUFDVyxRQUFJLEVBQUU7QUFBQ1MsY0FBUSxFQUFFeUU7QUFBWDtBQUFQLEdBQXJDLEVBaEI4QyxDQWtCOUM7QUFDQTs7QUFDQSxNQUFJO0FBQ0Z6QyxxQ0FBaUMsQ0FBQyxVQUFELEVBQWEsVUFBYixFQUF5QnlDLFdBQXpCLEVBQXNDakosSUFBSSxDQUFDb0QsR0FBM0MsQ0FBakM7QUFDRCxHQUZELENBRUUsT0FBTytGLEVBQVAsRUFBVztBQUNYO0FBQ0ExSSxVQUFNLENBQUN1QixLQUFQLENBQWE4QixNQUFiLENBQW9CO0FBQUNWLFNBQUcsRUFBRXBELElBQUksQ0FBQ29EO0FBQVgsS0FBcEIsRUFBcUM7QUFBQ1csVUFBSSxFQUFFO0FBQUNTLGdCQUFRLEVBQUUwRTtBQUFYO0FBQVAsS0FBckM7QUFDQSxVQUFNQyxFQUFOO0FBQ0Q7QUFDRixDQTNCRCxDLENBNkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ExSSxNQUFNLENBQUMySSxPQUFQLENBQWU7QUFBQ0MsZ0JBQWMsRUFBRSxVQUFVQyxXQUFWLEVBQXVCQyxXQUF2QixFQUFvQztBQUNsRS9CLFNBQUssQ0FBQzhCLFdBQUQsRUFBY3pCLGlCQUFkLENBQUw7QUFDQUwsU0FBSyxDQUFDK0IsV0FBRCxFQUFjMUIsaUJBQWQsQ0FBTDs7QUFFQSxRQUFJLENBQUMsS0FBS3JFLE1BQVYsRUFBa0I7QUFDaEIsWUFBTSxJQUFJL0MsTUFBTSxDQUFDaUMsS0FBWCxDQUFpQixHQUFqQixFQUFzQixtQkFBdEIsQ0FBTjtBQUNEOztBQUVELFVBQU0xQyxJQUFJLEdBQUc2QixXQUFXLENBQUMsS0FBSzJCLE1BQU4sRUFBYztBQUFDMEQsWUFBTTtBQUMzQzdELGdCQUFRLEVBQUU7QUFEaUMsU0FFeENoRCxRQUFRLENBQUM4Qyx3QkFGK0I7QUFBUCxLQUFkLENBQXhCOztBQUlBLFFBQUksQ0FBQ25ELElBQUwsRUFBVztBQUNUNEQsaUJBQVcsQ0FBQyxnQkFBRCxDQUFYO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDNUQsSUFBSSxDQUFDcUQsUUFBTixJQUFrQixDQUFDckQsSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUFqQyxJQUNDLENBQUN2QyxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJqQixNQUF4QixJQUFrQyxDQUFDdEIsSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUFkLENBQXVCeUYsR0FEL0QsRUFDcUU7QUFDbkVwRSxpQkFBVyxDQUFDLDBCQUFELENBQVg7QUFDRDs7QUFFRCxRQUFJLENBQUU1RCxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJqQixNQUE3QixFQUFxQztBQUNuQyxZQUFNLElBQUliLE1BQU0sQ0FBQ2lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IscUJBQXRCLEVBQTZDOEYsS0FBSyxDQUFDQyxTQUFOLENBQWdCO0FBQ2pFQyxjQUFNLEVBQUUsS0FEeUQ7QUFFakVKLGdCQUFRLEVBQUV0SSxJQUFJLENBQUNxRCxRQUFMLENBQWNkLFFBQWQsQ0FBdUJ5RixHQUF2QixDQUEyQk07QUFGNEIsT0FBaEIsQ0FBN0MsQ0FBTjtBQUlEOztBQUVELFVBQU0vRSxNQUFNLEdBQUdTLGFBQWEsQ0FBQ2hFLElBQUQsRUFBT3NKLFdBQVAsQ0FBNUI7O0FBQ0EsUUFBSS9GLE1BQU0sQ0FBQ0ksS0FBWCxFQUFrQjtBQUNoQixZQUFNSixNQUFNLENBQUNJLEtBQWI7QUFDRDs7QUFFRCxVQUFNNkYsTUFBTSxHQUFHNUcsWUFBWSxDQUFDMkcsV0FBRCxDQUEzQixDQWpDa0UsQ0FtQ2xFO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQU1FLFlBQVksR0FBR3BKLFFBQVEsQ0FBQ3FKLGNBQVQsQ0FBd0IsS0FBS0MsVUFBTCxDQUFnQjdILEVBQXhDLENBQXJCOztBQUNBckIsVUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUNFO0FBQUVWLFNBQUcsRUFBRSxLQUFLSTtBQUFaLEtBREYsRUFFRTtBQUNFTyxVQUFJLEVBQUU7QUFBRSxvQ0FBNEJ5RjtBQUE5QixPQURSO0FBRUVJLFdBQUssRUFBRTtBQUNMLHVDQUErQjtBQUFFQyxxQkFBVyxFQUFFO0FBQUVDLGVBQUcsRUFBRUw7QUFBUDtBQUFmO0FBRDFCLE9BRlQ7QUFLRVYsWUFBTSxFQUFFO0FBQUUsbUNBQTJCO0FBQTdCO0FBTFYsS0FGRjtBQVdBLFdBQU87QUFBQ2dCLHFCQUFlLEVBQUU7QUFBbEIsS0FBUDtBQUNEO0FBcERjLENBQWYsRSxDQXVEQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0ExSixRQUFRLENBQUMySixXQUFULEdBQXVCLENBQUN4RyxNQUFELEVBQVN5RyxvQkFBVCxFQUErQmxJLE9BQS9CLEtBQTJDO0FBQ2hFQSxTQUFPO0FBQUttSSxVQUFNLEVBQUU7QUFBYixLQUF1Qm5JLE9BQXZCLENBQVA7QUFFQSxRQUFNL0IsSUFBSSxHQUFHNkIsV0FBVyxDQUFDMkIsTUFBRCxFQUFTO0FBQUMwRCxVQUFNLEVBQUU7QUFBQzlELFNBQUcsRUFBRTtBQUFOO0FBQVQsR0FBVCxDQUF4Qjs7QUFDQSxNQUFJLENBQUNwRCxJQUFMLEVBQVc7QUFDVCxVQUFNLElBQUlTLE1BQU0sQ0FBQ2lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZ0JBQXRCLENBQU47QUFDRDs7QUFFRCxRQUFNb0IsTUFBTSxHQUFHO0FBQ2JpRixVQUFNLEVBQUU7QUFDTiwrQkFBeUIsQ0FEbkI7QUFDc0I7QUFDNUIsaUNBQTJCO0FBRnJCLEtBREs7QUFLYmhGLFFBQUksRUFBRTtBQUFDLGtDQUE0Qm5CLFlBQVksQ0FBQ3FILG9CQUFEO0FBQXpDO0FBTE8sR0FBZjs7QUFRQSxNQUFJbEksT0FBTyxDQUFDbUksTUFBWixFQUFvQjtBQUNsQnBHLFVBQU0sQ0FBQ2lGLE1BQVAsQ0FBYyw2QkFBZCxJQUErQyxDQUEvQztBQUNEOztBQUVEdEksUUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUFvQjtBQUFDVixPQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQUFYLEdBQXBCLEVBQXFDVSxNQUFyQztBQUNELENBckJELEMsQ0F3QkE7QUFDQTtBQUNBO0FBRUE7OztBQUNBLE1BQU1xRyxjQUFjLEdBQUc7QUFBQSxNQUFDQyxNQUFELHVFQUFVLEVBQVY7QUFBQSxTQUFpQkEsTUFBTSxDQUFDNUUsR0FBUCxDQUFXZixLQUFLLElBQUlBLEtBQUssQ0FBQzRGLE9BQTFCLENBQWpCO0FBQUEsQ0FBdkIsQyxDQUVBO0FBQ0E7OztBQUNBNUosTUFBTSxDQUFDMkksT0FBUCxDQUFlO0FBQUNrQixnQkFBYyxFQUFFdkksT0FBTyxJQUFJO0FBQ3pDeUYsU0FBSyxDQUFDekYsT0FBRCxFQUFVO0FBQUMwQyxXQUFLLEVBQUVnRDtBQUFSLEtBQVYsQ0FBTDtBQUVBLFVBQU16SCxJQUFJLEdBQUdLLFFBQVEsQ0FBQzJFLGVBQVQsQ0FBeUJqRCxPQUFPLENBQUMwQyxLQUFqQyxFQUF3QztBQUFDeUMsWUFBTSxFQUFFO0FBQUNrRCxjQUFNLEVBQUU7QUFBVDtBQUFULEtBQXhDLENBQWI7O0FBQ0EsUUFBSSxDQUFDcEssSUFBTCxFQUFXO0FBQ1Q0RCxpQkFBVyxDQUFDLGdCQUFELENBQVg7QUFDRDs7QUFFRCxVQUFNd0csTUFBTSxHQUFHRCxjQUFjLENBQUNuSyxJQUFJLENBQUNvSyxNQUFOLENBQTdCO0FBQ0EsVUFBTUcsa0JBQWtCLEdBQUdILE1BQU0sQ0FBQ3ZGLElBQVAsQ0FDekJKLEtBQUssSUFBSUEsS0FBSyxDQUFDNEIsV0FBTixPQUF3QnRFLE9BQU8sQ0FBQzBDLEtBQVIsQ0FBYzRCLFdBQWQsRUFEUixDQUEzQjtBQUlBaEcsWUFBUSxDQUFDbUssc0JBQVQsQ0FBZ0N4SyxJQUFJLENBQUNvRCxHQUFyQyxFQUEwQ21ILGtCQUExQztBQUNEO0FBZGMsQ0FBZjtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQWxLLFFBQVEsQ0FBQ29LLGtCQUFULEdBQThCLENBQUNqSCxNQUFELEVBQVNpQixLQUFULEVBQWdCaUcsTUFBaEIsRUFBd0JDLGNBQXhCLEtBQTJDO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBLFFBQU0zSyxJQUFJLEdBQUc2QixXQUFXLENBQUMyQixNQUFELENBQXhCOztBQUNBLE1BQUksQ0FBQ3hELElBQUwsRUFBVztBQUNUNEQsZUFBVyxDQUFDLGlCQUFELENBQVg7QUFDRCxHQVBzRSxDQVN2RTs7O0FBQ0EsTUFBSSxDQUFDYSxLQUFELElBQVV6RSxJQUFJLENBQUNvSyxNQUFmLElBQXlCcEssSUFBSSxDQUFDb0ssTUFBTCxDQUFZLENBQVosQ0FBN0IsRUFBNkM7QUFDM0MzRixTQUFLLEdBQUd6RSxJQUFJLENBQUNvSyxNQUFMLENBQVksQ0FBWixFQUFlQyxPQUF2QjtBQUNELEdBWnNFLENBY3ZFOzs7QUFDQSxNQUFJLENBQUM1RixLQUFELElBQ0YsQ0FBRTBGLGNBQWMsQ0FBQ25LLElBQUksQ0FBQ29LLE1BQU4sQ0FBZCxDQUE0QlEsUUFBNUIsQ0FBcUNuRyxLQUFyQyxDQURKLEVBQ2tEO0FBQ2hEYixlQUFXLENBQUMseUJBQUQsQ0FBWDtBQUNEOztBQUVELFFBQU1pSCxLQUFLLEdBQUdDLE1BQU0sQ0FBQ0MsTUFBUCxFQUFkO0FBQ0EsUUFBTUMsV0FBVyxHQUFHO0FBQ2xCSCxTQURrQjtBQUVsQnBHLFNBRmtCO0FBR2xCd0csUUFBSSxFQUFFLElBQUlDLElBQUo7QUFIWSxHQUFwQjs7QUFNQSxNQUFJUixNQUFNLEtBQUssZUFBZixFQUFnQztBQUM5Qk0sZUFBVyxDQUFDTixNQUFaLEdBQXFCLE9BQXJCO0FBQ0QsR0FGRCxNQUVPLElBQUlBLE1BQU0sS0FBSyxlQUFmLEVBQWdDO0FBQ3JDTSxlQUFXLENBQUNOLE1BQVosR0FBcUIsUUFBckI7QUFDRCxHQUZNLE1BRUEsSUFBSUEsTUFBSixFQUFZO0FBQ2pCO0FBQ0FNLGVBQVcsQ0FBQ04sTUFBWixHQUFxQkEsTUFBckI7QUFDRDs7QUFFRCxNQUFJQyxjQUFKLEVBQW9CO0FBQ2xCL0QsVUFBTSxDQUFDdUUsTUFBUCxDQUFjSCxXQUFkLEVBQTJCTCxjQUEzQjtBQUNEOztBQUVEbEssUUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUFvQjtBQUFDVixPQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQUFYLEdBQXBCLEVBQXFDO0FBQUNXLFFBQUksRUFBRTtBQUMxQyxpQ0FBMkJpSDtBQURlO0FBQVAsR0FBckMsRUF4Q3VFLENBNEN2RTs7QUFDQXZLLFFBQU0sQ0FBQzJLLE9BQVAsQ0FBZXBMLElBQWYsRUFBcUIsVUFBckIsRUFBaUMsVUFBakMsRUFBNkNxTCxLQUE3QyxHQUFxREwsV0FBckQ7QUFFQSxTQUFPO0FBQUN2RyxTQUFEO0FBQVF6RSxRQUFSO0FBQWM2SztBQUFkLEdBQVA7QUFDRCxDQWhERDtBQWtEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBeEssUUFBUSxDQUFDaUwseUJBQVQsR0FBcUMsQ0FBQzlILE1BQUQsRUFBU2lCLEtBQVQsRUFBZ0JrRyxjQUFoQixLQUFtQztBQUN0RTtBQUNBO0FBQ0E7QUFDQSxRQUFNM0ssSUFBSSxHQUFHNkIsV0FBVyxDQUFDMkIsTUFBRCxDQUF4Qjs7QUFDQSxNQUFJLENBQUN4RCxJQUFMLEVBQVc7QUFDVDRELGVBQVcsQ0FBQyxpQkFBRCxDQUFYO0FBQ0QsR0FQcUUsQ0FTdEU7OztBQUNBLE1BQUksQ0FBQ2EsS0FBTCxFQUFZO0FBQ1YsVUFBTThHLFdBQVcsR0FBRyxDQUFDdkwsSUFBSSxDQUFDb0ssTUFBTCxJQUFlLEVBQWhCLEVBQW9CdkYsSUFBcEIsQ0FBeUIyRyxDQUFDLElBQUksQ0FBQ0EsQ0FBQyxDQUFDQyxRQUFqQyxDQUFwQjtBQUNBaEgsU0FBSyxHQUFHLENBQUM4RyxXQUFXLElBQUksRUFBaEIsRUFBb0JsQixPQUE1Qjs7QUFFQSxRQUFJLENBQUM1RixLQUFMLEVBQVk7QUFDVmIsaUJBQVcsQ0FBQyw4Q0FBRCxDQUFYO0FBQ0Q7QUFDRixHQWpCcUUsQ0FtQnRFOzs7QUFDQSxNQUFJLENBQUNhLEtBQUQsSUFDRixDQUFFMEYsY0FBYyxDQUFDbkssSUFBSSxDQUFDb0ssTUFBTixDQUFkLENBQTRCUSxRQUE1QixDQUFxQ25HLEtBQXJDLENBREosRUFDa0Q7QUFDaERiLGVBQVcsQ0FBQyx5QkFBRCxDQUFYO0FBQ0Q7O0FBRUQsUUFBTWlILEtBQUssR0FBR0MsTUFBTSxDQUFDQyxNQUFQLEVBQWQ7QUFDQSxRQUFNQyxXQUFXLEdBQUc7QUFDbEJILFNBRGtCO0FBRWxCO0FBQ0FSLFdBQU8sRUFBRTVGLEtBSFM7QUFJbEJ3RyxRQUFJLEVBQUUsSUFBSUMsSUFBSjtBQUpZLEdBQXBCOztBQU9BLE1BQUlQLGNBQUosRUFBb0I7QUFDbEIvRCxVQUFNLENBQUN1RSxNQUFQLENBQWNILFdBQWQsRUFBMkJMLGNBQTNCO0FBQ0Q7O0FBRURsSyxRQUFNLENBQUN1QixLQUFQLENBQWE4QixNQUFiLENBQW9CO0FBQUNWLE9BQUcsRUFBRXBELElBQUksQ0FBQ29EO0FBQVgsR0FBcEIsRUFBcUM7QUFBQ3NJLFNBQUssRUFBRTtBQUMzQywyQ0FBcUNWO0FBRE07QUFBUixHQUFyQyxFQXJDc0UsQ0F5Q3RFOztBQUNBdkssUUFBTSxDQUFDMkssT0FBUCxDQUFlcEwsSUFBZixFQUFxQixVQUFyQixFQUFpQyxPQUFqQzs7QUFDQSxNQUFJLENBQUNBLElBQUksQ0FBQ3FELFFBQUwsQ0FBY29CLEtBQWQsQ0FBb0JrSCxrQkFBekIsRUFBNkM7QUFDM0MzTCxRQUFJLENBQUNxRCxRQUFMLENBQWNvQixLQUFkLENBQW9Ca0gsa0JBQXBCLEdBQXlDLEVBQXpDO0FBQ0Q7O0FBQ0QzTCxNQUFJLENBQUNxRCxRQUFMLENBQWNvQixLQUFkLENBQW9Ca0gsa0JBQXBCLENBQXVDQyxJQUF2QyxDQUE0Q1osV0FBNUM7QUFFQSxTQUFPO0FBQUN2RyxTQUFEO0FBQVF6RSxRQUFSO0FBQWM2SztBQUFkLEdBQVA7QUFDRCxDQWpERDtBQW1EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQXhLLFFBQVEsQ0FBQ3dMLHVCQUFULEdBQW1DLENBQUNwSCxLQUFELEVBQVF6RSxJQUFSLEVBQWNDLEdBQWQsRUFBbUJ5SyxNQUFuQixLQUE4QjtBQUMvRCxRQUFNM0ksT0FBTyxHQUFHO0FBQ2QrSixNQUFFLEVBQUVySCxLQURVO0FBRWRsRSxRQUFJLEVBQUVGLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3Qm9LLE1BQXhCLEVBQWdDbkssSUFBaEMsR0FDRkYsUUFBUSxDQUFDQyxjQUFULENBQXdCb0ssTUFBeEIsRUFBZ0NuSyxJQUFoQyxDQUFxQ1AsSUFBckMsQ0FERSxHQUVGSyxRQUFRLENBQUNDLGNBQVQsQ0FBd0JDLElBSmQ7QUFLZE0sV0FBTyxFQUFFUixRQUFRLENBQUNDLGNBQVQsQ0FBd0JvSyxNQUF4QixFQUFnQzdKLE9BQWhDLENBQXdDYixJQUF4QztBQUxLLEdBQWhCOztBQVFBLE1BQUksT0FBT0ssUUFBUSxDQUFDQyxjQUFULENBQXdCb0ssTUFBeEIsRUFBZ0M1SixJQUF2QyxLQUFnRCxVQUFwRCxFQUFnRTtBQUM5RGlCLFdBQU8sQ0FBQ2pCLElBQVIsR0FBZVQsUUFBUSxDQUFDQyxjQUFULENBQXdCb0ssTUFBeEIsRUFBZ0M1SixJQUFoQyxDQUFxQ2QsSUFBckMsRUFBMkNDLEdBQTNDLENBQWY7QUFDRDs7QUFFRCxNQUFJLE9BQU9JLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3Qm9LLE1BQXhCLEVBQWdDcUIsSUFBdkMsS0FBZ0QsVUFBcEQsRUFBZ0U7QUFDOURoSyxXQUFPLENBQUNnSyxJQUFSLEdBQWUxTCxRQUFRLENBQUNDLGNBQVQsQ0FBd0JvSyxNQUF4QixFQUFnQ3FCLElBQWhDLENBQXFDL0wsSUFBckMsRUFBMkNDLEdBQTNDLENBQWY7QUFDRDs7QUFFRCxNQUFJLE9BQU9JLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QjBMLE9BQS9CLEtBQTJDLFFBQS9DLEVBQXlEO0FBQ3ZEakssV0FBTyxDQUFDaUssT0FBUixHQUFrQjNMLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QjBMLE9BQTFDO0FBQ0Q7O0FBRUQsU0FBT2pLLE9BQVA7QUFDRCxDQXRCRCxDLENBd0JBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTFCLFFBQVEsQ0FBQ21LLHNCQUFULEdBQWtDLENBQUNoSCxNQUFELEVBQVNpQixLQUFULEVBQWdCa0csY0FBaEIsS0FBbUM7QUFDbkUsUUFBTTtBQUFDbEcsU0FBSyxFQUFFd0gsU0FBUjtBQUFtQmpNLFFBQW5CO0FBQXlCNks7QUFBekIsTUFDSnhLLFFBQVEsQ0FBQ29LLGtCQUFULENBQTRCakgsTUFBNUIsRUFBb0NpQixLQUFwQyxFQUEyQyxlQUEzQyxFQUE0RGtHLGNBQTVELENBREY7QUFFQSxRQUFNMUssR0FBRyxHQUFHSSxRQUFRLENBQUM2TCxJQUFULENBQWN0TCxhQUFkLENBQTRCaUssS0FBNUIsQ0FBWjtBQUNBLFFBQU05SSxPQUFPLEdBQUcxQixRQUFRLENBQUN3TCx1QkFBVCxDQUFpQ0ksU0FBakMsRUFBNENqTSxJQUE1QyxFQUFrREMsR0FBbEQsRUFBdUQsZUFBdkQsQ0FBaEI7QUFDQWtNLE9BQUssQ0FBQ0MsSUFBTixDQUFXckssT0FBWDs7QUFDQSxNQUFJdEIsTUFBTSxDQUFDNEwsYUFBWCxFQUEwQjtBQUN4QkMsV0FBTyxDQUFDQyxHQUFSLGlDQUFxQ3RNLEdBQXJDO0FBQ0Q7O0FBQ0QsU0FBTztBQUFDd0UsU0FBSyxFQUFFd0gsU0FBUjtBQUFtQmpNLFFBQW5CO0FBQXlCNkssU0FBekI7QUFBZ0M1SyxPQUFoQztBQUFxQzhCO0FBQXJDLEdBQVA7QUFDRCxDQVZELEMsQ0FZQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBMUIsUUFBUSxDQUFDbU0sbUJBQVQsR0FBK0IsQ0FBQ2hKLE1BQUQsRUFBU2lCLEtBQVQsRUFBZ0JrRyxjQUFoQixLQUFtQztBQUNoRSxRQUFNO0FBQUNsRyxTQUFLLEVBQUV3SCxTQUFSO0FBQW1Cak0sUUFBbkI7QUFBeUI2SztBQUF6QixNQUNKeEssUUFBUSxDQUFDb0ssa0JBQVQsQ0FBNEJqSCxNQUE1QixFQUFvQ2lCLEtBQXBDLEVBQTJDLGVBQTNDLEVBQTREa0csY0FBNUQsQ0FERjtBQUVBLFFBQU0xSyxHQUFHLEdBQUdJLFFBQVEsQ0FBQzZMLElBQVQsQ0FBY2xMLGFBQWQsQ0FBNEI2SixLQUE1QixDQUFaO0FBQ0EsUUFBTTlJLE9BQU8sR0FBRzFCLFFBQVEsQ0FBQ3dMLHVCQUFULENBQWlDSSxTQUFqQyxFQUE0Q2pNLElBQTVDLEVBQWtEQyxHQUFsRCxFQUF1RCxlQUF2RCxDQUFoQjtBQUNBa00sT0FBSyxDQUFDQyxJQUFOLENBQVdySyxPQUFYOztBQUNBLE1BQUl0QixNQUFNLENBQUM0TCxhQUFYLEVBQTBCO0FBQ3hCQyxXQUFPLENBQUNDLEdBQVIsbUNBQXVDdE0sR0FBdkM7QUFDRDs7QUFDRCxTQUFPO0FBQUN3RSxTQUFLLEVBQUV3SCxTQUFSO0FBQW1Cak0sUUFBbkI7QUFBeUI2SyxTQUF6QjtBQUFnQzVLLE9BQWhDO0FBQXFDOEI7QUFBckMsR0FBUDtBQUNELENBVkQsQyxDQWFBO0FBQ0E7OztBQUNBdEIsTUFBTSxDQUFDMkksT0FBUCxDQUFlO0FBQUN4SSxlQUFhLEVBQUUsWUFBbUI7QUFBQSxzQ0FBTjZMLElBQU07QUFBTkEsVUFBTTtBQUFBOztBQUNoRCxVQUFNNUIsS0FBSyxHQUFHNEIsSUFBSSxDQUFDLENBQUQsQ0FBbEI7QUFDQSxVQUFNbEQsV0FBVyxHQUFHa0QsSUFBSSxDQUFDLENBQUQsQ0FBeEI7QUFDQSxXQUFPcE0sUUFBUSxDQUFDcU0sWUFBVCxDQUNMLElBREssRUFFTCxlQUZLLEVBR0xELElBSEssRUFJTCxVQUpLLEVBS0wsTUFBTTtBQUNKakYsV0FBSyxDQUFDcUQsS0FBRCxFQUFRcEQsTUFBUixDQUFMO0FBQ0FELFdBQUssQ0FBQytCLFdBQUQsRUFBYzFCLGlCQUFkLENBQUw7QUFFQSxZQUFNN0gsSUFBSSxHQUFHUyxNQUFNLENBQUN1QixLQUFQLENBQWFDLE9BQWIsQ0FDWDtBQUFDLHlDQUFpQzRJO0FBQWxDLE9BRFcsRUFFWDtBQUFDM0QsY0FBTSxFQUFFO0FBQ1A3RCxrQkFBUSxFQUFFLENBREg7QUFFUCtHLGdCQUFNLEVBQUU7QUFGRDtBQUFULE9BRlcsQ0FBYjs7QUFPQSxVQUFJLENBQUNwSyxJQUFMLEVBQVc7QUFDVCxjQUFNLElBQUlTLE1BQU0sQ0FBQ2lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZUFBdEIsQ0FBTjtBQUNEOztBQUNELFlBQU07QUFBRXVJLFlBQUY7QUFBUVAsY0FBUjtBQUFnQmpHO0FBQWhCLFVBQTBCekUsSUFBSSxDQUFDcUQsUUFBTCxDQUFjZCxRQUFkLENBQXVCOEksS0FBdkQ7O0FBQ0EsVUFBSXNCLGVBQWUsR0FBR3RNLFFBQVEsQ0FBQ3VNLGdDQUFULEVBQXRCOztBQUNBLFVBQUlsQyxNQUFNLEtBQUssUUFBZixFQUF5QjtBQUN2QmlDLHVCQUFlLEdBQUd0TSxRQUFRLENBQUN3TSxpQ0FBVCxFQUFsQjtBQUNEOztBQUNELFlBQU1DLGFBQWEsR0FBRzVCLElBQUksQ0FBQzZCLEdBQUwsRUFBdEI7QUFDQSxVQUFLRCxhQUFhLEdBQUc3QixJQUFqQixHQUF5QjBCLGVBQTdCLEVBQ0UsTUFBTSxJQUFJbE0sTUFBTSxDQUFDaUMsS0FBWCxDQUFpQixHQUFqQixFQUFzQixlQUF0QixDQUFOO0FBQ0YsVUFBSSxDQUFFeUgsY0FBYyxDQUFDbkssSUFBSSxDQUFDb0ssTUFBTixDQUFkLENBQTRCUSxRQUE1QixDQUFxQ25HLEtBQXJDLENBQU4sRUFDRSxPQUFPO0FBQ0xqQixjQUFNLEVBQUV4RCxJQUFJLENBQUNvRCxHQURSO0FBRUxPLGFBQUssRUFBRSxJQUFJbEQsTUFBTSxDQUFDaUMsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpQ0FBdEI7QUFGRixPQUFQO0FBS0YsWUFBTThHLE1BQU0sR0FBRzVHLFlBQVksQ0FBQzJHLFdBQUQsQ0FBM0IsQ0E1QkksQ0E4Qko7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsWUFBTXlELFFBQVEsR0FBRzNNLFFBQVEsQ0FBQ3FKLGNBQVQsQ0FBd0IsS0FBS0MsVUFBTCxDQUFnQjdILEVBQXhDLENBQWpCOztBQUNBekIsY0FBUSxDQUFDNE0sY0FBVCxDQUF3QmpOLElBQUksQ0FBQ29ELEdBQTdCLEVBQWtDLEtBQUt1RyxVQUF2QyxFQUFtRCxJQUFuRDs7QUFDQSxZQUFNdUQsZUFBZSxHQUFHLE1BQ3RCN00sUUFBUSxDQUFDNE0sY0FBVCxDQUF3QmpOLElBQUksQ0FBQ29ELEdBQTdCLEVBQWtDLEtBQUt1RyxVQUF2QyxFQUFtRHFELFFBQW5ELENBREY7O0FBR0EsVUFBSTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBTUcsZUFBZSxHQUFHMU0sTUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUN0QjtBQUNFVixhQUFHLEVBQUVwRCxJQUFJLENBQUNvRCxHQURaO0FBRUUsNEJBQWtCcUIsS0FGcEI7QUFHRSwyQ0FBaUNvRztBQUhuQyxTQURzQixFQU10QjtBQUFDOUcsY0FBSSxFQUFFO0FBQUMsd0NBQTRCeUYsTUFBN0I7QUFDQyxpQ0FBcUI7QUFEdEIsV0FBUDtBQUVDVCxnQkFBTSxFQUFFO0FBQUMsdUNBQTJCLENBQTVCO0FBQ0MscUNBQXlCO0FBRDFCO0FBRlQsU0FOc0IsQ0FBeEI7QUFVQSxZQUFJb0UsZUFBZSxLQUFLLENBQXhCLEVBQ0UsT0FBTztBQUNMM0osZ0JBQU0sRUFBRXhELElBQUksQ0FBQ29ELEdBRFI7QUFFTE8sZUFBSyxFQUFFLElBQUlsRCxNQUFNLENBQUNpQyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGVBQXRCO0FBRkYsU0FBUDtBQUlILE9BcEJELENBb0JFLE9BQU8wSyxHQUFQLEVBQVk7QUFDWkYsdUJBQWU7QUFDZixjQUFNRSxHQUFOO0FBQ0QsT0E5REcsQ0FnRUo7QUFDQTs7O0FBQ0EvTSxjQUFRLENBQUNnTixvQkFBVCxDQUE4QnJOLElBQUksQ0FBQ29ELEdBQW5DOztBQUVBLGFBQU87QUFBQ0ksY0FBTSxFQUFFeEQsSUFBSSxDQUFDb0Q7QUFBZCxPQUFQO0FBQ0QsS0ExRUksQ0FBUDtBQTRFRDtBQS9FYyxDQUFmLEUsQ0FpRkE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EvQyxRQUFRLENBQUNpTixxQkFBVCxHQUFpQyxDQUFDOUosTUFBRCxFQUFTaUIsS0FBVCxFQUFnQmtHLGNBQWhCLEtBQW1DO0FBQ2xFO0FBQ0E7QUFDQTtBQUVBLFFBQU07QUFBQ2xHLFNBQUssRUFBRXdILFNBQVI7QUFBbUJqTSxRQUFuQjtBQUF5QjZLO0FBQXpCLE1BQ0p4SyxRQUFRLENBQUNpTCx5QkFBVCxDQUFtQzlILE1BQW5DLEVBQTJDaUIsS0FBM0MsRUFBa0RrRyxjQUFsRCxDQURGO0FBRUEsUUFBTTFLLEdBQUcsR0FBR0ksUUFBUSxDQUFDNkwsSUFBVCxDQUFjbkwsV0FBZCxDQUEwQjhKLEtBQTFCLENBQVo7QUFDQSxRQUFNOUksT0FBTyxHQUFHMUIsUUFBUSxDQUFDd0wsdUJBQVQsQ0FBaUNJLFNBQWpDLEVBQTRDak0sSUFBNUMsRUFBa0RDLEdBQWxELEVBQXVELGFBQXZELENBQWhCO0FBQ0FrTSxPQUFLLENBQUNDLElBQU4sQ0FBV3JLLE9BQVg7O0FBQ0EsTUFBSXRCLE1BQU0sQ0FBQzRMLGFBQVgsRUFBMEI7QUFDeEJDLFdBQU8sQ0FBQ0MsR0FBUixxQ0FBeUN0TSxHQUF6QztBQUNEOztBQUNELFNBQU87QUFBQ3dFLFNBQUssRUFBRXdILFNBQVI7QUFBbUJqTSxRQUFuQjtBQUF5QjZLLFNBQXpCO0FBQWdDNUssT0FBaEM7QUFBcUM4QjtBQUFyQyxHQUFQO0FBQ0QsQ0FkRCxDLENBZ0JBO0FBQ0E7OztBQUNBdEIsTUFBTSxDQUFDMkksT0FBUCxDQUFlO0FBQUNySSxhQUFXLEVBQUUsWUFBbUI7QUFBQSx1Q0FBTjBMLElBQU07QUFBTkEsVUFBTTtBQUFBOztBQUM5QyxVQUFNNUIsS0FBSyxHQUFHNEIsSUFBSSxDQUFDLENBQUQsQ0FBbEI7QUFDQSxXQUFPcE0sUUFBUSxDQUFDcU0sWUFBVCxDQUNMLElBREssRUFFTCxhQUZLLEVBR0xELElBSEssRUFJTCxVQUpLLEVBS0wsTUFBTTtBQUNKakYsV0FBSyxDQUFDcUQsS0FBRCxFQUFRcEQsTUFBUixDQUFMO0FBRUEsWUFBTXpILElBQUksR0FBR1MsTUFBTSxDQUFDdUIsS0FBUCxDQUFhQyxPQUFiLENBQ1g7QUFBQyxtREFBMkM0STtBQUE1QyxPQURXLEVBRVg7QUFBQzNELGNBQU0sRUFBRTtBQUNQN0Qsa0JBQVEsRUFBRSxDQURIO0FBRVArRyxnQkFBTSxFQUFFO0FBRkQ7QUFBVCxPQUZXLENBQWI7QUFPQSxVQUFJLENBQUNwSyxJQUFMLEVBQ0UsTUFBTSxJQUFJUyxNQUFNLENBQUNpQyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDJCQUF0QixDQUFOO0FBRUEsWUFBTXNJLFdBQVcsR0FBR2hMLElBQUksQ0FBQ3FELFFBQUwsQ0FBY29CLEtBQWQsQ0FBb0JrSCxrQkFBcEIsQ0FBdUM5RyxJQUF2QyxDQUNsQjBJLENBQUMsSUFBSUEsQ0FBQyxDQUFDMUMsS0FBRixJQUFXQSxLQURFLENBQXBCO0FBR0YsVUFBSSxDQUFDRyxXQUFMLEVBQ0UsT0FBTztBQUNMeEgsY0FBTSxFQUFFeEQsSUFBSSxDQUFDb0QsR0FEUjtBQUVMTyxhQUFLLEVBQUUsSUFBSWxELE1BQU0sQ0FBQ2lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsMkJBQXRCO0FBRkYsT0FBUDtBQUtGLFlBQU04SyxZQUFZLEdBQUd4TixJQUFJLENBQUNvSyxNQUFMLENBQVl2RixJQUFaLENBQ25CMkcsQ0FBQyxJQUFJQSxDQUFDLENBQUNuQixPQUFGLElBQWFXLFdBQVcsQ0FBQ1gsT0FEWCxDQUFyQjtBQUdBLFVBQUksQ0FBQ21ELFlBQUwsRUFDRSxPQUFPO0FBQ0xoSyxjQUFNLEVBQUV4RCxJQUFJLENBQUNvRCxHQURSO0FBRUxPLGFBQUssRUFBRSxJQUFJbEQsTUFBTSxDQUFDaUMsS0FBWCxDQUFpQixHQUFqQixFQUFzQiwwQ0FBdEI7QUFGRixPQUFQLENBMUJFLENBK0JKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FqQyxZQUFNLENBQUN1QixLQUFQLENBQWE4QixNQUFiLENBQ0U7QUFBQ1YsV0FBRyxFQUFFcEQsSUFBSSxDQUFDb0QsR0FBWDtBQUNDLDBCQUFrQjRILFdBQVcsQ0FBQ1g7QUFEL0IsT0FERixFQUdFO0FBQUN0RyxZQUFJLEVBQUU7QUFBQywrQkFBcUI7QUFBdEIsU0FBUDtBQUNDNkYsYUFBSyxFQUFFO0FBQUMsK0NBQXFDO0FBQUNTLG1CQUFPLEVBQUVXLFdBQVcsQ0FBQ1g7QUFBdEI7QUFBdEM7QUFEUixPQUhGO0FBTUEsYUFBTztBQUFDN0csY0FBTSxFQUFFeEQsSUFBSSxDQUFDb0Q7QUFBZCxPQUFQO0FBQ0QsS0FoREksQ0FBUDtBQWtERDtBQXBEYyxDQUFmO0FBc0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQS9DLFFBQVEsQ0FBQ29OLFFBQVQsR0FBb0IsQ0FBQ2pLLE1BQUQsRUFBU2tLLFFBQVQsRUFBbUJqQyxRQUFuQixLQUFnQztBQUNsRGpFLE9BQUssQ0FBQ2hFLE1BQUQsRUFBUzRELGNBQVQsQ0FBTDtBQUNBSSxPQUFLLENBQUNrRyxRQUFELEVBQVd0RyxjQUFYLENBQUw7QUFDQUksT0FBSyxDQUFDaUUsUUFBRCxFQUFXcEUsS0FBSyxDQUFDTSxRQUFOLENBQWVnRyxPQUFmLENBQVgsQ0FBTDs7QUFFQSxNQUFJbEMsUUFBUSxLQUFLLEtBQUssQ0FBdEIsRUFBeUI7QUFDdkJBLFlBQVEsR0FBRyxLQUFYO0FBQ0Q7O0FBRUQsUUFBTXpMLElBQUksR0FBRzZCLFdBQVcsQ0FBQzJCLE1BQUQsRUFBUztBQUFDMEQsVUFBTSxFQUFFO0FBQUNrRCxZQUFNLEVBQUU7QUFBVDtBQUFULEdBQVQsQ0FBeEI7QUFDQSxNQUFJLENBQUNwSyxJQUFMLEVBQ0UsTUFBTSxJQUFJUyxNQUFNLENBQUNpQyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGdCQUF0QixDQUFOLENBWGdELENBYWxEO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQU1rTCxxQkFBcUIsR0FDekIsSUFBSWxJLE1BQUosWUFBZWpGLE1BQU0sQ0FBQ2tGLGFBQVAsQ0FBcUIrSCxRQUFyQixDQUFmLFFBQWtELEdBQWxELENBREY7QUFHQSxRQUFNRyxpQkFBaUIsR0FBRyxDQUFDN04sSUFBSSxDQUFDb0ssTUFBTCxJQUFlLEVBQWhCLEVBQW9CMEQsTUFBcEIsQ0FDeEIsQ0FBQ0MsSUFBRCxFQUFPdEosS0FBUCxLQUFpQjtBQUNmLFFBQUltSixxQkFBcUIsQ0FBQ0ksSUFBdEIsQ0FBMkJ2SixLQUFLLENBQUM0RixPQUFqQyxDQUFKLEVBQStDO0FBQzdDNUosWUFBTSxDQUFDdUIsS0FBUCxDQUFhOEIsTUFBYixDQUFvQjtBQUNsQlYsV0FBRyxFQUFFcEQsSUFBSSxDQUFDb0QsR0FEUTtBQUVsQiwwQkFBa0JxQixLQUFLLENBQUM0RjtBQUZOLE9BQXBCLEVBR0c7QUFBQ3RHLFlBQUksRUFBRTtBQUNSLDhCQUFvQjJKLFFBRFo7QUFFUiwrQkFBcUJqQztBQUZiO0FBQVAsT0FISDtBQU9BLGFBQU8sSUFBUDtBQUNELEtBVEQsTUFTTztBQUNMLGFBQU9zQyxJQUFQO0FBQ0Q7QUFDRixHQWR1QixFQWV4QixLQWZ3QixDQUExQixDQXhCa0QsQ0EwQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFJRixpQkFBSixFQUF1QjtBQUNyQjtBQUNELEdBbkRpRCxDQXFEbEQ7OztBQUNBckgsbUNBQWlDLENBQUMsZ0JBQUQsRUFBbUIsT0FBbkIsRUFBNEJrSCxRQUE1QixFQUFzQzFOLElBQUksQ0FBQ29ELEdBQTNDLENBQWpDO0FBRUEzQyxRQUFNLENBQUN1QixLQUFQLENBQWE4QixNQUFiLENBQW9CO0FBQ2xCVixPQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQURRLEdBQXBCLEVBRUc7QUFDRDZLLGFBQVMsRUFBRTtBQUNUN0QsWUFBTSxFQUFFO0FBQ05DLGVBQU8sRUFBRXFELFFBREg7QUFFTmpDLGdCQUFRLEVBQUVBO0FBRko7QUFEQztBQURWLEdBRkgsRUF4RGtELENBbUVsRDtBQUNBOztBQUNBLE1BQUk7QUFDRmpGLHFDQUFpQyxDQUFDLGdCQUFELEVBQW1CLE9BQW5CLEVBQTRCa0gsUUFBNUIsRUFBc0MxTixJQUFJLENBQUNvRCxHQUEzQyxDQUFqQztBQUNELEdBRkQsQ0FFRSxPQUFPK0YsRUFBUCxFQUFXO0FBQ1g7QUFDQTFJLFVBQU0sQ0FBQ3VCLEtBQVAsQ0FBYThCLE1BQWIsQ0FBb0I7QUFBQ1YsU0FBRyxFQUFFcEQsSUFBSSxDQUFDb0Q7QUFBWCxLQUFwQixFQUNFO0FBQUN3RyxXQUFLLEVBQUU7QUFBQ1EsY0FBTSxFQUFFO0FBQUNDLGlCQUFPLEVBQUVxRDtBQUFWO0FBQVQ7QUFBUixLQURGO0FBRUEsVUFBTXZFLEVBQU47QUFDRDtBQUNGLENBN0VEO0FBK0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBOUksUUFBUSxDQUFDNk4sV0FBVCxHQUF1QixDQUFDMUssTUFBRCxFQUFTaUIsS0FBVCxLQUFtQjtBQUN4QytDLE9BQUssQ0FBQ2hFLE1BQUQsRUFBUzRELGNBQVQsQ0FBTDtBQUNBSSxPQUFLLENBQUMvQyxLQUFELEVBQVEyQyxjQUFSLENBQUw7QUFFQSxRQUFNcEgsSUFBSSxHQUFHNkIsV0FBVyxDQUFDMkIsTUFBRCxFQUFTO0FBQUMwRCxVQUFNLEVBQUU7QUFBQzlELFNBQUcsRUFBRTtBQUFOO0FBQVQsR0FBVCxDQUF4QjtBQUNBLE1BQUksQ0FBQ3BELElBQUwsRUFDRSxNQUFNLElBQUlTLE1BQU0sQ0FBQ2lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZ0JBQXRCLENBQU47QUFFRmpDLFFBQU0sQ0FBQ3VCLEtBQVAsQ0FBYThCLE1BQWIsQ0FBb0I7QUFBQ1YsT0FBRyxFQUFFcEQsSUFBSSxDQUFDb0Q7QUFBWCxHQUFwQixFQUNFO0FBQUN3RyxTQUFLLEVBQUU7QUFBQ1EsWUFBTSxFQUFFO0FBQUNDLGVBQU8sRUFBRTVGO0FBQVY7QUFBVDtBQUFSLEdBREY7QUFFRCxDQVZELEMsQ0FZQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNMEosVUFBVSxHQUFHcE0sT0FBTyxJQUFJO0FBQzVCO0FBQ0E7QUFDQXlGLE9BQUssQ0FBQ3pGLE9BQUQsRUFBVXNGLEtBQUssQ0FBQytHLGVBQU4sQ0FBc0I7QUFDbkM1SixZQUFRLEVBQUU2QyxLQUFLLENBQUNNLFFBQU4sQ0FBZUYsTUFBZixDQUR5QjtBQUVuQ2hELFNBQUssRUFBRTRDLEtBQUssQ0FBQ00sUUFBTixDQUFlRixNQUFmLENBRjRCO0FBR25DbEYsWUFBUSxFQUFFOEUsS0FBSyxDQUFDTSxRQUFOLENBQWVFLGlCQUFmO0FBSHlCLEdBQXRCLENBQVYsQ0FBTDtBQU1BLFFBQU07QUFBRXJELFlBQUY7QUFBWUMsU0FBWjtBQUFtQmxDO0FBQW5CLE1BQWdDUixPQUF0QztBQUNBLE1BQUksQ0FBQ3lDLFFBQUQsSUFBYSxDQUFDQyxLQUFsQixFQUNFLE1BQU0sSUFBSWhFLE1BQU0sQ0FBQ2lDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsaUNBQXRCLENBQU47QUFFRixRQUFNMUMsSUFBSSxHQUFHO0FBQUNxRCxZQUFRLEVBQUU7QUFBWCxHQUFiOztBQUNBLE1BQUlkLFFBQUosRUFBYztBQUNaLFVBQU1pSCxNQUFNLEdBQUc1RyxZQUFZLENBQUNMLFFBQUQsQ0FBM0I7QUFDQXZDLFFBQUksQ0FBQ3FELFFBQUwsQ0FBY2QsUUFBZCxHQUF5QjtBQUFFakIsWUFBTSxFQUFFa0k7QUFBVixLQUF6QjtBQUNEOztBQUVELE1BQUloRixRQUFKLEVBQ0V4RSxJQUFJLENBQUN3RSxRQUFMLEdBQWdCQSxRQUFoQjtBQUNGLE1BQUlDLEtBQUosRUFDRXpFLElBQUksQ0FBQ29LLE1BQUwsR0FBYyxDQUFDO0FBQUNDLFdBQU8sRUFBRTVGLEtBQVY7QUFBaUJnSCxZQUFRLEVBQUU7QUFBM0IsR0FBRCxDQUFkLENBdEIwQixDQXdCNUI7O0FBQ0FqRixtQ0FBaUMsQ0FBQyxVQUFELEVBQWEsVUFBYixFQUF5QmhDLFFBQXpCLENBQWpDO0FBQ0FnQyxtQ0FBaUMsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0Qi9CLEtBQTVCLENBQWpDO0FBRUEsUUFBTWpCLE1BQU0sR0FBR25ELFFBQVEsQ0FBQ2dPLGFBQVQsQ0FBdUJ0TSxPQUF2QixFQUFnQy9CLElBQWhDLENBQWYsQ0E1QjRCLENBNkI1QjtBQUNBOztBQUNBLE1BQUk7QUFDRndHLHFDQUFpQyxDQUFDLFVBQUQsRUFBYSxVQUFiLEVBQXlCaEMsUUFBekIsRUFBbUNoQixNQUFuQyxDQUFqQztBQUNBZ0QscUNBQWlDLENBQUMsZ0JBQUQsRUFBbUIsT0FBbkIsRUFBNEIvQixLQUE1QixFQUFtQ2pCLE1BQW5DLENBQWpDO0FBQ0QsR0FIRCxDQUdFLE9BQU8yRixFQUFQLEVBQVc7QUFDWDtBQUNBMUksVUFBTSxDQUFDdUIsS0FBUCxDQUFhc00sTUFBYixDQUFvQjlLLE1BQXBCO0FBQ0EsVUFBTTJGLEVBQU47QUFDRDs7QUFDRCxTQUFPM0YsTUFBUDtBQUNELENBeENELEMsQ0EwQ0E7OztBQUNBL0MsTUFBTSxDQUFDMkksT0FBUCxDQUFlO0FBQUMrRSxZQUFVLEVBQUUsWUFBbUI7QUFBQSx1Q0FBTjFCLElBQU07QUFBTkEsVUFBTTtBQUFBOztBQUM3QyxVQUFNMUssT0FBTyxHQUFHMEssSUFBSSxDQUFDLENBQUQsQ0FBcEI7QUFDQSxXQUFPcE0sUUFBUSxDQUFDcU0sWUFBVCxDQUNMLElBREssRUFFTCxZQUZLLEVBR0xELElBSEssRUFJTCxVQUpLLEVBS0wsTUFBTTtBQUNKO0FBQ0FqRixXQUFLLENBQUN6RixPQUFELEVBQVU2RSxNQUFWLENBQUw7QUFDQSxVQUFJdkcsUUFBUSxDQUFDK0IsUUFBVCxDQUFrQm1NLDJCQUF0QixFQUNFLE9BQU87QUFDTDVLLGFBQUssRUFBRSxJQUFJbEQsTUFBTSxDQUFDaUMsS0FBWCxDQUFpQixHQUFqQixFQUFzQixtQkFBdEI7QUFERixPQUFQO0FBSUYsWUFBTWMsTUFBTSxHQUFHbkQsUUFBUSxDQUFDbU8sd0JBQVQsQ0FBa0N6TSxPQUFsQyxDQUFmLENBUkksQ0FVSjs7QUFDQSxhQUFPO0FBQUN5QixjQUFNLEVBQUVBO0FBQVQsT0FBUDtBQUNELEtBakJJLENBQVA7QUFtQkQ7QUFyQmMsQ0FBZixFLENBdUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FuRCxRQUFRLENBQUNtTyx3QkFBVCxHQUFxQ3pNLE9BQUQsSUFBYTtBQUMvQ0EsU0FBTyxxQkFBUUEsT0FBUixDQUFQLENBRCtDLENBRS9DOztBQUNBLFFBQU15QixNQUFNLEdBQUcySyxVQUFVLENBQUNwTSxPQUFELENBQXpCLENBSCtDLENBSS9DO0FBQ0E7O0FBQ0EsTUFBSSxDQUFFeUIsTUFBTixFQUNFLE1BQU0sSUFBSWQsS0FBSixDQUFVLHNDQUFWLENBQU4sQ0FQNkMsQ0FTL0M7QUFDQTtBQUNBOztBQUNBLE1BQUlYLE9BQU8sQ0FBQzBDLEtBQVIsSUFBaUJwRSxRQUFRLENBQUMrQixRQUFULENBQWtCa0wscUJBQXZDLEVBQThEO0FBQzVELFFBQUl2TCxPQUFPLENBQUNRLFFBQVosRUFBc0I7QUFDcEJsQyxjQUFRLENBQUNpTixxQkFBVCxDQUErQjlKLE1BQS9CLEVBQXVDekIsT0FBTyxDQUFDMEMsS0FBL0M7QUFDRCxLQUZELE1BRU87QUFDTHBFLGNBQVEsQ0FBQ21NLG1CQUFULENBQTZCaEosTUFBN0IsRUFBcUN6QixPQUFPLENBQUMwQyxLQUE3QztBQUNEO0FBQ0Y7O0FBRUQsU0FBT2pCLE1BQVA7QUFDRCxDQXJCRCxDLENBdUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FuRCxRQUFRLENBQUM4TixVQUFULEdBQXNCLENBQUNwTSxPQUFELEVBQVUwTSxRQUFWLEtBQXVCO0FBQzNDMU0sU0FBTyxxQkFBUUEsT0FBUixDQUFQLENBRDJDLENBRzNDOztBQUNBLE1BQUkwTSxRQUFKLEVBQWM7QUFDWixVQUFNLElBQUkvTCxLQUFKLENBQVUsb0VBQVYsQ0FBTjtBQUNEOztBQUVELFNBQU95TCxVQUFVLENBQUNwTSxPQUFELENBQWpCO0FBQ0QsQ0FURCxDLENBV0E7QUFDQTtBQUNBOzs7QUFDQXRCLE1BQU0sQ0FBQ3VCLEtBQVAsQ0FBYTBNLFlBQWIsQ0FBMEIseUNBQTFCLEVBQzBCO0FBQUVDLFFBQU0sRUFBRSxJQUFWO0FBQWdCQyxRQUFNLEVBQUU7QUFBeEIsQ0FEMUI7O0FBRUFuTyxNQUFNLENBQUN1QixLQUFQLENBQWEwTSxZQUFiLENBQTBCLCtCQUExQixFQUMwQjtBQUFFQyxRQUFNLEVBQUUsSUFBVjtBQUFnQkMsUUFBTSxFQUFFO0FBQXhCLENBRDFCLEUiLCJmaWxlIjoiL3BhY2thZ2VzL2FjY291bnRzLXBhc3N3b3JkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZ3JlZXQgPSB3ZWxjb21lTXNnID0+ICh1c2VyLCB1cmwpID0+IHtcbiAgICAgIGNvbnN0IGdyZWV0aW5nID0gKHVzZXIucHJvZmlsZSAmJiB1c2VyLnByb2ZpbGUubmFtZSkgP1xuICAgICAgICAgICAgKGBIZWxsbyAke3VzZXIucHJvZmlsZS5uYW1lfSxgKSA6IFwiSGVsbG8sXCI7XG4gICAgICByZXR1cm4gYCR7Z3JlZXRpbmd9XG5cbiR7d2VsY29tZU1zZ30sIHNpbXBseSBjbGljayB0aGUgbGluayBiZWxvdy5cblxuJHt1cmx9XG5cblRoYW5rcy5cbmA7XG59O1xuXG4vKipcbiAqIEBzdW1tYXJ5IE9wdGlvbnMgdG8gY3VzdG9taXplIGVtYWlscyBzZW50IGZyb20gdGhlIEFjY291bnRzIHN5c3RlbS5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmVtYWlsVGVtcGxhdGVzID0ge1xuICBmcm9tOiBcIkFjY291bnRzIEV4YW1wbGUgPG5vLXJlcGx5QGV4YW1wbGUuY29tPlwiLFxuICBzaXRlTmFtZTogTWV0ZW9yLmFic29sdXRlVXJsKCkucmVwbGFjZSgvXmh0dHBzPzpcXC9cXC8vLCAnJykucmVwbGFjZSgvXFwvJC8sICcnKSxcblxuICByZXNldFBhc3N3b3JkOiB7XG4gICAgc3ViamVjdDogKCkgPT4gYEhvdyB0byByZXNldCB5b3VyIHBhc3N3b3JkIG9uICR7QWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuc2l0ZU5hbWV9YCxcbiAgICB0ZXh0OiBncmVldChcIlRvIHJlc2V0IHlvdXIgcGFzc3dvcmRcIiksXG4gIH0sXG4gIHZlcmlmeUVtYWlsOiB7XG4gICAgc3ViamVjdDogKCkgPT4gYEhvdyB0byB2ZXJpZnkgZW1haWwgYWRkcmVzcyBvbiAke0FjY291bnRzLmVtYWlsVGVtcGxhdGVzLnNpdGVOYW1lfWAsXG4gICAgdGV4dDogZ3JlZXQoXCJUbyB2ZXJpZnkgeW91ciBhY2NvdW50IGVtYWlsXCIpLFxuICB9LFxuICBlbnJvbGxBY2NvdW50OiB7XG4gICAgc3ViamVjdDogKCkgPT4gYEFuIGFjY291bnQgaGFzIGJlZW4gY3JlYXRlZCBmb3IgeW91IG9uICR7QWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuc2l0ZU5hbWV9YCxcbiAgICB0ZXh0OiBncmVldChcIlRvIHN0YXJ0IHVzaW5nIHRoZSBzZXJ2aWNlXCIpLFxuICB9LFxufTtcbiIsIi8vLyBCQ1JZUFRcblxuY29uc3QgYmNyeXB0ID0gTnBtTW9kdWxlQmNyeXB0O1xuY29uc3QgYmNyeXB0SGFzaCA9IE1ldGVvci53cmFwQXN5bmMoYmNyeXB0Lmhhc2gpO1xuY29uc3QgYmNyeXB0Q29tcGFyZSA9IE1ldGVvci53cmFwQXN5bmMoYmNyeXB0LmNvbXBhcmUpO1xuXG4vLyBVdGlsaXR5IGZvciBncmFiYmluZyB1c2VyXG5jb25zdCBnZXRVc2VyQnlJZCA9IChpZCwgb3B0aW9ucykgPT4gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoaWQsIEFjY291bnRzLl9hZGREZWZhdWx0RmllbGRTZWxlY3RvcihvcHRpb25zKSk7XG5cbi8vIFVzZXIgcmVjb3JkcyBoYXZlIGEgJ3NlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCcgZmllbGQgb24gdGhlbSB0byBob2xkXG4vLyB0aGVpciBoYXNoZWQgcGFzc3dvcmRzICh1bmxlc3MgdGhleSBoYXZlIGEgJ3NlcnZpY2VzLnBhc3N3b3JkLnNycCdcbi8vIGZpZWxkLCBpbiB3aGljaCBjYXNlIHRoZXkgd2lsbCBiZSB1cGdyYWRlZCB0byBiY3J5cHQgdGhlIG5leHQgdGltZVxuLy8gdGhleSBsb2cgaW4pLlxuLy9cbi8vIFdoZW4gdGhlIGNsaWVudCBzZW5kcyBhIHBhc3N3b3JkIHRvIHRoZSBzZXJ2ZXIsIGl0IGNhbiBlaXRoZXIgYmUgYVxuLy8gc3RyaW5nICh0aGUgcGxhaW50ZXh0IHBhc3N3b3JkKSBvciBhbiBvYmplY3Qgd2l0aCBrZXlzICdkaWdlc3QnIGFuZFxuLy8gJ2FsZ29yaXRobScgKG11c3QgYmUgXCJzaGEtMjU2XCIgZm9yIG5vdykuIFRoZSBNZXRlb3IgY2xpZW50IGFsd2F5cyBzZW5kc1xuLy8gcGFzc3dvcmQgb2JqZWN0cyB7IGRpZ2VzdDogKiwgYWxnb3JpdGhtOiBcInNoYS0yNTZcIiB9LCBidXQgRERQIGNsaWVudHNcbi8vIHRoYXQgZG9uJ3QgaGF2ZSBhY2Nlc3MgdG8gU0hBIGNhbiBqdXN0IHNlbmQgcGxhaW50ZXh0IHBhc3N3b3JkcyBhc1xuLy8gc3RyaW5ncy5cbi8vXG4vLyBXaGVuIHRoZSBzZXJ2ZXIgcmVjZWl2ZXMgYSBwbGFpbnRleHQgcGFzc3dvcmQgYXMgYSBzdHJpbmcsIGl0IGFsd2F5c1xuLy8gaGFzaGVzIGl0IHdpdGggU0hBMjU2IGJlZm9yZSBwYXNzaW5nIGl0IGludG8gYmNyeXB0LiBXaGVuIHRoZSBzZXJ2ZXJcbi8vIHJlY2VpdmVzIGEgcGFzc3dvcmQgYXMgYW4gb2JqZWN0LCBpdCBhc3NlcnRzIHRoYXQgdGhlIGFsZ29yaXRobSBpc1xuLy8gXCJzaGEtMjU2XCIgYW5kIHRoZW4gcGFzc2VzIHRoZSBkaWdlc3QgdG8gYmNyeXB0LlxuXG5cbkFjY291bnRzLl9iY3J5cHRSb3VuZHMgPSAoKSA9PiBBY2NvdW50cy5fb3B0aW9ucy5iY3J5cHRSb3VuZHMgfHwgMTA7XG5cbi8vIEdpdmVuIGEgJ3Bhc3N3b3JkJyBmcm9tIHRoZSBjbGllbnQsIGV4dHJhY3QgdGhlIHN0cmluZyB0aGF0IHdlIHNob3VsZFxuLy8gYmNyeXB0LiAncGFzc3dvcmQnIGNhbiBiZSBvbmUgb2Y6XG4vLyAgLSBTdHJpbmcgKHRoZSBwbGFpbnRleHQgcGFzc3dvcmQpXG4vLyAgLSBPYmplY3Qgd2l0aCAnZGlnZXN0JyBhbmQgJ2FsZ29yaXRobScga2V5cy4gJ2FsZ29yaXRobScgbXVzdCBiZSBcInNoYS0yNTZcIi5cbi8vXG5jb25zdCBnZXRQYXNzd29yZFN0cmluZyA9IHBhc3N3b3JkID0+IHtcbiAgaWYgKHR5cGVvZiBwYXNzd29yZCA9PT0gXCJzdHJpbmdcIikge1xuICAgIHBhc3N3b3JkID0gU0hBMjU2KHBhc3N3b3JkKTtcbiAgfSBlbHNlIHsgLy8gJ3Bhc3N3b3JkJyBpcyBhbiBvYmplY3RcbiAgICBpZiAocGFzc3dvcmQuYWxnb3JpdGhtICE9PSBcInNoYS0yNTZcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBwYXNzd29yZCBoYXNoIGFsZ29yaXRobS4gXCIgK1xuICAgICAgICAgICAgICAgICAgICAgIFwiT25seSAnc2hhLTI1NicgaXMgYWxsb3dlZC5cIik7XG4gICAgfVxuICAgIHBhc3N3b3JkID0gcGFzc3dvcmQuZGlnZXN0O1xuICB9XG4gIHJldHVybiBwYXNzd29yZDtcbn07XG5cbi8vIFVzZSBiY3J5cHQgdG8gaGFzaCB0aGUgcGFzc3dvcmQgZm9yIHN0b3JhZ2UgaW4gdGhlIGRhdGFiYXNlLlxuLy8gYHBhc3N3b3JkYCBjYW4gYmUgYSBzdHJpbmcgKGluIHdoaWNoIGNhc2UgaXQgd2lsbCBiZSBydW4gdGhyb3VnaFxuLy8gU0hBMjU2IGJlZm9yZSBiY3J5cHQpIG9yIGFuIG9iamVjdCB3aXRoIHByb3BlcnRpZXMgYGRpZ2VzdGAgYW5kXG4vLyBgYWxnb3JpdGhtYCAoaW4gd2hpY2ggY2FzZSB3ZSBiY3J5cHQgYHBhc3N3b3JkLmRpZ2VzdGApLlxuLy9cbmNvbnN0IGhhc2hQYXNzd29yZCA9IHBhc3N3b3JkID0+IHtcbiAgcGFzc3dvcmQgPSBnZXRQYXNzd29yZFN0cmluZyhwYXNzd29yZCk7XG4gIHJldHVybiBiY3J5cHRIYXNoKHBhc3N3b3JkLCBBY2NvdW50cy5fYmNyeXB0Um91bmRzKCkpO1xufTtcblxuLy8gRXh0cmFjdCB0aGUgbnVtYmVyIG9mIHJvdW5kcyB1c2VkIGluIHRoZSBzcGVjaWZpZWQgYmNyeXB0IGhhc2guXG5jb25zdCBnZXRSb3VuZHNGcm9tQmNyeXB0SGFzaCA9IGhhc2ggPT4ge1xuICBsZXQgcm91bmRzO1xuICBpZiAoaGFzaCkge1xuICAgIGNvbnN0IGhhc2hTZWdtZW50cyA9IGhhc2guc3BsaXQoJyQnKTtcbiAgICBpZiAoaGFzaFNlZ21lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgIHJvdW5kcyA9IHBhcnNlSW50KGhhc2hTZWdtZW50c1syXSwgMTApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcm91bmRzO1xufTtcblxuLy8gQ2hlY2sgd2hldGhlciB0aGUgcHJvdmlkZWQgcGFzc3dvcmQgbWF0Y2hlcyB0aGUgYmNyeXB0J2VkIHBhc3N3b3JkIGluXG4vLyB0aGUgZGF0YWJhc2UgdXNlciByZWNvcmQuIGBwYXNzd29yZGAgY2FuIGJlIGEgc3RyaW5nIChpbiB3aGljaCBjYXNlXG4vLyBpdCB3aWxsIGJlIHJ1biB0aHJvdWdoIFNIQTI1NiBiZWZvcmUgYmNyeXB0KSBvciBhbiBvYmplY3Qgd2l0aFxuLy8gcHJvcGVydGllcyBgZGlnZXN0YCBhbmQgYGFsZ29yaXRobWAgKGluIHdoaWNoIGNhc2Ugd2UgYmNyeXB0XG4vLyBgcGFzc3dvcmQuZGlnZXN0YCkuXG4vL1xuLy8gVGhlIHVzZXIgcGFyYW1ldGVyIG5lZWRzIGF0IGxlYXN0IHVzZXIuX2lkIGFuZCB1c2VyLnNlcnZpY2VzXG5BY2NvdW50cy5fY2hlY2tQYXNzd29yZFVzZXJGaWVsZHMgPSB7X2lkOiAxLCBzZXJ2aWNlczogMX07XG4vL1xuQWNjb3VudHMuX2NoZWNrUGFzc3dvcmQgPSAodXNlciwgcGFzc3dvcmQpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgIHVzZXJJZDogdXNlci5faWRcbiAgfTtcblxuICBjb25zdCBmb3JtYXR0ZWRQYXNzd29yZCA9IGdldFBhc3N3b3JkU3RyaW5nKHBhc3N3b3JkKTtcbiAgY29uc3QgaGFzaCA9IHVzZXIuc2VydmljZXMucGFzc3dvcmQuYmNyeXB0O1xuICBjb25zdCBoYXNoUm91bmRzID0gZ2V0Um91bmRzRnJvbUJjcnlwdEhhc2goaGFzaCk7XG5cbiAgaWYgKCEgYmNyeXB0Q29tcGFyZShmb3JtYXR0ZWRQYXNzd29yZCwgaGFzaCkpIHtcbiAgICByZXN1bHQuZXJyb3IgPSBoYW5kbGVFcnJvcihcIkluY29ycmVjdCBwYXNzd29yZFwiLCBmYWxzZSk7XG4gIH0gZWxzZSBpZiAoaGFzaCAmJiBBY2NvdW50cy5fYmNyeXB0Um91bmRzKCkgIT0gaGFzaFJvdW5kcykge1xuICAgIC8vIFRoZSBwYXNzd29yZCBjaGVja3Mgb3V0LCBidXQgdGhlIHVzZXIncyBiY3J5cHQgaGFzaCBuZWVkcyB0byBiZSB1cGRhdGVkLlxuICAgIE1ldGVvci5kZWZlcigoKSA9PiB7XG4gICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiB1c2VyLl9pZCB9LCB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAnc2VydmljZXMucGFzc3dvcmQuYmNyeXB0JzpcbiAgICAgICAgICAgIGJjcnlwdEhhc2goZm9ybWF0dGVkUGFzc3dvcmQsIEFjY291bnRzLl9iY3J5cHRSb3VuZHMoKSlcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gcmVzdWx0O1xufTtcbmNvbnN0IGNoZWNrUGFzc3dvcmQgPSBBY2NvdW50cy5fY2hlY2tQYXNzd29yZDtcblxuLy8vXG4vLy8gRVJST1IgSEFORExFUlxuLy8vXG5jb25zdCBoYW5kbGVFcnJvciA9IChtc2csIHRocm93RXJyb3IgPSB0cnVlKSA9PiB7XG4gIGNvbnN0IGVycm9yID0gbmV3IE1ldGVvci5FcnJvcihcbiAgICA0MDMsXG4gICAgQWNjb3VudHMuX29wdGlvbnMuYW1iaWd1b3VzRXJyb3JNZXNzYWdlc1xuICAgICAgPyBcIlNvbWV0aGluZyB3ZW50IHdyb25nLiBQbGVhc2UgY2hlY2sgeW91ciBjcmVkZW50aWFscy5cIlxuICAgICAgOiBtc2dcbiAgKTtcbiAgaWYgKHRocm93RXJyb3IpIHtcbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxuICByZXR1cm4gZXJyb3I7XG59O1xuXG4vLy9cbi8vLyBMT0dJTlxuLy8vXG5cbkFjY291bnRzLl9maW5kVXNlckJ5UXVlcnkgPSAocXVlcnksIG9wdGlvbnMpID0+IHtcbiAgbGV0IHVzZXIgPSBudWxsO1xuXG4gIGlmIChxdWVyeS5pZCkge1xuICAgIC8vIGRlZmF1bHQgZmllbGQgc2VsZWN0b3IgaXMgYWRkZWQgd2l0aGluIGdldFVzZXJCeUlkKClcbiAgICB1c2VyID0gZ2V0VXNlckJ5SWQocXVlcnkuaWQsIG9wdGlvbnMpO1xuICB9IGVsc2Uge1xuICAgIG9wdGlvbnMgPSBBY2NvdW50cy5fYWRkRGVmYXVsdEZpZWxkU2VsZWN0b3Iob3B0aW9ucyk7XG4gICAgbGV0IGZpZWxkTmFtZTtcbiAgICBsZXQgZmllbGRWYWx1ZTtcbiAgICBpZiAocXVlcnkudXNlcm5hbWUpIHtcbiAgICAgIGZpZWxkTmFtZSA9ICd1c2VybmFtZSc7XG4gICAgICBmaWVsZFZhbHVlID0gcXVlcnkudXNlcm5hbWU7XG4gICAgfSBlbHNlIGlmIChxdWVyeS5lbWFpbCkge1xuICAgICAgZmllbGROYW1lID0gJ2VtYWlscy5hZGRyZXNzJztcbiAgICAgIGZpZWxkVmFsdWUgPSBxdWVyeS5lbWFpbDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwic2hvdWxkbid0IGhhcHBlbiAodmFsaWRhdGlvbiBtaXNzZWQgc29tZXRoaW5nKVwiKTtcbiAgICB9XG4gICAgbGV0IHNlbGVjdG9yID0ge307XG4gICAgc2VsZWN0b3JbZmllbGROYW1lXSA9IGZpZWxkVmFsdWU7XG4gICAgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHNlbGVjdG9yLCBvcHRpb25zKTtcbiAgICAvLyBJZiB1c2VyIGlzIG5vdCBmb3VuZCwgdHJ5IGEgY2FzZSBpbnNlbnNpdGl2ZSBsb29rdXBcbiAgICBpZiAoIXVzZXIpIHtcbiAgICAgIHNlbGVjdG9yID0gc2VsZWN0b3JGb3JGYXN0Q2FzZUluc2Vuc2l0aXZlTG9va3VwKGZpZWxkTmFtZSwgZmllbGRWYWx1ZSk7XG4gICAgICBjb25zdCBjYW5kaWRhdGVVc2VycyA9IE1ldGVvci51c2Vycy5maW5kKHNlbGVjdG9yLCBvcHRpb25zKS5mZXRjaCgpO1xuICAgICAgLy8gTm8gbWF0Y2ggaWYgbXVsdGlwbGUgY2FuZGlkYXRlcyBhcmUgZm91bmRcbiAgICAgIGlmIChjYW5kaWRhdGVVc2Vycy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgdXNlciA9IGNhbmRpZGF0ZVVzZXJzWzBdO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB1c2VyO1xufTtcblxuLyoqXG4gKiBAc3VtbWFyeSBGaW5kcyB0aGUgdXNlciB3aXRoIHRoZSBzcGVjaWZpZWQgdXNlcm5hbWUuXG4gKiBGaXJzdCB0cmllcyB0byBtYXRjaCB1c2VybmFtZSBjYXNlIHNlbnNpdGl2ZWx5OyBpZiB0aGF0IGZhaWxzLCBpdFxuICogdHJpZXMgY2FzZSBpbnNlbnNpdGl2ZWx5OyBidXQgaWYgbW9yZSB0aGFuIG9uZSB1c2VyIG1hdGNoZXMgdGhlIGNhc2VcbiAqIGluc2Vuc2l0aXZlIHNlYXJjaCwgaXQgcmV0dXJucyBudWxsLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJuYW1lIFRoZSB1c2VybmFtZSB0byBsb29rIGZvclxuICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICogQHBhcmFtIHtNb25nb0ZpZWxkU3BlY2lmaWVyfSBvcHRpb25zLmZpZWxkcyBEaWN0aW9uYXJ5IG9mIGZpZWxkcyB0byByZXR1cm4gb3IgZXhjbHVkZS5cbiAqIEByZXR1cm5zIHtPYmplY3R9IEEgdXNlciBpZiBmb3VuZCwgZWxzZSBudWxsXG4gKiBAaW1wb3J0RnJvbVBhY2thZ2UgYWNjb3VudHMtYmFzZVxuICovXG5BY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUgPVxuICAodXNlcm5hbWUsIG9wdGlvbnMpID0+IEFjY291bnRzLl9maW5kVXNlckJ5UXVlcnkoeyB1c2VybmFtZSB9LCBvcHRpb25zKTtcblxuLyoqXG4gKiBAc3VtbWFyeSBGaW5kcyB0aGUgdXNlciB3aXRoIHRoZSBzcGVjaWZpZWQgZW1haWwuXG4gKiBGaXJzdCB0cmllcyB0byBtYXRjaCBlbWFpbCBjYXNlIHNlbnNpdGl2ZWx5OyBpZiB0aGF0IGZhaWxzLCBpdFxuICogdHJpZXMgY2FzZSBpbnNlbnNpdGl2ZWx5OyBidXQgaWYgbW9yZSB0aGFuIG9uZSB1c2VyIG1hdGNoZXMgdGhlIGNhc2VcbiAqIGluc2Vuc2l0aXZlIHNlYXJjaCwgaXQgcmV0dXJucyBudWxsLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IGVtYWlsIFRoZSBlbWFpbCBhZGRyZXNzIHRvIGxvb2sgZm9yXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcGFyYW0ge01vbmdvRmllbGRTcGVjaWZpZXJ9IG9wdGlvbnMuZmllbGRzIERpY3Rpb25hcnkgb2YgZmllbGRzIHRvIHJldHVybiBvciBleGNsdWRlLlxuICogQHJldHVybnMge09iamVjdH0gQSB1c2VyIGlmIGZvdW5kLCBlbHNlIG51bGxcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmZpbmRVc2VyQnlFbWFpbCA9XG4gIChlbWFpbCwgb3B0aW9ucykgPT4gQWNjb3VudHMuX2ZpbmRVc2VyQnlRdWVyeSh7IGVtYWlsIH0sIG9wdGlvbnMpO1xuXG4vLyBHZW5lcmF0ZXMgYSBNb25nb0RCIHNlbGVjdG9yIHRoYXQgY2FuIGJlIHVzZWQgdG8gcGVyZm9ybSBhIGZhc3QgY2FzZVxuLy8gaW5zZW5zaXRpdmUgbG9va3VwIGZvciB0aGUgZ2l2ZW4gZmllbGROYW1lIGFuZCBzdHJpbmcuIFNpbmNlIE1vbmdvREIgZG9lc1xuLy8gbm90IHN1cHBvcnQgY2FzZSBpbnNlbnNpdGl2ZSBpbmRleGVzLCBhbmQgY2FzZSBpbnNlbnNpdGl2ZSByZWdleCBxdWVyaWVzXG4vLyBhcmUgc2xvdywgd2UgY29uc3RydWN0IGEgc2V0IG9mIHByZWZpeCBzZWxlY3RvcnMgZm9yIGFsbCBwZXJtdXRhdGlvbnMgb2Zcbi8vIHRoZSBmaXJzdCA0IGNoYXJhY3RlcnMgb3Vyc2VsdmVzLiBXZSBmaXJzdCBhdHRlbXB0IHRvIG1hdGNoaW5nIGFnYWluc3Rcbi8vIHRoZXNlLCBhbmQgYmVjYXVzZSAncHJlZml4IGV4cHJlc3Npb24nIHJlZ2V4IHF1ZXJpZXMgZG8gdXNlIGluZGV4ZXMgKHNlZVxuLy8gaHR0cDovL2RvY3MubW9uZ29kYi5vcmcvdjIuNi9yZWZlcmVuY2Uvb3BlcmF0b3IvcXVlcnkvcmVnZXgvI2luZGV4LXVzZSksXG4vLyB0aGlzIGhhcyBiZWVuIGZvdW5kIHRvIGdyZWF0bHkgaW1wcm92ZSBwZXJmb3JtYW5jZSAoZnJvbSAxMjAwbXMgdG8gNW1zIGluIGFcbi8vIHRlc3Qgd2l0aCAxLjAwMC4wMDAgdXNlcnMpLlxuY29uc3Qgc2VsZWN0b3JGb3JGYXN0Q2FzZUluc2Vuc2l0aXZlTG9va3VwID0gKGZpZWxkTmFtZSwgc3RyaW5nKSA9PiB7XG4gIC8vIFBlcmZvcm1hbmNlIHNlZW1zIHRvIGltcHJvdmUgdXAgdG8gNCBwcmVmaXggY2hhcmFjdGVyc1xuICBjb25zdCBwcmVmaXggPSBzdHJpbmcuc3Vic3RyaW5nKDAsIE1hdGgubWluKHN0cmluZy5sZW5ndGgsIDQpKTtcbiAgY29uc3Qgb3JDbGF1c2UgPSBnZW5lcmF0ZUNhc2VQZXJtdXRhdGlvbnNGb3JTdHJpbmcocHJlZml4KS5tYXAoXG4gICAgcHJlZml4UGVybXV0YXRpb24gPT4ge1xuICAgICAgY29uc3Qgc2VsZWN0b3IgPSB7fTtcbiAgICAgIHNlbGVjdG9yW2ZpZWxkTmFtZV0gPVxuICAgICAgICBuZXcgUmVnRXhwKGBeJHtNZXRlb3IuX2VzY2FwZVJlZ0V4cChwcmVmaXhQZXJtdXRhdGlvbil9YCk7XG4gICAgICByZXR1cm4gc2VsZWN0b3I7XG4gICAgfSk7XG4gIGNvbnN0IGNhc2VJbnNlbnNpdGl2ZUNsYXVzZSA9IHt9O1xuICBjYXNlSW5zZW5zaXRpdmVDbGF1c2VbZmllbGROYW1lXSA9XG4gICAgbmV3IFJlZ0V4cChgXiR7TWV0ZW9yLl9lc2NhcGVSZWdFeHAoc3RyaW5nKX0kYCwgJ2knKVxuICByZXR1cm4geyRhbmQ6IFt7JG9yOiBvckNsYXVzZX0sIGNhc2VJbnNlbnNpdGl2ZUNsYXVzZV19O1xufVxuXG4vLyBHZW5lcmF0ZXMgcGVybXV0YXRpb25zIG9mIGFsbCBjYXNlIHZhcmlhdGlvbnMgb2YgYSBnaXZlbiBzdHJpbmcuXG5jb25zdCBnZW5lcmF0ZUNhc2VQZXJtdXRhdGlvbnNGb3JTdHJpbmcgPSBzdHJpbmcgPT4ge1xuICBsZXQgcGVybXV0YXRpb25zID0gWycnXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHJpbmcubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaCA9IHN0cmluZy5jaGFyQXQoaSk7XG4gICAgcGVybXV0YXRpb25zID0gW10uY29uY2F0KC4uLihwZXJtdXRhdGlvbnMubWFwKHByZWZpeCA9PiB7XG4gICAgICBjb25zdCBsb3dlckNhc2VDaGFyID0gY2gudG9Mb3dlckNhc2UoKTtcbiAgICAgIGNvbnN0IHVwcGVyQ2FzZUNoYXIgPSBjaC50b1VwcGVyQ2FzZSgpO1xuICAgICAgLy8gRG9uJ3QgYWRkIHVubmVjY2VzYXJ5IHBlcm11dGF0aW9ucyB3aGVuIGNoIGlzIG5vdCBhIGxldHRlclxuICAgICAgaWYgKGxvd2VyQ2FzZUNoYXIgPT09IHVwcGVyQ2FzZUNoYXIpIHtcbiAgICAgICAgcmV0dXJuIFtwcmVmaXggKyBjaF07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gW3ByZWZpeCArIGxvd2VyQ2FzZUNoYXIsIHByZWZpeCArIHVwcGVyQ2FzZUNoYXJdO1xuICAgICAgfVxuICAgIH0pKSk7XG4gIH1cbiAgcmV0dXJuIHBlcm11dGF0aW9ucztcbn1cblxuY29uc3QgY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzID0gKGZpZWxkTmFtZSwgZGlzcGxheU5hbWUsIGZpZWxkVmFsdWUsIG93blVzZXJJZCkgPT4ge1xuICAvLyBTb21lIHRlc3RzIG5lZWQgdGhlIGFiaWxpdHkgdG8gYWRkIHVzZXJzIHdpdGggdGhlIHNhbWUgY2FzZSBpbnNlbnNpdGl2ZVxuICAvLyB2YWx1ZSwgaGVuY2UgdGhlIF9za2lwQ2FzZUluc2Vuc2l0aXZlQ2hlY2tzRm9yVGVzdCBjaGVja1xuICBjb25zdCBza2lwQ2hlY2sgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoQWNjb3VudHMuX3NraXBDYXNlSW5zZW5zaXRpdmVDaGVja3NGb3JUZXN0LCBmaWVsZFZhbHVlKTtcblxuICBpZiAoZmllbGRWYWx1ZSAmJiAhc2tpcENoZWNrKSB7XG4gICAgY29uc3QgbWF0Y2hlZFVzZXJzID0gTWV0ZW9yLnVzZXJzLmZpbmQoXG4gICAgICBzZWxlY3RvckZvckZhc3RDYXNlSW5zZW5zaXRpdmVMb29rdXAoZmllbGROYW1lLCBmaWVsZFZhbHVlKSxcbiAgICAgIHtcbiAgICAgICAgZmllbGRzOiB7X2lkOiAxfSxcbiAgICAgICAgLy8gd2Ugb25seSBuZWVkIGEgbWF4aW11bSBvZiAyIHVzZXJzIGZvciB0aGUgbG9naWMgYmVsb3cgdG8gd29ya1xuICAgICAgICBsaW1pdDogMixcbiAgICAgIH1cbiAgICApLmZldGNoKCk7XG5cbiAgICBpZiAobWF0Y2hlZFVzZXJzLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgLy8gSWYgd2UgZG9uJ3QgaGF2ZSBhIHVzZXJJZCB5ZXQsIGFueSBtYXRjaCB3ZSBmaW5kIGlzIGEgZHVwbGljYXRlXG4gICAgICAgICghb3duVXNlcklkIHx8XG4gICAgICAgIC8vIE90aGVyd2lzZSwgY2hlY2sgdG8gc2VlIGlmIHRoZXJlIGFyZSBtdWx0aXBsZSBtYXRjaGVzIG9yIGEgbWF0Y2hcbiAgICAgICAgLy8gdGhhdCBpcyBub3QgdXNcbiAgICAgICAgKG1hdGNoZWRVc2Vycy5sZW5ndGggPiAxIHx8IG1hdGNoZWRVc2Vyc1swXS5faWQgIT09IG93blVzZXJJZCkpKSB7XG4gICAgICBoYW5kbGVFcnJvcihgJHtkaXNwbGF5TmFtZX0gYWxyZWFkeSBleGlzdHMuYCk7XG4gICAgfVxuICB9XG59O1xuXG4vLyBYWFggbWF5YmUgdGhpcyBiZWxvbmdzIGluIHRoZSBjaGVjayBwYWNrYWdlXG5jb25zdCBOb25FbXB0eVN0cmluZyA9IE1hdGNoLldoZXJlKHggPT4ge1xuICBjaGVjayh4LCBTdHJpbmcpO1xuICByZXR1cm4geC5sZW5ndGggPiAwO1xufSk7XG5cbmNvbnN0IHVzZXJRdWVyeVZhbGlkYXRvciA9IE1hdGNoLldoZXJlKHVzZXIgPT4ge1xuICBjaGVjayh1c2VyLCB7XG4gICAgaWQ6IE1hdGNoLk9wdGlvbmFsKE5vbkVtcHR5U3RyaW5nKSxcbiAgICB1c2VybmFtZTogTWF0Y2guT3B0aW9uYWwoTm9uRW1wdHlTdHJpbmcpLFxuICAgIGVtYWlsOiBNYXRjaC5PcHRpb25hbChOb25FbXB0eVN0cmluZylcbiAgfSk7XG4gIGlmIChPYmplY3Qua2V5cyh1c2VyKS5sZW5ndGggIT09IDEpXG4gICAgdGhyb3cgbmV3IE1hdGNoLkVycm9yKFwiVXNlciBwcm9wZXJ0eSBtdXN0IGhhdmUgZXhhY3RseSBvbmUgZmllbGRcIik7XG4gIHJldHVybiB0cnVlO1xufSk7XG5cbmNvbnN0IHBhc3N3b3JkVmFsaWRhdG9yID0gTWF0Y2guT25lT2YoXG4gIFN0cmluZyxcbiAgeyBkaWdlc3Q6IFN0cmluZywgYWxnb3JpdGhtOiBTdHJpbmcgfVxuKTtcblxuLy8gSGFuZGxlciB0byBsb2dpbiB3aXRoIGEgcGFzc3dvcmQuXG4vL1xuLy8gVGhlIE1ldGVvciBjbGllbnQgc2V0cyBvcHRpb25zLnBhc3N3b3JkIHRvIGFuIG9iamVjdCB3aXRoIGtleXNcbi8vICdkaWdlc3QnIChzZXQgdG8gU0hBMjU2KHBhc3N3b3JkKSkgYW5kICdhbGdvcml0aG0nIChcInNoYS0yNTZcIikuXG4vL1xuLy8gRm9yIG90aGVyIEREUCBjbGllbnRzIHdoaWNoIGRvbid0IGhhdmUgYWNjZXNzIHRvIFNIQSwgdGhlIGhhbmRsZXJcbi8vIGFsc28gYWNjZXB0cyB0aGUgcGxhaW50ZXh0IHBhc3N3b3JkIGluIG9wdGlvbnMucGFzc3dvcmQgYXMgYSBzdHJpbmcuXG4vL1xuLy8gKEl0IG1pZ2h0IGJlIG5pY2UgaWYgc2VydmVycyBjb3VsZCB0dXJuIHRoZSBwbGFpbnRleHQgcGFzc3dvcmRcbi8vIG9wdGlvbiBvZmYuIE9yIG1heWJlIGl0IHNob3VsZCBiZSBvcHQtaW4sIG5vdCBvcHQtb3V0P1xuLy8gQWNjb3VudHMuY29uZmlnIG9wdGlvbj8pXG4vL1xuLy8gTm90ZSB0aGF0IG5laXRoZXIgcGFzc3dvcmQgb3B0aW9uIGlzIHNlY3VyZSB3aXRob3V0IFNTTC5cbi8vXG5BY2NvdW50cy5yZWdpc3RlckxvZ2luSGFuZGxlcihcInBhc3N3b3JkXCIsIG9wdGlvbnMgPT4ge1xuICBpZiAoISBvcHRpb25zLnBhc3N3b3JkIHx8IG9wdGlvbnMuc3JwKVxuICAgIHJldHVybiB1bmRlZmluZWQ7IC8vIGRvbid0IGhhbmRsZVxuXG4gIGNoZWNrKG9wdGlvbnMsIHtcbiAgICB1c2VyOiB1c2VyUXVlcnlWYWxpZGF0b3IsXG4gICAgcGFzc3dvcmQ6IHBhc3N3b3JkVmFsaWRhdG9yXG4gIH0pO1xuXG5cbiAgY29uc3QgdXNlciA9IEFjY291bnRzLl9maW5kVXNlckJ5UXVlcnkob3B0aW9ucy51c2VyLCB7ZmllbGRzOiB7XG4gICAgc2VydmljZXM6IDEsXG4gICAgLi4uQWNjb3VudHMuX2NoZWNrUGFzc3dvcmRVc2VyRmllbGRzLFxuICB9fSk7XG4gIGlmICghdXNlcikge1xuICAgIGhhbmRsZUVycm9yKFwiVXNlciBub3QgZm91bmRcIik7XG4gIH1cblxuICBpZiAoIXVzZXIuc2VydmljZXMgfHwgIXVzZXIuc2VydmljZXMucGFzc3dvcmQgfHxcbiAgICAgICEodXNlci5zZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQgfHwgdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnApKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIGhhcyBubyBwYXNzd29yZCBzZXRcIik7XG4gIH1cblxuICBpZiAoIXVzZXIuc2VydmljZXMucGFzc3dvcmQuYmNyeXB0KSB7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLnBhc3N3b3JkID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAvLyBUaGUgY2xpZW50IGhhcyBwcmVzZW50ZWQgYSBwbGFpbnRleHQgcGFzc3dvcmQsIGFuZCB0aGUgdXNlciBpc1xuICAgICAgLy8gbm90IHVwZ3JhZGVkIHRvIGJjcnlwdCB5ZXQuIFdlIGRvbid0IGF0dGVtcHQgdG8gdGVsbCB0aGUgY2xpZW50XG4gICAgICAvLyB0byB1cGdyYWRlIHRvIGJjcnlwdCwgYmVjYXVzZSBpdCBtaWdodCBiZSBhIHN0YW5kYWxvbmUgRERQXG4gICAgICAvLyBjbGllbnQgZG9lc24ndCBrbm93IGhvdyB0byBkbyBzdWNoIGEgdGhpbmcuXG4gICAgICBjb25zdCB2ZXJpZmllciA9IHVzZXIuc2VydmljZXMucGFzc3dvcmQuc3JwO1xuICAgICAgY29uc3QgbmV3VmVyaWZpZXIgPSBTUlAuZ2VuZXJhdGVWZXJpZmllcihvcHRpb25zLnBhc3N3b3JkLCB7XG4gICAgICAgIGlkZW50aXR5OiB2ZXJpZmllci5pZGVudGl0eSwgc2FsdDogdmVyaWZpZXIuc2FsdH0pO1xuXG4gICAgICBpZiAodmVyaWZpZXIudmVyaWZpZXIgIT09IG5ld1ZlcmlmaWVyLnZlcmlmaWVyKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdXNlcklkOiBBY2NvdW50cy5fb3B0aW9ucy5hbWJpZ3VvdXNFcnJvck1lc3NhZ2VzID8gbnVsbCA6IHVzZXIuX2lkLFxuICAgICAgICAgIGVycm9yOiBoYW5kbGVFcnJvcihcIkluY29ycmVjdCBwYXNzd29yZFwiLCBmYWxzZSlcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHt1c2VySWQ6IHVzZXIuX2lkfTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGVsbCB0aGUgY2xpZW50IHRvIHVzZSB0aGUgU1JQIHVwZ3JhZGUgcHJvY2Vzcy5cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCBcIm9sZCBwYXNzd29yZCBmb3JtYXRcIiwgRUpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgZm9ybWF0OiAnc3JwJyxcbiAgICAgICAgaWRlbnRpdHk6IHVzZXIuc2VydmljZXMucGFzc3dvcmQuc3JwLmlkZW50aXR5XG4gICAgICB9KSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNoZWNrUGFzc3dvcmQoXG4gICAgdXNlcixcbiAgICBvcHRpb25zLnBhc3N3b3JkXG4gICk7XG59KTtcblxuLy8gSGFuZGxlciB0byBsb2dpbiB1c2luZyB0aGUgU1JQIHVwZ3JhZGUgcGF0aC4gVG8gdXNlIHRoaXMgbG9naW5cbi8vIGhhbmRsZXIsIHRoZSBjbGllbnQgbXVzdCBwcm92aWRlOlxuLy8gICAtIHNycDogSChpZGVudGl0eSArIFwiOlwiICsgcGFzc3dvcmQpXG4vLyAgIC0gcGFzc3dvcmQ6IGEgc3RyaW5nIG9yIGFuIG9iamVjdCB3aXRoIHByb3BlcnRpZXMgJ2RpZ2VzdCcgYW5kICdhbGdvcml0aG0nXG4vL1xuLy8gV2UgdXNlIGBvcHRpb25zLnNycGAgdG8gdmVyaWZ5IHRoYXQgdGhlIGNsaWVudCBrbm93cyB0aGUgY29ycmVjdFxuLy8gcGFzc3dvcmQgd2l0aG91dCBkb2luZyBhIGZ1bGwgU1JQIGZsb3cuIE9uY2Ugd2UndmUgY2hlY2tlZCB0aGF0LCB3ZVxuLy8gdXBncmFkZSB0aGUgdXNlciB0byBiY3J5cHQgYW5kIHJlbW92ZSB0aGUgU1JQIGluZm9ybWF0aW9uIGZyb20gdGhlXG4vLyB1c2VyIGRvY3VtZW50LlxuLy9cbi8vIFRoZSBjbGllbnQgZW5kcyB1cCB1c2luZyB0aGlzIGxvZ2luIGhhbmRsZXIgYWZ0ZXIgdHJ5aW5nIHRoZSBub3JtYWxcbi8vIGxvZ2luIGhhbmRsZXIgKGFib3ZlKSwgd2hpY2ggdGhyb3dzIGFuIGVycm9yIHRlbGxpbmcgdGhlIGNsaWVudCB0b1xuLy8gdHJ5IHRoZSBTUlAgdXBncmFkZSBwYXRoLlxuLy9cbi8vIFhYWCBDT01QQVQgV0lUSCAwLjguMS4zXG5BY2NvdW50cy5yZWdpc3RlckxvZ2luSGFuZGxlcihcInBhc3N3b3JkXCIsIG9wdGlvbnMgPT4ge1xuICBpZiAoIW9wdGlvbnMuc3JwIHx8ICFvcHRpb25zLnBhc3N3b3JkKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDsgLy8gZG9uJ3QgaGFuZGxlXG4gIH1cblxuICBjaGVjayhvcHRpb25zLCB7XG4gICAgdXNlcjogdXNlclF1ZXJ5VmFsaWRhdG9yLFxuICAgIHNycDogU3RyaW5nLFxuICAgIHBhc3N3b3JkOiBwYXNzd29yZFZhbGlkYXRvclxuICB9KTtcblxuICBjb25zdCB1c2VyID0gQWNjb3VudHMuX2ZpbmRVc2VyQnlRdWVyeShvcHRpb25zLnVzZXIsIHtmaWVsZHM6IHtcbiAgICBzZXJ2aWNlczogMSxcbiAgICAuLi5BY2NvdW50cy5fY2hlY2tQYXNzd29yZFVzZXJGaWVsZHMsXG4gIH19KTtcbiAgaWYgKCF1c2VyKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIC8vIENoZWNrIHRvIHNlZSBpZiBhbm90aGVyIHNpbXVsdGFuZW91cyBsb2dpbiBoYXMgYWxyZWFkeSB1cGdyYWRlZFxuICAvLyB0aGUgdXNlciByZWNvcmQgdG8gYmNyeXB0LlxuICBpZiAodXNlci5zZXJ2aWNlcyAmJiB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkICYmIHVzZXIuc2VydmljZXMucGFzc3dvcmQuYmNyeXB0KSB7XG4gICAgcmV0dXJuIGNoZWNrUGFzc3dvcmQodXNlciwgb3B0aW9ucy5wYXNzd29yZCk7XG4gIH1cblxuICBpZiAoISh1c2VyLnNlcnZpY2VzICYmIHVzZXIuc2VydmljZXMucGFzc3dvcmQgJiYgdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnApKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIGhhcyBubyBwYXNzd29yZCBzZXRcIik7XG4gIH1cblxuICBjb25zdCB2MSA9IHVzZXIuc2VydmljZXMucGFzc3dvcmQuc3JwLnZlcmlmaWVyO1xuICBjb25zdCB2MiA9IFNSUC5nZW5lcmF0ZVZlcmlmaWVyKFxuICAgIG51bGwsXG4gICAge1xuICAgICAgaGFzaGVkSWRlbnRpdHlBbmRQYXNzd29yZDogb3B0aW9ucy5zcnAsXG4gICAgICBzYWx0OiB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLnNycC5zYWx0XG4gICAgfVxuICApLnZlcmlmaWVyO1xuICBpZiAodjEgIT09IHYyKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHVzZXJJZDogQWNjb3VudHMuX29wdGlvbnMuYW1iaWd1b3VzRXJyb3JNZXNzYWdlcyA/IG51bGwgOiB1c2VyLl9pZCxcbiAgICAgIGVycm9yOiBoYW5kbGVFcnJvcihcIkluY29ycmVjdCBwYXNzd29yZFwiLCBmYWxzZSlcbiAgICB9O1xuICB9XG5cbiAgLy8gVXBncmFkZSB0byBiY3J5cHQgb24gc3VjY2Vzc2Z1bCBsb2dpbi5cbiAgY29uc3Qgc2FsdGVkID0gaGFzaFBhc3N3b3JkKG9wdGlvbnMucGFzc3dvcmQpO1xuICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgIHVzZXIuX2lkLFxuICAgIHtcbiAgICAgICR1bnNldDogeyAnc2VydmljZXMucGFzc3dvcmQuc3JwJzogMSB9LFxuICAgICAgJHNldDogeyAnc2VydmljZXMucGFzc3dvcmQuYmNyeXB0Jzogc2FsdGVkIH1cbiAgICB9XG4gICk7XG5cbiAgcmV0dXJuIHt1c2VySWQ6IHVzZXIuX2lkfTtcbn0pO1xuXG5cbi8vL1xuLy8vIENIQU5HSU5HXG4vLy9cblxuLyoqXG4gKiBAc3VtbWFyeSBDaGFuZ2UgYSB1c2VyJ3MgdXNlcm5hbWUuIFVzZSB0aGlzIGluc3RlYWQgb2YgdXBkYXRpbmcgdGhlXG4gKiBkYXRhYmFzZSBkaXJlY3RseS4gVGhlIG9wZXJhdGlvbiB3aWxsIGZhaWwgaWYgdGhlcmUgaXMgYW4gZXhpc3RpbmcgdXNlclxuICogd2l0aCBhIHVzZXJuYW1lIG9ubHkgZGlmZmVyaW5nIGluIGNhc2UuXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge1N0cmluZ30gdXNlcklkIFRoZSBJRCBvZiB0aGUgdXNlciB0byB1cGRhdGUuXG4gKiBAcGFyYW0ge1N0cmluZ30gbmV3VXNlcm5hbWUgQSBuZXcgdXNlcm5hbWUgZm9yIHRoZSB1c2VyLlxuICogQGltcG9ydEZyb21QYWNrYWdlIGFjY291bnRzLWJhc2VcbiAqL1xuQWNjb3VudHMuc2V0VXNlcm5hbWUgPSAodXNlcklkLCBuZXdVc2VybmFtZSkgPT4ge1xuICBjaGVjayh1c2VySWQsIE5vbkVtcHR5U3RyaW5nKTtcbiAgY2hlY2sobmV3VXNlcm5hbWUsIE5vbkVtcHR5U3RyaW5nKTtcblxuICBjb25zdCB1c2VyID0gZ2V0VXNlckJ5SWQodXNlcklkLCB7ZmllbGRzOiB7XG4gICAgdXNlcm5hbWU6IDEsXG4gIH19KTtcbiAgaWYgKCF1c2VyKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGNvbnN0IG9sZFVzZXJuYW1lID0gdXNlci51c2VybmFtZTtcblxuICAvLyBQZXJmb3JtIGEgY2FzZSBpbnNlbnNpdGl2ZSBjaGVjayBmb3IgZHVwbGljYXRlcyBiZWZvcmUgdXBkYXRlXG4gIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygndXNlcm5hbWUnLCAnVXNlcm5hbWUnLCBuZXdVc2VybmFtZSwgdXNlci5faWQpO1xuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LCB7JHNldDoge3VzZXJuYW1lOiBuZXdVc2VybmFtZX19KTtcblxuICAvLyBQZXJmb3JtIGFub3RoZXIgY2hlY2sgYWZ0ZXIgdXBkYXRlLCBpbiBjYXNlIGEgbWF0Y2hpbmcgdXNlciBoYXMgYmVlblxuICAvLyBpbnNlcnRlZCBpbiB0aGUgbWVhbnRpbWVcbiAgdHJ5IHtcbiAgICBjaGVja0ZvckNhc2VJbnNlbnNpdGl2ZUR1cGxpY2F0ZXMoJ3VzZXJuYW1lJywgJ1VzZXJuYW1lJywgbmV3VXNlcm5hbWUsIHVzZXIuX2lkKTtcbiAgfSBjYXRjaCAoZXgpIHtcbiAgICAvLyBVbmRvIHVwZGF0ZSBpZiB0aGUgY2hlY2sgZmFpbHNcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHVzZXIuX2lkfSwgeyRzZXQ6IHt1c2VybmFtZTogb2xkVXNlcm5hbWV9fSk7XG4gICAgdGhyb3cgZXg7XG4gIH1cbn07XG5cbi8vIExldCB0aGUgdXNlciBjaGFuZ2UgdGhlaXIgb3duIHBhc3N3b3JkIGlmIHRoZXkga25vdyB0aGUgb2xkXG4vLyBwYXNzd29yZC4gYG9sZFBhc3N3b3JkYCBhbmQgYG5ld1Bhc3N3b3JkYCBzaG91bGQgYmUgb2JqZWN0cyB3aXRoIGtleXNcbi8vIGBkaWdlc3RgIGFuZCBgYWxnb3JpdGhtYCAocmVwcmVzZW50aW5nIHRoZSBTSEEyNTYgb2YgdGhlIHBhc3N3b3JkKS5cbi8vXG4vLyBYWFggQ09NUEFUIFdJVEggMC44LjEuM1xuLy8gTGlrZSB0aGUgbG9naW4gbWV0aG9kLCBpZiB0aGUgdXNlciBoYXNuJ3QgYmVlbiB1cGdyYWRlZCBmcm9tIFNSUCB0b1xuLy8gYmNyeXB0IHlldCwgdGhlbiB0aGlzIG1ldGhvZCB3aWxsIHRocm93IGFuICdvbGQgcGFzc3dvcmQgZm9ybWF0J1xuLy8gZXJyb3IuIFRoZSBjbGllbnQgc2hvdWxkIGNhbGwgdGhlIFNSUCB1cGdyYWRlIGxvZ2luIGhhbmRsZXIgYW5kIHRoZW5cbi8vIHJldHJ5IHRoaXMgbWV0aG9kIGFnYWluLlxuLy9cbi8vIFVOTElLRSB0aGUgbG9naW4gbWV0aG9kLCB0aGVyZSBpcyBubyB3YXkgdG8gYXZvaWQgZ2V0dGluZyBTUlAgdXBncmFkZVxuLy8gZXJyb3JzIHRocm93bi4gVGhlIHJlYXNvbmluZyBmb3IgdGhpcyBpcyB0aGF0IGNsaWVudHMgdXNpbmcgdGhpc1xuLy8gbWV0aG9kIGRpcmVjdGx5IHdpbGwgbmVlZCB0byBiZSB1cGRhdGVkIGFueXdheSBiZWNhdXNlIHdlIG5vIGxvbmdlclxuLy8gc3VwcG9ydCB0aGUgU1JQIGZsb3cgdGhhdCB0aGV5IHdvdWxkIGhhdmUgYmVlbiBkb2luZyB0byB1c2UgdGhpc1xuLy8gbWV0aG9kIHByZXZpb3VzbHkuXG5NZXRlb3IubWV0aG9kcyh7Y2hhbmdlUGFzc3dvcmQ6IGZ1bmN0aW9uIChvbGRQYXNzd29yZCwgbmV3UGFzc3dvcmQpIHtcbiAgY2hlY2sob2xkUGFzc3dvcmQsIHBhc3N3b3JkVmFsaWRhdG9yKTtcbiAgY2hlY2sobmV3UGFzc3dvcmQsIHBhc3N3b3JkVmFsaWRhdG9yKTtcblxuICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDEsIFwiTXVzdCBiZSBsb2dnZWQgaW5cIik7XG4gIH1cblxuICBjb25zdCB1c2VyID0gZ2V0VXNlckJ5SWQodGhpcy51c2VySWQsIHtmaWVsZHM6IHtcbiAgICBzZXJ2aWNlczogMSxcbiAgICAuLi5BY2NvdW50cy5fY2hlY2tQYXNzd29yZFVzZXJGaWVsZHMsXG4gIH19KTtcbiAgaWYgKCF1c2VyKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGlmICghdXNlci5zZXJ2aWNlcyB8fCAhdXNlci5zZXJ2aWNlcy5wYXNzd29yZCB8fFxuICAgICAgKCF1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCAmJiAhdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnApKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIGhhcyBubyBwYXNzd29yZCBzZXRcIik7XG4gIH1cblxuICBpZiAoISB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCkge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCBcIm9sZCBwYXNzd29yZCBmb3JtYXRcIiwgRUpTT04uc3RyaW5naWZ5KHtcbiAgICAgIGZvcm1hdDogJ3NycCcsXG4gICAgICBpZGVudGl0eTogdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnAuaWRlbnRpdHlcbiAgICB9KSk7XG4gIH1cblxuICBjb25zdCByZXN1bHQgPSBjaGVja1Bhc3N3b3JkKHVzZXIsIG9sZFBhc3N3b3JkKTtcbiAgaWYgKHJlc3VsdC5lcnJvcikge1xuICAgIHRocm93IHJlc3VsdC5lcnJvcjtcbiAgfVxuXG4gIGNvbnN0IGhhc2hlZCA9IGhhc2hQYXNzd29yZChuZXdQYXNzd29yZCk7XG5cbiAgLy8gSXQgd291bGQgYmUgYmV0dGVyIGlmIHRoaXMgcmVtb3ZlZCBBTEwgZXhpc3RpbmcgdG9rZW5zIGFuZCByZXBsYWNlZFxuICAvLyB0aGUgdG9rZW4gZm9yIHRoZSBjdXJyZW50IGNvbm5lY3Rpb24gd2l0aCBhIG5ldyBvbmUsIGJ1dCB0aGF0IHdvdWxkXG4gIC8vIGJlIHRyaWNreSwgc28gd2UnbGwgc2V0dGxlIGZvciBqdXN0IHJlcGxhY2luZyBhbGwgdG9rZW5zIG90aGVyIHRoYW5cbiAgLy8gdGhlIG9uZSBmb3IgdGhlIGN1cnJlbnQgY29ubmVjdGlvbi5cbiAgY29uc3QgY3VycmVudFRva2VuID0gQWNjb3VudHMuX2dldExvZ2luVG9rZW4odGhpcy5jb25uZWN0aW9uLmlkKTtcbiAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICB7IF9pZDogdGhpcy51c2VySWQgfSxcbiAgICB7XG4gICAgICAkc2V0OiB7ICdzZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQnOiBoYXNoZWQgfSxcbiAgICAgICRwdWxsOiB7XG4gICAgICAgICdzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMnOiB7IGhhc2hlZFRva2VuOiB7ICRuZTogY3VycmVudFRva2VuIH0gfVxuICAgICAgfSxcbiAgICAgICR1bnNldDogeyAnc2VydmljZXMucGFzc3dvcmQucmVzZXQnOiAxIH1cbiAgICB9XG4gICk7XG5cbiAgcmV0dXJuIHtwYXNzd29yZENoYW5nZWQ6IHRydWV9O1xufX0pO1xuXG5cbi8vIEZvcmNlIGNoYW5nZSB0aGUgdXNlcnMgcGFzc3dvcmQuXG5cbi8qKlxuICogQHN1bW1hcnkgRm9yY2libHkgY2hhbmdlIHRoZSBwYXNzd29yZCBmb3IgYSB1c2VyLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgaWQgb2YgdGhlIHVzZXIgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IG5ld1Bhc3N3b3JkIEEgbmV3IHBhc3N3b3JkIGZvciB0aGUgdXNlci5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zLmxvZ291dCBMb2dvdXQgYWxsIGN1cnJlbnQgY29ubmVjdGlvbnMgd2l0aCB0aGlzIHVzZXJJZCAoZGVmYXVsdDogdHJ1ZSlcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnNldFBhc3N3b3JkID0gKHVzZXJJZCwgbmV3UGxhaW50ZXh0UGFzc3dvcmQsIG9wdGlvbnMpID0+IHtcbiAgb3B0aW9ucyA9IHsgbG9nb3V0OiB0cnVlICwgLi4ub3B0aW9ucyB9O1xuXG4gIGNvbnN0IHVzZXIgPSBnZXRVc2VyQnlJZCh1c2VySWQsIHtmaWVsZHM6IHtfaWQ6IDF9fSk7XG4gIGlmICghdXNlcikge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlVzZXIgbm90IGZvdW5kXCIpO1xuICB9XG5cbiAgY29uc3QgdXBkYXRlID0ge1xuICAgICR1bnNldDoge1xuICAgICAgJ3NlcnZpY2VzLnBhc3N3b3JkLnNycCc6IDEsIC8vIFhYWCBDT01QQVQgV0lUSCAwLjguMS4zXG4gICAgICAnc2VydmljZXMucGFzc3dvcmQucmVzZXQnOiAxXG4gICAgfSxcbiAgICAkc2V0OiB7J3NlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCc6IGhhc2hQYXNzd29yZChuZXdQbGFpbnRleHRQYXNzd29yZCl9XG4gIH07XG5cbiAgaWYgKG9wdGlvbnMubG9nb3V0KSB7XG4gICAgdXBkYXRlLiR1bnNldFsnc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zJ10gPSAxO1xuICB9XG5cbiAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7X2lkOiB1c2VyLl9pZH0sIHVwZGF0ZSk7XG59O1xuXG5cbi8vL1xuLy8vIFJFU0VUVElORyBWSUEgRU1BSUxcbi8vL1xuXG4vLyBVdGlsaXR5IGZvciBwbHVja2luZyBhZGRyZXNzZXMgZnJvbSBlbWFpbHNcbmNvbnN0IHBsdWNrQWRkcmVzc2VzID0gKGVtYWlscyA9IFtdKSA9PiBlbWFpbHMubWFwKGVtYWlsID0+IGVtYWlsLmFkZHJlc3MpO1xuXG4vLyBNZXRob2QgY2FsbGVkIGJ5IGEgdXNlciB0byByZXF1ZXN0IGEgcGFzc3dvcmQgcmVzZXQgZW1haWwuIFRoaXMgaXNcbi8vIHRoZSBzdGFydCBvZiB0aGUgcmVzZXQgcHJvY2Vzcy5cbk1ldGVvci5tZXRob2RzKHtmb3Jnb3RQYXNzd29yZDogb3B0aW9ucyA9PiB7XG4gIGNoZWNrKG9wdGlvbnMsIHtlbWFpbDogU3RyaW5nfSk7XG5cbiAgY29uc3QgdXNlciA9IEFjY291bnRzLmZpbmRVc2VyQnlFbWFpbChvcHRpb25zLmVtYWlsLCB7ZmllbGRzOiB7ZW1haWxzOiAxfX0pO1xuICBpZiAoIXVzZXIpIHtcbiAgICBoYW5kbGVFcnJvcihcIlVzZXIgbm90IGZvdW5kXCIpO1xuICB9XG5cbiAgY29uc3QgZW1haWxzID0gcGx1Y2tBZGRyZXNzZXModXNlci5lbWFpbHMpO1xuICBjb25zdCBjYXNlU2Vuc2l0aXZlRW1haWwgPSBlbWFpbHMuZmluZChcbiAgICBlbWFpbCA9PiBlbWFpbC50b0xvd2VyQ2FzZSgpID09PSBvcHRpb25zLmVtYWlsLnRvTG93ZXJDYXNlKClcbiAgKTtcblxuICBBY2NvdW50cy5zZW5kUmVzZXRQYXNzd29yZEVtYWlsKHVzZXIuX2lkLCBjYXNlU2Vuc2l0aXZlRW1haWwpO1xufX0pO1xuXG4vKipcbiAqIEBzdW1tYXJ5IEdlbmVyYXRlcyBhIHJlc2V0IHRva2VuIGFuZCBzYXZlcyBpdCBpbnRvIHRoZSBkYXRhYmFzZS5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7U3RyaW5nfSB1c2VySWQgVGhlIGlkIG9mIHRoZSB1c2VyIHRvIGdlbmVyYXRlIHRoZSByZXNldCB0b2tlbiBmb3IuXG4gKiBAcGFyYW0ge1N0cmluZ30gZW1haWwgV2hpY2ggYWRkcmVzcyBvZiB0aGUgdXNlciB0byBnZW5lcmF0ZSB0aGUgcmVzZXQgdG9rZW4gZm9yLiBUaGlzIGFkZHJlc3MgbXVzdCBiZSBpbiB0aGUgdXNlcidzIGBlbWFpbHNgIGxpc3QuIElmIGBudWxsYCwgZGVmYXVsdHMgdG8gdGhlIGZpcnN0IGVtYWlsIGluIHRoZSBsaXN0LlxuICogQHBhcmFtIHtTdHJpbmd9IHJlYXNvbiBgcmVzZXRQYXNzd29yZGAgb3IgYGVucm9sbEFjY291bnRgLlxuICogQHBhcmFtIHtPYmplY3R9IFtleHRyYVRva2VuRGF0YV0gT3B0aW9uYWwgYWRkaXRpb25hbCBkYXRhIHRvIGJlIGFkZGVkIGludG8gdGhlIHRva2VuIHJlY29yZC5cbiAqIEByZXR1cm5zIHtPYmplY3R9IE9iamVjdCB3aXRoIHtlbWFpbCwgdXNlciwgdG9rZW59IHZhbHVlcy5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmdlbmVyYXRlUmVzZXRUb2tlbiA9ICh1c2VySWQsIGVtYWlsLCByZWFzb24sIGV4dHJhVG9rZW5EYXRhKSA9PiB7XG4gIC8vIE1ha2Ugc3VyZSB0aGUgdXNlciBleGlzdHMsIGFuZCBlbWFpbCBpcyBvbmUgb2YgdGhlaXIgYWRkcmVzc2VzLlxuICAvLyBEb24ndCBsaW1pdCB0aGUgZmllbGRzIGluIHRoZSB1c2VyIG9iamVjdCBzaW5jZSB0aGUgdXNlciBpcyByZXR1cm5lZFxuICAvLyBieSB0aGUgZnVuY3Rpb24gYW5kIHNvbWUgb3RoZXIgZmllbGRzIG1pZ2h0IGJlIHVzZWQgZWxzZXdoZXJlLlxuICBjb25zdCB1c2VyID0gZ2V0VXNlckJ5SWQodXNlcklkKTtcbiAgaWYgKCF1c2VyKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJDYW4ndCBmaW5kIHVzZXJcIik7XG4gIH1cblxuICAvLyBwaWNrIHRoZSBmaXJzdCBlbWFpbCBpZiB3ZSB3ZXJlbid0IHBhc3NlZCBhbiBlbWFpbC5cbiAgaWYgKCFlbWFpbCAmJiB1c2VyLmVtYWlscyAmJiB1c2VyLmVtYWlsc1swXSkge1xuICAgIGVtYWlsID0gdXNlci5lbWFpbHNbMF0uYWRkcmVzcztcbiAgfVxuXG4gIC8vIG1ha2Ugc3VyZSB3ZSBoYXZlIGEgdmFsaWQgZW1haWxcbiAgaWYgKCFlbWFpbCB8fFxuICAgICEocGx1Y2tBZGRyZXNzZXModXNlci5lbWFpbHMpLmluY2x1ZGVzKGVtYWlsKSkpIHtcbiAgICBoYW5kbGVFcnJvcihcIk5vIHN1Y2ggZW1haWwgZm9yIHVzZXIuXCIpO1xuICB9XG5cbiAgY29uc3QgdG9rZW4gPSBSYW5kb20uc2VjcmV0KCk7XG4gIGNvbnN0IHRva2VuUmVjb3JkID0ge1xuICAgIHRva2VuLFxuICAgIGVtYWlsLFxuICAgIHdoZW46IG5ldyBEYXRlKClcbiAgfTtcblxuICBpZiAocmVhc29uID09PSAncmVzZXRQYXNzd29yZCcpIHtcbiAgICB0b2tlblJlY29yZC5yZWFzb24gPSAncmVzZXQnO1xuICB9IGVsc2UgaWYgKHJlYXNvbiA9PT0gJ2Vucm9sbEFjY291bnQnKSB7XG4gICAgdG9rZW5SZWNvcmQucmVhc29uID0gJ2Vucm9sbCc7XG4gIH0gZWxzZSBpZiAocmVhc29uKSB7XG4gICAgLy8gZmFsbGJhY2sgc28gdGhhdCB0aGlzIGZ1bmN0aW9uIGNhbiBiZSB1c2VkIGZvciB1bmtub3duIHJlYXNvbnMgYXMgd2VsbFxuICAgIHRva2VuUmVjb3JkLnJlYXNvbiA9IHJlYXNvbjtcbiAgfVxuXG4gIGlmIChleHRyYVRva2VuRGF0YSkge1xuICAgIE9iamVjdC5hc3NpZ24odG9rZW5SZWNvcmQsIGV4dHJhVG9rZW5EYXRhKTtcbiAgfVxuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LCB7JHNldDoge1xuICAgICdzZXJ2aWNlcy5wYXNzd29yZC5yZXNldCc6IHRva2VuUmVjb3JkXG4gIH19KTtcblxuICAvLyBiZWZvcmUgcGFzc2luZyB0byB0ZW1wbGF0ZSwgdXBkYXRlIHVzZXIgb2JqZWN0IHdpdGggbmV3IHRva2VuXG4gIE1ldGVvci5fZW5zdXJlKHVzZXIsICdzZXJ2aWNlcycsICdwYXNzd29yZCcpLnJlc2V0ID0gdG9rZW5SZWNvcmQ7XG5cbiAgcmV0dXJuIHtlbWFpbCwgdXNlciwgdG9rZW59O1xufTtcblxuLyoqXG4gKiBAc3VtbWFyeSBHZW5lcmF0ZXMgYW4gZS1tYWlsIHZlcmlmaWNhdGlvbiB0b2tlbiBhbmQgc2F2ZXMgaXQgaW50byB0aGUgZGF0YWJhc2UuXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge1N0cmluZ30gdXNlcklkIFRoZSBpZCBvZiB0aGUgdXNlciB0byBnZW5lcmF0ZSB0aGUgIGUtbWFpbCB2ZXJpZmljYXRpb24gdG9rZW4gZm9yLlxuICogQHBhcmFtIHtTdHJpbmd9IGVtYWlsIFdoaWNoIGFkZHJlc3Mgb2YgdGhlIHVzZXIgdG8gZ2VuZXJhdGUgdGhlIGUtbWFpbCB2ZXJpZmljYXRpb24gdG9rZW4gZm9yLiBUaGlzIGFkZHJlc3MgbXVzdCBiZSBpbiB0aGUgdXNlcidzIGBlbWFpbHNgIGxpc3QuIElmIGBudWxsYCwgZGVmYXVsdHMgdG8gdGhlIGZpcnN0IHVudmVyaWZpZWQgZW1haWwgaW4gdGhlIGxpc3QuXG4gKiBAcGFyYW0ge09iamVjdH0gW2V4dHJhVG9rZW5EYXRhXSBPcHRpb25hbCBhZGRpdGlvbmFsIGRhdGEgdG8gYmUgYWRkZWQgaW50byB0aGUgdG9rZW4gcmVjb3JkLlxuICogQHJldHVybnMge09iamVjdH0gT2JqZWN0IHdpdGgge2VtYWlsLCB1c2VyLCB0b2tlbn0gdmFsdWVzLlxuICogQGltcG9ydEZyb21QYWNrYWdlIGFjY291bnRzLWJhc2VcbiAqL1xuQWNjb3VudHMuZ2VuZXJhdGVWZXJpZmljYXRpb25Ub2tlbiA9ICh1c2VySWQsIGVtYWlsLCBleHRyYVRva2VuRGF0YSkgPT4ge1xuICAvLyBNYWtlIHN1cmUgdGhlIHVzZXIgZXhpc3RzLCBhbmQgZW1haWwgaXMgb25lIG9mIHRoZWlyIGFkZHJlc3Nlcy5cbiAgLy8gRG9uJ3QgbGltaXQgdGhlIGZpZWxkcyBpbiB0aGUgdXNlciBvYmplY3Qgc2luY2UgdGhlIHVzZXIgaXMgcmV0dXJuZWRcbiAgLy8gYnkgdGhlIGZ1bmN0aW9uIGFuZCBzb21lIG90aGVyIGZpZWxkcyBtaWdodCBiZSB1c2VkIGVsc2V3aGVyZS5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHVzZXJJZCk7XG4gIGlmICghdXNlcikge1xuICAgIGhhbmRsZUVycm9yKFwiQ2FuJ3QgZmluZCB1c2VyXCIpO1xuICB9XG5cbiAgLy8gcGljayB0aGUgZmlyc3QgdW52ZXJpZmllZCBlbWFpbCBpZiB3ZSB3ZXJlbid0IHBhc3NlZCBhbiBlbWFpbC5cbiAgaWYgKCFlbWFpbCkge1xuICAgIGNvbnN0IGVtYWlsUmVjb3JkID0gKHVzZXIuZW1haWxzIHx8IFtdKS5maW5kKGUgPT4gIWUudmVyaWZpZWQpO1xuICAgIGVtYWlsID0gKGVtYWlsUmVjb3JkIHx8IHt9KS5hZGRyZXNzO1xuXG4gICAgaWYgKCFlbWFpbCkge1xuICAgICAgaGFuZGxlRXJyb3IoXCJUaGF0IHVzZXIgaGFzIG5vIHVudmVyaWZpZWQgZW1haWwgYWRkcmVzc2VzLlwiKTtcbiAgICB9XG4gIH1cblxuICAvLyBtYWtlIHN1cmUgd2UgaGF2ZSBhIHZhbGlkIGVtYWlsXG4gIGlmICghZW1haWwgfHxcbiAgICAhKHBsdWNrQWRkcmVzc2VzKHVzZXIuZW1haWxzKS5pbmNsdWRlcyhlbWFpbCkpKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJObyBzdWNoIGVtYWlsIGZvciB1c2VyLlwiKTtcbiAgfVxuXG4gIGNvbnN0IHRva2VuID0gUmFuZG9tLnNlY3JldCgpO1xuICBjb25zdCB0b2tlblJlY29yZCA9IHtcbiAgICB0b2tlbixcbiAgICAvLyBUT0RPOiBUaGlzIHNob3VsZCBwcm9iYWJseSBiZSByZW5hbWVkIHRvIFwiZW1haWxcIiB0byBtYXRjaCByZXNldCB0b2tlbiByZWNvcmQuXG4gICAgYWRkcmVzczogZW1haWwsXG4gICAgd2hlbjogbmV3IERhdGUoKVxuICB9O1xuXG4gIGlmIChleHRyYVRva2VuRGF0YSkge1xuICAgIE9iamVjdC5hc3NpZ24odG9rZW5SZWNvcmQsIGV4dHJhVG9rZW5EYXRhKTtcbiAgfVxuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LCB7JHB1c2g6IHtcbiAgICAnc2VydmljZXMuZW1haWwudmVyaWZpY2F0aW9uVG9rZW5zJzogdG9rZW5SZWNvcmRcbiAgfX0pO1xuXG4gIC8vIGJlZm9yZSBwYXNzaW5nIHRvIHRlbXBsYXRlLCB1cGRhdGUgdXNlciBvYmplY3Qgd2l0aCBuZXcgdG9rZW5cbiAgTWV0ZW9yLl9lbnN1cmUodXNlciwgJ3NlcnZpY2VzJywgJ2VtYWlsJyk7XG4gIGlmICghdXNlci5zZXJ2aWNlcy5lbWFpbC52ZXJpZmljYXRpb25Ub2tlbnMpIHtcbiAgICB1c2VyLnNlcnZpY2VzLmVtYWlsLnZlcmlmaWNhdGlvblRva2VucyA9IFtdO1xuICB9XG4gIHVzZXIuc2VydmljZXMuZW1haWwudmVyaWZpY2F0aW9uVG9rZW5zLnB1c2godG9rZW5SZWNvcmQpO1xuXG4gIHJldHVybiB7ZW1haWwsIHVzZXIsIHRva2VufTtcbn07XG5cbi8qKlxuICogQHN1bW1hcnkgQ3JlYXRlcyBvcHRpb25zIGZvciBlbWFpbCBzZW5kaW5nIGZvciByZXNldCBwYXNzd29yZCBhbmQgZW5yb2xsIGFjY291bnQgZW1haWxzLlxuICogWW91IGNhbiB1c2UgdGhpcyBmdW5jdGlvbiB3aGVuIGN1c3RvbWl6aW5nIGEgcmVzZXQgcGFzc3dvcmQgb3IgZW5yb2xsIGFjY291bnQgZW1haWwgc2VuZGluZy5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7T2JqZWN0fSBlbWFpbCBXaGljaCBhZGRyZXNzIG9mIHRoZSB1c2VyJ3MgdG8gc2VuZCB0aGUgZW1haWwgdG8uXG4gKiBAcGFyYW0ge09iamVjdH0gdXNlciBUaGUgdXNlciBvYmplY3QgdG8gZ2VuZXJhdGUgb3B0aW9ucyBmb3IuXG4gKiBAcGFyYW0ge1N0cmluZ30gdXJsIFVSTCB0byB3aGljaCB1c2VyIGlzIGRpcmVjdGVkIHRvIGNvbmZpcm0gdGhlIGVtYWlsLlxuICogQHBhcmFtIHtTdHJpbmd9IHJlYXNvbiBgcmVzZXRQYXNzd29yZGAgb3IgYGVucm9sbEFjY291bnRgLlxuICogQHJldHVybnMge09iamVjdH0gT3B0aW9ucyB3aGljaCBjYW4gYmUgcGFzc2VkIHRvIGBFbWFpbC5zZW5kYC5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmdlbmVyYXRlT3B0aW9uc0ZvckVtYWlsID0gKGVtYWlsLCB1c2VyLCB1cmwsIHJlYXNvbikgPT4ge1xuICBjb25zdCBvcHRpb25zID0ge1xuICAgIHRvOiBlbWFpbCxcbiAgICBmcm9tOiBBY2NvdW50cy5lbWFpbFRlbXBsYXRlc1tyZWFzb25dLmZyb21cbiAgICAgID8gQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS5mcm9tKHVzZXIpXG4gICAgICA6IEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmZyb20sXG4gICAgc3ViamVjdDogQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS5zdWJqZWN0KHVzZXIpXG4gIH07XG5cbiAgaWYgKHR5cGVvZiBBY2NvdW50cy5lbWFpbFRlbXBsYXRlc1tyZWFzb25dLnRleHQgPT09ICdmdW5jdGlvbicpIHtcbiAgICBvcHRpb25zLnRleHQgPSBBY2NvdW50cy5lbWFpbFRlbXBsYXRlc1tyZWFzb25dLnRleHQodXNlciwgdXJsKTtcbiAgfVxuXG4gIGlmICh0eXBlb2YgQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS5odG1sID09PSAnZnVuY3Rpb24nKSB7XG4gICAgb3B0aW9ucy5odG1sID0gQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS5odG1sKHVzZXIsIHVybCk7XG4gIH1cblxuICBpZiAodHlwZW9mIEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmhlYWRlcnMgPT09ICdvYmplY3QnKSB7XG4gICAgb3B0aW9ucy5oZWFkZXJzID0gQWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuaGVhZGVycztcbiAgfVxuXG4gIHJldHVybiBvcHRpb25zO1xufTtcblxuLy8gc2VuZCB0aGUgdXNlciBhbiBlbWFpbCB3aXRoIGEgbGluayB0aGF0IHdoZW4gb3BlbmVkIGFsbG93cyB0aGUgdXNlclxuLy8gdG8gc2V0IGEgbmV3IHBhc3N3b3JkLCB3aXRob3V0IHRoZSBvbGQgcGFzc3dvcmQuXG5cbi8qKlxuICogQHN1bW1hcnkgU2VuZCBhbiBlbWFpbCB3aXRoIGEgbGluayB0aGUgdXNlciBjYW4gdXNlIHRvIHJlc2V0IHRoZWlyIHBhc3N3b3JkLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgaWQgb2YgdGhlIHVzZXIgdG8gc2VuZCBlbWFpbCB0by5cbiAqIEBwYXJhbSB7U3RyaW5nfSBbZW1haWxdIE9wdGlvbmFsLiBXaGljaCBhZGRyZXNzIG9mIHRoZSB1c2VyJ3MgdG8gc2VuZCB0aGUgZW1haWwgdG8uIFRoaXMgYWRkcmVzcyBtdXN0IGJlIGluIHRoZSB1c2VyJ3MgYGVtYWlsc2AgbGlzdC4gRGVmYXVsdHMgdG8gdGhlIGZpcnN0IGVtYWlsIGluIHRoZSBsaXN0LlxuICogQHBhcmFtIHtPYmplY3R9IFtleHRyYVRva2VuRGF0YV0gT3B0aW9uYWwgYWRkaXRpb25hbCBkYXRhIHRvIGJlIGFkZGVkIGludG8gdGhlIHRva2VuIHJlY29yZC5cbiAqIEByZXR1cm5zIHtPYmplY3R9IE9iamVjdCB3aXRoIHtlbWFpbCwgdXNlciwgdG9rZW4sIHVybCwgb3B0aW9uc30gdmFsdWVzLlxuICogQGltcG9ydEZyb21QYWNrYWdlIGFjY291bnRzLWJhc2VcbiAqL1xuQWNjb3VudHMuc2VuZFJlc2V0UGFzc3dvcmRFbWFpbCA9ICh1c2VySWQsIGVtYWlsLCBleHRyYVRva2VuRGF0YSkgPT4ge1xuICBjb25zdCB7ZW1haWw6IHJlYWxFbWFpbCwgdXNlciwgdG9rZW59ID1cbiAgICBBY2NvdW50cy5nZW5lcmF0ZVJlc2V0VG9rZW4odXNlcklkLCBlbWFpbCwgJ3Jlc2V0UGFzc3dvcmQnLCBleHRyYVRva2VuRGF0YSk7XG4gIGNvbnN0IHVybCA9IEFjY291bnRzLnVybHMucmVzZXRQYXNzd29yZCh0b2tlbik7XG4gIGNvbnN0IG9wdGlvbnMgPSBBY2NvdW50cy5nZW5lcmF0ZU9wdGlvbnNGb3JFbWFpbChyZWFsRW1haWwsIHVzZXIsIHVybCwgJ3Jlc2V0UGFzc3dvcmQnKTtcbiAgRW1haWwuc2VuZChvcHRpb25zKTtcbiAgaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KSB7XG4gICAgY29uc29sZS5sb2coYFxcblJlc2V0IHBhc3N3b3JkIFVSTDogJHt1cmx9YCk7XG4gIH1cbiAgcmV0dXJuIHtlbWFpbDogcmVhbEVtYWlsLCB1c2VyLCB0b2tlbiwgdXJsLCBvcHRpb25zfTtcbn07XG5cbi8vIHNlbmQgdGhlIHVzZXIgYW4gZW1haWwgaW5mb3JtaW5nIHRoZW0gdGhhdCB0aGVpciBhY2NvdW50IHdhcyBjcmVhdGVkLCB3aXRoXG4vLyBhIGxpbmsgdGhhdCB3aGVuIG9wZW5lZCBib3RoIG1hcmtzIHRoZWlyIGVtYWlsIGFzIHZlcmlmaWVkIGFuZCBmb3JjZXMgdGhlbVxuLy8gdG8gY2hvb3NlIHRoZWlyIHBhc3N3b3JkLiBUaGUgZW1haWwgbXVzdCBiZSBvbmUgb2YgdGhlIGFkZHJlc3NlcyBpbiB0aGVcbi8vIHVzZXIncyBlbWFpbHMgZmllbGQsIG9yIHVuZGVmaW5lZCB0byBwaWNrIHRoZSBmaXJzdCBlbWFpbCBhdXRvbWF0aWNhbGx5LlxuLy9cbi8vIFRoaXMgaXMgbm90IGNhbGxlZCBhdXRvbWF0aWNhbGx5LiBJdCBtdXN0IGJlIGNhbGxlZCBtYW51YWxseSBpZiB5b3Vcbi8vIHdhbnQgdG8gdXNlIGVucm9sbG1lbnQgZW1haWxzLlxuXG4vKipcbiAqIEBzdW1tYXJ5IFNlbmQgYW4gZW1haWwgd2l0aCBhIGxpbmsgdGhlIHVzZXIgY2FuIHVzZSB0byBzZXQgdGhlaXIgaW5pdGlhbCBwYXNzd29yZC5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7U3RyaW5nfSB1c2VySWQgVGhlIGlkIG9mIHRoZSB1c2VyIHRvIHNlbmQgZW1haWwgdG8uXG4gKiBAcGFyYW0ge1N0cmluZ30gW2VtYWlsXSBPcHRpb25hbC4gV2hpY2ggYWRkcmVzcyBvZiB0aGUgdXNlcidzIHRvIHNlbmQgdGhlIGVtYWlsIHRvLiBUaGlzIGFkZHJlc3MgbXVzdCBiZSBpbiB0aGUgdXNlcidzIGBlbWFpbHNgIGxpc3QuIERlZmF1bHRzIHRvIHRoZSBmaXJzdCBlbWFpbCBpbiB0aGUgbGlzdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbZXh0cmFUb2tlbkRhdGFdIE9wdGlvbmFsIGFkZGl0aW9uYWwgZGF0YSB0byBiZSBhZGRlZCBpbnRvIHRoZSB0b2tlbiByZWNvcmQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBPYmplY3Qgd2l0aCB7ZW1haWwsIHVzZXIsIHRva2VuLCB1cmwsIG9wdGlvbnN9IHZhbHVlcy5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnNlbmRFbnJvbGxtZW50RW1haWwgPSAodXNlcklkLCBlbWFpbCwgZXh0cmFUb2tlbkRhdGEpID0+IHtcbiAgY29uc3Qge2VtYWlsOiByZWFsRW1haWwsIHVzZXIsIHRva2VufSA9XG4gICAgQWNjb3VudHMuZ2VuZXJhdGVSZXNldFRva2VuKHVzZXJJZCwgZW1haWwsICdlbnJvbGxBY2NvdW50JywgZXh0cmFUb2tlbkRhdGEpO1xuICBjb25zdCB1cmwgPSBBY2NvdW50cy51cmxzLmVucm9sbEFjY291bnQodG9rZW4pO1xuICBjb25zdCBvcHRpb25zID0gQWNjb3VudHMuZ2VuZXJhdGVPcHRpb25zRm9yRW1haWwocmVhbEVtYWlsLCB1c2VyLCB1cmwsICdlbnJvbGxBY2NvdW50Jyk7XG4gIEVtYWlsLnNlbmQob3B0aW9ucyk7XG4gIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICAgIGNvbnNvbGUubG9nKGBcXG5FbnJvbGxtZW50IGVtYWlsIFVSTDogJHt1cmx9YCk7XG4gIH1cbiAgcmV0dXJuIHtlbWFpbDogcmVhbEVtYWlsLCB1c2VyLCB0b2tlbiwgdXJsLCBvcHRpb25zfTtcbn07XG5cblxuLy8gVGFrZSB0b2tlbiBmcm9tIHNlbmRSZXNldFBhc3N3b3JkRW1haWwgb3Igc2VuZEVucm9sbG1lbnRFbWFpbCwgY2hhbmdlXG4vLyB0aGUgdXNlcnMgcGFzc3dvcmQsIGFuZCBsb2cgdGhlbSBpbi5cbk1ldGVvci5tZXRob2RzKHtyZXNldFBhc3N3b3JkOiBmdW5jdGlvbiAoLi4uYXJncykge1xuICBjb25zdCB0b2tlbiA9IGFyZ3NbMF07XG4gIGNvbnN0IG5ld1Bhc3N3b3JkID0gYXJnc1sxXTtcbiAgcmV0dXJuIEFjY291bnRzLl9sb2dpbk1ldGhvZChcbiAgICB0aGlzLFxuICAgIFwicmVzZXRQYXNzd29yZFwiLFxuICAgIGFyZ3MsXG4gICAgXCJwYXNzd29yZFwiLFxuICAgICgpID0+IHtcbiAgICAgIGNoZWNrKHRva2VuLCBTdHJpbmcpO1xuICAgICAgY2hlY2sobmV3UGFzc3dvcmQsIHBhc3N3b3JkVmFsaWRhdG9yKTtcblxuICAgICAgY29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKFxuICAgICAgICB7XCJzZXJ2aWNlcy5wYXNzd29yZC5yZXNldC50b2tlblwiOiB0b2tlbn0sXG4gICAgICAgIHtmaWVsZHM6IHtcbiAgICAgICAgICBzZXJ2aWNlczogMSxcbiAgICAgICAgICBlbWFpbHM6IDEsXG4gICAgICAgIH19XG4gICAgICApO1xuICAgICAgaWYgKCF1c2VyKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlRva2VuIGV4cGlyZWRcIik7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHdoZW4sIHJlYXNvbiwgZW1haWwgfSA9IHVzZXIuc2VydmljZXMucGFzc3dvcmQucmVzZXQ7XG4gICAgICBsZXQgdG9rZW5MaWZldGltZU1zID0gQWNjb3VudHMuX2dldFBhc3N3b3JkUmVzZXRUb2tlbkxpZmV0aW1lTXMoKTtcbiAgICAgIGlmIChyZWFzb24gPT09IFwiZW5yb2xsXCIpIHtcbiAgICAgICAgdG9rZW5MaWZldGltZU1zID0gQWNjb3VudHMuX2dldFBhc3N3b3JkRW5yb2xsVG9rZW5MaWZldGltZU1zKCk7XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50VGltZU1zID0gRGF0ZS5ub3coKTtcbiAgICAgIGlmICgoY3VycmVudFRpbWVNcyAtIHdoZW4pID4gdG9rZW5MaWZldGltZU1zKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJUb2tlbiBleHBpcmVkXCIpO1xuICAgICAgaWYgKCEocGx1Y2tBZGRyZXNzZXModXNlci5lbWFpbHMpLmluY2x1ZGVzKGVtYWlsKSkpXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdXNlcklkOiB1c2VyLl9pZCxcbiAgICAgICAgICBlcnJvcjogbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiVG9rZW4gaGFzIGludmFsaWQgZW1haWwgYWRkcmVzc1wiKVxuICAgICAgICB9O1xuXG4gICAgICBjb25zdCBoYXNoZWQgPSBoYXNoUGFzc3dvcmQobmV3UGFzc3dvcmQpO1xuXG4gICAgICAvLyBOT1RFOiBXZSdyZSBhYm91dCB0byBpbnZhbGlkYXRlIHRva2VucyBvbiB0aGUgdXNlciwgd2hvIHdlIG1pZ2h0IGJlXG4gICAgICAvLyBsb2dnZWQgaW4gYXMuIE1ha2Ugc3VyZSB0byBhdm9pZCBsb2dnaW5nIG91cnNlbHZlcyBvdXQgaWYgdGhpc1xuICAgICAgLy8gaGFwcGVucy4gQnV0IGFsc28gbWFrZSBzdXJlIG5vdCB0byBsZWF2ZSB0aGUgY29ubmVjdGlvbiBpbiBhIHN0YXRlXG4gICAgICAvLyBvZiBoYXZpbmcgYSBiYWQgdG9rZW4gc2V0IGlmIHRoaW5ncyBmYWlsLlxuICAgICAgY29uc3Qgb2xkVG9rZW4gPSBBY2NvdW50cy5fZ2V0TG9naW5Ub2tlbih0aGlzLmNvbm5lY3Rpb24uaWQpO1xuICAgICAgQWNjb3VudHMuX3NldExvZ2luVG9rZW4odXNlci5faWQsIHRoaXMuY29ubmVjdGlvbiwgbnVsbCk7XG4gICAgICBjb25zdCByZXNldFRvT2xkVG9rZW4gPSAoKSA9PlxuICAgICAgICBBY2NvdW50cy5fc2V0TG9naW5Ub2tlbih1c2VyLl9pZCwgdGhpcy5jb25uZWN0aW9uLCBvbGRUb2tlbik7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIFVwZGF0ZSB0aGUgdXNlciByZWNvcmQgYnk6XG4gICAgICAgIC8vIC0gQ2hhbmdpbmcgdGhlIHBhc3N3b3JkIHRvIHRoZSBuZXcgb25lXG4gICAgICAgIC8vIC0gRm9yZ2V0dGluZyBhYm91dCB0aGUgcmVzZXQgdG9rZW4gdGhhdCB3YXMganVzdCB1c2VkXG4gICAgICAgIC8vIC0gVmVyaWZ5aW5nIHRoZWlyIGVtYWlsLCBzaW5jZSB0aGV5IGdvdCB0aGUgcGFzc3dvcmQgcmVzZXQgdmlhIGVtYWlsLlxuICAgICAgICBjb25zdCBhZmZlY3RlZFJlY29yZHMgPSBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIF9pZDogdXNlci5faWQsXG4gICAgICAgICAgICAnZW1haWxzLmFkZHJlc3MnOiBlbWFpbCxcbiAgICAgICAgICAgICdzZXJ2aWNlcy5wYXNzd29yZC5yZXNldC50b2tlbic6IHRva2VuXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7JHNldDogeydzZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQnOiBoYXNoZWQsXG4gICAgICAgICAgICAgICAgICAnZW1haWxzLiQudmVyaWZpZWQnOiB0cnVlfSxcbiAgICAgICAgICAgJHVuc2V0OiB7J3NlcnZpY2VzLnBhc3N3b3JkLnJlc2V0JzogMSxcbiAgICAgICAgICAgICAgICAgICAgJ3NlcnZpY2VzLnBhc3N3b3JkLnNycCc6IDF9fSk7XG4gICAgICAgIGlmIChhZmZlY3RlZFJlY29yZHMgIT09IDEpXG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVzZXJJZDogdXNlci5faWQsXG4gICAgICAgICAgICBlcnJvcjogbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiSW52YWxpZCBlbWFpbFwiKVxuICAgICAgICAgIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVzZXRUb09sZFRva2VuKCk7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cblxuICAgICAgLy8gUmVwbGFjZSBhbGwgdmFsaWQgbG9naW4gdG9rZW5zIHdpdGggbmV3IG9uZXMgKGNoYW5naW5nXG4gICAgICAvLyBwYXNzd29yZCBzaG91bGQgaW52YWxpZGF0ZSBleGlzdGluZyBzZXNzaW9ucykuXG4gICAgICBBY2NvdW50cy5fY2xlYXJBbGxMb2dpblRva2Vucyh1c2VyLl9pZCk7XG5cbiAgICAgIHJldHVybiB7dXNlcklkOiB1c2VyLl9pZH07XG4gICAgfVxuICApO1xufX0pO1xuXG4vLy9cbi8vLyBFTUFJTCBWRVJJRklDQVRJT05cbi8vL1xuXG5cbi8vIHNlbmQgdGhlIHVzZXIgYW4gZW1haWwgd2l0aCBhIGxpbmsgdGhhdCB3aGVuIG9wZW5lZCBtYXJrcyB0aGF0XG4vLyBhZGRyZXNzIGFzIHZlcmlmaWVkXG5cbi8qKlxuICogQHN1bW1hcnkgU2VuZCBhbiBlbWFpbCB3aXRoIGEgbGluayB0aGUgdXNlciBjYW4gdXNlIHZlcmlmeSB0aGVpciBlbWFpbCBhZGRyZXNzLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgaWQgb2YgdGhlIHVzZXIgdG8gc2VuZCBlbWFpbCB0by5cbiAqIEBwYXJhbSB7U3RyaW5nfSBbZW1haWxdIE9wdGlvbmFsLiBXaGljaCBhZGRyZXNzIG9mIHRoZSB1c2VyJ3MgdG8gc2VuZCB0aGUgZW1haWwgdG8uIFRoaXMgYWRkcmVzcyBtdXN0IGJlIGluIHRoZSB1c2VyJ3MgYGVtYWlsc2AgbGlzdC4gRGVmYXVsdHMgdG8gdGhlIGZpcnN0IHVudmVyaWZpZWQgZW1haWwgaW4gdGhlIGxpc3QuXG4gKiBAcGFyYW0ge09iamVjdH0gW2V4dHJhVG9rZW5EYXRhXSBPcHRpb25hbCBhZGRpdGlvbmFsIGRhdGEgdG8gYmUgYWRkZWQgaW50byB0aGUgdG9rZW4gcmVjb3JkLlxuICogQHJldHVybnMge09iamVjdH0gT2JqZWN0IHdpdGgge2VtYWlsLCB1c2VyLCB0b2tlbiwgdXJsLCBvcHRpb25zfSB2YWx1ZXMuXG4gKiBAaW1wb3J0RnJvbVBhY2thZ2UgYWNjb3VudHMtYmFzZVxuICovXG5BY2NvdW50cy5zZW5kVmVyaWZpY2F0aW9uRW1haWwgPSAodXNlcklkLCBlbWFpbCwgZXh0cmFUb2tlbkRhdGEpID0+IHtcbiAgLy8gWFhYIEFsc28gZ2VuZXJhdGUgYSBsaW5rIHVzaW5nIHdoaWNoIHNvbWVvbmUgY2FuIGRlbGV0ZSB0aGlzXG4gIC8vIGFjY291bnQgaWYgdGhleSBvd24gc2FpZCBhZGRyZXNzIGJ1dCB3ZXJlbid0IHRob3NlIHdobyBjcmVhdGVkXG4gIC8vIHRoaXMgYWNjb3VudC5cblxuICBjb25zdCB7ZW1haWw6IHJlYWxFbWFpbCwgdXNlciwgdG9rZW59ID1cbiAgICBBY2NvdW50cy5nZW5lcmF0ZVZlcmlmaWNhdGlvblRva2VuKHVzZXJJZCwgZW1haWwsIGV4dHJhVG9rZW5EYXRhKTtcbiAgY29uc3QgdXJsID0gQWNjb3VudHMudXJscy52ZXJpZnlFbWFpbCh0b2tlbik7XG4gIGNvbnN0IG9wdGlvbnMgPSBBY2NvdW50cy5nZW5lcmF0ZU9wdGlvbnNGb3JFbWFpbChyZWFsRW1haWwsIHVzZXIsIHVybCwgJ3ZlcmlmeUVtYWlsJyk7XG4gIEVtYWlsLnNlbmQob3B0aW9ucyk7XG4gIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICAgIGNvbnNvbGUubG9nKGBcXG5WZXJpZmljYXRpb24gZW1haWwgVVJMOiAke3VybH1gKTtcbiAgfVxuICByZXR1cm4ge2VtYWlsOiByZWFsRW1haWwsIHVzZXIsIHRva2VuLCB1cmwsIG9wdGlvbnN9O1xufTtcblxuLy8gVGFrZSB0b2tlbiBmcm9tIHNlbmRWZXJpZmljYXRpb25FbWFpbCwgbWFyayB0aGUgZW1haWwgYXMgdmVyaWZpZWQsXG4vLyBhbmQgbG9nIHRoZW0gaW4uXG5NZXRlb3IubWV0aG9kcyh7dmVyaWZ5RW1haWw6IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gIGNvbnN0IHRva2VuID0gYXJnc1swXTtcbiAgcmV0dXJuIEFjY291bnRzLl9sb2dpbk1ldGhvZChcbiAgICB0aGlzLFxuICAgIFwidmVyaWZ5RW1haWxcIixcbiAgICBhcmdzLFxuICAgIFwicGFzc3dvcmRcIixcbiAgICAoKSA9PiB7XG4gICAgICBjaGVjayh0b2tlbiwgU3RyaW5nKTtcblxuICAgICAgY29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKFxuICAgICAgICB7J3NlcnZpY2VzLmVtYWlsLnZlcmlmaWNhdGlvblRva2Vucy50b2tlbic6IHRva2VufSxcbiAgICAgICAge2ZpZWxkczoge1xuICAgICAgICAgIHNlcnZpY2VzOiAxLFxuICAgICAgICAgIGVtYWlsczogMSxcbiAgICAgICAgfX1cbiAgICAgICk7XG4gICAgICBpZiAoIXVzZXIpXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlZlcmlmeSBlbWFpbCBsaW5rIGV4cGlyZWRcIik7XG5cbiAgICAgICAgY29uc3QgdG9rZW5SZWNvcmQgPSB1c2VyLnNlcnZpY2VzLmVtYWlsLnZlcmlmaWNhdGlvblRva2Vucy5maW5kKFxuICAgICAgICAgIHQgPT4gdC50b2tlbiA9PSB0b2tlblxuICAgICAgICApO1xuICAgICAgaWYgKCF0b2tlblJlY29yZClcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB1c2VySWQ6IHVzZXIuX2lkLFxuICAgICAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJWZXJpZnkgZW1haWwgbGluayBleHBpcmVkXCIpXG4gICAgICAgIH07XG5cbiAgICAgIGNvbnN0IGVtYWlsc1JlY29yZCA9IHVzZXIuZW1haWxzLmZpbmQoXG4gICAgICAgIGUgPT4gZS5hZGRyZXNzID09IHRva2VuUmVjb3JkLmFkZHJlc3NcbiAgICAgICk7XG4gICAgICBpZiAoIWVtYWlsc1JlY29yZClcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB1c2VySWQ6IHVzZXIuX2lkLFxuICAgICAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJWZXJpZnkgZW1haWwgbGluayBpcyBmb3IgdW5rbm93biBhZGRyZXNzXCIpXG4gICAgICAgIH07XG5cbiAgICAgIC8vIEJ5IGluY2x1ZGluZyB0aGUgYWRkcmVzcyBpbiB0aGUgcXVlcnksIHdlIGNhbiB1c2UgJ2VtYWlscy4kJyBpbiB0aGVcbiAgICAgIC8vIG1vZGlmaWVyIHRvIGdldCBhIHJlZmVyZW5jZSB0byB0aGUgc3BlY2lmaWMgb2JqZWN0IGluIHRoZSBlbWFpbHNcbiAgICAgIC8vIGFycmF5LiBTZWVcbiAgICAgIC8vIGh0dHA6Ly93d3cubW9uZ29kYi5vcmcvZGlzcGxheS9ET0NTL1VwZGF0aW5nLyNVcGRhdGluZy1UaGUlMjRwb3NpdGlvbmFsb3BlcmF0b3IpXG4gICAgICAvLyBodHRwOi8vd3d3Lm1vbmdvZGIub3JnL2Rpc3BsYXkvRE9DUy9VcGRhdGluZyNVcGRhdGluZy0lMjRwdWxsXG4gICAgICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICB7X2lkOiB1c2VyLl9pZCxcbiAgICAgICAgICdlbWFpbHMuYWRkcmVzcyc6IHRva2VuUmVjb3JkLmFkZHJlc3N9LFxuICAgICAgICB7JHNldDogeydlbWFpbHMuJC52ZXJpZmllZCc6IHRydWV9LFxuICAgICAgICAgJHB1bGw6IHsnc2VydmljZXMuZW1haWwudmVyaWZpY2F0aW9uVG9rZW5zJzoge2FkZHJlc3M6IHRva2VuUmVjb3JkLmFkZHJlc3N9fX0pO1xuXG4gICAgICByZXR1cm4ge3VzZXJJZDogdXNlci5faWR9O1xuICAgIH1cbiAgKTtcbn19KTtcblxuLyoqXG4gKiBAc3VtbWFyeSBBZGQgYW4gZW1haWwgYWRkcmVzcyBmb3IgYSB1c2VyLiBVc2UgdGhpcyBpbnN0ZWFkIG9mIGRpcmVjdGx5XG4gKiB1cGRhdGluZyB0aGUgZGF0YWJhc2UuIFRoZSBvcGVyYXRpb24gd2lsbCBmYWlsIGlmIHRoZXJlIGlzIGEgZGlmZmVyZW50IHVzZXJcbiAqIHdpdGggYW4gZW1haWwgb25seSBkaWZmZXJpbmcgaW4gY2FzZS4gSWYgdGhlIHNwZWNpZmllZCB1c2VyIGhhcyBhbiBleGlzdGluZ1xuICogZW1haWwgb25seSBkaWZmZXJpbmcgaW4gY2FzZSBob3dldmVyLCB3ZSByZXBsYWNlIGl0LlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgSUQgb2YgdGhlIHVzZXIgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IG5ld0VtYWlsIEEgbmV3IGVtYWlsIGFkZHJlc3MgZm9yIHRoZSB1c2VyLlxuICogQHBhcmFtIHtCb29sZWFufSBbdmVyaWZpZWRdIE9wdGlvbmFsIC0gd2hldGhlciB0aGUgbmV3IGVtYWlsIGFkZHJlc3Mgc2hvdWxkXG4gKiBiZSBtYXJrZWQgYXMgdmVyaWZpZWQuIERlZmF1bHRzIHRvIGZhbHNlLlxuICogQGltcG9ydEZyb21QYWNrYWdlIGFjY291bnRzLWJhc2VcbiAqL1xuQWNjb3VudHMuYWRkRW1haWwgPSAodXNlcklkLCBuZXdFbWFpbCwgdmVyaWZpZWQpID0+IHtcbiAgY2hlY2sodXNlcklkLCBOb25FbXB0eVN0cmluZyk7XG4gIGNoZWNrKG5ld0VtYWlsLCBOb25FbXB0eVN0cmluZyk7XG4gIGNoZWNrKHZlcmlmaWVkLCBNYXRjaC5PcHRpb25hbChCb29sZWFuKSk7XG5cbiAgaWYgKHZlcmlmaWVkID09PSB2b2lkIDApIHtcbiAgICB2ZXJpZmllZCA9IGZhbHNlO1xuICB9XG5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHVzZXJJZCwge2ZpZWxkczoge2VtYWlsczogMX19KTtcbiAgaWYgKCF1c2VyKVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlVzZXIgbm90IGZvdW5kXCIpO1xuXG4gIC8vIEFsbG93IHVzZXJzIHRvIGNoYW5nZSB0aGVpciBvd24gZW1haWwgdG8gYSB2ZXJzaW9uIHdpdGggYSBkaWZmZXJlbnQgY2FzZVxuXG4gIC8vIFdlIGRvbid0IGhhdmUgdG8gY2FsbCBjaGVja0ZvckNhc2VJbnNlbnNpdGl2ZUR1cGxpY2F0ZXMgdG8gZG8gYSBjYXNlXG4gIC8vIGluc2Vuc2l0aXZlIGNoZWNrIGFjcm9zcyBhbGwgZW1haWxzIGluIHRoZSBkYXRhYmFzZSBoZXJlIGJlY2F1c2U6ICgxKSBpZlxuICAvLyB0aGVyZSBpcyBubyBjYXNlLWluc2Vuc2l0aXZlIGR1cGxpY2F0ZSBiZXR3ZWVuIHRoaXMgdXNlciBhbmQgb3RoZXIgdXNlcnMsXG4gIC8vIHRoZW4gd2UgYXJlIE9LIGFuZCAoMikgaWYgdGhpcyB3b3VsZCBjcmVhdGUgYSBjb25mbGljdCB3aXRoIG90aGVyIHVzZXJzXG4gIC8vIHRoZW4gdGhlcmUgd291bGQgYWxyZWFkeSBiZSBhIGNhc2UtaW5zZW5zaXRpdmUgZHVwbGljYXRlIGFuZCB3ZSBjYW4ndCBmaXhcbiAgLy8gdGhhdCBpbiB0aGlzIGNvZGUgYW55d2F5LlxuICBjb25zdCBjYXNlSW5zZW5zaXRpdmVSZWdFeHAgPVxuICAgIG5ldyBSZWdFeHAoYF4ke01ldGVvci5fZXNjYXBlUmVnRXhwKG5ld0VtYWlsKX0kYCwgJ2knKTtcblxuICBjb25zdCBkaWRVcGRhdGVPd25FbWFpbCA9ICh1c2VyLmVtYWlscyB8fCBbXSkucmVkdWNlKFxuICAgIChwcmV2LCBlbWFpbCkgPT4ge1xuICAgICAgaWYgKGNhc2VJbnNlbnNpdGl2ZVJlZ0V4cC50ZXN0KGVtYWlsLmFkZHJlc3MpKSB7XG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoe1xuICAgICAgICAgIF9pZDogdXNlci5faWQsXG4gICAgICAgICAgJ2VtYWlscy5hZGRyZXNzJzogZW1haWwuYWRkcmVzc1xuICAgICAgICB9LCB7JHNldDoge1xuICAgICAgICAgICdlbWFpbHMuJC5hZGRyZXNzJzogbmV3RW1haWwsXG4gICAgICAgICAgJ2VtYWlscy4kLnZlcmlmaWVkJzogdmVyaWZpZWRcbiAgICAgICAgfX0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBwcmV2O1xuICAgICAgfVxuICAgIH0sXG4gICAgZmFsc2VcbiAgKTtcblxuICAvLyBJbiB0aGUgb3RoZXIgdXBkYXRlcyBiZWxvdywgd2UgaGF2ZSB0byBkbyBhbm90aGVyIGNhbGwgdG9cbiAgLy8gY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzIHRvIG1ha2Ugc3VyZSB0aGF0IG5vIGNvbmZsaWN0aW5nIHZhbHVlc1xuICAvLyB3ZXJlIGFkZGVkIHRvIHRoZSBkYXRhYmFzZSBpbiB0aGUgbWVhbnRpbWUuIFdlIGRvbid0IGhhdmUgdG8gZG8gdGhpcyBmb3JcbiAgLy8gdGhlIGNhc2Ugd2hlcmUgdGhlIHVzZXIgaXMgdXBkYXRpbmcgdGhlaXIgZW1haWwgYWRkcmVzcyB0byBvbmUgdGhhdCBpcyB0aGVcbiAgLy8gc2FtZSBhcyBiZWZvcmUsIGJ1dCBvbmx5IGRpZmZlcmVudCBiZWNhdXNlIG9mIGNhcGl0YWxpemF0aW9uLiBSZWFkIHRoZVxuICAvLyBiaWcgY29tbWVudCBhYm92ZSB0byB1bmRlcnN0YW5kIHdoeS5cblxuICBpZiAoZGlkVXBkYXRlT3duRW1haWwpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBQZXJmb3JtIGEgY2FzZSBpbnNlbnNpdGl2ZSBjaGVjayBmb3IgZHVwbGljYXRlcyBiZWZvcmUgdXBkYXRlXG4gIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygnZW1haWxzLmFkZHJlc3MnLCAnRW1haWwnLCBuZXdFbWFpbCwgdXNlci5faWQpO1xuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe1xuICAgIF9pZDogdXNlci5faWRcbiAgfSwge1xuICAgICRhZGRUb1NldDoge1xuICAgICAgZW1haWxzOiB7XG4gICAgICAgIGFkZHJlc3M6IG5ld0VtYWlsLFxuICAgICAgICB2ZXJpZmllZDogdmVyaWZpZWRcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gIC8vIFBlcmZvcm0gYW5vdGhlciBjaGVjayBhZnRlciB1cGRhdGUsIGluIGNhc2UgYSBtYXRjaGluZyB1c2VyIGhhcyBiZWVuXG4gIC8vIGluc2VydGVkIGluIHRoZSBtZWFudGltZVxuICB0cnkge1xuICAgIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygnZW1haWxzLmFkZHJlc3MnLCAnRW1haWwnLCBuZXdFbWFpbCwgdXNlci5faWQpO1xuICB9IGNhdGNoIChleCkge1xuICAgIC8vIFVuZG8gdXBkYXRlIGlmIHRoZSBjaGVjayBmYWlsc1xuICAgIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LFxuICAgICAgeyRwdWxsOiB7ZW1haWxzOiB7YWRkcmVzczogbmV3RW1haWx9fX0pO1xuICAgIHRocm93IGV4O1xuICB9XG59XG5cbi8qKlxuICogQHN1bW1hcnkgUmVtb3ZlIGFuIGVtYWlsIGFkZHJlc3MgZm9yIGEgdXNlci4gVXNlIHRoaXMgaW5zdGVhZCBvZiB1cGRhdGluZ1xuICogdGhlIGRhdGFiYXNlIGRpcmVjdGx5LlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgSUQgb2YgdGhlIHVzZXIgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IGVtYWlsIFRoZSBlbWFpbCBhZGRyZXNzIHRvIHJlbW92ZS5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnJlbW92ZUVtYWlsID0gKHVzZXJJZCwgZW1haWwpID0+IHtcbiAgY2hlY2sodXNlcklkLCBOb25FbXB0eVN0cmluZyk7XG4gIGNoZWNrKGVtYWlsLCBOb25FbXB0eVN0cmluZyk7XG5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHVzZXJJZCwge2ZpZWxkczoge19pZDogMX19KTtcbiAgaWYgKCF1c2VyKVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlVzZXIgbm90IGZvdW5kXCIpO1xuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LFxuICAgIHskcHVsbDoge2VtYWlsczoge2FkZHJlc3M6IGVtYWlsfX19KTtcbn1cblxuLy8vXG4vLy8gQ1JFQVRJTkcgVVNFUlNcbi8vL1xuXG4vLyBTaGFyZWQgY3JlYXRlVXNlciBmdW5jdGlvbiBjYWxsZWQgZnJvbSB0aGUgY3JlYXRlVXNlciBtZXRob2QsIGJvdGhcbi8vIGlmIG9yaWdpbmF0ZXMgaW4gY2xpZW50IG9yIHNlcnZlciBjb2RlLiBDYWxscyB1c2VyIHByb3ZpZGVkIGhvb2tzLFxuLy8gZG9lcyB0aGUgYWN0dWFsIHVzZXIgaW5zZXJ0aW9uLlxuLy9cbi8vIHJldHVybnMgdGhlIHVzZXIgaWRcbmNvbnN0IGNyZWF0ZVVzZXIgPSBvcHRpb25zID0+IHtcbiAgLy8gVW5rbm93biBrZXlzIGFsbG93ZWQsIGJlY2F1c2UgYSBvbkNyZWF0ZVVzZXJIb29rIGNhbiB0YWtlIGFyYml0cmFyeVxuICAvLyBvcHRpb25zLlxuICBjaGVjayhvcHRpb25zLCBNYXRjaC5PYmplY3RJbmNsdWRpbmcoe1xuICAgIHVzZXJuYW1lOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIGVtYWlsOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIHBhc3N3b3JkOiBNYXRjaC5PcHRpb25hbChwYXNzd29yZFZhbGlkYXRvcilcbiAgfSkpO1xuXG4gIGNvbnN0IHsgdXNlcm5hbWUsIGVtYWlsLCBwYXNzd29yZCB9ID0gb3B0aW9ucztcbiAgaWYgKCF1c2VybmFtZSAmJiAhZW1haWwpXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsIFwiTmVlZCB0byBzZXQgYSB1c2VybmFtZSBvciBlbWFpbFwiKTtcblxuICBjb25zdCB1c2VyID0ge3NlcnZpY2VzOiB7fX07XG4gIGlmIChwYXNzd29yZCkge1xuICAgIGNvbnN0IGhhc2hlZCA9IGhhc2hQYXNzd29yZChwYXNzd29yZCk7XG4gICAgdXNlci5zZXJ2aWNlcy5wYXNzd29yZCA9IHsgYmNyeXB0OiBoYXNoZWQgfTtcbiAgfVxuXG4gIGlmICh1c2VybmFtZSlcbiAgICB1c2VyLnVzZXJuYW1lID0gdXNlcm5hbWU7XG4gIGlmIChlbWFpbClcbiAgICB1c2VyLmVtYWlscyA9IFt7YWRkcmVzczogZW1haWwsIHZlcmlmaWVkOiBmYWxzZX1dO1xuXG4gIC8vIFBlcmZvcm0gYSBjYXNlIGluc2Vuc2l0aXZlIGNoZWNrIGJlZm9yZSBpbnNlcnRcbiAgY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzKCd1c2VybmFtZScsICdVc2VybmFtZScsIHVzZXJuYW1lKTtcbiAgY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzKCdlbWFpbHMuYWRkcmVzcycsICdFbWFpbCcsIGVtYWlsKTtcblxuICBjb25zdCB1c2VySWQgPSBBY2NvdW50cy5pbnNlcnRVc2VyRG9jKG9wdGlvbnMsIHVzZXIpO1xuICAvLyBQZXJmb3JtIGFub3RoZXIgY2hlY2sgYWZ0ZXIgaW5zZXJ0LCBpbiBjYXNlIGEgbWF0Y2hpbmcgdXNlciBoYXMgYmVlblxuICAvLyBpbnNlcnRlZCBpbiB0aGUgbWVhbnRpbWVcbiAgdHJ5IHtcbiAgICBjaGVja0ZvckNhc2VJbnNlbnNpdGl2ZUR1cGxpY2F0ZXMoJ3VzZXJuYW1lJywgJ1VzZXJuYW1lJywgdXNlcm5hbWUsIHVzZXJJZCk7XG4gICAgY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzKCdlbWFpbHMuYWRkcmVzcycsICdFbWFpbCcsIGVtYWlsLCB1c2VySWQpO1xuICB9IGNhdGNoIChleCkge1xuICAgIC8vIFJlbW92ZSBpbnNlcnRlZCB1c2VyIGlmIHRoZSBjaGVjayBmYWlsc1xuICAgIE1ldGVvci51c2Vycy5yZW1vdmUodXNlcklkKTtcbiAgICB0aHJvdyBleDtcbiAgfVxuICByZXR1cm4gdXNlcklkO1xufTtcblxuLy8gbWV0aG9kIGZvciBjcmVhdGUgdXNlci4gUmVxdWVzdHMgY29tZSBmcm9tIHRoZSBjbGllbnQuXG5NZXRlb3IubWV0aG9kcyh7Y3JlYXRlVXNlcjogZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgY29uc3Qgb3B0aW9ucyA9IGFyZ3NbMF07XG4gIHJldHVybiBBY2NvdW50cy5fbG9naW5NZXRob2QoXG4gICAgdGhpcyxcbiAgICBcImNyZWF0ZVVzZXJcIixcbiAgICBhcmdzLFxuICAgIFwicGFzc3dvcmRcIixcbiAgICAoKSA9PiB7XG4gICAgICAvLyBjcmVhdGVVc2VyKCkgYWJvdmUgZG9lcyBtb3JlIGNoZWNraW5nLlxuICAgICAgY2hlY2sob3B0aW9ucywgT2JqZWN0KTtcbiAgICAgIGlmIChBY2NvdW50cy5fb3B0aW9ucy5mb3JiaWRDbGllbnRBY2NvdW50Q3JlYXRpb24pXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZXJyb3I6IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlNpZ251cHMgZm9yYmlkZGVuXCIpXG4gICAgICAgIH07XG5cbiAgICAgIGNvbnN0IHVzZXJJZCA9IEFjY291bnRzLmNyZWF0ZVVzZXJWZXJpZnlpbmdFbWFpbChvcHRpb25zKTtcblxuICAgICAgLy8gY2xpZW50IGdldHMgbG9nZ2VkIGluIGFzIHRoZSBuZXcgdXNlciBhZnRlcndhcmRzLlxuICAgICAgcmV0dXJuIHt1c2VySWQ6IHVzZXJJZH07XG4gICAgfVxuICApO1xufX0pO1xuXG4vLyBDcmVhdGUgdXNlciBkaXJlY3RseSBvbiB0aGUgc2VydmVyLlxuLy9cbi8vIERpZmZlcmVudGx5IGZyb20gQWNjb3VudHMuY3JlYXRlVXNlcigpLCB0aGlzIGV2YWx1YXRlcyB0aGUgQWNjb3VudHMgcGFja2FnZVxuLy8gY29uZmlndXJhdGlvbnMgYW5kIHNlbmQgYSB2ZXJpZmljYXRpb24gZW1haWwgaWYgdGhlIHVzZXIgaGFzIGJlZW4gcmVnaXN0ZXJlZFxuLy8gc3VjY2Vzc2Z1bGx5LlxuQWNjb3VudHMuY3JlYXRlVXNlclZlcmlmeWluZ0VtYWlsID0gKG9wdGlvbnMpID0+IHtcbiAgb3B0aW9ucyA9IHsgLi4ub3B0aW9ucyB9O1xuICAvLyBDcmVhdGUgdXNlci4gcmVzdWx0IGNvbnRhaW5zIGlkIGFuZCB0b2tlbi5cbiAgY29uc3QgdXNlcklkID0gY3JlYXRlVXNlcihvcHRpb25zKTtcbiAgLy8gc2FmZXR5IGJlbHQuIGNyZWF0ZVVzZXIgaXMgc3VwcG9zZWQgdG8gdGhyb3cgb24gZXJyb3IuIHNlbmQgNTAwIGVycm9yXG4gIC8vIGluc3RlYWQgb2Ygc2VuZGluZyBhIHZlcmlmaWNhdGlvbiBlbWFpbCB3aXRoIGVtcHR5IHVzZXJpZC5cbiAgaWYgKCEgdXNlcklkKVxuICAgIHRocm93IG5ldyBFcnJvcihcImNyZWF0ZVVzZXIgZmFpbGVkIHRvIGluc2VydCBuZXcgdXNlclwiKTtcblxuICAvLyBJZiBgQWNjb3VudHMuX29wdGlvbnMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsYCBpcyBzZXQsIHJlZ2lzdGVyXG4gIC8vIGEgdG9rZW4gdG8gdmVyaWZ5IHRoZSB1c2VyJ3MgcHJpbWFyeSBlbWFpbCwgYW5kIHNlbmQgaXQgdG9cbiAgLy8gdGhhdCBhZGRyZXNzLlxuICBpZiAob3B0aW9ucy5lbWFpbCAmJiBBY2NvdW50cy5fb3B0aW9ucy5zZW5kVmVyaWZpY2F0aW9uRW1haWwpIHtcbiAgICBpZiAob3B0aW9ucy5wYXNzd29yZCkge1xuICAgICAgQWNjb3VudHMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsKHVzZXJJZCwgb3B0aW9ucy5lbWFpbCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIEFjY291bnRzLnNlbmRFbnJvbGxtZW50RW1haWwodXNlcklkLCBvcHRpb25zLmVtYWlsKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdXNlcklkO1xufTtcblxuLy8gQ3JlYXRlIHVzZXIgZGlyZWN0bHkgb24gdGhlIHNlcnZlci5cbi8vXG4vLyBVbmxpa2UgdGhlIGNsaWVudCB2ZXJzaW9uLCB0aGlzIGRvZXMgbm90IGxvZyB5b3UgaW4gYXMgdGhpcyB1c2VyXG4vLyBhZnRlciBjcmVhdGlvbi5cbi8vXG4vLyByZXR1cm5zIHVzZXJJZCBvciB0aHJvd3MgYW4gZXJyb3IgaWYgaXQgY2FuJ3QgY3JlYXRlXG4vL1xuLy8gWFhYIGFkZCBhbm90aGVyIGFyZ3VtZW50IChcInNlcnZlciBvcHRpb25zXCIpIHRoYXQgZ2V0cyBzZW50IHRvIG9uQ3JlYXRlVXNlcixcbi8vIHdoaWNoIGlzIGFsd2F5cyBlbXB0eSB3aGVuIGNhbGxlZCBmcm9tIHRoZSBjcmVhdGVVc2VyIG1ldGhvZD8gZWcsIFwiYWRtaW46XG4vLyB0cnVlXCIsIHdoaWNoIHdlIHdhbnQgdG8gcHJldmVudCB0aGUgY2xpZW50IGZyb20gc2V0dGluZywgYnV0IHdoaWNoIGEgY3VzdG9tXG4vLyBtZXRob2QgY2FsbGluZyBBY2NvdW50cy5jcmVhdGVVc2VyIGNvdWxkIHNldD9cbi8vXG5BY2NvdW50cy5jcmVhdGVVc2VyID0gKG9wdGlvbnMsIGNhbGxiYWNrKSA9PiB7XG4gIG9wdGlvbnMgPSB7IC4uLm9wdGlvbnMgfTtcblxuICAvLyBYWFggYWxsb3cgYW4gb3B0aW9uYWwgY2FsbGJhY2s/XG4gIGlmIChjYWxsYmFjaykge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkFjY291bnRzLmNyZWF0ZVVzZXIgd2l0aCBjYWxsYmFjayBub3Qgc3VwcG9ydGVkIG9uIHRoZSBzZXJ2ZXIgeWV0LlwiKTtcbiAgfVxuXG4gIHJldHVybiBjcmVhdGVVc2VyKG9wdGlvbnMpO1xufTtcblxuLy8vXG4vLy8gUEFTU1dPUkQtU1BFQ0lGSUMgSU5ERVhFUyBPTiBVU0VSU1xuLy8vXG5NZXRlb3IudXNlcnMuX2Vuc3VyZUluZGV4KCdzZXJ2aWNlcy5lbWFpbC52ZXJpZmljYXRpb25Ub2tlbnMudG9rZW4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IHVuaXF1ZTogdHJ1ZSwgc3BhcnNlOiB0cnVlIH0pO1xuTWV0ZW9yLnVzZXJzLl9lbnN1cmVJbmRleCgnc2VydmljZXMucGFzc3dvcmQucmVzZXQudG9rZW4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IHVuaXF1ZTogdHJ1ZSwgc3BhcnNlOiB0cnVlIH0pO1xuIl19
