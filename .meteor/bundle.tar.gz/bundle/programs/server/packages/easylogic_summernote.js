(function () {



/* Exports */
Package._define("easylogic:summernote");

})();
