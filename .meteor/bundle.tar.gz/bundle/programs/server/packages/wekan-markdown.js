(function () {

/* Package-scope variables */
var Markdown;



/* Exports */
Package._define("wekan-markdown", {
  Markdown: Markdown
});

})();
