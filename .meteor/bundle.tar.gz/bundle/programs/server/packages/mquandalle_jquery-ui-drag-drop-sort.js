(function () {



/* Exports */
Package._define("mquandalle:jquery-ui-drag-drop-sort");

})();
