(function () {



/* Exports */
Package._define("templates:tabs");

})();
