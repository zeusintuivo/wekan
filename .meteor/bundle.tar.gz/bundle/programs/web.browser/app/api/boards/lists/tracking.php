
- - - - - - - - - - - - - - - - - Tracked on: 2020-12-24 01:20:50;
- - - _HEADERS's: 
Upgrade-Insecure-Requests: 1
Cookie: meteor_login_token=_x1QK0RjNg9Gl8ezC_lvy940KmdYfJK9fYi8uljnKai
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.5
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
User-Agent: Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0
Host: wekan.test
Content-Length: 
Content-Type: 
- - - _INPUT's: 
- - - _GET's: 
board: 7NWGtHpi4xWBfWuT3;
authToken: _x1QK0RjNg9Gl8ezC_lvy940KmdYfJK9fYi8uljnKai;
- - - _POST's: 
- - - _SERVER's: 
USER: zeus;
HOME: /home/zeus;
HTTP_UPGRADE_INSECURE_REQUESTS: 1;
HTTP_COOKIE: meteor_login_token=_x1QK0RjNg9Gl8ezC_lvy940KmdYfJK9fYi8uljnKai;
HTTP_CONNECTION: keep-alive;
HTTP_ACCEPT_ENCODING: gzip, deflate;
HTTP_ACCEPT_LANGUAGE: en-US,en;q=0.5;
HTTP_ACCEPT: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8;
HTTP_USER_AGENT: Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0;
HTTP_HOST: wekan.test;
REDIRECT_STATUS: 200;
SERVER_NAME: wekan.test;
SERVER_PORT: 80;
SERVER_ADDR: 127.0.0.1;
REMOTE_PORT: 49200;
REMOTE_ADDR: 127.0.0.1;
SERVER_SOFTWARE: nginx/1.18.0;
GATEWAY_INTERFACE: CGI/1.1;
REQUEST_SCHEME: http;
SERVER_PROTOCOL: HTTP/1.1;
DOCUMENT_ROOT: /home/zeus/.valet/Sites/wekan;
DOCUMENT_URI: /api/boards/lists/track.php;
REQUEST_URI: /api/boards/lists/track.php?board=7NWGtHpi4xWBfWuT3&authToken=_x1QK0RjNg9Gl8ezC_lvy940KmdYfJK9fYi8uljnKai;
SCRIPT_NAME: /api/boards/lists/track.php;
SCRIPT_FILENAME: /home/zeus/.valet/Sites/wekan/api/boards/lists/track.php;
CONTENT_LENGTH: ;
CONTENT_TYPE: ;
REQUEST_METHOD: GET;
QUERY_STRING: board=7NWGtHpi4xWBfWuT3&authToken=_x1QK0RjNg9Gl8ezC_lvy940KmdYfJK9fYi8uljnKai;
FCGI_ROLE: RESPONDER;
PHP_SELF: /api/boards/lists/track.php;
REQUEST_TIME_FLOAT: 1608772850.8717;
REQUEST_TIME: 1608772850;
- - - _REQUEST's: 
board: 7NWGtHpi4xWBfWuT3;
authToken: _x1QK0RjNg9Gl8ezC_lvy940KmdYfJK9fYi8uljnKai;
