self.addEventListener('install', function(event) {
  // Dummy service worker that does nothing,
  // for mobile browsers "Add to home screen".
});
