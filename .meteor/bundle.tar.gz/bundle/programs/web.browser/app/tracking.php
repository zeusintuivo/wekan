
- - - - - - - - - - - - - - - - - Tracked on: 2020-12-24 01:55:42;
- - - _INPUT's: 
- - - _GET's: 
- - - _POST's: 
- - - _SERVER's: 
USER: zeus;
HOME: /home/zeus;
HTTP_UPGRADE_INSECURE_REQUESTS: 1;
HTTP_COOKIE: meteor_login_token=YGA83n6HiOmjEf5r-uW5YAX5kHKEJkNWifW1sKvSWj8;
HTTP_CONNECTION: keep-alive;
HTTP_ACCEPT_ENCODING: gzip, deflate;
HTTP_ACCEPT_LANGUAGE: en-US,en;q=0.5;
HTTP_ACCEPT: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8;
HTTP_USER_AGENT: Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0;
HTTP_HOST: wekan.test;
REDIRECT_STATUS: 200;
SERVER_NAME: wekan.test;
SERVER_PORT: 80;
SERVER_ADDR: 127.0.0.1;
REMOTE_PORT: 34110;
REMOTE_ADDR: 127.0.0.1;
SERVER_SOFTWARE: nginx/1.18.0;
GATEWAY_INTERFACE: CGI/1.1;
REQUEST_SCHEME: http;
SERVER_PROTOCOL: HTTP/1.1;
DOCUMENT_ROOT: /home/zeus/.valet/Sites/wekan;
DOCUMENT_URI: /track.php;
REQUEST_URI: /track.php;
SCRIPT_NAME: /track.php;
SCRIPT_FILENAME: /home/zeus/.valet/Sites/wekan/track.php;
CONTENT_LENGTH: ;
CONTENT_TYPE: ;
REQUEST_METHOD: GET;
QUERY_STRING: ;
FCGI_ROLE: RESPONDER;
PHP_SELF: /track.php;
REQUEST_TIME_FLOAT: 1608774942.5332;
REQUEST_TIME: 1608774942;
- - - _REQUEST's: 
